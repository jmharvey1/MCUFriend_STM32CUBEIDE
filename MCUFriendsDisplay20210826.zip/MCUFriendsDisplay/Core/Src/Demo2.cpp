/*
 * Demo2.cpp
 *
 *  Created on: Feb 14, 2021
 *      Author: jim
 *       */
/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.cpp
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "main.h"
//#include "usb_device.h"
//#include "usbd_cdc_if.h"
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include "MCUFRIEND_kbv.h"
#include "Adafruit_GFX.h"
#include "STM32F411def.h"
//#include "utility/BlackPill_STM32F411def.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//################################################
// GLUE class that implements the UTFT API
// replace UTFT include and constructor statements
// remove UTFT font declaration e.g. SmallFont
//################################################

#include "UTFTGLUE.h"              //use GLUE class and constructor
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB8|PB9|

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
//I2S_HandleTypeDef hi2s2;
//DMA_HandleTypeDef hdma_i2s2_ext_rx;
//DMA_HandleTypeDef hdma_spi2_tx;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

PCD_HandleTypeDef hpcd_USB_OTG_FS;
unsigned long AvgBias =0;
uint16_t ID;
int toggle = 0;

float sx = 0, sy = 1, mx = 1, my = 0, hx = -1, hy = 0;    // Saved H, M, S x & y multipliers
float sdeg=0, mdeg=0, hdeg=0;
uint16_t osx=120, osy=120, omx=120, omy=120, ohx=120, ohy=120;  // Saved H, M, S x & y coords
uint16_t x00=0, x11=0, y00=0, y11=0;
//uint32_t targetTime = 0;                    // for next 1 second timeout
boolean initial = 1;
char Bufr[14];

static uint8_t conv2d(const char* p) {
  uint8_t v = 0;
  if ('0' <= *p && *p <= '9')
    v = *p - '0';
  return 10 * v + *++p - '0';
}

uint8_t hh=conv2d(__TIME__), mm=conv2d(__TIME__+3), ss=conv2d(__TIME__+6);  // Get H, M, S from compile time

unsigned long millisval = 0;
unsigned long Secruntime =0;
unsigned long LastRanNum =0;
/* Private variables END---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
//static void MX_DMA_Init(void);
//static void MX_I2S2_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
//void Timer_ISR(void);
void delay(int Millis);
int random(int max);
unsigned long millis(void);
void dispMsg(char Msgbuf[32], int cursorX, int cursorY, int FontSz);
MCUFRIEND_kbv tft;
UTFTGLUE myGLCD(0,0,0,0,0,0); //all dummy args
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
//  MX_DMA_Init();
//  MX_I2S2_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim2);
  HAL_TIM_Base_Start(&htim3);
  /*###########################################################################*/
    //                       Begin Arduino SetUp Code

  myGLCD.InitLCD();
  myGLCD.setFont(SmallFont);
/*                         End Arduino SetUp Code                               */
   /*###########################################################################*/


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
	  int buf[478];
	   int x, x2;
	   int y, y2;
	   int r;

	 // Clear the screen and draw the frame
	   myGLCD.clrScr();

	   myGLCD.setColor(255, 0, 0);
	   myGLCD.fillRect(0, 0, 479, 13);
	   myGLCD.setColor(64, 64, 64);
	   myGLCD.fillRect(0, 306, 479, 319);
	   myGLCD.setColor(255, 255, 255);
	   myGLCD.setBackColor(255, 0, 0);
	   myGLCD.print("* Universal Color TFT Display Library *", CENTER, 1);
	   myGLCD.setBackColor(64, 64, 64);
	   myGLCD.setColor(255,255,0);
	   myGLCD.print("<http://www.RinkyDinkElectronics.com/>", CENTER, 307);

	   myGLCD.setColor(0, 0, 255);
	   myGLCD.drawRect(0, 14, 479, 305);

	 // Draw crosshairs
	   myGLCD.setColor(0, 0, 255);
	   myGLCD.setBackColor(0, 0, 0);
	   myGLCD.drawLine(239, 15, 239, 304);
	   myGLCD.drawLine(1, 159, 478, 159);
	   for (int i=9; i<470; i+=10)
	     myGLCD.drawLine(i, 157, i, 161);
	   for (int i=19; i<220; i+=10)
	     myGLCD.drawLine(237, i, 241, i);

	 // Draw sin-, cos- and tan-lines
	   myGLCD.setColor(0,255,255);
	   myGLCD.print("Sin", 5, 15);
	   for (int i=1; i<478; i++)
	   {
	     myGLCD.drawPixel(i,159+(sin(((i*1.13)*3.14)/180)*95));
	   }

	   myGLCD.setColor(255,0,0);
	   myGLCD.print("Cos", 5, 27);
	   for (int i=1; i<478; i++)
	   {
	     myGLCD.drawPixel(i,159+(cos(((i*1.13)*3.14)/180)*95));
	   }

	   myGLCD.setColor(255,255,0);
	   myGLCD.print("Tan", 5, 39);
	   for (int i=1; i<478; i++)
	   {
	     myGLCD.drawPixel(i,159+(tan(((i*1.13)*3.14)/180)));
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);
	   myGLCD.setColor(0, 0, 255);
	   myGLCD.setBackColor(0, 0, 0);
	   myGLCD.drawLine(239, 15, 239, 304);
	   myGLCD.drawLine(1, 159, 478, 159);

	 // Draw a moving sinewave
	   x=1;
	   for (int i=1; i<(478*15); i++)
	   {
	     x++;
	     if (x==479)
	       x=1;
	     if (i>479)
	     {
	       if ((x==239)||(buf[x-1]==159))
	         myGLCD.setColor(0,0,255);
	       else
	         myGLCD.setColor(0,0,0);
	       myGLCD.drawPixel(x,buf[x-1]);
	     }
	     myGLCD.setColor(0,255,255);
	     y=159+(sin(((i*0.7)*3.14)/180)*(90-(i / 100)));
	     myGLCD.drawPixel(x,y);
	     buf[x-1]=y;
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	 // Draw some filled rectangles
	   for (int i=1; i<6; i++)
	   {
	     switch (i)
	     {
	       case 1:
	         myGLCD.setColor(255,0,255);
	         break;
	       case 2:
	         myGLCD.setColor(255,0,0);
	         break;
	       case 3:
	         myGLCD.setColor(0,255,0);
	         break;
	       case 4:
	         myGLCD.setColor(0,0,255);
	         break;
	       case 5:
	         myGLCD.setColor(255,255,0);
	         break;
	     }
	     myGLCD.fillRect(150+(i*20), 70+(i*20), 210+(i*20), 130+(i*20));
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	 // Draw some filled, rounded rectangles
	   for (int i=1; i<6; i++)
	   {
	     switch (i)
	     {
	       case 1:
	         myGLCD.setColor(255,0,255);
	         break;
	       case 2:
	         myGLCD.setColor(255,0,0);
	         break;
	       case 3:
	         myGLCD.setColor(0,255,0);
	         break;
	       case 4:
	         myGLCD.setColor(0,0,255);
	         break;
	       case 5:
	         myGLCD.setColor(255,255,0);
	         break;
	     }
	     myGLCD.fillRoundRect(270-(i*20), 70+(i*20), 330-(i*20), 130+(i*20));
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	 // Draw some filled circles
	   for (int i=1; i<6; i++)
	   {
	     switch (i)
	     {
	       case 1:
	         myGLCD.setColor(255,0,255);
	         break;
	       case 2:
	         myGLCD.setColor(255,0,0);
	         break;
	       case 3:
	         myGLCD.setColor(0,255,0);
	         break;
	       case 4:
	         myGLCD.setColor(0,0,255);
	         break;
	       case 5:
	         myGLCD.setColor(255,255,0);
	         break;
	     }
	     myGLCD.fillCircle(180+(i*20),100+(i*20), 30);
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	 // Draw some lines in a pattern
	   myGLCD.setColor (255,0,0);
	   for (int i=15; i<304; i+=5)
	   {
	     myGLCD.drawLine(1, i, (i*1.6)-10, 304);
	   }
	   myGLCD.setColor (255,0,0);
	   for (int i=304; i>15; i-=5)
	   {
	     myGLCD.drawLine(478, i, (i*1.6)-11, 15);
	   }
	   myGLCD.setColor (0,255,255);
	   for (int i=304; i>15; i-=5)
	   {
	     myGLCD.drawLine(1, i, 491-(i*1.6), 15);
	   }
	   myGLCD.setColor (0,255,255);
	   for (int i=15; i<304; i+=5)
	   {
	     myGLCD.drawLine(478, i, 490-(i*1.6), 304);
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	 // Draw some random circles
	   for (int i=0; i<100; i++)
	   {
	     myGLCD.setColor(random(255), random(255), random(255));
	     x=32+random(416);
	     y=45+random(226);
	     r=random(30);
	     myGLCD.drawCircle(x, y, r);
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	 // Draw some random rectangles
	   for (int i=0; i<100; i++)
	   {
	     myGLCD.setColor(random(255), random(255), random(255));
	     x=2+random(476);
	     y=16+random(289);
	     x2=2+random(476);
	     y2=16+random(289);
	     myGLCD.drawRect(x, y, x2, y2);
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	 // Draw some random rounded rectangles
	   for (int i=0; i<100; i++)
	   {
	     myGLCD.setColor(random(255), random(255), random(255));
	     x=2+random(476);
	     y=16+random(289);
	     x2=2+random(476);
	     y2=16+random(289);
	     myGLCD.drawRoundRect(x, y, x2, y2);
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	   for (int i=0; i<100; i++)
	   {
	     myGLCD.setColor(random(255), random(255), random(255));
	     x=2+random(476);
	     y=16+random(289);
	     x2=2+random(476);
	     y2=16+random(289);
	     myGLCD.drawLine(x, y, x2, y2);
	   }

	   delay(2000);

	   myGLCD.setColor(0,0,0);
	   myGLCD.fillRect(1,15,478,304);

	   for (int i=0; i<10000; i++)
	   {
	     myGLCD.setColor(random(255), random(255), random(255));
	     myGLCD.drawPixel(2+random(476), 16+random(289));
	   }

	   delay(2000);

	   myGLCD.fillScr(0, 0, 255);
	   myGLCD.setColor(255, 0, 0);
	   myGLCD.fillRoundRect(160, 70, 319, 169);

	   myGLCD.setColor(255, 255, 255);
	   myGLCD.setBackColor(255, 0, 0);
	   myGLCD.print("That's it!", CENTER, 93);
	   myGLCD.print("Restarting in a", CENTER, 119);
	   myGLCD.print("few seconds...", CENTER, 132);

	   myGLCD.setColor(0, 255, 0);
	   myGLCD.setBackColor(0, 0, 255);
	   myGLCD.print("Runtime: (msecs)", CENTER, 290);
	   myGLCD.printNumI(millis(), CENTER, 305);

	   delay (10000);
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}
/* ####################         END MAIN LOOP        ##########################*/


//////////////////////////////////////////////////////////////////////
//20210206 JMH Added "delay_us" function to provide a us delay via STM32CubeIDE platform
void delay_us (uint16_t us)
{
	__HAL_TIM_SET_COUNTER(&htim3,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim3) < us);  // wait for the counter to reach the us input in the parameter
}

//////////////////////////////////////////////////////////////////////
void delay(int Millis){
	while(Millis>0){
		delay_us(1000);
		--Millis;
	}
}
//////////////////////////////////////////////////////////////////////
int random(int max){
	int Frctn =0;
	unsigned long curCnt = (3*LastRanNum)+ millis();
	unsigned long Multpl = curCnt/max;
	Frctn = (curCnt-(max*Multpl));
	LastRanNum = Frctn;
	return Frctn;
}

//////////////////////////////////////////////////////////////////////
unsigned long millis(void){
	millisval = (__HAL_TIM_GET_COUNTER(&htim2))/10;
	millisval += 1000*Secruntime;
	return millisval;
}
/////////////////////////////////////////////////////////////////////
void dispMsg(char Msgbuf[32], int cursorX, int cursorY, int FontSz) {
  int msgpntr = 0;
  int curRow = 0;
  int offset =0;
  int fontH = 16;
  int fontW = 18;//12;
  int displayW = 320;
  int cnt = 0;
  while (Msgbuf[msgpntr] != 0) ++msgpntr;

  //clear previous entry
  tft.fillRect(cursorX , (cursorY), msgpntr * fontW, fontH + 10, TFT_LIGHTGREY);
  tft.setCursor(cursorX, cursorY);
  tft.setTextColor(TFT_BLACK);//tft.setTextColor(WHITE, BLACK);
  tft.setTextSize(FontSz);
  msgpntr = 0;
  while ( Msgbuf[msgpntr] != 0) {
    char curChar = Msgbuf[msgpntr];
    tft.print(curChar);
    msgpntr++;
    cnt++;
    if (((cnt) - offset)*fontW >= displayW) {
      curRow++;
      cursorX = 0;
      cursorY = curRow * (fontH + 10);
      offset = cnt;
      tft.setCursor(cursorX, cursorY);
//      if (curRow + 1 > row) {
//        scrollpg();
//      }
    }
    else cursorX = (cnt - offset) * fontW;
  }
}
//////////////////////////////////////////////////////////////////////
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 96;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 12;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
//static void MX_I2S2_Init(void)
//{
//
//  /* USER CODE BEGIN I2S2_Init 0 */
//
//  /* USER CODE END I2S2_Init 0 */
//
//  /* USER CODE BEGIN I2S2_Init 1 */
//
//  /* USER CODE END I2S2_Init 1 */
//  hi2s2.Instance = SPI2;
//  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
//  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
//  hi2s2.Init.DataFormat = I2S_DATAFORMAT_24B;
//  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
//  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_96K;
//  hi2s2.Init.CPOL = I2S_CPOL_LOW;
//  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
//  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_ENABLE;
//  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN I2S2_Init 2 */
//
//  /* USER CODE END I2S2_Init 2 */
//
//}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 9600-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 10000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 96-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USB_OTG_FS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_FS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_FS_Init 0 */

  /* USER CODE END USB_OTG_FS_Init 0 */

  /* USER CODE BEGIN USB_OTG_FS_Init 1 */

  /* USER CODE END USB_OTG_FS_Init 1 */
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_OTG_FS_Init 2 */

  /* USER CODE END USB_OTG_FS_Init 2 */

}

/**
  * Enable DMA controller clock
  */
//static void MX_DMA_Init(void)
//{
//
//  /* DMA controller clock enable */
//  __HAL_RCC_DMA1_CLK_ENABLE();
//
//  /* DMA interrupt init */
//  /* DMA1_Stream3_IRQn interrupt configuration */
//  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
//  /* DMA1_Stream4_IRQn interrupt configuration */
//  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
//
//}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
			|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin
			|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin : LED_Pin */
	GPIO_InitStruct.Pin = LED_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : LCD_D0_Pin LCD_D1_Pin LCD_D2_Pin LCD_D4_Pin
                           LCD_D5_Pin LCD_D6_Pin LCD_D7_Pin */
	GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
			|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : LCD_D3_Pin LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin
                           LCD_CS_Pin LCD_RST_Pin */
	GPIO_InitStruct.Pin = LCD_D3_Pin|LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin
			|LCD_CS_Pin|LCD_RST_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	//HAL_GPIO_TogglePin(,);
	toggle ^= 1;
	Secruntime++;
	//digitalWrite(LED_BUILTIN, toggle);//Arduino call syntax
	if(toggle) PIN_HIGH(LED_GPIO_Port, LED_Pin);
	else PIN_LOW(LED_GPIO_Port, LED_Pin);
	//HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, (GPIO_PinState)toggle);
//	    sprintf(Bufr," Bias: %d", AvgBias );
//	    dispMsg(Bufr, 20, 320, 3);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/




