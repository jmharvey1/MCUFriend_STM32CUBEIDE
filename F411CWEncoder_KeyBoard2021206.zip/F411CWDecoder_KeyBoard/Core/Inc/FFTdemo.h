/*
 * FFTdemo.cpp
 *
 *  Created on: Aug 29, 2021
 *      Author: jim
 */

#ifndef INC_FFTDEMO_CPP_
#define INC_FFTDEMO_CPP_
extern bool RunFFT_DEMO;
void FFTLoop(void);
void FFT_PeriodElapsedCallback(void);


#endif /* INC_FFTDEMO_CPP_ */
