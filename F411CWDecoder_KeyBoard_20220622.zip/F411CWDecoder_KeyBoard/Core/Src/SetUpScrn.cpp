/*
 * SetUpScrn.cpp
 *
 *  Created on: Jun 8, 2022
 *      Author: jim
 */

/*
 * BtnSuprt.cpp
 *
 *  Created on: Mar 26, 2021
 *      Author: jim
 */

/* Includes ------------------------------------------------------------------*/
#include <eeprom.h>
#include "SetUpScrn.h"
#include "KeyBoardR01.h"
#include "TxtNtryBox.h"
#include "STM32F411def.h"
#include "Arduino.h"
#include "SerialClass.h"
#include "MCUFRIEND_kbv.h"
#include "Adafruit_GFX.h"
#include "TouchScreen_kbv.h"
#include "UTFTGLUE.h"              //use GLUE class and constructor

#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF
//#define LED_NO    1

uint16_t KBntry; //used by SetUpScrn.cpp to handle Keyboard entries while user is operating in settings mode
//int px = 0; //mapped 'x' display touch value
//int py = 0;
///*TODO "touch-screen" references need to go away*/
//const int XP=PB7, XM=PA6, YP=PA7, YM=PB6;
//const int TS_LEFT=634,TS_RT=399,TS_TOP=492,TS_BOT=522;
//TouchScreen_kbv ts(XP, YP, XM, YM, 300);
//TSPoint_kbv tp;//TODO Needs to go away
//int PrgmNdx = 0;//TODO Needs to go away

int16_t scrnHeight = tft.height();
int16_t scrnWidth= tft.width();

/*  Added for buttons support */
char textMsg[51];
int tchcnt =0;// needed global variable for read/detect button support
bool BlkIntrpt = false; // needed global variable for read/detect button support
int btnPrsdCnt = 0; // needed global variable for read/detect button support
const int fontH = 16;// needed global variable for read/detect button support
const int fontW = 12;// needed global variable for read/detect button support
bool buttonEnabled = true; // needed global variable for read/detect button support
int value; // needed global variable for debugging button support
bool FrstTime = true; // needed global variable for readResistiveTouch() function
/* Begin Button Definitions */
int loopcnt;
int btnHght = 40;
int btnWdthS = 80;
int btnWdthL = 2*btnWdthS;
int row0;
int row1;
int row2;
int row3;
int row4;
int col0 = 0;
int col1 = btnWdthS+1;
int col2 = col1 + btnWdthS+1;
int col3 = col2+ btnWdthS+1;
int col4 = col3+ btnWdthS+1;
int col5 = col4+ btnWdthS+1;
char BtnCaptn[14];
char BtnCaptn1[14];
char BtnCaptn2[14];
char BtnCaptn3[14];
BtnParams SetUpBtns[19]; //currently the Setup screen has 19 buttons
bool SetScrnActv;
//SerialClass Serial;//this object is declared/created in the USBHost library
uint16_t adc_buf[ ADC_BUF_LEN];//TODO get rid of this
bool Test;//TODO get rid of this
bool TonPltFlg;//TODO get rid of this
int TonSig = 1;//TODO get rid of this
volatile unsigned long LpCnt =0;//TODO get rid of this
//struct BtnParams MycallBxsettings;


/* End Button Definitions */

ADC_HandleTypeDef OLDhadc1;
ADC_ChannelConfTypeDef OLDsConfig;
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* USER CODE BEGIN PFP */
//TouchScreen_kbv ts(XP, YP, XM, YM, 300);
//TSPoint_kbv tp; //global point
template <class T>
int EEPROM_write(uint16_t ee, const T& value)
{
   //const byte* p = (const byte*)(const void*)&value;
   const uint16_t* p = (const uint16_t*)(const void*)&value;
   int i=0;
   while (i < sizeof(value)){
       //EEPROM.write(ee++, *p++);
	   EE_WriteVariable(ee, *p);
   	   ee +=2;
   	   i +=2;
   	   p++;// +=2;
   }
   return i;
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  Button entry point.
  * @retval int
  */
//////////////////////////////////////////////////////////////////////////
void BldButtons(void){
//	row0 = scrnHeight - (btnHght + 5);
//	row1 = scrnHeight - (2*btnHght + 5);
//	row2 = scrnHeight - (3*btnHght + 5);
//	row3 = scrnHeight - (4*btnHght + 5);
//	row4 = scrnHeight - (5*btnHght + 5);
//	//Exit Button 0
//	SetUpBtns[0].BtnXpos = col2;//130;  //Button X position
//	SetUpBtns[0].BtnWdth = btnWdthS;//80;  //Button Width
//	SetUpBtns[0].BtnHght =btnHght;
//	SetUpBtns[0].BtnYpos = row0;// scrnHeight - (SetUpBtns[0].BtnHght + 5);  //Button Y position
//	SetUpBtns[0].Captn = "Exit";
//	SetUpBtns[0].BtnClr = YELLOW;
//	SetUpBtns[0].TxtClr = WHITE;
//	//  Save Button position parameters
//	SetUpBtns[1].BtnXpos = col3;//SetUpBtns[0].BtnXpos+ SetUpBtns[0].BtnWdth+1;  //Button X position
//	SetUpBtns[1].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
//	SetUpBtns[1].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
//	SetUpBtns[1].BtnYpos = row0;//SetUpBtns[0].BtnYpos;  //Button Y position
//	SetUpBtns[1].Captn = "Save";
//	SetUpBtns[1].BtnClr = GREEN;
//	SetUpBtns[1].TxtClr = WHITE;
//
//	//IncFreq Button parameters Button 2
//	SetUpBtns[2].BtnXpos = col4;//SetUpBtns[1].BtnXpos+SetUpBtns[1].BtnWdth+1;  //Button X position
//	SetUpBtns[2].BtnWdth = 80;  //Button Width
//	SetUpBtns[2].BtnHght = 40;
//	SetUpBtns[2].BtnYpos = row1;//scrnHeight - (SetUpBtns[0].BtnHght + SetUpBtns[2].BtnHght + 5);  //Button Y position
//	//SetUpBtns[2].Captn = "SMPL+";
//	SetUpBtns[2].Captn = "Freq+";
//	SetUpBtns[2].BtnClr = BLUE;
//	SetUpBtns[2].TxtClr = WHITE;
//
//	//DecFreq Button parameters Button 3
//	SetUpBtns[3].BtnXpos = col1;//SetUpBtns[0].BtnXpos-(80+1);  //Button X position
//	SetUpBtns[3].BtnWdth = 80;  //Button Width
//	SetUpBtns[3].BtnHght = 40;
//	SetUpBtns[3].BtnYpos = row1;//scrnHeight - (SetUpBtns[0].BtnHght+SetUpBtns[3].BtnHght + 5);  //Button Y position
//	//SetUpBtns[3].Captn = "SMPL-";
//	SetUpBtns[3].Captn = "Freq-";
//	SetUpBtns[3].BtnClr = BLUE;
//	SetUpBtns[3].TxtClr = WHITE;
//
//	//IncLED Button parameters Button 4
//	SetUpBtns[4].BtnXpos = col5;//SetUpBtns[2].BtnXpos+SetUpBtns[2].BtnWdth+1;  //Button X position
//	SetUpBtns[4].BtnWdth = 80;  //Button Width
//	SetUpBtns[4].BtnHght = 40;
//	SetUpBtns[4].BtnYpos = row2;//SetUpBtns[2].BtnYpos-SetUpBtns[4].BtnHght;  //Button Y position
//	SetUpBtns[4].Captn = "LED +";
//	SetUpBtns[4].BtnClr = BLUE;
//	SetUpBtns[4].TxtClr = WHITE;
//
//	//DecLED Button parameters  Button 5
//	SetUpBtns[5].BtnXpos = col0;//SetUpBtns[0].BtnXpos-((2*80)+1);  //Button X position
//	SetUpBtns[5].BtnWdth = 80;  //Button Width
//	SetUpBtns[5].BtnHght = 40;
//	SetUpBtns[5].BtnYpos = row2;//SetUpBtns[2].BtnYpos-SetUpBtns[5].BtnHght;  //Button Y position
//	SetUpBtns[5].Captn = "LED -";
//	SetUpBtns[5].BtnClr = BLUE;
//	SetUpBtns[5].TxtClr = WHITE;
//
//	//IncTone Scale Factor Button Position parameters Button 6
//	SetUpBtns[6].BtnXpos = col5;//SetUpBtns[4].BtnXpos;  //Button X position
//	SetUpBtns[6].BtnWdth = 80;  //Button Width
//	SetUpBtns[6].BtnHght = 40;
//	SetUpBtns[6].BtnYpos = row3;//SetUpBtns[5].BtnYpos-SetUpBtns[6].BtnHght;  //Button Y position
//	SetUpBtns[6].Captn = "TSF +";
//	SetUpBtns[6].BtnClr = RED;
//	SetUpBtns[6].TxtClr = WHITE;
//
//
//
//	//DecTone Scale Factor Button Position  parameters Button 7
//	SetUpBtns[7].BtnXpos = col0;//SetUpBtns[5].BtnXpos;  //Button X position
//	SetUpBtns[7].BtnWdth = 80;  //Button Width
//	SetUpBtns[7].BtnHght = 40;
//	SetUpBtns[7].BtnYpos = row3;//SetUpBtns[4].BtnYpos - SetUpBtns[7].BtnHght;  //Button Y position
//	SetUpBtns[7].Captn = "TSF -";
//	SetUpBtns[7].BtnClr = RED;
//	SetUpBtns[7].TxtClr = WHITE;
//
//
//	//IncNoise Scale Factor Button Position parameters Button 8
//	SetUpBtns[8].BtnWdth = 80;  //Button Width
//	SetUpBtns[8].BtnHght = 40;
//	SetUpBtns[8].BtnXpos = col4;//SetUpBtns[6].BtnXpos-(SetUpBtns[8].BtnWdth+1);  //Button X position
//	SetUpBtns[8].BtnYpos = row3;//SetUpBtns[4].BtnYpos-SetUpBtns[8].BtnHght;  //Button Y position
//	SetUpBtns[8].Captn = "NSF +";
//	SetUpBtns[8].BtnClr = RED;
//	SetUpBtns[8].TxtClr = WHITE;
//
//	//DecNoise Scale Factor Button Position  parameters Button 9
//	SetUpBtns[9].BtnWdth = 80;  //Button Width
//	SetUpBtns[9].BtnHght = 40;
//	SetUpBtns[9].BtnXpos = col1;//SetUpBtns[7].BtnXpos+(SetUpBtns[7].BtnWdth+1);  //Button X position
//	SetUpBtns[9].BtnYpos = row3;//SetUpBtns[4].BtnYpos-SetUpBtns[9].BtnHght;  //Button Y position
//	SetUpBtns[9].Captn = "NSF -";
//	SetUpBtns[9].BtnClr = RED;
//	SetUpBtns[9].TxtClr = WHITE;
//
//	//IncBIAS Button parameters Button 10
//	SetUpBtns[10].BtnXpos = col5;  //Button X position
//	SetUpBtns[10].BtnWdth = btnWdthS;  //Button Width
//	SetUpBtns[10].BtnHght = btnHght;
//	SetUpBtns[10].BtnYpos = row4;  //Button Y position
//	SetUpBtns[10].Captn = "BIAS+";
//	SetUpBtns[10].BtnClr = YELLOW;
//	SetUpBtns[10].TxtClr = WHITE;
//
//	//DecBIAS Button parameters Button 11
//	SetUpBtns[11].BtnXpos = col0;  //Button X position
//	SetUpBtns[11].BtnWdth = btnWdthS;  //Button Width
//	SetUpBtns[11].BtnHght = btnHght;
//	SetUpBtns[11].BtnYpos = row4;  //Button Y position
//	SetUpBtns[11].Captn = "BIAS-";
//	SetUpBtns[11].BtnClr = YELLOW;
//	SetUpBtns[11].TxtClr = WHITE;
//
//	//IncSQLCH Button parameters Button 12
//	SetUpBtns[12].BtnXpos = col4;  //Button X position
//	SetUpBtns[12].BtnWdth = btnWdthS;  //Button Width
//	SetUpBtns[12].BtnHght = btnHght;
//	SetUpBtns[12].BtnYpos = row4;  //Button Y position
//	SetUpBtns[12].Captn = "MSQL+";
//	SetUpBtns[12].BtnClr = MAGENTA;
//	SetUpBtns[12].TxtClr = WHITE;
//
//	//DecSQLCH Button parameters Button 13
//	SetUpBtns[13].BtnXpos = col1;  //Button X position
//	SetUpBtns[13].BtnWdth = btnWdthS;  //Button Width
//	SetUpBtns[13].BtnHght = btnHght;
//	SetUpBtns[13].BtnYpos = row4;  //Button Y position
//	SetUpBtns[13].Captn = "MSQL-";
//	SetUpBtns[13].BtnClr = MAGENTA;
//	SetUpBtns[13].TxtClr = WHITE;
//
//	if (NoiseSqlch) sprintf(BtnCaptn1, "NOISE SQLCH");
//	else sprintf(BtnCaptn1, " MAN SQLCH");
//	//SqMode Button parameters Button 14
//	SetUpBtns[14].BtnXpos = col2;  //Button X position
//	SetUpBtns[14].BtnWdth = btnWdthL;  //Button Width
//	SetUpBtns[14].BtnHght = btnHght;
//	SetUpBtns[14].BtnYpos = row4;  //Button Y position
//	SetUpBtns[14].Captn = BtnCaptn1;
//	SetUpBtns[14].BtnClr = MAGENTA;
//	SetUpBtns[14].TxtClr = WHITE;
//
//	//Dfault Button parameters Button 15
//	SetUpBtns[15].BtnXpos = col2;  //Button X position
//	SetUpBtns[15].BtnWdth = btnWdthL;  //Button Width
//	SetUpBtns[15].BtnHght = btnHght;
//	SetUpBtns[15].BtnYpos = row3;  //Button Y position
//	SetUpBtns[15].Captn = "FACTORY VALS";
//	SetUpBtns[15].BtnClr = GREEN;
//	SetUpBtns[15].TxtClr = WHITE;
//
//
//	//DeBug Button parameters Button 16
//	SetDBgCptn(BtnCaptn);
//	SetUpBtns[16].BtnXpos = col2;  //Button X position
//	SetUpBtns[16].BtnWdth = btnWdthL;  //Button Width
//	SetUpBtns[16].BtnHght = btnHght;
//	SetUpBtns[16].BtnYpos = row2;  //Button Y position
//	SetUpBtns[16].Captn = BtnCaptn;
//	SetUpBtns[16].BtnClr = MAGENTA;
//	SetUpBtns[16].TxtClr = WHITE;
//
//	//Freq Mode Button parameters Button 17
//	if (AutoTune) sprintf(BtnCaptn2, " AUTO TUNE");
//	else sprintf(BtnCaptn2, "FREQ LOCKED");
//	SetUpBtns[17].BtnXpos = col2;  //Button X position
//	SetUpBtns[17].BtnWdth = btnWdthL;  //Button Width
//	SetUpBtns[17].BtnHght = btnHght;
//	SetUpBtns[17].BtnYpos = row1;  //Button Y position
//	SetUpBtns[17].Captn = BtnCaptn2;
//	SetUpBtns[17].BtnClr = RED;
//	SetUpBtns[17].TxtClr = WHITE;
//
//	//  Program Select Button position parameters
//	SetPrgmCptn(BtnCaptn3);
//	SetUpBtns[18].BtnXpos = col1;//
//	SetUpBtns[18].BtnWdth = btnWdthS;
//	SetUpBtns[18].BtnHght = btnHght;
//	SetUpBtns[18].BtnYpos = row0;
//	SetUpBtns[18].Captn = BtnCaptn3; //"CW";
//	SetUpBtns[18].BtnClr = TFT_ORANGE;
//	SetUpBtns[18].TxtClr = TFT_BLACK;
//
//	enableDisplay();// not needed with NoTouch display
//	tft.fillScreen(BLACK);
//	tft.fillScreen(BLACK);// need to call this twice, to ensure full erasure of old display

//	for(int i=0; i<19; i++){
//		BldBtn(i, SetUpBtns); // Build the SetUp Button Set
//	}

}
//////////////////////////////////////////////////////////////////////////
/* This is for external calls to the BtnSuprt code to test a special button set or group */
//int ReadBtns(void){
//	readResistiveTouch();
//	if (tp.z > 150) { // if (tp.z > MINPRESSURE && tp.z < MAXPRESSURE) { //
//		//use the following for Screen orientation set to 1
//		py = map(tp.y, TS_TOP, TS_BOT, 0, scrnHeight);
//		px = map(tp.x, TS_LEFT, TS_RT, 0, scrnWidth);
//		/* original code */
////		py = map(tp.x, 890, 116, 0, 320);
////		px = map(tp.y, 100, 950, 0, 480);
//		/* Un-comment diagnostic test/verification of screen touch coordinates */
////		sprintf( textMsg, "px: %d", px);
////		ShwData(5, 30, textMsg);
////		sprintf( textMsg, "py: %d", py);
////		ShwData(5, 55, textMsg);
////		delay(200);
//
//	}else{
//		py=-10;
//		px=-10;
//		buttonEnabled = true; //set true here just for this demo code;
//		//normally a completed action would set this back to true
//	}
//
//	if (BtnActive(2, SetUpBtns, px, py)){
//		// Inc Feq button was pressed
//		RptActvBtn(strdup("Inc Freq"));
//		loopcnt =0;
//		return 1;
//	}
//
//	if (BtnActive(3, SetUpBtns, px, py)){
//		// Dec Feq button was pressed
//		RptActvBtn(strdup("Dec Freq"));
//		loopcnt =0;
//		return 2;
//	}
//	RptActvBtn(strdup(""));
//	return 0;
//}
//////////////////////////////////////////////////////////////////////////

void setuploop(void){
//	loopcnt = 100;
//	py = 0;
//	px = 0;
//	tchcnt = 100;
//	BldButtons();//clear current display
	tft.fillScreen(BLACK);
	tft.fillScreen(BLACK);// need to call this twice, to ensure full erasure of old display
	const int paramCnt = 6;// Total number of parameters/settings that can be edited on this screen
	TxtNtryBox NtryBoxGrp[paramCnt];
	const char CallBtnCaptn[9] = {'M', 'y', ' ', 'C', 'a', 'l', 'l', ':'};
	const char *CaptnPtr = CallBtnCaptn;
	struct BtnParams MycallBxsettings;
	int curRow = 0;
    MycallBxsettings.BtnXpos = 0;  //Button X position
	MycallBxsettings.BtnWdth = 80;  //Button Width
	MycallBxsettings.BtnYpos = curRow;  //Button X position
	MycallBxsettings.BtnHght = 15;  //Button Height
	MycallBxsettings.Captn = CaptnPtr;
	MycallBxsettings.BtnClr = TFT_GREEN;
	MycallBxsettings.TxtClr = TFT_WHITE;
	MycallBxsettings.IsNumbr = false;
	MycallBxsettings.BxIndx = 0;
	NtryBoxGrp[MycallBxsettings.BxIndx].InitBox(MycallBxsettings);
	NtryBoxGrp[MycallBxsettings.BxIndx].SetValue(MyCall, sizeof(MyCall));

	const char WPMBtnCaptn[5] = {'W', 'P', 'M', ':'};
	const char *WPMCaptnPtr = WPMBtnCaptn;
	struct BtnParams WPMBxsettings;
	curRow += fontH+6;
    WPMBxsettings.BtnXpos = 0;  //Button X position
	WPMBxsettings.BtnWdth = 80;  //Button Width
	WPMBxsettings.BtnYpos = curRow;  //Button X position
	WPMBxsettings.BtnHght = 15;  //Button Height
	WPMBxsettings.Captn = WPMCaptnPtr;
	WPMBxsettings.BtnClr = TFT_GREEN;
	WPMBxsettings.TxtClr = TFT_WHITE;
	WPMBxsettings.IsNumbr = true;
	WPMBxsettings.BxIndx = 1;

	/*Convert WPM int parameter to character*/
	char WPM_char[2 + sizeof(char)];
    sprintf(WPM_char, "%d", DFault.WPM);
    NtryBoxGrp[WPMBxsettings.BxIndx].InitBox(WPMBxsettings);
    NtryBoxGrp[WPMBxsettings.BxIndx].SetValue(WPM_char, sizeof(WPM_char));

	const char MemF2BtnCaptn[11] = {'M', 'e', 'm', 'o', 'r', 'y', ' ', 'F', '2', ':'};
	const char *MF2CaptnPtr = MemF2BtnCaptn;
	struct BtnParams MemF2Bxsettings;
	curRow += fontH+6;
    MemF2Bxsettings.BtnXpos = 0;  //Button X position
	MemF2Bxsettings.BtnWdth = 80;  //Button Width
	MemF2Bxsettings.BtnYpos = curRow;  //Button X position
	MemF2Bxsettings.BtnHght = 15;  //Button Height
	MemF2Bxsettings.Captn = MF2CaptnPtr;
	MemF2Bxsettings.BtnClr = TFT_GREEN;
	MemF2Bxsettings.TxtClr = TFT_WHITE;
	MemF2Bxsettings.IsNumbr = false;
	MemF2Bxsettings.BxIndx = 2;
	NtryBoxGrp[MemF2Bxsettings.BxIndx].InitBox(MemF2Bxsettings);
	NtryBoxGrp[MemF2Bxsettings.BxIndx].SetValue(MemF2, sizeof(MemF2));

	const char DBugOFFBtnCaptn[10] = {'D', 'E', 'B', 'U', 'G', ' ', 'O', 'F', 'F'};
	const char DBugONBtnCaptn[10] = {'D', 'E', 'B', 'U', 'G', ' ', 'O', 'N'};
	const char *DBugCaptnPtr[2];
	DBugCaptnPtr[0] = DBugOFFBtnCaptn;
	DBugCaptnPtr[1] = DBugONBtnCaptn;
	struct BtnParams DBugBxsettings;
	curRow += 2*(fontH+6);
	int BtnWdth = 125;
    DBugBxsettings.BtnXpos = 0*BtnWdth;  //Button X position
	DBugBxsettings.BtnWdth = BtnWdth;  //Button Width
	DBugBxsettings.BtnYpos = curRow;  //Button X position
	DBugBxsettings.BtnHght = 38;  //Button Height
	DBugBxsettings.Captn = DBugCaptnPtr[DFault.DeBug];
	DBugBxsettings.BtnClr = TFT_GREEN;
	DBugBxsettings.TxtClr = TFT_WHITE;
	DBugBxsettings.IsNumbr = false;
	DBugBxsettings.BxIndx = 3;
	DBugBxsettings.Option = DFault.DeBug;
	NtryBoxGrp[DBugBxsettings.BxIndx].InitBox(DBugBxsettings);
	char Null[] = {' '};
	NtryBoxGrp[DBugBxsettings.BxIndx].SetValue(Null, 0);

	BtnWdth = 70;
	const char SaveBtnCaptn[5] = {'S', 'A', 'V', 'E'};
	const char *SaveCaptnPtr = SaveBtnCaptn;
	struct BtnParams SaveBxsettings;
	curRow += fontH+24;
    SaveBxsettings.BtnXpos = 0*BtnWdth;  //Button X position
	SaveBxsettings.BtnWdth = BtnWdth;  //Button Width
	SaveBxsettings.BtnYpos = curRow;  //Button X position
	SaveBxsettings.BtnHght = 38;  //Button Height
	SaveBxsettings.Captn = SaveCaptnPtr;
	SaveBxsettings.BtnClr = TFT_GREEN;
	SaveBxsettings.TxtClr = TFT_WHITE;
	SaveBxsettings.IsNumbr = false;
	SaveBxsettings.BxIndx = 4;
	NtryBoxGrp[SaveBxsettings.BxIndx].InitBox(SaveBxsettings);
	//char Null[] = {' '};
	NtryBoxGrp[SaveBxsettings.BxIndx].SetValue(Null, 0);

	const char ExitBtnCaptn[5] = {'E', 'X', 'I', 'T'};
	const char *ExitCaptnPtr = ExitBtnCaptn;
	struct BtnParams ExitBxsettings;
    ExitBxsettings.BtnXpos = 1*BtnWdth;  //Button X position
	ExitBxsettings.BtnWdth = BtnWdth;  //Button Width
	ExitBxsettings.BtnYpos = curRow;  //Button X position
	ExitBxsettings.BtnHght = 38;  //Button Height
	ExitBxsettings.Captn = ExitCaptnPtr;
	ExitBxsettings.BtnClr = TFT_GREEN;
	ExitBxsettings.TxtClr = TFT_WHITE;
	ExitBxsettings.IsNumbr = false;
	ExitBxsettings.BxIndx = 5;
	NtryBoxGrp[ExitBxsettings.BxIndx].InitBox(ExitBxsettings);
	NtryBoxGrp[ExitBxsettings.BxIndx].SetValue(Null, 0);


    delay(250);
	SetScrnActv = true;
	int NdxPtr = 0;//pointer to the active character in the Value array for the parameter currently in "FOCUS"
	int paramPtr = 0;//Pointer to current parameter that has "FOCUS"

	bool FocusChngd = true;
	while(setupFlg){ // run inside this loop until user exits setup mode
		delay(4);
		LpCnt++;
		Usb.Task();//Check the keyboard, & process new key strokes
		/*Test if user wants to change/move the "focus" to another parameter/setting*/
		if(KBntry == 0x52){//Arrow UP
			KBntry = 0;
			NtryBoxGrp[paramPtr].KillCsr();
			paramPtr++;
			FocusChngd = true;
		}else if(KBntry == 0x51){//Arrow DOWN
			KBntry = 0;
			NtryBoxGrp[paramPtr].KillCsr();
			paramPtr--;
			FocusChngd = true;
		}
		if(paramPtr == paramCnt) paramPtr =0;
		if(paramPtr <0 ) paramPtr =paramCnt-1;
		int len = NtryBoxGrp[paramPtr].GetValLen();
		char *value = Null;
		if(len>0) value = NtryBoxGrp[paramPtr].GetValue();

		if(FocusChngd){
			FocusChngd = false;
			NtryBoxGrp[paramPtr].ShwCsr(0);
			NdxPtr = 0;
		}
		if(KBntry == 0x4F){//Right Arrow Key => Move Cursor Right
			KBntry = 0;
			if(NtryBoxGrp[paramPtr].BxIndx == DBugBxsettings.BxIndx){//"DeBug" button has Focus
				/*Set DeBug to ON*/
				DFault.DeBug = 1;
				NtryBoxGrp[DBugBxsettings.BxIndx].Option = DFault.DeBug;
				NtryBoxGrp[DBugBxsettings.BxIndx].UpDateCaptn((char*)DBugCaptnPtr[DFault.DeBug]);

			}else{
				NdxPtr++;
				if(NdxPtr == len) NdxPtr--;
				/*the following two cases should never happen, but check/fix anyway */
				if(value[NdxPtr] == 0){
					NdxPtr--;
				}
				if(NdxPtr < 0) NdxPtr= 0;
				NtryBoxGrp[paramPtr].ShwCsr(NdxPtr);
			}
		}else if(KBntry == 0x50){//Left Arrow Key  => Move Cursor Left
			KBntry = 0;
			if(NtryBoxGrp[paramPtr].BxIndx == DBugBxsettings.BxIndx){//"DeBug" button has Focus
				/*Set DeBug to OFF*/
				DFault.DeBug = 0;
				NtryBoxGrp[DBugBxsettings.BxIndx].Option = DFault.DeBug;
				NtryBoxGrp[DBugBxsettings.BxIndx].UpDateCaptn((char*)DBugCaptnPtr[DFault.DeBug]);
			}else{
				NdxPtr--;
				if(NdxPtr <0) NdxPtr++;
				NtryBoxGrp[paramPtr].ShwCsr(NdxPtr);
			}
		}else if((KBntry ==0x28)){ // "ENTER" Key
			KBntry = 0;
			if(NtryBoxGrp[paramPtr].GetValLen()== 0){ //len ==0; this a "choice" parameter & user wants to "select" the current "option"
				if(NtryBoxGrp[paramPtr].BxIndx == ExitBxsettings.BxIndx){//"Exit" button
					setupFlg = false;
				}else if(NtryBoxGrp[paramPtr].BxIndx == SaveBxsettings.BxIndx){//"Save" button
					//Save current Parameters to EEPROM;
					NtryBoxGrp[paramPtr].ShwBGColor(TFT_BLUE);
					/* Collect current MyCall value from Parameters/setting Screen */
					char *value =NtryBoxGrp[MycallBxsettings.BxIndx].GetValue();
					int len =NtryBoxGrp[MycallBxsettings.BxIndx].GetValLen();
					for(int i = 0; i<len; i++){
						MyCall[i] = value[i];
					}
					/* Collect current WPM value from Parameters/setting Screen */
					value =NtryBoxGrp[WPMBxsettings.BxIndx].GetValue();
					len = NtryBoxGrp[WPMBxsettings.BxIndx].GetValLen();
					/*recover WPM value (an integer from a character array*/
					int intVal =0;
					for(int i = 0; i<len; i++){
						if(value[i]>0) intVal = (i*10*intVal)+(value[i] - '0');
					}
					DFault.WPM = intVal;
					/* Collect current Debug option/mode from Parameters/setting Screen */
					DFault.DeBug = NtryBoxGrp[DBugBxsettings.BxIndx].Option;
					SaveUsrVals();
					delay(500);
					NtryBoxGrp[paramPtr].ShwCsr(0);
				} else if(NtryBoxGrp[paramPtr].BxIndx == DBugBxsettings.BxIndx){//"DeBug" button has Focus
					/*Swap DeBug state (ON to OFF; OFF to ON)*/
					if(DFault.DeBug) DFault.DeBug = 0;
					else DFault.DeBug = 1;
					NtryBoxGrp[DBugBxsettings.BxIndx].Option = DFault.DeBug;
					NtryBoxGrp[DBugBxsettings.BxIndx].UpDateCaptn((char*)DBugCaptnPtr[DFault.DeBug]);
				}
			}else{// process "Enter" key as a "text" parameter input
				for(int i=NdxPtr; i<len; i++){
					value[i] = 0;//MyCall[i] = 0;
				}
				NdxPtr = 0;
				NtryBoxGrp[paramPtr].SetValue(value, len);
				NtryBoxGrp[paramPtr].ShwCsr(NdxPtr);
			}
		}else if((KBntry ==0x2A)){ // "BACKSpace" Key
			KBntry = 0;
			if(NdxPtr > 0){ // Skip if Pointer already at 0 position
				NdxPtr--;
				/*replace character at the current position by moving the
				 * remaining characters right of this position one place left.*/
				for(int i=NdxPtr; i<(len-1); i++){
					value[i] = value[i+1];
					NtryBoxGrp[paramPtr].UpDateValue(i, NdxPtr);
				}
				if(value[len-1]!= 0){
					value[len-1] = 0;
					NtryBoxGrp[paramPtr].UpDateValue(len-1, NdxPtr);
				}
			}
		}else if((KBntry ==0x4C)){ // "DELETE" Key
			KBntry = 0;

			for(int i=NdxPtr; i<(len-1); i++){//delete character at the current position by moving the remaining characters right of this position one place left.
				value[i] = value[i+1];
				NtryBoxGrp[paramPtr].UpDateValue(i, NdxPtr);
			}
			/*Now check test special case where array is completely full*/
			if(value[len-1]!= 0){
				value[len-1] = 0;
				NtryBoxGrp[paramPtr].UpDateValue(len-1, NdxPtr);
			}
		}
		if(KBntry >=200){//Key Entry is a regular ASCII character
			KBntry = KBntry -200;
			char AsciiVal = (char)KBntry;
			/*test if current parameter is a numeric box/button*/
			if(NtryBoxGrp[paramPtr].IsNumbr){
				if((AsciiVal>='0') && (AsciiVal<='9')){
					if(NdxPtr<NtryBoxGrp[paramPtr].ValueLen) value[NdxPtr] = AsciiVal;
					NdxPtr++;
					if(NdxPtr>=(NtryBoxGrp[paramPtr].ValueLen-1)){
						NdxPtr--;
						NtryBoxGrp[paramPtr].UpDateValue(NdxPtr, NdxPtr);
					} else NtryBoxGrp[paramPtr].UpDateValue(NdxPtr-1, NdxPtr);
				}
			}else {
				int charPos = NdxPtr;
				value[charPos] = AsciiVal;//insert new key entry into this parameter's value array
				NdxPtr++;
				if(NdxPtr == len) NdxPtr--;
				NtryBoxGrp[paramPtr].UpDateValue(charPos, NdxPtr);//refresh the settings screen
			}
			KBntry = 0; // need this here; Otherwise on next while loop pass "KBntry" could evaluate to a special character; i.e. "up arrow"
		}

	}//End While Loop
	//Transfer modified button values back to their respective variables/parameters
	/* Collect current MyCall value from Parameters/setting Screen */
	char *value =NtryBoxGrp[MycallBxsettings.BxIndx].GetValue();
	int len =NtryBoxGrp[MycallBxsettings.BxIndx].GetValLen();
	for(int i = 0; i<len; i++){
		MyCall[i] = value[i];
	}
	value =NtryBoxGrp[MemF2Bxsettings.BxIndx].GetValue();
	len =NtryBoxGrp[MemF2Bxsettings.BxIndx].GetValLen();
	for(int i = 0; i<len; i++){
		MemF2[i] = value[i];
	}

	/* Collect current WPM value from Parameters/setting Screen */
	value =NtryBoxGrp[WPMBxsettings.BxIndx].GetValue();
	len = NtryBoxGrp[WPMBxsettings.BxIndx].GetValLen();
	/*recover WPM value (an integer from a character array*/
	int intVal =0;
	for(int i = 0; i<len; i++){
		if(value[i]>0) intVal = (i*10*intVal)+(value[i] - '0');
	}
	DFault.WPM = intVal;
	CWsndengn.SetWPM(DFault.WPM);
	/* Collect current Debug option/mode from Parameters/setting Screen */
	DFault.DeBug = NtryBoxGrp[DBugBxsettings.BxIndx].Option;
	DeBug = DFault.DeBug;
	return;
}//end of SetUp Loop

//////////////////////////////////////////////////////////////////////////
void LdFactryVals(void){//TODO Needs works; the "factory" values are being overwritten, by other routines
	for(int i = 0; i<sizeof(MyCall);i++){
		DFault.MyCall[i] = MyCall[i];
		}
	DFault.WPM = CWsndengn.GetWPM() ;
	DFault.DeBug = DeBug;
}
//////////////////////////////////////////////////////////////////////////
void SaveUsrVals(void){
	/* Unlock the Flash Program Erase controller */
	char buf[30];
	FLASH_Unlock();
	/* EEPROM Init */
	uint16_t reslt = EE_Init();
	if (reslt != fLASH_COMPLETE){
		sprintf(buf, "EE_Init() ERROR: %d", reslt);
		tftmsgbx.dispMsg(buf, TFT_RED);
		while(1);
	}

	int	n;
	int offset = 0;

	for(int i = 0; i < sizeof(MyCall); i++){
		n = EEPROM_write(EEaddress+(offset), MyCall[i]);
		offset += 2*n;
	}
	for(int i = 0; i < sizeof(MemF2); i++){
		n = EEPROM_write(EEaddress+(offset), MemF2[i]);
		offset += 2*n;
	}
	n = EEPROM_write(EEaddress+(offset), DFault.WPM);
	offset += 2*n;
	n= EEPROM_write(EEaddress+offset, DFault.DeBug);




	FLASH_Lock();
	sprintf(buf, "User Params SAVED");
	tftmsgbx.dispStat(buf, TFT_GREEN);
}




