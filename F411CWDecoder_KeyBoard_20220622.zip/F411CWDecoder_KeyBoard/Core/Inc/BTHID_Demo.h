/*
 * BTHID_Demo.h
 *
 *  Created on: Sep 21, 2021
 *      Author: jim
 */

#ifndef INC_BTHID_DEMO_H_
#define INC_BTHID_DEMO_H_

void dispMsg(char Msgbuf[50], uint16_t Color);



#endif /* INC_BTHID_DEMO_H_ */
