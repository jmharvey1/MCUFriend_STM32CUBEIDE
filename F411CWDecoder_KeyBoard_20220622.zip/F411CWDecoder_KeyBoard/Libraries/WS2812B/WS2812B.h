/*
 * WS2812B.h
 *
 *  Created on: Mar 19, 2021
 *      Author: jim
 */

#ifndef WS2812B_H_
#define WS2812B_H_


#include <stdbool.h>
#include "main.h"
/* Encoder Map; A WS2812B bit value takes 4 SPI Bytes to send  */
const uint8_t leddata[256*4] = { // size = 256 * 4
0X44 , 0X44 , 0X44 , 0X44 , // 0
0X44 , 0X44 , 0X44 , 0X47 , // 1
0X44 , 0X44 , 0X44 , 0X74 ,
0X44 , 0X44 , 0X44 , 0X77 ,
0X44 , 0X44 , 0X47 , 0X44 ,
0X44 , 0X44 , 0X47 , 0X47 ,
0X44 , 0X44 , 0X47 , 0X74 ,
0X44 , 0X44 , 0X47 , 0X77 ,
0X44 , 0X44 , 0X74 , 0X44 ,
0X44 , 0X44 , 0X74 , 0X47 ,
0X44 , 0X44 , 0X74 , 0X74 ,
0X44 , 0X44 , 0X74 , 0X77 ,
0X44 , 0X44 , 0X77 , 0X44 ,
0X44 , 0X44 , 0X77 , 0X47 ,
0X44 , 0X44 , 0X77 , 0X74 ,
0X44 , 0X44 , 0X77 , 0X77 ,
0X44 , 0X47 , 0X44 , 0X44 ,
0X44 , 0X47 , 0X44 , 0X47 ,
0X44 , 0X47 , 0X44 , 0X74 ,
0X44 , 0X47 , 0X44 , 0X77 ,
0X44 , 0X47 , 0X47 , 0X44 ,
0X44 , 0X47 , 0X47 , 0X47 ,
0X44 , 0X47 , 0X47 , 0X74 ,
0X44 , 0X47 , 0X47 , 0X77 ,
0X44 , 0X47 , 0X74 , 0X44 ,
0X44 , 0X47 , 0X74 , 0X47 ,
0X44 , 0X47 , 0X74 , 0X74 ,
0X44 , 0X47 , 0X74 , 0X77 ,
0X44 , 0X47 , 0X77 , 0X44 ,
0X44 , 0X47 , 0X77 , 0X47 ,
0X44 , 0X47 , 0X77 , 0X74 ,
0X44 , 0X47 , 0X77 , 0X77 ,
0X44 , 0X74 , 0X44 , 0X44 ,
0X44 , 0X74 , 0X44 , 0X47 ,
0X44 , 0X74 , 0X44 , 0X74 ,
0X44 , 0X74 , 0X44 , 0X77 ,
0X44 , 0X74 , 0X47 , 0X44 ,
0X44 , 0X74 , 0X47 , 0X47 ,
0X44 , 0X74 , 0X47 , 0X74 ,
0X44 , 0X74 , 0X47 , 0X77 ,
0X44 , 0X74 , 0X74 , 0X44 ,
0X44 , 0X74 , 0X74 , 0X47 ,
0X44 , 0X74 , 0X74 , 0X74 ,
0X44 , 0X74 , 0X74 , 0X77 ,
0X44 , 0X74 , 0X77 , 0X44 ,
0X44 , 0X74 , 0X77 , 0X47 ,
0X44 , 0X74 , 0X77 , 0X74 ,
0X44 , 0X74 , 0X77 , 0X77 ,
0X44 , 0X77 , 0X44 , 0X44 ,
0X44 , 0X77 , 0X44 , 0X47 ,
0X44 , 0X77 , 0X44 , 0X74 ,
0X44 , 0X77 , 0X44 , 0X77 ,
0X44 , 0X77 , 0X47 , 0X44 ,
0X44 , 0X77 , 0X47 , 0X47 ,
0X44 , 0X77 , 0X47 , 0X74 ,
0X44 , 0X77 , 0X47 , 0X77 ,
0X44 , 0X77 , 0X74 , 0X44 ,
0X44 , 0X77 , 0X74 , 0X47 ,
0X44 , 0X77 , 0X74 , 0X74 ,
0X44 , 0X77 , 0X74 , 0X77 ,
0X44 , 0X77 , 0X77 , 0X44 ,
0X44 , 0X77 , 0X77 , 0X47 ,
0X44 , 0X77 , 0X77 , 0X74 ,
0X44 , 0X77 , 0X77 , 0X77 ,
0X47 , 0X44 , 0X44 , 0X44 ,
0X47 , 0X44 , 0X44 , 0X47 ,
0X47 , 0X44 , 0X44 , 0X74 ,
0X47 , 0X44 , 0X44 , 0X77 ,
0X47 , 0X44 , 0X47 , 0X44 ,
0X47 , 0X44 , 0X47 , 0X47 ,
0X47 , 0X44 , 0X47 , 0X74 ,
0X47 , 0X44 , 0X47 , 0X77 ,
0X47 , 0X44 , 0X74 , 0X44 ,
0X47 , 0X44 , 0X74 , 0X47 ,
0X47 , 0X44 , 0X74 , 0X74 ,
0X47 , 0X44 , 0X74 , 0X77 ,
0X47 , 0X44 , 0X77 , 0X44 ,
0X47 , 0X44 , 0X77 , 0X47 ,
0X47 , 0X44 , 0X77 , 0X74 ,
0X47 , 0X44 , 0X77 , 0X77 ,
0X47 , 0X47 , 0X44 , 0X44 ,
0X47 , 0X47 , 0X44 , 0X47 ,
0X47 , 0X47 , 0X44 , 0X74 ,
0X47 , 0X47 , 0X44 , 0X77 ,
0X47 , 0X47 , 0X47 , 0X44 ,
0X47 , 0X47 , 0X47 , 0X47 ,
0X47 , 0X47 , 0X47 , 0X74 ,
0X47 , 0X47 , 0X47 , 0X77 ,
0X47 , 0X47 , 0X74 , 0X44 ,
0X47 , 0X47 , 0X74 , 0X47 ,
0X47 , 0X47 , 0X74 , 0X74 ,
0X47 , 0X47 , 0X74 , 0X77 ,
0X47 , 0X47 , 0X77 , 0X44 ,
0X47 , 0X47 , 0X77 , 0X47 ,
0X47 , 0X47 , 0X77 , 0X74 ,
0X47 , 0X47 , 0X77 , 0X77 ,
0X47 , 0X74 , 0X44 , 0X44 ,
0X47 , 0X74 , 0X44 , 0X47 ,
0X47 , 0X74 , 0X44 , 0X74 ,
0X47 , 0X74 , 0X44 , 0X77 ,
0X47 , 0X74 , 0X47 , 0X44 ,
0X47 , 0X74 , 0X47 , 0X47 ,
0X47 , 0X74 , 0X47 , 0X74 ,
0X47 , 0X74 , 0X47 , 0X77 ,
0X47 , 0X74 , 0X74 , 0X44 ,
0X47 , 0X74 , 0X74 , 0X47 ,
0X47 , 0X74 , 0X74 , 0X74 ,
0X47 , 0X74 , 0X74 , 0X77 ,
0X47 , 0X74 , 0X77 , 0X44 ,
0X47 , 0X74 , 0X77 , 0X47 ,
0X47 , 0X74 , 0X77 , 0X74 ,
0X47 , 0X74 , 0X77 , 0X77 ,
0X47 , 0X77 , 0X44 , 0X44 ,
0X47 , 0X77 , 0X44 , 0X47 ,
0X47 , 0X77 , 0X44 , 0X74 ,
0X47 , 0X77 , 0X44 , 0X77 ,
0X47 , 0X77 , 0X47 , 0X44 ,
0X47 , 0X77 , 0X47 , 0X47 ,
0X47 , 0X77 , 0X47 , 0X74 ,
0X47 , 0X77 , 0X47 , 0X77 ,
0X47 , 0X77 , 0X74 , 0X44 ,
0X47 , 0X77 , 0X74 , 0X47 ,
0X47 , 0X77 , 0X74 , 0X74 ,
0X47 , 0X77 , 0X74 , 0X77 ,
0X47 , 0X77 , 0X77 , 0X44 ,
0X47 , 0X77 , 0X77 , 0X47 ,
0X47 , 0X77 , 0X77 , 0X74 ,
0X47 , 0X77 , 0X77 , 0X77 ,
0X74 , 0X44 , 0X44 , 0X44 ,
0X74 , 0X44 , 0X44 , 0X47 ,
0X74 , 0X44 , 0X44 , 0X74 ,
0X74 , 0X44 , 0X44 , 0X77 ,
0X74 , 0X44 , 0X47 , 0X44 ,
0X74 , 0X44 , 0X47 , 0X47 ,
0X74 , 0X44 , 0X47 , 0X74 ,
0X74 , 0X44 , 0X47 , 0X77 ,
0X74 , 0X44 , 0X74 , 0X44 ,
0X74 , 0X44 , 0X74 , 0X47 ,
0X74 , 0X44 , 0X74 , 0X74 ,
0X74 , 0X44 , 0X74 , 0X77 ,
0X74 , 0X44 , 0X77 , 0X44 ,
0X74 , 0X44 , 0X77 , 0X47 ,
0X74 , 0X44 , 0X77 , 0X74 ,
0X74 , 0X44 , 0X77 , 0X77 ,
0X74 , 0X47 , 0X44 , 0X44 ,
0X74 , 0X47 , 0X44 , 0X47 ,
0X74 , 0X47 , 0X44 , 0X74 ,
0X74 , 0X47 , 0X44 , 0X77 ,
0X74 , 0X47 , 0X47 , 0X44 ,
0X74 , 0X47 , 0X47 , 0X47 ,
0X74 , 0X47 , 0X47 , 0X74 ,
0X74 , 0X47 , 0X47 , 0X77 ,
0X74 , 0X47 , 0X74 , 0X44 ,
0X74 , 0X47 , 0X74 , 0X47 ,
0X74 , 0X47 , 0X74 , 0X74 ,
0X74 , 0X47 , 0X74 , 0X77 ,
0X74 , 0X47 , 0X77 , 0X44 ,
0X74 , 0X47 , 0X77 , 0X47 ,
0X74 , 0X47 , 0X77 , 0X74 ,
0X74 , 0X47 , 0X77 , 0X77 ,
0X74 , 0X74 , 0X44 , 0X44 ,
0X74 , 0X74 , 0X44 , 0X47 ,
0X74 , 0X74 , 0X44 , 0X74 ,
0X74 , 0X74 , 0X44 , 0X77 ,
0X74 , 0X74 , 0X47 , 0X44 ,
0X74 , 0X74 , 0X47 , 0X47 ,
0X74 , 0X74 , 0X47 , 0X74 ,
0X74 , 0X74 , 0X47 , 0X77 ,
0X74 , 0X74 , 0X74 , 0X44 ,
0X74 , 0X74 , 0X74 , 0X47 ,
0X74 , 0X74 , 0X74 , 0X74 ,
0X74 , 0X74 , 0X74 , 0X77 ,
0X74 , 0X74 , 0X77 , 0X44 ,
0X74 , 0X74 , 0X77 , 0X47 ,
0X74 , 0X74 , 0X77 , 0X74 ,
0X74 , 0X74 , 0X77 , 0X77 ,
0X74 , 0X77 , 0X44 , 0X44 ,
0X74 , 0X77 , 0X44 , 0X47 ,
0X74 , 0X77 , 0X44 , 0X74 ,
0X74 , 0X77 , 0X44 , 0X77 ,
0X74 , 0X77 , 0X47 , 0X44 ,
0X74 , 0X77 , 0X47 , 0X47 ,
0X74 , 0X77 , 0X47 , 0X74 ,
0X74 , 0X77 , 0X47 , 0X77 ,
0X74 , 0X77 , 0X74 , 0X44 ,
0X74 , 0X77 , 0X74 , 0X47 ,
0X74 , 0X77 , 0X74 , 0X74 ,
0X74 , 0X77 , 0X74 , 0X77 ,
0X74 , 0X77 , 0X77 , 0X44 ,
0X74 , 0X77 , 0X77 , 0X47 ,
0X74 , 0X77 , 0X77 , 0X74 ,
0X74 , 0X77 , 0X77 , 0X77 ,
0X77 , 0X44 , 0X44 , 0X44 ,
0X77 , 0X44 , 0X44 , 0X47 ,
0X77 , 0X44 , 0X44 , 0X74 ,
0X77 , 0X44 , 0X44 , 0X77 ,
0X77 , 0X44 , 0X47 , 0X44 ,
0X77 , 0X44 , 0X47 , 0X47 ,
0X77 , 0X44 , 0X47 , 0X74 ,
0X77 , 0X44 , 0X47 , 0X77 ,
0X77 , 0X44 , 0X74 , 0X44 ,
0X77 , 0X44 , 0X74 , 0X47 ,
0X77 , 0X44 , 0X74 , 0X74 ,
0X77 , 0X44 , 0X74 , 0X77 ,
0X77 , 0X44 , 0X77 , 0X44 ,
0X77 , 0X44 , 0X77 , 0X47 ,
0X77 , 0X44 , 0X77 , 0X74 ,
0X77 , 0X44 , 0X77 , 0X77 ,
0X77 , 0X47 , 0X44 , 0X44 ,
0X77 , 0X47 , 0X44 , 0X47 ,
0X77 , 0X47 , 0X44 , 0X74 ,
0X77 , 0X47 , 0X44 , 0X77 ,
0X77 , 0X47 , 0X47 , 0X44 ,
0X77 , 0X47 , 0X47 , 0X47 ,
0X77 , 0X47 , 0X47 , 0X74 ,
0X77 , 0X47 , 0X47 , 0X77 ,
0X77 , 0X47 , 0X74 , 0X44 ,
0X77 , 0X47 , 0X74 , 0X47 ,
0X77 , 0X47 , 0X74 , 0X74 ,
0X77 , 0X47 , 0X74 , 0X77 ,
0X77 , 0X47 , 0X77 , 0X44 ,
0X77 , 0X47 , 0X77 , 0X47 ,
0X77 , 0X47 , 0X77 , 0X74 ,
0X77 , 0X47 , 0X77 , 0X77 ,
0X77 , 0X74 , 0X44 , 0X44 ,
0X77 , 0X74 , 0X44 , 0X47 ,
0X77 , 0X74 , 0X44 , 0X74 ,
0X77 , 0X74 , 0X44 , 0X77 ,
0X77 , 0X74 , 0X47 , 0X44 ,
0X77 , 0X74 , 0X47 , 0X47 ,
0X77 , 0X74 , 0X47 , 0X74 ,
0X77 , 0X74 , 0X47 , 0X77 ,
0X77 , 0X74 , 0X74 , 0X44 ,
0X77 , 0X74 , 0X74 , 0X47 ,
0X77 , 0X74 , 0X74 , 0X74 ,
0X77 , 0X74 , 0X74 , 0X77 ,
0X77 , 0X74 , 0X77 , 0X44 ,
0X77 , 0X74 , 0X77 , 0X47 ,
0X77 , 0X74 , 0X77 , 0X74 ,
0X77 , 0X74 , 0X77 , 0X77 ,
0X77 , 0X77 , 0X44 , 0X44 ,
0X77 , 0X77 , 0X44 , 0X47 ,
0X77 , 0X77 , 0X44 , 0X74 ,
0X77 , 0X77 , 0X44 , 0X77 ,
0X77 , 0X77 , 0X47 , 0X44 ,
0X77 , 0X77 , 0X47 , 0X47 ,
0X77 , 0X77 , 0X47 , 0X74 ,
0X77 , 0X77 , 0X47 , 0X77 ,
0X77 , 0X77 , 0X74 , 0X44 ,
0X77 , 0X77 , 0X74 , 0X47 ,
0X77 , 0X77 , 0X74 , 0X74 ,
0X77 , 0X77 , 0X74 , 0X77 ,
0X77 , 0X77 , 0X77 , 0X44 ,
0X77 , 0X77 , 0X77 , 0X47 ,
0X77 , 0X77 , 0X77 , 0X74 ,
0X77 , 0X77 , 0X77 , 0X77 ,

};


class WS2812B {
public:
	SPI_HandleTypeDef* _hspi2;
	DMA_HandleTypeDef* _hdma_spi2_tx;

	//Constructor: number of LEDs
	WS2812B(uint16_t number_of_leds, SPI_HandleTypeDef* spipntr, DMA_HandleTypeDef* dmapntr );
	//WS2812B(uint16_t number_of_leds);
	~WS2812B();

	void
	begin(void),
	show(void),
	setPixelColor(uint16_t n, uint8_t r, uint8_t g, uint8_t b),
	//   setPixelColor(uint16_t n, uint8_t r, uint8_t g, uint8_t b, uint8_t w),
	setPixelColor(uint16_t n, uint32_t c),
	setBrightness(uint8_t),
	clear(),
	MX_SPI2_Init(void),
	//HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi),
	//HAL_SPI_TxHalfCpltCallback(SPI_HandleTypeDef *hspi),
	updateLength(uint16_t n);

	uint8_t
	//   *getPixels(void) const,
	ws_buffer[12*10],
	getBrightness(void) const;

	uint16_t
	numPixels(void) const;

	static uint32_t
	Color(uint8_t r, uint8_t g, uint8_t b),
	Color(uint8_t r, uint8_t g, uint8_t b, uint8_t w);

	// uint32_t
	//   getPixelColor(uint16_t n) const;

	//inline bool
	//canShow(void) { return (micros() - endTime) >= 300L};

private:

	bool
	begun =false;         // true if begin() previously called

	uint16_t
	numLEDs,       // Number of RGB LEDs in strip
	numBytes;      // Size of 'pixels' buffer

	uint8_t
	brightness,
	*pixels,        // Holds the current LED color values, which the external API calls interact with 9 bytes per pixel + start + end empty bytes
	//ws_buffer[12*10],     //*DblBuff  = (uint8_t *)mybuff,	// Holds the start of the double buffer (1 buffer for async DMA transfer and one for the API interaction.
	rOffset,       // Index of red byte within each 3- or 4-byte pixel
	gOffset,       // Index of green byte
	bOffset,       // Index of blue byte
	wOffset;       // Index of white byte (same as rOffset if no white)

	uint32_t
	endTime;       // Latch timing reference
};

#endif /* WS2812B_H_ */
