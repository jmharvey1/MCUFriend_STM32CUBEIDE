/*
 * KeyboardParser.h
 *
 *  Created on: Sep 21, 2021
 *      Author: jim
 */

#ifndef INC_KEYBOARDPARSER_H_
#define INC_KEYBOARDPARSER_H_
#include "hidboot.h"
#include "BTHID.h"
#include "BTHID_Demo.h"
#include "KeyBoardR01.h"
//#define DEBUG_PARSER

class KbdRptParser : public KeyboardReportParser {
  protected:
    virtual uint8_t HandleLockingKeys(USBHID *hid, uint8_t key);
    virtual void OnControlKeysChanged(uint8_t before, uint8_t after);
    virtual void OnKeyDown(uint8_t mod, uint8_t key);
    virtual void OnKeyUp(uint8_t mod, uint8_t key);
    virtual void OnKeyPressed(uint8_t key);

  private:
    void PrintKey(uint8_t mod, uint8_t key);
};

#ifdef DEBUG_PARSER
uint8_t KbdRptParser::HandleLockingKeys(USBHID *hid, uint8_t key) {
  uint8_t old_keys = kbdLockingKeys.bLeds;

  switch (key) {
    case UHS_HID_BOOT_KEY_NUM_LOCK:
      Serial.println(F("Num lock"));
      kbdLockingKeys.kbdLeds.bmNumLock = ~kbdLockingKeys.kbdLeds.bmNumLock;
      break;
    case UHS_HID_BOOT_KEY_CAPS_LOCK:
      Serial.println(F("Caps lock"));
      kbdLockingKeys.kbdLeds.bmCapsLock = ~kbdLockingKeys.kbdLeds.bmCapsLock;
      break;
    case UHS_HID_BOOT_KEY_SCROLL_LOCK:
      Serial.println(F("Scroll lock"));
      kbdLockingKeys.kbdLeds.bmScrollLock = ~kbdLockingKeys.kbdLeds.bmScrollLock;
      break;
  }

  if (old_keys != kbdLockingKeys.bLeds && hid) {
    BTHID *pBTHID = reinterpret_cast<BTHID *> (hid); // A cast the other way around is done in BTHID.cpp
    pBTHID->setLeds(kbdLockingKeys.bLeds); // Update the LEDs on the keyboard
  }

  return 0;
};

void KbdRptParser::PrintKey(uint8_t m, uint8_t key) {
  MODIFIERKEYS mod;
  *((uint8_t*)&mod) = m;
  Serial.print((mod.bmLeftCtrl == 1) ? F("C") : F(" "));
  Serial.print((mod.bmLeftShift == 1) ? F("S") : F(" "));
  Serial.print((mod.bmLeftAlt == 1) ? F("A") : F(" "));
  Serial.print((mod.bmLeftGUI == 1) ? F("G") : F(" "));

  Serial.print(F(" >"));
  PrintHex<uint8_t>(key, 0x80);
  Serial.print(F("< "));

  Serial.print((mod.bmRightCtrl == 1) ? F("C") : F(" "));
  Serial.print((mod.bmRightShift == 1) ? F("S") : F(" "));
  Serial.print((mod.bmRightAlt == 1) ? F("A") : F(" "));
  Serial.println((mod.bmRightGUI == 1) ? F("G") : F(" "));
};

void KbdRptParser::OnKeyDown(uint8_t mod, uint8_t key) {
  Serial.print(F("DN "));
  PrintKey(mod, key);
  uint8_t c = OemToAscii(mod, key);

  if (c)
    OnKeyPressed(c);
};

void KbdRptParser::OnControlKeysChanged(uint8_t before, uint8_t after) {
  MODIFIERKEYS beforeMod;
  *((uint8_t*)&beforeMod) = before;

  MODIFIERKEYS afterMod;
  *((uint8_t*)&afterMod) = after;

  if (beforeMod.bmLeftCtrl != afterMod.bmLeftCtrl)
    Serial.println(F("LeftCtrl changed"));
  if (beforeMod.bmLeftShift != afterMod.bmLeftShift)
    Serial.println(F("LeftShift changed"));
  if (beforeMod.bmLeftAlt != afterMod.bmLeftAlt)
    Serial.println(F("LeftAlt changed"));
  if (beforeMod.bmLeftGUI != afterMod.bmLeftGUI)
    Serial.println(F("LeftGUI changed"));

  if (beforeMod.bmRightCtrl != afterMod.bmRightCtrl)
    Serial.println(F("RightCtrl changed"));
  if (beforeMod.bmRightShift != afterMod.bmRightShift)
    Serial.println(F("RightShift changed"));
  if (beforeMod.bmRightAlt != afterMod.bmRightAlt)
    Serial.println(F("RightAlt changed"));
  if (beforeMod.bmRightGUI != afterMod.bmRightGUI)
    Serial.println(F("RightGUI changed"));
};

void KbdRptParser::OnKeyUp(uint8_t mod, uint8_t key) {
  Serial.print(F("UP "));
  PrintKey(mod, key);
};

void KbdRptParser::OnKeyPressed(uint8_t key) {
  Serial.print(F("ASCII: "));
  Serial.println((char)key);
};
#else
uint8_t KbdRptParser::HandleLockingKeys(USBHID *hid, uint8_t key) {
  uint8_t old_keys = kbdLockingKeys.bLeds;

  switch (key) {
    case UHS_HID_BOOT_KEY_NUM_LOCK:
      //Serial.println(F("Num lock"));
      kbdLockingKeys.kbdLeds.bmNumLock = ~kbdLockingKeys.kbdLeds.bmNumLock;
      break;
    case UHS_HID_BOOT_KEY_CAPS_LOCK:
      //Serial.println(F("Caps lock"));
      kbdLockingKeys.kbdLeds.bmCapsLock = ~kbdLockingKeys.kbdLeds.bmCapsLock;
      break;
    case UHS_HID_BOOT_KEY_SCROLL_LOCK:
      //Serial.println(F("Scroll lock"));
      kbdLockingKeys.kbdLeds.bmScrollLock = ~kbdLockingKeys.kbdLeds.bmScrollLock;
      break;
  }

  if (old_keys != kbdLockingKeys.bLeds && hid) {
    BTHID *pBTHID = reinterpret_cast<BTHID *> (hid); // A cast the other way around is done in BTHID.cpp
    pBTHID->setLeds(kbdLockingKeys.bLeds); // Update the LEDs on the keyboard
  }

  return 0;
};

void KbdRptParser::OnControlKeysChanged(uint8_t before, uint8_t after){
	 MODIFIERKEYS beforeMod;
	  *((uint8_t*)&beforeMod) = before;

	  MODIFIERKEYS afterMod;
	  *((uint8_t*)&afterMod) = after;

	  if (beforeMod.bmLeftCtrl != afterMod.bmLeftCtrl)
//	    Serial.println(F("LeftCtrl changed"));
	return;
};
void KbdRptParser::OnKeyDown(uint8_t mod, uint8_t key) {
//	Serial.print(int(mod));
//	Serial.print(" ");
//	Serial.print(int(key));
  if(key == 0x2A){ //Delete key pressed
	  //Serial.print(" Delete ");
	  int ChrCnt = CWsndengn.Delete();
	  if(ChrCnt>0) tftmsgbx.Delete(ChrCnt);
  }else if(key == 0x52){//PG UP
	  CWsndengn.IncWPM();
	  return;
  }else if(key == 0x51){//PG DOWN
	  CWsndengn.DecWPM();
	  return;
//  }else if(key == 0x45){//F12 key (Alternate action SOT [Send On type])
//  	  CWsndengn.SOTmode();
//  	  return;
//  }else if(key == 0x3A){//F1 key (store TEXT)
//  	  CWsndengn.StrTxtmode();
//  	  return;
  }else if(key == 0x4F){//F12 key (Alternate action SOT [Send On type])
  	  CWsndengn.SOTmode();
  	  return;
  }else if(key == 0x50){//F1 key (store TEXT)
  	  CWsndengn.StrTxtmode();
  	  return;
  }else if(key == 0x29){//ESC key (Kill Send)
    	  CWsndengn.AbortSnd();
    	  return;
  }else if((mod == 1) && (key ==0x17)){ //Cntrl+"T"
	  CWsndengn.Tune();
  }else if((mod == 0) && (key ==0x28)){ // "ENTER" Key send myCallSign
	  if(CWsndengn.IsActv() && !CWsndengn.LstNtrySpc()) CWsndengn.AddNewChar(" ");
	  CWsndengn.LdMsg(MyCall, 10);
  }else if((mod == 1) && (key ==0x28)){ // "Cntrl+ENTER" send StrdTxt call
  	  if(CWsndengn.IsActv() && !CWsndengn.LstNtrySpc()) CWsndengn.AddNewChar(" ");
   	  CWsndengn.LdMsg(StrdTxt, 20);
  }else if((mod == 2) && (key ==0x28)){ // "shift+ENTER" send both calls (StrdTxt & MyCall)
  	  if(CWsndengn.IsActv() && !CWsndengn.LstNtrySpc()) CWsndengn.AddNewChar(" ");
   	  char buf[20];
	  sprintf(buf, "%s DE %s", StrdTxt, MyCall);
  	  CWsndengn.LdMsg(buf, 20);
  }else{
	  uint8_t c = OemToAscii(mod, key);
	  if (c)
	      OnKeyPressed(c);
  }
};
void KbdRptParser::OnKeyUp(uint8_t mod, uint8_t key){
	return;
};

void KbdRptParser::OnKeyPressed(uint8_t key) {
	bool addspce = false;
	if((key>=97) & (key<=122)){
		key = key - 32;
	}
	char Ltr2Bsent = (char)key;
	switch(Ltr2Bsent){
		case '=' :
			addspce = true;//<BT>
			break;
		case '+' :
			addspce = true;//<KN>
			break;
		case '%' :
			addspce = true;;//<SK>
			break;
		case '>' :
			addspce = true;//<BT>
			break;
		case '<' :
			addspce = true;//<BT>
			break;
	}
	if(addspce && CWsndengn.IsActv() && !CWsndengn.LstNtrySpc()) CWsndengn.AddNewChar(" ");
	CWsndengn.AddNewChar(&Ltr2Bsent);
};

void KbdRptParser::PrintKey(uint8_t m, uint8_t key) {
  MODIFIERKEYS mod;
  *((uint8_t*)&mod) = m;
  return;
};

#endif




#endif /* INC_KEYBOARDPARSER_H_ */
