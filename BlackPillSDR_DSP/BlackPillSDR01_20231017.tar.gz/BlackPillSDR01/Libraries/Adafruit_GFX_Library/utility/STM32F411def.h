/*
 * STM32F411def.h
 *
 *  Created on: Feb 13, 2021
 *      Author: jim
 */

#ifndef ADAFRUIT_GFX_LIBRARY_UTILITY_STM32F411DEF_H_
#define ADAFRUIT_GFX_LIBRARY_UTILITY_STM32F411DEF_H_
/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : BlackPill_STM32F411def
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
//#define  ISTARGET_NUCLEO64
//#include "utility/pin_shield_8.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
  #define RD_PORT LCD_RD_GPIO_Port  //A0_PORT
  #define RD_PIN  LCD_RD_Pin   //A0_PIN
  #define WR_PORT LCD_WR_GPIO_Port  //A1_PORT
  #define WR_PIN  LCD_WR_Pin   //A1_PIN
  #define CD_PORT LCD_RS_GPIO_Port  //A2_PORT
  #define CD_PIN  LCD_RS_Pin   //A2_PIN
  #define CS_PORT LCD_CS_GPIO_Port  //A3_PORT
  #define CS_PIN  LCD_CS_Pin  //A3_PIN
  #define RESET_PORT LCD_RST_GPIO_Port  //A4_PORT
  #define RESET_PIN  LCD_RST_Pin   //A4_PIN

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
//#define setWriteDir() { setReadDir1(); \
//                        GPIOA->MODER |=0b00000000000000000101000100010100  ; GPIOB->MODER |=0b00000000000000000000000000000100;}
////#define setReadDir()  { GPIOA->MODER &= ~0x3F0000; GPIOB->MODER &= ~0x300FC0; GPIOC->MODER &= ~0xC000; }
//#define setReadDir1()  { GPIOA->MODER &=0b11111111111111111010111011101011; GPIOB->MODER &=11111111111111111111111111111011;}
//#define setReadDir()  { GPIOA->MODER &=0b11111111111111110000000011000000; GPIOB->MODER &=11111111111111111111111111111100;}

  #define write_8(d) { \
   GPIOA->BSRR = 0b000111101110000000000000000; \
   GPIOB->BSRR = 0b000000000010000000000000000; \
   GPIOA->BSRR = (((d) & (1<<0)) << 0) \
               | (((d) & (1<<1)) << 0) \
               | (((d) & (1<<2)) << 0) \
               | (((d) & (1<<4)) << 0) \
               | (((d) & (1<<5)) << 0) \
               | (((d) & (1<<6)) >> 0) \
               | (((d) & (1<<7)) << 0); \
   GPIOB->BSRR = (((d) & (1<<3)) >> 3); \
   }
  #define read_8() (          (((GPIOA->IDR & (1<<0)) >> 0) \
                             | ((GPIOA->IDR & (1<<1)) >> 0) \
                             | ((GPIOA->IDR & (1<<2)) >> 0) \
                             | ((GPIOB->IDR & (1<<0)) << 3) \
                             | ((GPIOA->IDR & (1<<4)) >> 0) \
                             | ((GPIOA->IDR & (1<<5)) << 0) \
                             | ((GPIOA->IDR & (1<<6)) >> 0) \
                             | ((GPIOA->IDR & (1<<7)) >> 0)))
//////////////////////////////////////////////////////////////////////////////////////////////
//20210210 JMH the following "defines" were created to support Input/output GPIO control for black pill stm32F411 board

#define func1(x)  (x)=(x+1)
#define func2(x)  (x)=(x)>>1
#define func3(pin)  ({temp=((uint32_t)(pin)); temp;})
#define CALL_FUNCS(pin) \
({uint32_t temp=func3((pin)); \
uint32_t position = 0U; \
do { \
  func1(position); \
  func2(temp); \
} while (temp > 1U); \
position;})

#define PINMASK(pin) (~(1u<<(CALL_FUNCS(pin))*2U))
#define PIN_MODE2(reg, pin, mode) reg= (((reg)&PINMASK(pin))|((mode)<<((CALL_FUNCS(pin))*2U)))
#define PIN_OUTPUT(port, pin) PIN_MODE2((port)->MODER, pin, 0x1)//20210206 JMH Added to provide BlackPill Support on STM32CubeIDE
#define PIN_INPUT(port, pin) PIN_MODE2((port)->MODER, pin, 0x0)
//////////////////////////////////////////////////////////////////////////////////////////////
#define RD_STROBE RD_IDLE, RD_ACTIVE, RD_ACTIVE, RD_ACTIVE      //PWLR=TRDL=150ns, tDDR=100ns
#define READ_8(dst)   { RD_STROBE; READ_DELAY; dst = read_8(); RD_IDLE2; RD_IDLE; }
#define READ_16(dst)  { uint8_t hi; READ_8(hi); READ_8(dst); dst |= (hi << 8); }

// general purpose pin macros
#define PIN_LOW(port, pin)    (port)->BSRR = (uint32_t)((pin)<<16u) //20210206 JMH Added to provide BlackPill Support on STM32CubeIDE
#define PIN_HIGH(port, pin)   (port)->BSRR = pin  //20210206 JMH Added to provide BlackPill Support on STM32CubeIDE
 #define RD_ACTIVE  PIN_LOW(RD_PORT, RD_PIN)
 #define RD_IDLE    PIN_HIGH(RD_PORT, RD_PIN)
 #define RD_OUTPUT  PIN_OUTPUT(RD_PORT, RD_PIN)
 #define WR_ACTIVE  PIN_LOW(WR_PORT, WR_PIN)
 #define WR_IDLE    PIN_HIGH(WR_PORT, WR_PIN)
 #define WR_OUTPUT  PIN_OUTPUT(WR_PORT, WR_PIN)
 #define CD_COMMAND PIN_LOW(CD_PORT, CD_PIN)
 #define CD_DATA    PIN_HIGH(CD_PORT, CD_PIN)
 #define CD_OUTPUT  PIN_OUTPUT(CD_PORT, CD_PIN)
 #define CS_ACTIVE  PIN_LOW(CS_PORT, CS_PIN)
 #define CS_IDLE    PIN_HIGH(CS_PORT, CS_PIN)
 #define CS_OUTPUT  PIN_OUTPUT(CS_PORT, CS_PIN)
 #define RESET_ACTIVE  PIN_LOW(RESET_PORT, RESET_PIN)
 #define RESET_IDLE    PIN_HIGH(RESET_PORT, RESET_PIN)
 #define RESET_OUTPUT  PIN_OUTPUT(RESET_PORT, RESET_PIN)

#define WR_ACTIVE2  {WR_ACTIVE; WR_ACTIVE;}
#define WR_ACTIVE4  {WR_ACTIVE2; WR_ACTIVE2;}
#define WR_ACTIVE8  {WR_ACTIVE4; WR_ACTIVE4;}
#define RD_ACTIVE2  {RD_ACTIVE; RD_ACTIVE;}
#define RD_ACTIVE4  {RD_ACTIVE2; RD_ACTIVE2;}
#define RD_ACTIVE8  {RD_ACTIVE4; RD_ACTIVE4;}
#define RD_ACTIVE16 {RD_ACTIVE8; RD_ACTIVE8;}
#define WR_IDLE2  {WR_IDLE; WR_IDLE;}
#define WR_IDLE4  {WR_IDLE2; WR_IDLE2;}
#define RD_IDLE2  {RD_IDLE; RD_IDLE;}
#define RD_IDLE4  {RD_IDLE2; RD_IDLE2;}
#define WR_STROBE { WR_ACTIVE; WR_IDLE; }         //PWLW=TWRL=50ns

#define WRITE_DELAY { WR_ACTIVE2; WR_ACTIVE; }//{ WR_ACTIVE2; WR_ACTIVE; } //100MHz
#define READ_DELAY  { RD_ACTIVE4; RD_ACTIVE2; }
#define IDLE_DELAY    { WR_IDLE; }
#define write8(x)     { write_8(x); WR_STROBE; IDLE_DELAY; }//{ write_8(x); WRITE_DELAY; WR_STROBE; IDLE_DELAY; } //
#define write16(x)    { uint8_t h = (x)>>8, l = x; write8(h); write8(l); }
#define WriteCmd(x)  { CD_COMMAND; write16(x); CD_DATA; }
#define WriteData(x) { write16(x); }
#define GPIO_INIT()   { RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN; }
#define CTL_INIT()   { GPIO_INIT(); RD_OUTPUT; WR_OUTPUT; CD_OUTPUT; CS_OUTPUT; RESET_OUTPUT; }
//#define CTL_INIT()   { RD_OUTPUT; WR_OUTPUT; CD_OUTPUT; CS_OUTPUT; RESET_OUTPUT; }

/* USER CODE END PM */

/* USER CODE END Header */





#endif /* ADAFRUIT_GFX_LIBRARY_UTILITY_STM32F411DEF_H_ */
