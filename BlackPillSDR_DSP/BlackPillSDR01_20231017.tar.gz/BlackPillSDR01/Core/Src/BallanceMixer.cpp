/*
 * BallanceMixer.cpp
 *
 *  Created on: Jul 11, 2022
 *      Author: jim
 */
/*
 * 20220719 added side-tone adjustment to screen
 * */

#include "main.h"//contains BtnParams definition
#include "CalSI5351Freq.h"
#include "BallanceMixer.h"
#include "SDR_Si5351r01.h"//added to support "readResistiveTouch()" call
#include "TFTMsgBox.h"
//#include "arm_math.h"
#include "arm_const_structs.h"// needed to support float32_t type definition
#include "MCUFRIEND_kbv.h" // need this to support TFT colors
#include "Arduino.h"
//#include "SerialClass.h"
#include "si5351.h"
const int BtnCnt = 18;
float QCFactr1;
int Balrxcenter;
int Baltxfreq;
int OldDBMx;
BtnParams MxrCalBtns[BtnCnt];
void BldMxrButtons(void);
void ShwSlctdBalBtn(int BtnNo);
void ApplyNewPhase(bool IncPhaseError);
void ApplyNewAmpGainEr(bool IncGainError);
void ShwSmtr(void);
void ShwPhzCorr(void);
void ShwAmpCorr(void);
void ShwSmtr(int Smtr, float DBm);
void ChkMode(float SideTonefreq);
void CalMode(float SideTonefreq);
/**
 * @brief  The application entry point.
 *
 */
void BalMixr_MainLoop(int rxcenter, int txfreq, int SamplRateInt, float SideTonefreq)
{

	char RevDate[9]  = "20220719";
	Balrxcenter =rxcenter;
	Baltxfreq = txfreq;
	/*Setup to adjust/set the Test carrier(xmit freq)*/
	si5351.pll_reset(SI5351_PLLA);//*
	SetTX = true;
	SetRX = false;
//	txfreq = CwTunefreq + SideTonefreq;
	CwTunefreq = txfreq - SideTonefreq;
	/*calculate the new tx freq (LO image) */
	float offset = float(rxcenter - txfreq);
	float ImageTxFreq = offset+rxcenter;
	sendFrequency(float(ImageTxFreq));
	si5351.output_enable(SI5351_CLK2, 1);//
	/*Restore "normal" SetRX/SetTX settings for receiving */
	SetRX = true;
	SetTX = false;
	/*No other Si5351 changes needed at this time */
	//	float offset = float(rxcenter - txfreq);
	//	float SideTonefreq = 750;
	//	float ImageTuneFreq = -offset +SideTonefreq;
	//	sendFrequency(float(rxcenter));
	//	LO_Phase_Shift = (ImageTuneFreq/samp_rate)*TwoPi;
	/* begin touchscreen setup*/
	tftmsgbx = TFTMsgBox(&tft, StrdTxt);
	tftmsgbx.InitDsplay();
	sprintf( Title, "Ballance Mixer(%s)\n", RevDate );
	tftmsgbx.dispTitl(Title, TFT_CYAN);
	tftmsgbx.LOFreq(rxcenter);
	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
	//	tftmsgbx.TuneFreq(rxcenter-ImageTuneFreq, SideTonefreq);
	BldMxrButtons();
	/* Start Sound Board DMA to begin IQ capture and stream demodulated audio */
	HAL_I2SEx_TransmitReceive_DMA(&hi2s2, txBuf, rxBuf, decimate_factor*4);
	delay(500);
	//sprintf(Title,"Err: %d",XtalErr);
	//tftmsgbx.dispTitl(Title, TFT_YELLOW);//for testing only
	OldDBMx =0;
	ShwSmtr();
	ShwPhzCorr();
	tftmsgbx.SmplRate(SamplRateInt);
	tftmsgbx.SdTFreq(int(SideTonefreq));
	/* Install Narrow audio filter */
	//	ZeroBtFltr();
	//FreqCalMode = true;
	bool testing = true;
	bool updtFLDIGI = true;
	int py;
	int px;
	FinTune = true;
	//	int oldDemodFreq = 0;
	while (testing)
	{
		delay(50);
		ShwSmtr();
		if (GetTouchPts(px, py) > 150 ) {
			/* check/test Band Buttons */
			for (int butNo = 0; butNo < BtnCnt; butNo++){
				if(BtnActive(butNo, MxrCalBtns, px, py)){
					//FreqCalMode = false;
					/*Found selected Band button; restore last setting(s) for this band*/
					XtalErr = si5351.get_correction(si5351.plla_ref_osc);// get current correction value
					bool updt = false;
					switch (butNo){
					case 4:  //sidetone -
						SideTonefreq -=10;
						if(SideTonefreq <500) SideTonefreq = 500;
						ApplySideTone(int(SideTonefreq));
						tftmsgbx.SdTFreq(int(SideTonefreq));
						ShwSlctdBalBtn(butNo);
						delay(50);
						CalMode(SideTonefreq);
//						ChkMode(SideTonefreq);
						ShwSlctdBalBtn(10);
						break;
					case 5:  //sidetone +
						SideTonefreq +=10;
						if(SideTonefreq >950) SideTonefreq = 950;
						ApplySideTone(int(SideTonefreq));
						tftmsgbx.SdTFreq(int(SideTonefreq));
						ShwSlctdBalBtn(butNo);
						delay(50);
						CalMode(SideTonefreq);
//						ChkMode(SideTonefreq);
						ShwSlctdBalBtn(10);
						break;
					case 6:
						ApplyNewPhase(false);
						break;
					case 7:
						ApplyNewPhase(true);
						break;
					case 8:
						ApplyNewAmpGainEr(false);
						break;
					case 9:
						ApplyNewAmpGainEr(true);
						break;
					case 10: //Cal
						ShwSlctdBalBtn(butNo);
						CalMode(SideTonefreq);
						break;
					case 11: //Check
						ShwSlctdBalBtn(butNo);
						ChkMode(SideTonefreq);
						break;

					case 12: //SmplRt-
						SamplRateInt -=5;
						ApplySmplRate( SamplRateInt);
						tftmsgbx.SmplRate(SamplRateInt);
						ShwSlctdBalBtn(butNo);
						delay(50);
						ChkMode(SideTonefreq);
						ShwSlctdBalBtn(11);
						break;
					case 13: //SmplRt+
						SamplRateInt +=5;
						ApplySmplRate( SamplRateInt);
						tftmsgbx.SmplRate(SamplRateInt);
						ShwSlctdBalBtn(butNo);
						delay(50);
						ChkMode(SideTonefreq);
						ShwSlctdBalBtn(11);
						break;

					case 15://exit Ballance Mixer process
						testing = false;//LO+SR/2
						FinTune = false;
						si5351.output_enable(SI5351_CLK2, 0);//Disable TX clock/oscillator
						break;
					}
					//					if(updt){
					//						ShwSlctdBalBtn(butNo);
					//						sprintf(Title,"Err: %d",XtalErr);
					//						si5351.set_correction(XtalErr ,si5351.plla_ref_osc);
					//						tftmsgbx.dispTitl(Title, TFT_YELLOW);//for testing only
					//					}
					//FreqCalMode = true;
				}
			}
		}

		/*check * update FLDIGI info requests*/
		if(updtFLDIGI){
			if(GetRmtCmd()){//check in with FLDIGI (function found in SDR_Si5351r01.cpp)
				updtFLDIGI = false;//Fldigi has been updated; No longer need to do this
				//tftmsgbx.dispTitl(Cmd, TFT_CYAN);//for testing only
			}
		}
	}
	//FreqCalMode = false;
}


void BldMxrButtons(void){
	int btnHght = 39;
	int btnWdthS = 40;
	int btnWdthL = (3*btnWdthS)+2;
	int row0;
	int row1;
	int row2;
	int row3;
	int row4;
	int row5; //band buttons
	row0 = int(scrnHeight/2) - (btnHght + 1);//Just above center Screen
	row1 = row0 + (btnHght + 1);//Just below center Screen
	row2 = row1 + (btnHght + 1);
	row3 = row2 + (btnHght + 1);
	row4 = scrnHeight - (5*btnHght + 1);
	row5 = row0 - (btnHght + 1);
	int BtnNo = 0;
	//Exit Button 0
	MxrCalBtns[BtnNo].BtnXpos = 0;
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//80;  //Button Width
	MxrCalBtns[BtnNo].BtnHght =btnHght;
	MxrCalBtns[BtnNo].BtnYpos = row0;
	MxrCalBtns[BtnNo].Captn = "LO+SR/2";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 1;
	MxrCalBtns[BtnNo].BtnXpos = 0;
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row1;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "LO-SR/2";
	MxrCalBtns[BtnNo].BtnClr = TFT_GREEN;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	int lastbin = 130;
	BtnNo = 2;
	MxrCalBtns[BtnNo].BtnXpos = lastbin;  //Button X position
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//80;  //Button Width
	MxrCalBtns[BtnNo].BtnHght =btnHght;
	MxrCalBtns[BtnNo].BtnYpos = row0-int(btnHght/4);// scrnHeight - (MxrCalBtns[0].BtnHght + 5);  //Button Y position
	MxrCalBtns[BtnNo].Captn = "^^";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLUE;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 3;
	MxrCalBtns[BtnNo].BtnXpos = lastbin;
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row1+int(btnHght/4);//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "vv";
	MxrCalBtns[BtnNo].BtnClr = TFT_RED;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 4;
	MxrCalBtns[BtnNo].BtnXpos = 0;//130;  //Button X position
	MxrCalBtns[BtnNo].BtnWdth = btnWdthL;;//80;  //Button Width
	MxrCalBtns[BtnNo].BtnHght =btnHght;
	MxrCalBtns[BtnNo].BtnYpos = row2;// scrnHeight - (MxrCalBtns[0].BtnHght + 5);  //Button Y position
	MxrCalBtns[BtnNo].Captn = "SideTone-";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 5;
	MxrCalBtns[BtnNo].BtnXpos = MxrCalBtns[BtnNo-1].BtnXpos+(btnWdthL+1);
	MxrCalBtns[BtnNo].BtnWdth = btnWdthL;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row2;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "SideTone+";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	/* Band Buttons */
	BtnNo = 6;
	MxrCalBtns[BtnNo].BtnXpos = 0;
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row0;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "Dec";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 7;
	MxrCalBtns[BtnNo].BtnXpos = MxrCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row0;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "Inc";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;//TFT_DARKCYAN;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 8;
	MxrCalBtns[BtnNo].BtnXpos = MxrCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row0;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "G-";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 9;
	MxrCalBtns[BtnNo].BtnXpos = MxrCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row0;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "G+";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 10;
	MxrCalBtns[BtnNo].BtnXpos = MxrCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row0;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "Cal";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	/*Filter Buttons*/
	BtnNo = 11;
	MxrCalBtns[BtnNo].BtnXpos = MxrCalBtns[BtnNo-1].BtnXpos+(int((btnWdthS+1)));
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row0;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "Chk";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 12;
	MxrCalBtns[BtnNo].BtnXpos = 0;
	MxrCalBtns[BtnNo].BtnWdth = btnWdthL;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row1;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "SmplRate-";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 13;
	MxrCalBtns[BtnNo].BtnXpos = MxrCalBtns[BtnNo-1].BtnXpos+(btnWdthL+1);
	MxrCalBtns[BtnNo].BtnWdth = btnWdthL;//MxrCalBtns[0].BtnWdth;  //Button Width
	MxrCalBtns[BtnNo].BtnHght = btnHght;//MxrCalBtns[0].BtnHght;
	MxrCalBtns[BtnNo].BtnYpos = row1;//MxrCalBtns[0].BtnYpos;  //Button Y position
	MxrCalBtns[BtnNo].Captn = "SmplRate+";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;//TFT_DARKCYAN;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 14;
	MxrCalBtns[BtnNo].BtnXpos = lastbin;
	MxrCalBtns[BtnNo].BtnWdth = btnWdthS;
	MxrCalBtns[BtnNo].BtnHght = int(btnHght/2);
	MxrCalBtns[BtnNo].BtnYpos = row1-int(btnHght/4);
	MxrCalBtns[BtnNo].Captn = "=0";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 15;
	MxrCalBtns[BtnNo].BtnXpos = 0;
	MxrCalBtns[BtnNo].BtnWdth = 285;
	MxrCalBtns[BtnNo].BtnHght = int(btnHght);
	MxrCalBtns[BtnNo].BtnYpos = 2;
	MxrCalBtns[BtnNo].Captn = "";
	MxrCalBtns[BtnNo].BtnClr = TFT_BLACK;
	MxrCalBtns[BtnNo].TxtClr = TFT_BLACK;


	for(int i=4; i<14; i++){
		BldBtn(i, MxrCalBtns); // Build the SetUp Button Set
		delay(20);
	}
	ShwSlctdBalBtn(10); //Hilight the "Tst" button
}
///////////////////////////////////////////////////////////////////////////////////////////////
void ShwSlctdBalBtn(int BtnNo){
	for(int i=4; i<14; i++){//for(int i=10; i<12; i++){
		if(BtnNo!= i){
			MxrCalBtns[i].BtnClr = TFT_BLACK;
		}else{
			MxrCalBtns[i].BtnClr = TFT_GREEN;
		}
		BldBtn(i, MxrCalBtns); // Build the SetUp Button Set
		//delay(20);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////
void ApplyNewPhase(bool IncPhaseError){
	if(IncPhaseError)PhasCorect += DPhasCor;
	else PhasCorect -= DPhasCor;
	if(PhasCorect>= maxPhasErr){
		PhasCorect = maxPhasErr;
	}
	if(PhasCorect<= -maxPhasErr){
		PhasCorect = -maxPhasErr;
	}
//	ICFactr = (1+ (0.5*arm_sin_f32((TwoPi/360)*PhasCorect)));
//	QCFactr = AmpFactor/ICFactr;
	ICFactr = (arm_sin_f32((TwoPi/360)*PhasCorect));
	QCFactr = AmpFactor;
	ShwPhzCorr();
}

///////////////////////////////////////////////////////////////////////////////////////////////
void ApplyNewAmpGainEr(bool IncGainError){
	if(IncGainError)AmpError += DampCor;
	else AmpError -= DampCor;
	if(AmpError >= maxAmpEr){
		AmpError = maxAmpEr;
	}
	if(AmpError <= -maxAmpEr){
		AmpError = -maxAmpEr;
	}
	AmpFactor =(1.0+ AmpError);
//	QCFactr = AmpFactor/ICFactr;
	ICFactr = (arm_sin_f32((TwoPi/360)*PhasCorect));
	QCFactr = AmpFactor;
	ShwAmpCorr();

}

///////////////////////////////////////////////////////////////////////////////////////////////
void ShwSmtr(void){

	int lineLen;
	int row0 = int(scrnHeight/2) - (40);
	int row1 = row0 -20;
	uint32_t Clr;
	float32_t DBm = -20 * __builtin_log10f(DemodGain/0.003);
	/*Draw a bar whose length is proportional to the current dbm value*/
	int Dbm_int = int(7*(119+DBm));//'119' is the no sig noise floor
	if(Dbm_int != OldDBMx){
		/* IF Mag < last time, We need to erase the difference */
		lineLen = (Dbm_int - OldDBMx);
		if(lineLen < 0) Clr = TFT_BLACK;
		else Clr = TFT_RED;
		for (int i =0; i<5; i++){
			tft.drawFastHLine(OldDBMx, row1-i, lineLen, Clr);
		}
//		if(Dbm_int <  OldDBMx){// Dbm magnitude has dropped since last report
//			lineLen = (Dbm_int - OldDBMx);
//			if(lineLen < 0) tft.drawFastHLine(OldDBMx,100 , lineLen, TFT_BLACK);
//		}else{
//			/* Now build the Current Magnitude segment of the spectrum bar */
//			lineLen = (Dbm_int-OldDBMx);
//			if(lineLen>0) tft.drawFastHLine(OldDBMx, 100, lineLen, TFT_RED);//
//		}
		OldDBMx = Dbm_int;
	}
	/*convert DBm value to S meter value (based on -73DBm = S9) */
	int Smtr = 9;
	int SdbmREf = -73;
	while((SdbmREf-0.05)> DBm){
		SdbmREf -=6;
		Smtr--;
	}
	DBm = DBm-SdbmREf;
	if(DBm < 0.0) DBm = 0.0;
	ShwSmtr(Smtr, DBm);
}
//////////////////////////////////////////////////////////////////////////////////////////////
void ShwPhzCorr(void){
//	sprintf(Title,"PhaseCor:%fDeg", (360*(PhasCorect/TwoPi)));
	sprintf(Title,"PhsEr:%.2fDg; AmpEr:%.4f ", PhasCorect, AmpFactor);
	tftmsgbx.dispTitl(Title, TFT_YELLOW);
}
////////////////////////////////////////////////////////////////////////////////////////////
void ShwAmpCorr(void){
	//sprintf(Title,"AmpCor:%.4f", AmpFactor);
	sprintf(Title,"PhsEr:%.2fDg; AmpEr:%.4f ", PhasCorect, AmpFactor);
	tftmsgbx.dispTitl(Title, TFT_YELLOW);
}
////////////////////////////////////////////////////////////////////////////////////////////
void ShwSmtr(int Smtr, float DBm){
sprintf( Title, "S%d %.1fdB", Smtr, DBm);
tftmsgbx.SigSmtr(Title, TFT_GREEN);
}
/////////////////////////////////////////////////////////////////////////////////////////
void ChkMode(float SideTonefreq){
	float offset = float(Balrxcenter - Baltxfreq);
	//float SideTonefreq = 750;
	float ImageTuneFreq = -offset +SideTonefreq;
	LO_Phase_Shift = (ImageTuneFreq/samp_rate)*TwoPi;
	tftmsgbx.TuneFreq(int(Balrxcenter+offset), 0); //int(SideTonefreq)
}
void CalMode(float SideTonefreq){
	LO_Phase_Shift = ((Balrxcenter-(CwTunefreq))/samp_rate)*TwoPi;
	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
}
