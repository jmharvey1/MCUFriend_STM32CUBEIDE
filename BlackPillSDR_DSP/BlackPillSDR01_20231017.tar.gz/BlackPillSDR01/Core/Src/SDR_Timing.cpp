/*
 * SDR_Timing.cpp
 *
 *  Created on: Oct 10, 2022
 *      Author: jim
 */

#include "main.h"//contains BtnParams definition
#include "CalSI5351Freq.h"
#include "SDR_Timing.h"
#include "BallanceMixer.h"//added to support 'DemodGain' variable
#include "SDR_Si5351r01.h"//added to support "readResistiveTouch()" call
#include "TFTMsgBox.h"
//#include "arm_math.h"
#include "arm_const_structs.h"// needed to support float32_t type definition
#include "MCUFRIEND_kbv.h" // need this to support TFT colors
#include "Arduino.h"
//#include "SerialClass.h"
#include "si5351.h"
const int BtnCnt = 5;
//float QCFactr1;
//int Balrxcenter;
//int Baltxfreq;
int OldTDBMx;
BtnParams TimingBtns[BtnCnt];
void BldTimingBtns(void);
void ShwSlctdTimeBtn(int BtnNo);
//void ApplyNewPhase(bool IncPhaseError);
//void ApplyNewAmpGainEr(bool IncGainError);
void ShwTmtr(void);
//void ShwTPhzCorr(void);
//void ShwTAmpCorr(void);
void ShwTmtr(int Smtr, float DBm);
//void ChkMode(float SideTonefreq);
//void CalMode(float SideTonefreq);
/**
 * @brief  The application entry point.
 *
 */
void Timing_MainLoop(void)
{

	char RevDate[9]  = "20221010";

	/* begin touchscreen setup*/
	tftmsgbx = TFTMsgBox(&tft, StrdTxt);
	tftmsgbx.InitDsplay();
	sprintf( Title, "SDR_Timing(%s)\n", RevDate );
	tftmsgbx.dispTitl(Title, TFT_CYAN);
//	tftmsgbx.LOFreq(0);
	tftmsgbx.ShwDly(int(TXdelay));
	tftmsgbx.ShwHT(int(TRHangTime));
	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
	BldTimingBtns();
	/* Start Sound Board DMA to begin IQ capture and stream demodulated audio */
	HAL_I2SEx_TransmitReceive_DMA(&hi2s2, txBuf, rxBuf, decimate_factor*4);
	delay(500);
	OldTDBMx =0;
	ShwTmtr();
//	ShwTPhzCorr();
//	tftmsgbx.SmplRate(5);
	tftmsgbx.SdTFreq(int(SideTonefreq));
	bool testing = true;
	bool updtFLDIGI = true;
	int py;
	int px;
	FinTune = true;
	while (testing)
	{
		while(KeyActive){// if true there's been recent key activity
			KeyEvntSR();
			if(HAL_GetTick() >= PTTtimeOut){
				/* Return T/R Relay to Receive position */
				KeyActive = false;
				StopTX(); //make absolutely certain that PA is shutdown
				HAL_GPIO_WritePin(TR_Relay_GPIO_Port, TR_Relay_Pin, GPIO_PIN_RESET);
				PTT = false;
				SetRX = true;//added this to make sure that radio would be configured to change RX freq, on exit from this wait loop.
			}
			/*Added to support new approach to effecting delayed Si5351 TX commands*/
			if(HAL_GetTick() >= ExecTXCmd && ExecTXCmd !=0){
				ExecTXCmd =0;
				if(TXON) StartTX();
				else StopTX();
			}
		}
		delay(50);
		ShwTmtr();
		if (GetTouchPts(px, py) > 150 ) {
			/* check/test Band Buttons */
			for (int butNo = 0; butNo < BtnCnt; butNo++){
				if(BtnActive(butNo, TimingBtns, px, py)){
					//FreqCalMode = false;
					/*Found selected Band button; restore last setting(s) for this band*/
					XtalErr = si5351.get_correction(si5351.plla_ref_osc);// get current correction value
					bool updt = false;
					switch (butNo){
					case 0:  //hang time -
						if(TRHangTime>=5) TRHangTime -= 5;
						if(TRHangTime<=TXdelay) TRHangTime += 5;
						tftmsgbx.ShwHT(int(TRHangTime));
						ShwSlctdTimeBtn(butNo);
						delay(50);
						break;
					case 1:  //hang time +
						TRHangTime += 5;
						if(TRHangTime>250) TRHangTime -= 5;
						tftmsgbx.ShwHT(int(TRHangTime));
						ShwSlctdTimeBtn(butNo);
						delay(50);
						break;
					case 2: //TX delay -
						if(TXdelay != 0) TXdelay -= 1;;
						tftmsgbx.ShwDly(int(TXdelay));
						ShwSlctdTimeBtn(butNo);
						delay(50);
						break;
					case 3: //TX delay -
						TXdelay += 1;
						if(TXdelay>60) TXdelay -= 1;
						tftmsgbx.ShwDly(int(TXdelay));
						if(TXdelay>TRHangTime){
							TRHangTime += 1;
							tftmsgbx.ShwHT(int(TRHangTime));
						}
						ShwSlctdTimeBtn(butNo);
						delay(50);
						break;

					case 4://exit SDR_Timing Screen
						testing = false;//LO+SR/2
						FinTune = false;
						si5351.output_enable(SI5351_CLK2, 0);//Disable TX clock/oscillator
						break;
					}
				}
			}
		}

		/*check * update FLDIGI info requests*/
		if(updtFLDIGI){
			if(GetRmtCmd()){//check in with FLDIGI (function found in SDR_Si5351r01.cpp)
				updtFLDIGI = false;//Fldigi has been updated; No longer need to do this
			}
		}
	}
}


void BldTimingBtns(void){
	int btnHght = 39;
	int btnWdthS = 40;
	int btnWdthL = (3*btnWdthS)+2;
	int row0;
	int row1;
	int row2;
	int row3;
	int row4;
	int row5; //band buttons
	row0 = int(scrnHeight/2) - (btnHght + 1);//Just above center Screen
	row1 = row0 + (btnHght + 1);//Just below center Screen
	row2 = row1 + (btnHght + 1);
	row3 = row2 + (btnHght + 1);
	row4 = scrnHeight - (5*btnHght + 1);
	row5 = row0 - (btnHght + 1);


	int BtnNo = 0;
	TimingBtns[BtnNo].BtnXpos = 0;//130;  //Button X position
	TimingBtns[BtnNo].BtnWdth = btnWdthL;;//80;  //Button Width
	TimingBtns[BtnNo].BtnHght =btnHght;
	TimingBtns[BtnNo].BtnYpos = row2;// scrnHeight - (TimingBtns[0].BtnHght + 5);  //Button Y position
	TimingBtns[BtnNo].Captn = "HangTime-";
	TimingBtns[BtnNo].BtnClr = TFT_BLACK;
	TimingBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 1;
	TimingBtns[BtnNo].BtnXpos = TimingBtns[BtnNo-1].BtnXpos+(btnWdthL+1);
	TimingBtns[BtnNo].BtnWdth = btnWdthL;//TimingBtns[0].BtnWdth;  //Button Width
	TimingBtns[BtnNo].BtnHght = btnHght;//TimingBtns[0].BtnHght;
	TimingBtns[BtnNo].BtnYpos = row2;//TimingBtns[0].BtnYpos;  //Button Y position
	TimingBtns[BtnNo].Captn = "HangTime+";
	TimingBtns[BtnNo].BtnClr = TFT_BLACK;
	TimingBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 2;
	TimingBtns[BtnNo].BtnXpos = 0;
	TimingBtns[BtnNo].BtnWdth = btnWdthL;//TimingBtns[0].BtnWdth;  //Button Width
	TimingBtns[BtnNo].BtnHght = btnHght;//TimingBtns[0].BtnHght;
	TimingBtns[BtnNo].BtnYpos = row1;//TimingBtns[0].BtnYpos;  //Button Y position
	TimingBtns[BtnNo].Captn = "TX Delay-";
	TimingBtns[BtnNo].BtnClr = TFT_BLACK;
	TimingBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 3;
	TimingBtns[BtnNo].BtnXpos = TimingBtns[BtnNo-1].BtnXpos+(btnWdthL+1);
	TimingBtns[BtnNo].BtnWdth = btnWdthL;//TimingBtns[0].BtnWdth;  //Button Width
	TimingBtns[BtnNo].BtnHght = btnHght;//TimingBtns[0].BtnHght;
	TimingBtns[BtnNo].BtnYpos = row1;//TimingBtns[0].BtnYpos;  //Button Y position
	TimingBtns[BtnNo].Captn = "TX Delay+";
	TimingBtns[BtnNo].BtnClr = TFT_BLACK;//TFT_DARKCYAN;
	TimingBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 4; //hidden 'Go Home' Button
	TimingBtns[BtnNo].BtnXpos = 0;
	TimingBtns[BtnNo].BtnWdth = 285;
	TimingBtns[BtnNo].BtnHght = int(btnHght);
	TimingBtns[BtnNo].BtnYpos = 2;
	TimingBtns[BtnNo].Captn = "";
	TimingBtns[BtnNo].BtnClr = TFT_BLACK;
	TimingBtns[BtnNo].TxtClr = TFT_BLACK;


	for(int i=0; i<BtnCnt-1; i++){//Don't draw the last button. Its a "hidden" button
		BldBtn(i, TimingBtns); // Build the SetUp Button Set
		delay(20);
	}
//	ShwSlctdTimeBtn(10); //Hilight the "Tst" button
}
///////////////////////////////////////////////////////////////////////////////////////////////
void ShwSlctdTimeBtn(int BtnNo){
	for(int i=0; i<BtnCnt-1; i++){//for(int i=10; i<12; i++){
		if(BtnNo!= i){
			TimingBtns[i].BtnClr = TFT_BLACK;
		}else{
			TimingBtns[i].BtnClr = TFT_GREEN;
		}
		BldBtn(i, TimingBtns); // Build the SDR_Timing Button Set
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////
//void ApplyNewPhase(bool IncPhaseError){
//	if(IncPhaseError)PhasCorect += DPhasCor;
//	else PhasCorect -= DPhasCor;
//	if(PhasCorect>= maxPhasErr){
//		PhasCorect = maxPhasErr;
//	}
//	if(PhasCorect<= -maxPhasErr){
//		PhasCorect = -maxPhasErr;
//	}
//	ICFactr = (arm_sin_f32((TwoPi/360)*PhasCorect));
//	QCFactr = AmpFactor;
//	ShwTPhzCorr();
//}

///////////////////////////////////////////////////////////////////////////////////////////////
//void ApplyNewAmpGainEr(bool IncGainError){
//	if(IncGainError)AmpError += DampCor;
//	else AmpError -= DampCor;
//	if(AmpError >= maxAmpEr){
//		AmpError = maxAmpEr;
//	}
//	if(AmpError <= -maxAmpEr){
//		AmpError = -maxAmpEr;
//	}
//	AmpFactor =(1.0+ AmpError);
//	ICFactr = (arm_sin_f32((TwoPi/360)*PhasCorect));
//	QCFactr = AmpFactor;
//	ShwTAmpCorr();
//
//}

///////////////////////////////////////////////////////////////////////////////////////////////
void ShwTmtr(void){

	int lineLen;
	int row0 = int(scrnHeight/2) - (40);
	int row1 = row0 -20;
	uint32_t Clr;
	float32_t DBm = -20 * __builtin_log10f(DemodGain/0.003);
	/*Draw a bar whose length is proportional to the current dbm value*/
	int Dbm_int = int(7*(119+DBm));//'119' is the no sig noise floor
	if(Dbm_int != OldTDBMx){
		/* IF Mag < last time, We need to erase the difference */
		lineLen = (Dbm_int - OldTDBMx);
		if(lineLen < 0) Clr = TFT_BLACK;
		else Clr = TFT_RED;
		for (int i =0; i<5; i++){
			tft.drawFastHLine(OldTDBMx, row1-i, lineLen, Clr);
		}
		OldTDBMx = Dbm_int;
	}
	/*convert DBm value to S meter value (based on -73DBm = S9) */
	int Smtr = 9;
	int SdbmREf = -73;
	while((SdbmREf-0.05)> DBm){
		SdbmREf -=6;
		Smtr--;
	}
	DBm = DBm-SdbmREf;
	if(DBm < 0.0) DBm = 0.0;
	ShwTmtr(Smtr, DBm);
}
//////////////////////////////////////////////////////////////////////////////////////////////
//void ShwTPhzCorr(void){
//	sprintf(Title,"TXdly:%dms; TRHangTime:%dms ", TXdelay, TRHangTime);
//	tftmsgbx.dispTitl(Title, TFT_YELLOW);
//}
////////////////////////////////////////////////////////////////////////////////////////////
//void ShwTAmpCorr(void){
//	//sprintf(Title,"TXdly:%dms; TRHangTime:%dms ", TXdelay, TRHangTime);
//	tftmsgbx.ShwDly(int(TXdelay));
//}
////////////////////////////////////////////////////////////////////////////////////////////
void ShwTmtr(int Smtr, float DBm){
sprintf( Title, "S%d %.1fdB", Smtr, DBm);
tftmsgbx.SigSmtr(Title, TFT_GREEN);
}
/////////////////////////////////////////////////////////////////////////////////////////
//void ChkMode(float SideTonefreq){
//	float offset = float(Balrxcenter - Baltxfreq);
//	//float SideTonefreq = 750;
//	float ImageTuneFreq = -offset +SideTonefreq;
//	LO_Phase_Shift = (ImageTuneFreq/samp_rate)*TwoPi;
//	tftmsgbx.TuneFreq(int(Balrxcenter+offset), 0); //int(SideTonefreq)
//}
//void CalMode(float SideTonefreq){
//	LO_Phase_Shift = ((Balrxcenter-(CwTunefreq))/samp_rate)*TwoPi;
//	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
//}



