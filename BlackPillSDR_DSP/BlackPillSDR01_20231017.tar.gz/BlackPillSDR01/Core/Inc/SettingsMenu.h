/*
 * SettingsMenu.h
 *
 *  Created on: Jul 12, 2022
 *      Author: jim
 */

#ifndef INC_SETTINGSMENU_H_
#define INC_SETTINGSMENU_H_

struct DF_t {
	int XP=PB6;
	int XM=PA7;
	int YP=PA6;
	int YM=PB7;
    int TS_LEFT;
    int TS_RT;
    int TS_TOP;
    int TS_BOT;
    int scrnHeight;
    int scrnWidth;
    int XtalErr;
    float samp_rate;
    unsigned long TXdelay; //millisecond delay in applying Si5351 TX ON/ TX OFF commands
    unsigned long TRHangTime;
    float Volume;
    float SideTonefreq;
};
typedef struct {
	int rxcenter;
	int SideTonefreq;
	int CwTunefreq;
	bool UpFFTflg;
	int ButtonNo;
	int FltrOpt;
	float PhasCorect;
	float AmpFactor;
	bool FFTWide;
	int DmodMode;
} BandConfig_t;
extern BandConfig_t BandSetting[5];
void Menu_MainLoop(int rxcenter, int txfreq, int SamplRateInt, float SideTonefreq);



#endif /* INC_SETTINGSMENU_H_ */
