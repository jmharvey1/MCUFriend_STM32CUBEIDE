/*
 * TFTMsgBox.h
 *
 *  Created on: Oct 7, 2021
 *      Author: jim
 */

#ifndef INC_TFTMSGBOX_H_
#define INC_TFTMSGBOX_H_
#include "stdint.h"
#include "main.h"
#include "MCUFRIEND_kbv.h"

#define RingBufSz 400

class TFTMsgBox
{
private:
	char RingbufChar[RingBufSz];
	uint16_t RingbufClr[RingBufSz];
	char Pgbuf[448];
	uint16_t PgbufColor[448];
	char Msgbuf[50];
	char OlDStat[50];
	char OlDSmtr[10];
	int StatMsgStrt=0;
	int TitlMsgStrt = 0;
	int txtpos;
	int RingbufPntr1;
	int RingbufPntr2;
	int displayW;
	int displayH;
	int CPL; //number of characters each line that a 3.5" screen can contain
	int row; //number of uable rows on a 3.5" screen
	int fontH;
	int fontW;
	int CursorPntr;
	int cursorY;
	int cursorX;
	int StatusY = 300;
	int StatusX = 100;
	int SmtrY;
	int SmtrX;
	int cnt; //used in scrollpage routine
	int curRow;
	int offset;
	int BlkStateVal[5];
	int BlkStateCntr;
	bool BlkState;
	bool SOTFlg;
	bool StrTxtFlg;
	MCUFRIEND_kbv *ptft;
	char *pStrdTxt;
	void scrollpg(void);
	void HiLiteBG(void);
	void RestoreBG(void);
	void PosHiLiteCusr(void);

public:
	TFTMsgBox( MCUFRIEND_kbv *tft_ptr, char *StrdTxt);
	void InitDsplay(void);
	void KBentry(char Ascii);
	void Delete(int ChrCnt);
	void dispMsg(char Msgbuf[50], uint16_t Color);
	void dispMsg2(void);
	void DisplCrLf(void);
	void IntrCrsr(int state);
	void dispStat(char Msgbuf[50], uint16_t Color);
	void dispTitl(char TitlTxt[], uint16_t Color);
	void SigSmtr(char Msgbuf[50], uint16_t Color);
	void LOFreq(int LoFreq);
	void setSOTFlg(bool flg);
	void setStrTxtFlg(bool flg);

};




#endif /* INC_TFTMSGBOX_H_ */
