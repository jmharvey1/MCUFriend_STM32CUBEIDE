/*
 * SettingsMenu.cpp
 *
 *  Created on: Jul 12, 2022
 *      Author: jim
 * 20220721 Added EEprom Save/load parameters/settings to menu options list
 */

#include "main.h"//contains BtnParams definition
#include "CalSI5351Freq.h"
#include "BallanceMixer.h"
#include "TchScrnCal.h"
#include "SettingsMenu.h"
#include "SDR_Si5351r01.h"//added to support "readResistiveTouch()" call
#include "TFTMsgBox.h"
#include "arm_const_structs.h"// needed to support float32_t type definition
#include "MCUFRIEND_kbv.h" // need this to support TFT colors
#include "Arduino.h"
#include "si5351.h"
#include <eeprom.h>
const int BtnCnt = 5;
BtnParams OtpnsBtns[BtnCnt];
void BldOptnsButtons(void);
void ShwSlctdOptnBtn(int BtnNo);
void SaveUsrVals(void);
template <class T>
int EEPROM_write(uint16_t ee, const T& value)
{
   //const byte* p = (const byte*)(const void*)&value;
   const uint16_t* p = (const uint16_t*)(const void*)&value;
   int i=0;
   while (i < sizeof(value)){
       //EEPROM.write(ee++, *p++);
	   EE_WriteVariable(ee, *p);
   	   ee +=2;
   	   i +=2;
   	   p++;// +=2;
   }
   return i;
}
/**
 * @brief  The application entry point.
 *
 */
void Menu_MainLoop(int rxcenter, int txfreq, int SamplRateInt, float SideTonefreq )
{

	char RevDate[9]  = "20220712";
	/* begin touchscreen setup*/
	tftmsgbx = TFTMsgBox(&tft, StrdTxt);
	tftmsgbx.InitDsplay();
	sprintf( Title, "OPTIONS(%s)\n", RevDate );
	tftmsgbx.dispTitl(Title, TFT_CYAN);
	BldOptnsButtons();
	/* Start Sound Board DMA to begin IQ capture and stream demodulated audio */
	delay(50);
	//sprintf(Title,"Err: %d",XtalErr);
	//tftmsgbx.dispTitl(Title, TFT_YELLOW);//for testing only
	/* Install Narrow audio filter */
	//	ZeroBtFltr();
	//FreqCalMode = true;
	bool testing = true;
	bool updtFLDIGI = true;
	int py;
	int px;
	FinTune = true;
	//	int oldDemodFreq = 0;
	while (testing)
	{
		delay(50);
		if (GetTouchPts(px, py) > 150 ) {
			/* check/test Band Buttons */
			for (int butNo = 0; butNo < BtnCnt; butNo++){
				if(BtnActive(butNo, OtpnsBtns, px, py)){
					bool updt = false;
					switch (butNo){
					case 0:
						ShwSlctdOptnBtn(butNo);
						CalFreq_MainLoop(SideTonefreq);
						testing = false;
						break;
					case 1:
						ShwSlctdOptnBtn(butNo);
						BalMixr_MainLoop(rxcenter, txfreq, SamplRateInt, SideTonefreq);
						testing = false;
						break;
					case 2://exit button
						ShwSlctdOptnBtn(butNo);
						testing = false;
						break;
					case 3:
						ShwSlctdOptnBtn(butNo);
						tftmsgbx.setTxtSize(0);
						TchScrnCal_MainLoop();
						tftmsgbx.setTxtSize(2);
						testing = false;
						break;
					case 4:
						ShwSlctdOptnBtn(4);
						SaveUsrVals();
						delay(200);
						testing = false;
						break;
//					case 11: //Check
//						ShwSlctdOptnBtn(butNo);
//						ChkMode();
//						break;
//					case 15://exit Ballance Mixer process
//						testing = false;//LO+SR/2
//						FinTune = false;
//						si5351.output_enable(SI5351_CLK2, 0);//Disable TX clock/oscillator
						break;
					}
				}
			}
		}

		/*check * update FLDIGI info requests*/
	}
}


void BldOptnsButtons(void){
	int btnHght = 39;
	int btnWdthS = 40;
	int btnWdthL = 140;
	int row0;
	int row1;
	int row2;
	int row3;
	int row4;
	int row5; //band buttons
	row0 = int(scrnHeight/2) - (btnHght + 1);//Just above center Screen
	row1 = row0 + (btnHght + 1);//Just below center Screen
	row2 = row1 + (btnHght + 1);
	row3 = row2 + (btnHght + 1);
	row4 = scrnHeight - (5*btnHght + 1);
	row5 = row0 - (btnHght + 1);
	int BtnNo = 0;
	//Exit Button 0
	OtpnsBtns[BtnNo].BtnXpos = 0;
	OtpnsBtns[BtnNo].BtnWdth = btnWdthL;//80;  //Button Width
	OtpnsBtns[BtnNo].BtnHght =btnHght;
	OtpnsBtns[BtnNo].BtnYpos = row0;
	OtpnsBtns[BtnNo].Captn = "Cal Si5351";
	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 1;
	OtpnsBtns[BtnNo].BtnXpos = 0;
	OtpnsBtns[BtnNo].BtnWdth = btnWdthL;//OtpnsBtns[0].BtnWdth;  //Button Width
	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
	OtpnsBtns[BtnNo].BtnYpos = row1;//OtpnsBtns[0].BtnYpos;  //Button Y position
	OtpnsBtns[BtnNo].Captn = "Bal Mixer";
	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 2;
	OtpnsBtns[BtnNo].BtnXpos = 0;
	OtpnsBtns[BtnNo].BtnWdth = btnWdthL;//OtpnsBtns[0].BtnWdth;  //Button Width
	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
	OtpnsBtns[BtnNo].BtnYpos = row2;//OtpnsBtns[0].BtnYpos;  //Button Y position
	OtpnsBtns[BtnNo].Captn = "   EXIT";
	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 3;
	OtpnsBtns[BtnNo].BtnXpos = btnWdthL;
	OtpnsBtns[BtnNo].BtnWdth = btnWdthL;//OtpnsBtns[0].BtnWdth;  //Button Width
	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
	OtpnsBtns[BtnNo].BtnYpos = row0;//OtpnsBtns[0].BtnYpos;  //Button Y position
	OtpnsBtns[BtnNo].Captn = "Cal Tch Scrn";
	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 4;
	OtpnsBtns[BtnNo].BtnXpos = btnWdthL;
	OtpnsBtns[BtnNo].BtnWdth = btnWdthL;//OtpnsBtns[0].BtnWdth;  //Button Width
	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
	OtpnsBtns[BtnNo].BtnYpos = row1;//OtpnsBtns[0].BtnYpos;  //Button Y position
	OtpnsBtns[BtnNo].Captn = "SAVE SETTINGS";
	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;

//	BtnNo = 5;
//	OtpnsBtns[BtnNo].BtnXpos = 0;
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row3;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "V-";
//	OtpnsBtns[BtnNo].BtnClr = TFT_ORANGE;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	/* Band Buttons */
//	BtnNo = 6;
//	OtpnsBtns[BtnNo].BtnXpos = 0;
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row5;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "Dec";
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	BtnNo = 7;
//	OtpnsBtns[BtnNo].BtnXpos = OtpnsBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row5;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "Inc";
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;//TFT_DARKCYAN;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	BtnNo = 8;
//	OtpnsBtns[BtnNo].BtnXpos = OtpnsBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row5;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "G-";
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	BtnNo = 9;
//	OtpnsBtns[BtnNo].BtnXpos = OtpnsBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row5;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "G+";
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	BtnNo = 10;
//	OtpnsBtns[BtnNo].BtnXpos = OtpnsBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row5;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "Cal";
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	/*Filter Buttons*/
//	BtnNo = 11;
//	OtpnsBtns[BtnNo].BtnXpos = OtpnsBtns[BtnNo-1].BtnXpos+(int((btnWdthS+1)));
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row5;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "Chk";1
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	BtnNo = 12;
//	OtpnsBtns[BtnNo].BtnXpos = OtpnsBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row5;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "fM";
//	OtpnsBtns[BtnNo].BtnClr = TFT_GREEN;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	BtnNo = 13;
//	OtpnsBtns[BtnNo].BtnXpos = OtpnsBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;//OtpnsBtns[0].BtnWdth;  //Button Width
//	OtpnsBtns[BtnNo].BtnHght = btnHght;//OtpnsBtns[0].BtnHght;
//	OtpnsBtns[BtnNo].BtnYpos = row5;//OtpnsBtns[0].BtnYpos;  //Button Y position
//	OtpnsBtns[BtnNo].Captn = "fN";
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	BtnNo = 14;
//	OtpnsBtns[BtnNo].BtnXpos = lastbin;
//	OtpnsBtns[BtnNo].BtnWdth = btnWdthS;
//	OtpnsBtns[BtnNo].BtnHght = int(btnHght/2);
//	OtpnsBtns[BtnNo].BtnYpos = row1-int(btnHght/4);
//	OtpnsBtns[BtnNo].Captn = "=0";
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
//	OtpnsBtns[BtnNo].TxtClr = TFT_WHITE;
//	BtnNo = 15;
//	OtpnsBtns[BtnNo].BtnXpos = 0;
//	OtpnsBtns[BtnNo].BtnWdth = 285;
//	OtpnsBtns[BtnNo].BtnHght = int(btnHght);
//	OtpnsBtns[BtnNo].BtnYpos = 2;
//	OtpnsBtns[BtnNo].Captn = "";
//	OtpnsBtns[BtnNo].BtnClr = TFT_BLACK;
//	OtpnsBtns[BtnNo].TxtClr = TFT_BLACK;


	for(int i=0; i<BtnCnt; i++){
		BldBtn(i, OtpnsBtns); // Build the SetUp Button Set
		delay(20);
	}
//	ShwSlctdOptnBtn(10); //Hilight the "Tst" button
}
///////////////////////////////////////////////////////////////////////////////////////////////
void ShwSlctdOptnBtn(int BtnNo){
	for(int i=0; i< BtnCnt; i++){
		if(BtnNo!= i){
			OtpnsBtns[i].BtnClr = TFT_BLACK;
		}else{
			OtpnsBtns[i].BtnClr = TFT_GREEN;
		}
		BldBtn(i, OtpnsBtns); // Build the SetUp Button Set
	}
	delay(200);
}
void SaveUsrVals(void){
	/* Unlock the Flash Program Erase controller */
	FLASH_Unlock();
	/* EEPROM Init */
	uint16_t reslt = EE_Init();
	if (reslt != fLASH_COMPLETE){
		sprintf(Title, "EE_Init() ERROR: %d", reslt);
		tftmsgbx.dispMsg(Title, TFT_RED);
		while(1);
	}

	int	n;
	int offset = 0;

	n = EEPROM_write(EEaddress+(offset),TS_BOT);
	offset += 2*n;
	n= EEPROM_write(EEaddress+offset, TS_LEFT);
	offset += 2*n;
	n = EEPROM_write(EEaddress+(offset), TS_TOP);
	offset += 2*n;
	n = EEPROM_write(EEaddress+(offset), TS_RT);
	offset += 2*n;
	n= EEPROM_write(EEaddress+offset, XM);
	offset += 2*n;
	n = EEPROM_write(EEaddress+(offset), XP);
	offset += 2*n;
	n= EEPROM_write(EEaddress+offset, YM);
	offset += 2*n;
	n= EEPROM_write(EEaddress+offset, YP);
	offset += 2*n;
	n= EEPROM_write(EEaddress+offset, scrnHeight);
	offset += 2*n;
	n = EEPROM_write(EEaddress+(offset), scrnWidth);
	offset += 2*n;
	n= EEPROM_write(EEaddress+offset, XtalErr);
	offset += 2*n;
	n= EEPROM_write(EEaddress+offset, samp_rate);
	offset += 2*n;
	for(int i = 0; i<4; i++){
		n= EEPROM_write(EEaddress+offset, BandSetting[i].CwTunefreq);
		offset += 2*n;
		n= EEPROM_write(EEaddress+offset, BandSetting[i].SideTonefreq);
		offset += 2*n;
		n= EEPROM_write(EEaddress+offset,BandSetting[i].UpFFTflg);
		offset += 2*n;
		n= EEPROM_write(EEaddress+offset, BandSetting[i].PhasCorect);
		offset += 2*n;
		n= EEPROM_write(EEaddress+offset, BandSetting[i].AmpFactor);
		offset += 2*n;
	}
	FLASH_Lock();
	sprintf(Title, "User Params SAVED");
	tftmsgbx.dispStat(Title, TFT_GREEN);
}


