/*
 * CalSI5351Freq.cpp
 *
 *  Created on: Jul 5, 2022
 *      Author: jim
 */

#include "main.h"//contains BtnParams definition
//#include "TchScrnCal.h"
#include "CalSI5351Freq.h"
//#include "filter.h"
#include "SDR_Si5351r01.h"//added to support "readResistiveTouch()" call
#include "TFTMsgBox.h"
//#include "arm_math.h"
#include "arm_const_structs.h"// needed to support float32_t type definition
//#include "usb_device.h"
//#include "usbd_cdc_if.h"
//#include <stdio.h>
//#include <math.h>
//#include <stdbool.h>
#include "MCUFRIEND_kbv.h" // need this to support TFT colors
//#include "Adafruit_GFX.h"
//#include "STM32F411def.h"
//#include "TouchScreen_kbv.h"
#include "Arduino.h"
//#include "SerialClass.h"
//#include <complex.h> //needed to support cabs()
#include "si5351.h"
const int BtnCnt = 16;
BtnParams FreqCalBtns[BtnCnt];
void BldFreqButtons(void);
void ShwSlctdCalBtn(int BtnNo);
//void SetUPFIR1(const __complex__ float *Fltr, size_t TapCnt);
//void BldBtn(int BtnNo, BtnParams Btns[]);
/**
 * @brief  The application entry point.
 *
 */
void CalFreq_MainLoop(float SideTonefreq)
{

	char RevDate[9]  = "20220705";
	si5351.pll_reset(SI5351_PLLA);//*
//	SetRX = true;
//	SetTX = false;
	int rxcenter = 10010000;
	txfreq = 10000000;
//	float SideTonefreq = 750;
	CwTunefreq = float(txfreq) - SideTonefreq;
	sendFrequency(float(rxcenter));
	LO_Phase_Shift = ((rxcenter-(CwTunefreq))/samp_rate)*TwoPi;
	/* begin touchscreen setup*/
	tftmsgbx = TFTMsgBox(&tft, StrdTxt);
	tftmsgbx.InitDsplay();
	sprintf( Title, "Cal Si5351 XtlFrq(%s)\n", RevDate );
	tftmsgbx.dispTitl(Title, TFT_CYAN);
	tftmsgbx.LOFreq(rxcenter);
	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
	BldFreqButtons();
	/* Start Sound Board DMA to begin IQ capture and stream demodulated audio */
	HAL_I2SEx_TransmitReceive_DMA(&hi2s2, txBuf, rxBuf, decimate_factor*4);
	delay(500);
	sprintf(Title,"Err: %d",XtalErr);
	tftmsgbx.dispTitl(Title, TFT_YELLOW);//for testing only
	/* Install Narrow audio filter */
	ZeroBtFltr(); //removed because it slowed the display & touch response
	FreqCalMode = true;
	bool testing = true;
	bool updtFLDIGI = true;
	int py;
	int px;
	FinTune = true;
	int oldDemodFreq = 0;
	while (testing)
	{
		delay(50);
		if((DemodFreq != oldDemodFreq) &&(DemodFreq>0) ){
			oldDemodFreq = DemodFreq;
			sprintf( Title, "DmodErr %dHz", (oldDemodFreq- int(SideTonefreq)));
			tftmsgbx.SigSmtr(Title, TFT_GREEN);
		}
		//readResistiveTouch();
		if (GetTouchPts(px, py) > 150 ) {
			/* check/test Band Buttons */
			for (int butNo = 0; butNo < BtnCnt; butNo++){
				if(BtnActive(butNo, FreqCalBtns, px, py)){
					FreqCalMode = false;
					/*Found selected Band button; restore last setting(s) for this band*/
					XtalErr = si5351.get_correction(si5351.plla_ref_osc);// get current correction value
					bool updt = false;
					switch (butNo){
					case 6:
						XtalErr += 1000;
						updt = true;
						break;
					case 7:
						XtalErr += 500;
						updt = true;
						break;
					case 8:
						XtalErr += 100;
						updt = true;
						break;
					case 9:
						XtalErr -= 100;
						updt = true;
						break;
					case 10:
						XtalErr -= 500;
						updt = true;
						break;
					case 11:
						XtalErr -= 1000;
						updt = true;
						break;
					case 15://exit xtal calibrate process
						testing = false;//LO+SR/2
						FinTune = false;
						break;
					}
					if(updt){
						ShwSlctdCalBtn(butNo);
						sprintf(Title,"Err: %d",XtalErr);
						si5351.set_correction(XtalErr ,si5351.plla_ref_osc);
						tftmsgbx.dispTitl(Title, TFT_YELLOW);//for testing only
					}
					FreqCalMode = true;
				}
			}
		}

		/*check * update FLDIGI info requests*/
		if(updtFLDIGI){
			if(GetRmtCmd( Cmd)){//check in with FLDIGI (function found in SDR_Si5351r01.cpp)
				updtFLDIGI = false;//Fldigi has been updated; No longer need to do this
				//tftmsgbx.dispTitl(Cmd, TFT_CYAN);//for testing only
			}
		}
	}
	FreqCalMode = false;
}


void BldFreqButtons(void){
	int btnHght = 39;
	int btnWdthS = 40;
	int btnWdthL = 2*btnWdthS;
	int row0;
	int row1;
	int row2;
	int row3;
	int row4;
	int row5; //band buttons
	row0 = int(scrnHeight/2) - (btnHght + 1);//Just above center Screen
	row1 = row0 + (btnHght + 1);//Just below center Screen
	row2 = row1 + (btnHght + 1);
	row3 = row2 + (btnHght + 1);
	row4 = scrnHeight - (5*btnHght + 1);
	row5 = row0 - (btnHght + 1);
	int BtnNo = 0;
	//Exit Button 0
	FreqCalBtns[BtnNo].BtnXpos = 0;
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//80;  //Button Width
	FreqCalBtns[BtnNo].BtnHght =btnHght;
	FreqCalBtns[BtnNo].BtnYpos = row0;
	FreqCalBtns[BtnNo].Captn = "LO+SR/2";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 1;
	FreqCalBtns[BtnNo].BtnXpos = 0;
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row1;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "LO-SR/2";
	FreqCalBtns[BtnNo].BtnClr = TFT_GREEN;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	int lastbin = 130;
	BtnNo = 2;
	FreqCalBtns[BtnNo].BtnXpos = lastbin;  //Button X position
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//80;  //Button Width
	FreqCalBtns[BtnNo].BtnHght =btnHght;
	FreqCalBtns[BtnNo].BtnYpos = row0-int(btnHght/4);// scrnHeight - (FreqCalBtns[0].BtnHght + 5);  //Button Y position
	FreqCalBtns[BtnNo].Captn = "^^";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLUE;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 3;
	FreqCalBtns[BtnNo].BtnXpos = lastbin;
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row1+int(btnHght/4);//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "vv";
	FreqCalBtns[BtnNo].BtnClr = TFT_RED;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 4;
	FreqCalBtns[BtnNo].BtnXpos = 0;//130;  //Button X position
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//80;  //Button Width
	FreqCalBtns[BtnNo].BtnHght =btnHght;
	FreqCalBtns[BtnNo].BtnYpos = row2;// scrnHeight - (FreqCalBtns[0].BtnHght + 5);  //Button Y position
	FreqCalBtns[BtnNo].Captn = "V+";
	FreqCalBtns[BtnNo].BtnClr = TFT_ORANGE;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 5;
	FreqCalBtns[BtnNo].BtnXpos = 0;
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row3;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "V-";
	FreqCalBtns[BtnNo].BtnClr = TFT_ORANGE;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	/* Band Buttons */
	BtnNo = 6;
	FreqCalBtns[BtnNo].BtnXpos = 0;
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row5;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "-10";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 7;
	FreqCalBtns[BtnNo].BtnXpos = FreqCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row5;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "-5";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;//TFT_DARKCYAN;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 8;
	FreqCalBtns[BtnNo].BtnXpos = FreqCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row5;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "-1";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 9;
	FreqCalBtns[BtnNo].BtnXpos = FreqCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row5;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "+1";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 10;
	FreqCalBtns[BtnNo].BtnXpos = FreqCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row5;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "+5";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	/*Filter Buttons*/
	BtnNo = 11;
	FreqCalBtns[BtnNo].BtnXpos = FreqCalBtns[BtnNo-1].BtnXpos+(int((btnWdthS+1)));
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row5;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "+10";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 12;
	FreqCalBtns[BtnNo].BtnXpos = FreqCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row5;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "fM";
	FreqCalBtns[BtnNo].BtnClr = TFT_GREEN;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 13;
	FreqCalBtns[BtnNo].BtnXpos = FreqCalBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;//FreqCalBtns[0].BtnWdth;  //Button Width
	FreqCalBtns[BtnNo].BtnHght = btnHght;//FreqCalBtns[0].BtnHght;
	FreqCalBtns[BtnNo].BtnYpos = row5;//FreqCalBtns[0].BtnYpos;  //Button Y position
	FreqCalBtns[BtnNo].Captn = "fN";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 14;
	FreqCalBtns[BtnNo].BtnXpos = lastbin;
	FreqCalBtns[BtnNo].BtnWdth = btnWdthS;
	FreqCalBtns[BtnNo].BtnHght = int(btnHght/2);
	FreqCalBtns[BtnNo].BtnYpos = row1-int(btnHght/4);
	FreqCalBtns[BtnNo].Captn = "=0";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 15;
	FreqCalBtns[BtnNo].BtnXpos = 0;
	FreqCalBtns[BtnNo].BtnWdth = 285;
	FreqCalBtns[BtnNo].BtnHght = int(btnHght);
	FreqCalBtns[BtnNo].BtnYpos = 2;
	FreqCalBtns[BtnNo].Captn = "";
	FreqCalBtns[BtnNo].BtnClr = TFT_BLACK;
	FreqCalBtns[BtnNo].TxtClr = TFT_BLACK;


	for(int i=4; i<12; i++){
		BldBtn(i, FreqCalBtns); // Build the SetUp Button Set
		delay(20);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////
void ShwSlctdCalBtn(int BtnNo){
	for(int i=6; i<12; i++){
		if(BtnNo!= i){
			FreqCalBtns[i].BtnClr = TFT_BLACK;
		}else{
			FreqCalBtns[i].BtnClr = TFT_GREEN;
		}
		BldBtn(i, FreqCalBtns); // Build the SetUp Button Set
		//delay(20);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////
