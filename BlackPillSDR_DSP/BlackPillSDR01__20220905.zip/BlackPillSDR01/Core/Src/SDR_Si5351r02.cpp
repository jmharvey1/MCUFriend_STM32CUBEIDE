/*
 * SDR_Si5351r02.cpp
 *
 *  Created on: Jul 20, 2022
 *      Author: jim
 */

/*
* SDR_Si5351r01.cpp
*
*  Created on: Feb 13, 2022
*  Author: jim(KW4KD)
*  This version features FFT display, USSB Demodulation, Freq control via i2c3 link to si5351,
*  4 band selection, T/R relay Control, & Manual Key input
*  This version exploits the Built-in special computational features486 of the
*  Arm Cortext M4 Processor and the DSP functions found in the STM32F411 processor
*  This project was last compiled using STM32CubeIDE:
*  Version: 1.9.0
*  Build: 12015_20220302_0855 (UTC)
******************************************************************************
* @file           : SDR_Si5351r01.cpp
* @brief          : Main program body
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
* All rights reserved.</center></h2>
*
* This software component is licunsigned long TnPrdStrtensed by ST under BSD 3-Clause license,
* the "License"; You may not use this file except in compliance with the
* License. You may obtain a copy of the License at:
* opensource.org/licenses/BSD-3-Clause
*
******************************************************************************
*    Notes:
*        - Under "Options for target" > "C/C++" > "Define" you must add 2 defines (I've already add them):
*            - ARM_MATH_CM4 // Do this below -JMH
*            - __FPU_PRESENT=1 //stm32f411xe.h does this -JMH
* 	to line 939 of stm32f4xx_hal_i152s_ex.c
* 	add the following entry:
*   	HAL_I2SEx_TxRxCpltCallback(hi2s);//JMH 20210122 added per video
*  	Note: located in Drivers/STM32F4xx_HAL_Driver/Src folder.
******************************************************************************
*/
/* 20220227 converted sig reading (gain value) to S meter reading */
/* 20220228 Added memory2memory DMA method to decrease I2S interrupt execution time */
/* 20220301 Refined Button timing to make tuning easier to manage & modified TFTMsgBox.cpp file to solve display issue */
/* 20220302- replaced old show tune code with new tftmsgbx.TuneFreq(int RxFreq)" method */
/* 20220303 Added 2nd audio filter option via GUI (W= 1000Hz / N=500Hz) */
/* 20220304 Added WWV band Option */
/* 20220305 Added freq tune memory & band default setting to band buttons */
/* 20220309 Fixed issue with Selected Band getting lost when filter option changed */
/* 20220321 Fixed S meter not incrementing @ +6.0db; FFT view not following band changes */
/* 20220322 Added "Auto zero beat" Screen touches inside FFT zone */
/* 20220323 modified KeyEvntSR() routine to stop audio squeal*/
/* 20220327 Added 2nd layer to Auto-Zero beat routine; Now samples audio for 30
 * periods, and derives tone freq, to further "zero in" on the actual far
 * end carrier frequency */
/* 20220328 Changed gain calculation method to reduce side-tone clipping */
/* 20220331 Added Zero Beat Button & refined Zero Beat/ fine-tune routine */
/* 20220404 Added limited SDR->FLDIGI RigCatcontrol support */
/* 20220409 Added Frequency Tick marks to FFT display  */
/* 20220510 Added Fix for 2.8"displays that report their ID as "0xD3D3"  */
/* 20220519 Adjusted tp.z (touch sensitivity) to better capture left side of FFT space
 * 20220617 Minor code change to GenSideTone function to reduce keyclicks in output audio
 * 20220625 changed auto-tune to calc tone freq from raw audio output; not volume adjusted audio
 * 20220704 Added touch screen calibration as part of setup/config option
 * 20220705 Starting add of si5351 feq calibration settings screen
 * 20220706 Basic functionality of si5351 feq calibration settings screen
 * 20220713 Added Mixer Balance Setup/configure parameters; uses clk2 as reference injection signal
 * 20220715 moved touch screen calibrate routine into the Options Menu Collection; to do this had to modifiy the "diagnose pins" routine to stop PB8 configuration change messing up the Si5351 interface
 * 20220718 Added Cal/Chk Sound board Sample Applied Rate to Ballance Mixer Settings Screen
 * 20220719 added side-tone adjustment to Ballance Mixer Settings Screen
 * */
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB4|PB9|
/*          |GRY|PUR|BLU|GRN|YEL|ORN|ORN|YEL| |GRN|BLU|PUR|GRY|WHT|
 *  Digilent Sound board connections:
 *    Black Pill			   Pmod I2S2
 * PA3.Signal=I2S2_MCK        Pin 1 & 7
 * PB10.Signal=I2S2_CK        Pin 3 & 9
 * PB12.Signal=I2S2_WS		  Pin 2 & 8
 * PB14.Signal=I2S2_ext_SD    Pin 10
 * PB15.Signal=I2S2_SD        Pin 4
 * 3.3V						  Pin 6 & 12
 * Gnd 						  Pin 5 & 11
 *
 */

/* Si5351/SSMicro connections for I2c communications
 *
 * PB8 = I2C3 SDA PUR
 * PA8 = I2C3 SCL BLU
 * PA9 = BndD0    YEL
 * PA10= BndD1    grn //`ORN
 * PB13= TRrelay  GRY
 * PA15= KeyIn    WHT
 * +5V = 		  RED
 * GND =		  BLK
 * */
/* DeBug SWO Pin
 *       PB3
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#define ARM_MATH_CM4
//#define __FPU_PRESENT = 1 //JMH - already declared in stm32f411xe.h

#define FFT_SIZE    (512) /* FFT size is always the same size as we have samples, so 256 in our case */
#define SAMPLES     (2*FFT_SIZE)         /* 256 real parts and 256 imaginary parts */
#include "main.h"  //"SDRtest01.h" //
//#include "SDR_Si5351r01.h"//Doing this caused un-fixable compile errors
#include "filter.h"
#include "TchScrnCal.h"
#include "CalSI5351Freq.h"
#include "BallanceMixer.h"
#include "SettingsMenu.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include "arm_math.h"
#include "arm_const_structs.h"
#include "Arduino.h"
#include "SerialClass.h"
#include "pgmstrings.h"
#include "TFTMsgBox.h"
#include "TouchScreen_kbv.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <complex.h>
#include <limits.h>
#include <math.h>
#include <eeprom.h>
/* includes for FFT support */
#include "STM32F411def.h"
#include "UTFTGLUE.h"
#include "si5351.h"
/* Private variables ---------------------------------------------------------*/

I2S_HandleTypeDef hi2s2;
DMA_HandleTypeDef hdma_spi2_tx;//sound board ring buffer
DMA_HandleTypeDef hdma_i2s2_ext_rx;//sound board ring buffer
DMA_HandleTypeDef hdma_memtomem_dma2_stream0;// advance ARMdecimate_buffer
/* Note: Timer 5 used by this program as well as some libraries
 * to do micro-second time measurements
 */
/* FFT Stuff */
const arm_cfft_instance_f32 CFFT_Instances[] = {
	{16, twiddleCoef_16, armBitRevIndexTable16, ARMBITREVINDEXTABLE__16_TABLE_LENGTH},
	{32, twiddleCoef_32, armBitRevIndexTable32, ARMBITREVINDEXTABLE__32_TABLE_LENGTH},
	{64, twiddleCoef_64, armBitRevIndexTable64, ARMBITREVINDEXTABLE__64_TABLE_LENGTH},
	{128, twiddleCoef_128, armBitRevIndexTable128, ARMBITREVINDEXTABLE_128_TABLE_LENGTH},
	{256, twiddleCoef_256, armBitRevIndexTable256, ARMBITREVINDEXTABLE_256_TABLE_LENGTH},
	{512, twiddleCoef_512, armBitRevIndexTable512, ARMBITREVINDEXTABLE_512_TABLE_LENGTH},
	{1024, twiddleCoef_1024, armBitRevIndexTable1024, ARMBITREVINDEXTABLE1024_TABLE_LENGTH},
	{2048, twiddleCoef_2048, armBitRevIndexTable2048, ARMBITREVINDEXTABLE2048_TABLE_LENGTH},
	{4096, twiddleCoef_4096, armBitRevIndexTable4096, ARMBITREVINDEXTABLE4096_TABLE_LENGTH}
};
typedef struct {
	float32_t* Input;               /*!< Pointer to data input buffer. Its length must be 2 * FFT_Size */
	float32_t* Output;              /*!< Pointer to data output buffer. Its length must be FFT_Size */
	uint16_t FFT_Size;              /*!< FFT size in units of samples. This parameter can be a value of 2^n where n is between 4 and 12 */
//	uint8_t UseMalloc;              /*!< Set to 1 when malloc is used for memory allocation for buffers. Meant for private use */
	uint16_t Count;                 /*!< Number of samples in buffer when using @ref TM_FFT_AddToBuffer function. Meant for private use */
	const arm_cfft_instance_f32* S; /*!< Pointer to @ref arm_cfft_instance_f32 structure. Meant for private use */
	float32_t MaxValue;             /*!< Max value in FTT result after calculation */
	uint32_t MaxIndex;              /*!< Index in output array where max value happened */
} TM_FFT_F32_t;
/* Band settings */
typedef struct {
	int rxcenter;               /*!< Pointer to data input buffer. Its length must be 2 * FFT_Size */
	int SideTonefreq;              /*!< Pointer to data output buffer. Its length must be FFT_Size */
	int CwTunefreq;
	bool UpFFTflg;              /*!< FFT size in units of samples. This parameter can be a value of 2^n where n is between 4 and 12 */
	int ButtonNo;
	int FltrOpt;
	float PhasCorect;
	float AmpFactor;
} BandConfig_t;
BandConfig_t BandSetting[5];
//int32_t Audio[8192]; //float32_t
//int AudioPtr = 0;
unsigned long TnPrdStrt;
bool TstNegFlg = false;
uint8_t NoTnCntr = 10;
uint8_t ZeroXCntr = 0;
uint8_t PeriodCntr = 0;
int DemodFreq = 0;
bool FinTune = false;
bool FreqCalMode = false;
unsigned long halfCntr;
unsigned long fullCntr;
unsigned long mainlpCntr;
unsigned long HalfCnt;
unsigned long FullCnt;
/* Variable listing used in AGC code */
const float maxTXmag = ((float)(0xFFFFFF))* 48.0;//800000000;//16777215 = 0xFFFFFF 24bit max val
const float maxGain = 100;

float RuningAvg;
float PeakVal;
float GainCoefnt;
float LastLSmpl;
float LastRSmpl;
float SmplBuf[100];
int SmplBufPntr;
int SmplCntr;
bool HalfCpltFlg;
bool FullCpltFlg;
bool AGConFlg;
bool busy;
uint8_t Buffer[50];
const float Pk2AvgCoef = 1.58;
char StrdTxt[20] ={'\0'};
char RevDate[9] = "20220719";
char Title[40];
char Cmd[64]; //used in FLDIGI serial interface
/* TFT Touch Screen variables*/
/*copy and past the following two lines from report
  generated by running the STM32_TouchScreen_Calibr_native Sketch
*/
/* TFT 2.4" Display */
//const int XP=PB4,XM=PA1,YP=PA0,YM=PB7; //480x320 ID=0x9486
//const int TS_LEFT=74,TS_RT=890,TS_TOP=881,TS_BOT=156;//TS_RT=844

/* TFT 2.8" Display  */
int XP=PB6,XM=PA7,YP=PA6,YM=PB7; //320x240 ID=0x4747
int TS_LEFT=75,TS_RT=931,TS_TOP=103,TS_BOT=851;
//int TS_LEFT =928, TS_RT =76, TS_TOP =884, TS_BOT =98;


int scrnHeight = 240;//pixel count
int scrnWidth = 320;//pixel count
TSPoint_kbv tp; //global point
int SkipRdBtns = 1000;
/* Si5351 variables */
/* A positive 'XtalErr' number lowers the output frequency.
 * On WWV the beep is 1Khz, & the tone can be either 600 or 500hz.
 * So for USB demodulation, if the tones are low, then the correction needs to
 * be a more positive value
 */
int XtalErr = -10400-(100*12);// integer value measured to 0.01 Hertz ie 100 = 1.00Hz
bool SetRX;
bool SetTX;
/*End variable listing used in original AGC code */
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
//static void MX_I2C3_Init(void);
static void MX_I2S2_Init(void);
//static void MX_TIM5_Init(void);
static void MX_ADC1_Init(void);
//static void MX_USB_OTG_FS_PCD_Init(void);
//void AGCModule(int *LdataSmpl, int *RdataSmpl);8; //12250
void SDRModule(void);//short *LdataSmpl, short *RdataSmpl
//__complex__ float CmplxMult(__complex__ float N1, __complex__ float N2);
int AutoZero(float32_t *maxSig, int TuneBin);
float hamming(float x);
void EvalDMAtime(void);
void Jump2XtalCal(int ButNo);
extern uint8_t CDC_Transmit_FS(uint8_t* Buf, uint16_t Len);
//void delay_us (uint16_t us);
uint16_t SetRGB(byte r, byte g, byte b);
int ReadBtns(void);
int GetTouchPts(int &px, int &py);
void readResistiveTouch(void);
bool ShowTunePos(float CurTunFreq, float LstBinfreq);
void BldButtons(void);
void BldBtn(int BtnNo, BtnParams Btns[]);
bool BtnActive(int BtnNo, BtnParams Btns[], int px, int py);
void ShwSlctdFFTbtn(bool FFTPlus);
void SetZeroBtbtn(int mode);
void ShwSlctdBndBtn(int BtnNo);
void ShwSlctdFltrBtn(int BtnNo);
bool GetRmtCmd(char Cmd[]);
void KeyEvntSR(void);
void StartTX(void);
void StopTX(void);
void LdTXBuffer(int offset);
void UnPakRxBuf(int offset);
void GenSideTone(void);
void DrwFrqMrkrs(int TunePos);
void EraseOldMrkrs(void);
void sendFrequency(float HzFreq);
void SetUPFIR(const __complex__ float *Fltr, size_t TapCnt);
void CalcIQfactors(void);
void ApplySmplRate(int SamplRateInt);
void ApplySideTone(int Freq);
/* USER CODE BEGIN PFP */
//PCD_HandleTypeDef hpcd_USB_OTG_FS; //JMH 20220505 commented this line out to avoid redefinition conflict when using CUBIDE1.9.0
MCUFRIEND_kbv tft;
TFTMsgBox tftmsgbx(&tft, StrdTxt);
TouchScreen_kbv ts(XP, YP, XM, YM, 300);
//UTFTGLUE myGLCD(0,0,0,0,0,0);// needed/used for FFT display plot/draw calls

SerialClass Serial; // Arduino styuint8_t void PrintAllDescriptors(UsbDevice *pdev)getdevdescr( uint8_t addr, uint8_t &num_conf );le Serial class
Si5351 si5351; //Create I2c3 access to Si5351 programmable clocks
/* USER CODE END PFP */
/*EEprom support variables*/
uint16_t VirtAddVarTab[NB_OF_VAR] = {0x0000, 0x0002, 0x0004};//added to support EEPROM operation/library
uint16_t VarDataTab[NB_OF_VAR];//added to support EEPROM operation/library
struct DF_t DFault;
template <class T>
int EEPROM_read(uint16_t ee, T& value)
{
   uint16_t* p = (uint16_t*)(void*)&value;
   uint16_t tmp;
   int i=0;
   while (i < sizeof(value)){
       //*p++ = EEPROM.read(ee++);
	   EE_ReadVariable(ee, &tmp);
	   ee +=2;
	   i +=2;
	   *p = tmp;
	   p++;//p +=2;
   }
   return i;
}

//modulation: can be 'l', 'u', 'a', 'f' for LSB, USB, AM, FM respectively
char modulation = 'u';
bool AGCflg = true;
int rxcenter = 7040000;// 7060000; //3550000; //
//int rxfreq =  +11400;//WSPR 40 mtrs
int rxfreq = 7028000; //7072000;// 7071000;// 3561500;/
int txfreq =  rxfreq;//7.040Mhz
int txfreqOld = 0;
float32_t PhaseErr = 0.0;//+1.3;//
//samp_rate: sampling rate of the input signal (in samples per second)
float samp_rate = 48830;//48800;//48900;//48850;//97700;//;96000;//240000;
//decimate_factor: only 1 out of <decimate_factor> samples will remain at the output of the decimating FIR filter
const int decimate_factor = 8;
const int Halfdecimate_factor = decimate_factor/2;
//output_rate: sampling rate of the output audio signal (in samples per second)
//const int output_rate =  samp_rate/decimate_factor;
//ssb_bw: filter bandwidth for SSB in Hz
const float ssb_bw = 3000;
//amfm_bw: filter bandwidth for AM & FM in Hz
const float amfm_bw = 12000;
//decimate_transition_bw: transition bandwidth for decimating FIR filter
//note: a lower value will slow down processing but will "sharpen" the filter charactersitic
//const float decimate_transition_bw = 2000;//currently not used
/* I2S Transmit & Receive RingBuffers */
uint16_t rxBuf[decimate_factor*2*2*2];//8= decimate factor; 2 = double for whole ringbuffer; two 16 bit words per channel; two channels(i&q)
uint16_t txBuf[decimate_factor*2*2*2];
uint16_t Dmod[4];
float32_t NewiqData[decimate_factor*2];
//LO_Phase_Shift: how much the LO phase is changed from sample to sample when generating the LO (for the shift)
float SideTonefreq = 750;
float CwTunefreq = rxfreq - SideTonefreq;//rxfreq;//
float LastBinfreq = rxcenter;
float MinFreq;//initialized in ApplySmplRate()// = rxcenter-(samp_rate/2);
float MaxFreq; //initialized in ApplySmplRate()// = rxcenter+(samp_rate/2);
float LO_Phase_Shift;//initialized in ApplySmplRate()// = ((rxcenter-CwTunefreq)/samp_rate)*2*M_PI;
float LO_Phase = 0;
float ST_Phase = 0;//current angle of Side Tone note
float txd_shift_phase = ((rxcenter-txfreq)/samp_rate)*2*M_PI;
//shift_phase: actual LO phase (for shift)
float shift_phase = 0;
float txshift_phase = 0;
//deicmate_taps_length: how many FIR filter taps we need to reach a given transition BW (should be odd, thus the |1)
int decimate_taps_length;// = FILTER_TAP_NUMN;//(int)(4.0f/(decimate_transition_bw/samp_rate)) | 1;
//decimate_taps: FIR filter taps for the decimating FIR filter:

//__complex__ float decimate_taps[FILTER_TAP_NUMN];
//__complex__ float deMod_taps[DFILTER_TAP_NUM];
int TapCntx2 = FILTER_TAP_NUMN*2;
float32_t ARMdecimate_taps[FILTER_TAP_NUMN*2];
float32_t pDst[FILTER_TAP_NUMN*2];
float32_t ARMdecimate_buffer[FILTER_TAP_NUMN*2];
//float32_t Mag[FILTER_TAP_NUM];
//int decimate_taps_middle = decimate_taps_length/2;

const float TwoPi = 2.0*M_PI;
/*Flter_Dshift: in case of SSB mode, we shift the filter taps in the frequency domain,
so that the filter will have an asymmetric transmission curve*/
const float Flter_Dshift = (modulation=='u'? +1:-1) *((1550/2)/samp_rate)*TwoPi;//((ssb_bw/2)/samp_rate)*2*M_PI;
//decimate_cutoff_rate: the cutoff frequency (in proportion to the sampling frequency) of the decimating FIR filter
const float decimate_cutoff_rate = (modulation=='u'||modulation=='l') ? (ssb_bw/2)/samp_rate : (amfm_bw/2)/samp_rate;
/* Set Key input "side tone" frequency */
float SideToneAngle = ((SideTonefreq*float(decimate_factor))/float(samp_rate))*M_PI; //750 = Side tone Freq

float maxPhasErr = 10; //(TwoPi/360)*15;//5 degrees converted to Radians
float DPhasCor = 0.1;//maxPhasErr/60;// step change to make in phase error after each pass
float PhasCorect = 0.041;//(TwoPi/360)*0.802140913;//*2.16; // Phase error to be applied during a given pass
float ICFactr; //the correction factor to be applied to the current data 'Q' sample
float QCFactr;
float AmpError = 0.0;
float AmpFactor = 1.0;
float maxAmpEr = 0.02;
float DampCor = 0.0005;
float drxfreq = 50;
float drxfreqstop = 4000;
float32_t decimated;
float32_t decimatedA;
float32_t decimatedB;
float32_t decimatedMax;
float32_t DemodGain;
float32_t SideToneGain = 250000000;//Sets the volume level Key input side tone
float32_t Volume;
float32_t Txmag = 25000000;
float32_t Maxvol = 335544280;//83886070.0;//8388607.0
float32_t PhErRad = (TwoPi/360.0)*PhaseErr;
int stop = int((TapCntx2*4)/decimate_factor);////int(sizeof(ARMdecimate_buffer)/decimate_factor);
size_t NuDataByteCnt = sizeof(NewiqData);
size_t ARMdecimateByteCnt;// = sizeof(ARMdecimate_buffer);
int StrtNuNdx;// = (ARMdecimateByteCnt-NuDataByteCnt)/4;

int lastbin; //used by FFT display & TouchScreen frequency detection
int firstbin;
int FreqShft = 0; //select the negative (FreqShft = 0) portion, or positive portion (FreqShft = FFTsize/2) of the FFT to display
//bool decimateFlg = false;
bool printflg = false;
float last_phi = 0;
int demodulator_output;// in this version demodulator_output needs to be a global variable
int demodulator_outputA;
int demodulator_outputB;
unsigned long StrtTime =0;
unsigned long StrtLP =0;
unsigned long HStrtTime =0;
unsigned long FStrtTime =0;
unsigned long H2FIntrvl =0;
unsigned long F2HIntrvl =0;
unsigned long LPIntrvl =0;
/* End declaration of global SDR variables */
/* FFT Specific Variables */
bool AFlg =false;
bool ARdy =false;
bool FullIntrv =false;
int MicPin = PB1;
float32_t InputA[SAMPLES];   /*!< Input buffer is always 2 * FFT_SIZE */
//float32_t InputB[SAMPLES];   /*!< Input buffer is always 2 * FFT_SIZE */
//int Pntr =0;
float32_t OutputA[FFT_SIZE]; /*!< Output buffer is always FFT_SIZE */
TM_FFT_F32_t FFTA;
/*buttons*/
const int BtnCnt = 16;
int IntrpAsec;//initialized in ApplySmplRate()// =int(samp_rate/decimate_factor);
BtnParams SetUpBtns[BtnCnt];
unsigned long PTTtimeOut = 0;
unsigned long TRHangTime = 160; //millisecond wait interval to resume RX mode after last key closure
/* 160 Ms hangtime => @WPM > 22.5, T/R relay will stay closed during charaters sent as words */
bool PTT = false; // tracks the state of the TR relay (true = relay in TX state)
bool KeyClosed = false;  // tracks instantaneous state of an external key (true = Key in "Key Down" state
bool KeyActive;
int BntCntrStop;
int CurSelBnd;
int GrphBase = 223;
int GrphTop = 120;
int TuneBin = 0;
int FltrBtn = 12;
int NoiseFlr;
bool NuTunFrq = true;
bool UpdateRmt = true;
float binfrqWdth; //initialized in ApplySmplRate()// = samp_rate/(FFT_SIZE);
int OldSpecVals[FFT_SIZE];
float CurSpecVals[FFT_SIZE]; //FFT display variable
int BinLimit;

int main(void)
{

	halfCntr = 0;
	fullCntr = 0;
	mainlpCntr = 0;
	decimatedMax= 0.0;
	DemodGain = 10;//2.32700134e-18;
	Volume = 1.0; //audio output volume
	HalfCpltFlg = true;
	FullCpltFlg = false;
	AGConFlg = false;
	busy = false;
	KeyActive = false; //tracks recent Key activity; true = key was operated recently
	SmplBufPntr = 0;
	SmplCntr = 0;
	LastLSmpl = 0;
	LastRSmpl = 0;
//	uint16_t yellow = SetRGB(255,255,0); //yellow
//	uint16_t black = SetRGB(0,0,0); //black
//	uint16_t red = SetRGB(255,0,0); //red
//	uint16_t blue = SetRGB(0,0,255); //blue
	/* apply phase error correction to incoming I/Q data stream */
//	ICFactr = (1+ (0.5*arm_sin_f32(PhasCorect)));
//	QCFactr = 1/ICFactr;
	/*###########################################################################*/
	/*                      Begin FFT setup                                      */
	/* Init FFT, FFT_SIZE define is used for FFT_SIZE, sample count is 2*FFT_SIZE*/
	//TM_FFT_Init_F32(&FFTA, FFT_SIZE, 0);
	/* Check for proper pointer value */
	for (int i = 0; i < 9; i++) {
		/* Check for proper number */
		if (FFT_SIZE == CFFT_Instances[i].fftLen) {
			/* Set FFT size */
			FFTA.FFT_Size = FFT_SIZE;

			/* Save proper pointer */
			FFTA.S = &CFFT_Instances[i];

			/* Stop for loop */
			break;
		}
	}
	/* Input buffer must be 2*FFT_SIZE in length because of real and imaginary part */
	/* Output buffer must be FFT_SIZE in length */
	//TM_FFT_SetBuffers_F32(&FFTA, InputA, OutputA);
	FFTA.Input = InputA;
	FFTA.Output = OutputA;
	/*                         End FFT SetUp Code                               */
	/*###########################################################################*/
	/* Setup default band settings (5) */
	BandSetting[0].ButtonNo = 6;
	BandSetting[0].CwTunefreq = 3561500 - SideTonefreq;
	BandSetting[0].SideTonefreq = SideTonefreq;
	BandSetting[0].UpFFTflg = true;
	BandSetting[0].rxcenter = 3550000;
	BandSetting[0].FltrOpt = 1;
	BandSetting[0].PhasCorect = 2.0;
	BandSetting[0].AmpFactor = 0.9955;

	BandSetting[1].ButtonNo = 7;
	BandSetting[1].CwTunefreq = 7028000 - SideTonefreq;
	BandSetting[1].SideTonefreq = SideTonefreq;
	BandSetting[1].UpFFTflg = false;
	BandSetting[1].rxcenter = 7040000;
	BandSetting[1].FltrOpt = 1;
	BandSetting[1].PhasCorect = 2.1;
	BandSetting[1].AmpFactor = 0.9925;


	BandSetting[2].ButtonNo = 8;
	BandSetting[2].CwTunefreq =  10112000 - SideTonefreq;
	BandSetting[2].SideTonefreq = SideTonefreq;
	BandSetting[2].UpFFTflg = false;
	BandSetting[2].rxcenter = 10125000;
	BandSetting[2].FltrOpt = 1;
	BandSetting[2].PhasCorect = 2.1;
	BandSetting[2].AmpFactor = 0.9925;

	BandSetting[3].ButtonNo = 9;
	BandSetting[3].CwTunefreq = 14047500 - SideTonefreq;//W1AW bulletin freq - sidetone freq(appears to be ~25hz higher than advertised)
	BandSetting[3].SideTonefreq = SideTonefreq;
	BandSetting[3].UpFFTflg = true;
	BandSetting[3].rxcenter = 14040000;
	BandSetting[3].FltrOpt = 1;
	BandSetting[3].PhasCorect = 6.49999;
	BandSetting[3].AmpFactor = 0.9865;

	BandSetting[4].ButtonNo = 10;
	BandSetting[4].CwTunefreq = 10000000;
	BandSetting[4].SideTonefreq = 0;
	BandSetting[4].UpFFTflg = false;
	BandSetting[4].rxcenter = 10010000;
	BandSetting[4].FltrOpt = 0;
	BandSetting[4].PhasCorect = 2.2;
	BandSetting[4].AmpFactor = 0.994;

	CurSelBnd = 1;

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();
	H2FIntrvl =0;
	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER StrtLP =__HAL_TIM_GET_COUNTER(&htim5);CODE BEGIN SysInit */
//	decimateFlg = false;
	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_USB_DEVICE_Init();
	MX_I2S2_Init();
	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, (GPIO_PinState)1);//LED Off
	coretick_init(); //JMH Added to support time measurements i.e millis() & micros() see Arduino.h & Arduino.cpp

	DFault.TS_BOT = TS_BOT;
	DFault.TS_LEFT = TS_LEFT;
	DFault.TS_RT = TS_RT;
	DFault.TS_TOP = TS_TOP;
	DFault.XM = XM;
	DFault.XP = XP;
	DFault.XtalErr = XtalErr;
	DFault.YM = YM;
	DFault.YP = YP;
	/* EEPROM Init */
	uint16_t reslt = EE_Init();
	if (reslt != fLASH_COMPLETE){
		tftmsgbx.InitDsplay();
		sprintf(Title, "EEPROM Init ERROR: %d", reslt);
		tftmsgbx.dispTitl(Title, TFT_RED);
		while(1){
			delay(100);
		}
	}

	int	n;
	int offset = 0;



//	TchScrnCal_MainLoop();//Added for testing a "settings/setup" options
	arm_fir_instance_f32 S;
	arm_status status;

	/* initialize Si5351 clocks */
	  si5351.init(SI5351_CRYSTAL_LOAD_10PF, 0, XtalErr);//si5351.init(SI5351_CRYSTAL_LOAD_8PF, 0, XtalErr);
	  si5351.set_ms_source(SI5351_CLK0, SI5351_PLLA);
	  si5351.set_ms_source(SI5351_CLK1, SI5351_PLLA);
	  si5351.set_ms_source(SI5351_CLK2, SI5351_PLLB);
	  si5351.set_clock_invert(SI5351_CLK0, 0);//*
	  si5351.set_clock_invert(SI5351_CLK1, 1);//*
	  si5351.set_phase(SI5351_CLK0, 0);
	  si5351.set_phase(SI5351_CLK1, 0);
	  si5351.drive_strength(SI5351_CLK0, SI5351_DRIVE_2MA);//* //SI5351_DRIVE_2MA ; SI5351_DRIVE_4MA ; SI5351_DRIVE_8MA
	  si5351.drive_strength(SI5351_CLK1, SI5351_DRIVE_2MA);//*
	  si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_8MA);//*// Tx Clock
	  si5351.set_clock_disable(SI5351_CLK2, SI5351_CLK_DISABLE_LOW);//* //enum si5351_clock_disable {SI5351_CLK_DISABLE_LOW, SI5351_CLK_DISABLE_HIGH, SI5351_CLK_DISABLE_HI_Z, SI5351_CLK_DISABLE_NEVER};

	  // Need to reset the PLL before Clocks will be in phase alignment
	  si5351.pll_reset(SI5351_PLLA);//*
	  SetRX = true;
	  SetTX = false;
	  CwTunefreq = BandSetting[CurSelBnd].CwTunefreq;
	  rxcenter = BandSetting[CurSelBnd].rxcenter;
	  SideTonefreq = BandSetting[CurSelBnd].SideTonefreq;

//	  sendFrequency(float(rxcenter));
	  /* Initialize using Medium audio filter */
//	  SetUPFIR(filter_tapsM, FILTER_TAP_NUMM);

	/* begin touchscreen setup*/
	tftmsgbx.InitDsplay();
	sprintf( Title, "STM32F411 SDR/FFT(%s)\n", RevDate );
	tftmsgbx.dispTitl(Title, TFT_CYAN);
	while(1){
		delay(100);
	}
}
/////////////////////////////////////////////////////////////////////////////////////
void KeyEvntSR(void) {
	return;
}

/////////////////////////////////////////////////////////////////////////////////////////////
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 96;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 12;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_HSI, RCC_MCODIV_1);
}

/**
    * @brief USB_OTG_FS Initialization Function
    * @param None
    * @retval None
    */
//  static void MX_USB_OTG_FS_PCD_Init(void)
//  {
//
//    /* USER CODE BEGIN USB_OTG_FS_Init 0 */
//
//    /* USER CODE END USB_OTG_FS_Init 0 */
//
//    /* USER CODE BEGIN USB_OTG_FS_Init 1 */
//
//    /* USER CODE END USB_OTG_FS_Init 1 */
//    hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
//    hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
//    hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
//    hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
//    hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
//    if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    /* USER CODE BEGIN USB_OTG_FS_Init 2 */
//
//    /* USER CODE END USB_OTG_FS_Init 2 */
//
//  }



static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

///**
//  * @brief I2C3 Initialization Function
//  * @param None
//  * @retval None
//  */
//static void MX_I2C3_Init(void)
//{
//
//  /* USER CODE BEGIN I2C3_Init 0 */
//
//  /* USER CODE END I2C3_Init 0 */
//
//  /* USER CODE BEGIN I2C3_Init 1 */
//
//  /* USER CODE END I2C3_Init 1 */
//  hi2c3.Instance = I2C3;
//  hi2c3.Init.ClockSpeed = 100000;
//  hi2c3.Init.DutyCycle = I2C_DUTYCYCLE_2;
//  hi2c3.Init.OwnAddress1 = 0;
//  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
//  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
//  hi2c3.Init.OwnAddress2 = 0;
//  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
//  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
//  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN I2C3_Init 2 */
//
//  /* USER CODE END I2C3_Init 2 */
//
//}


/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S2_Init(void)
{

  /* USER CODE BEGIN I2S2_Init 0 */

  /* USER CODE END I2S2_Init 0 */

  /* USER CODE BEGIN I2S2_Init 1 */

  /* USER CODE END I2S2_Init 1 */
  hi2s2.Instance = SPI2;
  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s2.Init.DataFormat = I2S_DATAFORMAT_24B;
  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_48K;//I2S_AUDIOFREQ_96K;
  hi2s2.Init.CPOL = I2S_CPOL_LOW;
  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_ENABLE;
  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S2_Init 2 */

  /* USER CODE END I2S2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* Configure DMA request hdma_memtomem_dma2_stream0 on DMA2_Stream0 */
  hdma_memtomem_dma2_stream0.Instance = DMA2_Stream0;
  hdma_memtomem_dma2_stream0.Init.Channel = DMA_CHANNEL_0;
  hdma_memtomem_dma2_stream0.Init.Direction = DMA_MEMORY_TO_MEMORY;
  hdma_memtomem_dma2_stream0.Init.PeriphInc = DMA_PINC_ENABLE;
  hdma_memtomem_dma2_stream0.Init.MemInc = DMA_MINC_ENABLE;
  hdma_memtomem_dma2_stream0.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
  hdma_memtomem_dma2_stream0.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
  hdma_memtomem_dma2_stream0.Init.Mode = DMA_NORMAL;
  hdma_memtomem_dma2_stream0.Init.Priority = DMA_PRIORITY_LOW;
  hdma_memtomem_dma2_stream0.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
  hdma_memtomem_dma2_stream0.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
  hdma_memtomem_dma2_stream0.Init.MemBurst = DMA_MBURST_INC4;
  hdma_memtomem_dma2_stream0.Init.PeriphBurst = DMA_PBURST_INC4;
  if (HAL_DMA_Init(&hdma_memtomem_dma2_stream0) != HAL_OK)
  {
    Error_Handler( );
  }
  __HAL_DMA_ENABLE_IT(&hdma_memtomem_dma2_stream0, DMA_IT_TC);
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 4); //shift decimate buffer interrupt
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);



  /* DMA interrupt init */
  /* DMA1_Stream3_IRQn (I2S RX data in) interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 3);//Sound board ring buffer interrupt
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
  /* DMA1_Stream4_IRQn (I2S TX data out)interrupt configuration */
//  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 3);
//  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

//  /*Configure GPIO pin : PA8 */
//  GPIO_InitStruct.Pin = GPIO_PIN_8;
//  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//  GPIO_InitStruct.Pull = GPIO_NOPULL;
//  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//  GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
//  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* Set Port A GPIO pins Low */
  HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin|BndD1_Pin
                          |BndD0_Pin, GPIO_PIN_RESET);

  /* Set Port B GPIO pins Low */
  HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|TR_Relay_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);

  /*Configure Port A GPIO pins  */
  GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin|BndD1_Pin
                          |BndD0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure Port B GPIO pins  */
  GPIO_InitStruct.Pin = LCD_D3_Pin|TR_Relay_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : KeyIn_ExtI15_Pin */
  GPIO_InitStruct.Pin = KeyIn_ExtI15_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP; //GPIO_NOPULL;
  HAL_GPIO_Init(KeyIn_ExtI15_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 1);// keyer interrupt
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
//static void MX_TIM5_Init(void)
//{
//
//  /* USER CODE BEGIN TIM5_Init 0 */
//
//  /* USER CODE END TIM5_Init 0 */
//
//  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
//  TIM_MasterConfigTypeDef sMasterConfig = {0};
//
//  /* USER CODE BEGIN TIM5_Init 1 */
//
//  /* USER CODE END TIM5_Init 1 */
//  htim5.Instance = TIM5;
//  htim5.Init.Prescaler = 96-1;
//  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
//  htim5.Init.Period = 4294967295;
//  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
//  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
//  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
//  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
//  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
//  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN TIM5_Init 2 */
//
//  /* USER CODE END TIM5_Init 2 */
//
//}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

