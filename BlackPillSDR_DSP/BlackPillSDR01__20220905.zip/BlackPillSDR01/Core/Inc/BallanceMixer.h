/*
 * BallanceMixer.h
 *
 *  Created on: Jul 11, 2022
 *      Author: jim
 */

#ifndef INC_BALLANCEMIXER_H_
#define INC_BALLANCEMIXER_H_

extern float maxPhasErr;//5 degrees converted to Radians
extern float DPhasCor;// step change to make in phase error after each pass
extern float PhasCorect;//*2.16; // Phase error to be applied during a given pass
extern float ICFactr; //the correction factor to be applied to the current data 'Q' sample
extern float QCFactr;

extern float AmpError;
extern float AmpFactor;
extern float maxAmpEr;
extern float DampCor;
extern float32_t DemodGain;
extern bool SetTX;
extern bool SetRX;
//extern void ShwSmtr(int Smtr, float DBm);
void BalMixr_MainLoop(int rxcenter, int txfreq, int SamplRateInt, float SideTonefreq);


#endif /* INC_BALLANCEMIXER_H_ */
