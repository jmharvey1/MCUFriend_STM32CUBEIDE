/*
 * TchScrnCal.h
 *
 *  Created on: Jul 1, 2022
 *      Author: jim
 */

#ifndef INC_TCHSCRNCAL_H_
#define INC_TCHSCRNCAL_H_

#include "TouchScreen_kbv.h"
#include "MCUFRIEND_kbv.h"
#include "TFTMsgBox.h"
//char StrdTxt[20] ={'\0'};
extern char Title[];
extern int XP,XM,YP,YM;
extern int TS_LEFT, TS_RT, TS_TOP, TS_BOT;
extern MCUFRIEND_kbv tft;
//extern TFTMsgBox tftmsgbx(&tft, StrdTxt);
//extern TouchScreen_kbv ts(XP, YP, XM, YM, 300);   //re-initialised after diagnose
extern TouchScreen_kbv ts;
extern TSPoint_kbv tp;
void TchScrnCal_MainLoop(void);



#endif /* INC_TCHSCRNCAL_H_ */
