/*
 * SDR_Si5351r01.h
 *
 *  Created on: Jul 3, 2022
 *      Author: jim
 */

#ifndef INC_SDR_SI5351R01_H_
#define INC_SDR_SI5351R01_H_

void readResistiveTouch(void);
int GetTouchPts(int &px, int &py);
void sendFrequency(float HzFreq);
bool GetRmtCmd(char Cmd[]);
void ApplySmplRate(int SamplRateInt);
void ApplySideTone(int Freq);
void ZeroBtFltr(void);


#endif /* INC_SDR_SI5351R01_H_ */
