/*
 * SDRtest01.cpp
 *
 *  Created on: Dec 27, 2021
 *      Author: jim
  ******************************************************************************
  * @file           : SDRtest01.cpp.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  * to line 939 of stm32f4xx_hal_i2s_ex.c
  * add the following entry:
  *   HAL_I2SEx_TxRxCpltCallback(hi2s);//JMH 20210122 added per video
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"  //"SDRtest01.h" //
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <complex.h>
#include <limits.h>
#include <math.h>

/*Start variable listing used in original AGC code */
/* Private variables ---------------------------------------------------------*/
I2S_HandleTypeDef hi2s2;
DMA_HandleTypeDef hdma_spi2_tx;
DMA_HandleTypeDef hdma_i2s2_ext_rx;
TIM_HandleTypeDef htim5;
uint16_t rxBuf[8];
uint16_t txBuf[8];
unsigned long halfCntr;
unsigned long fullCntr;
unsigned long HalfCnt;
unsigned long FullCnt;
/* Variable listing used in AGC code */
const float maxTXmag = ((float)(0xFFFFFF))* 48.0;//800000000;//16777215 = 0xFFFFFF 24bit max val
const float maxGain = 100;

float RuningAvg;
float PeakVal;
float GainCoefnt;
float LastLSmpl;
float LastRSmpl;
//float refval = 500000000;
float SmplBuf[100];
int SmplBufPntr;
int SmplCntr;
bool HalfCpltFlg;
bool FullCpltFlg;
bool AGConFlg;
uint8_t Buffer[50];
/*End variable listing used in original AGC code */
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2S2_Init(void);
static void MX_TIM5_Init(void);
void AGCModule(int *LdataSmpl, int *RdataSmpl);
void SDRModule(short *LdataSmpl, short *RdataSmpl);
__complex__ float CmplxMult(__complex__ float N1, __complex__ float N2);
float hamming(float x);
extern uint8_t CDC_Transmit_FS(uint8_t* Buf, uint16_t Len);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

//syntax to run this program: rx <center> <rx_freq> <l[sb]|u[sb]|a[m]|f[m]>
/* declare global SDR processing variables */
int rxcenter =0; //7.050Mhz
int rxfreq = -20000; //7.030Mhz
//samp_rate: sampling rate of the input signal (in samples per second)
const float samp_rate = 96000;//240000;
//output_rate: sampling rate of the output audio signal (in samples per second)
const int output_rate = 48000;
//ssb_bw: filter bandwidth for SSB in Hz
const float ssb_bw = 3000;
//amfm_bw: filter bandwidth for AM & FM in Hz
const float amfm_bw = 12000;
//decimate_transition_bw: transition bandwidth for decimating FIR filter
//note: a lower value will slow down processing but will "sharpen" the filter charactersitic
const float decimate_transition_bw = 800;

const float Pk2AvgCoef = 1.58;

//const float PkinptSig = (float)32*SHRT_MAX;
const int CplxFltSz = sizeof(__complex__ float);//JMHA added sizeof(__complex__ float)



// ====== calculate parameters for frequency translation and the decimating FIR filter ===
//modulation: can be 'l', 'u', 'a', 'f' for LSB, USB, AM, FM respectively
char modulation = 'u'; //argv[3][0];
//d_shift_phase: how much the LO phase is changed from sample to sample when generating the LO (for the shift)
//float d_shift_phase = ((atoi(argv[2])-atoi(argv[1]))/samp_rate)*2*M_PI;
float d_shift_phase = ((rxfreq-rxcenter)/samp_rate)*2*M_PI;
//shift_phase: actual LO phase (for shift)
float shift_phase = 0;
//deicmate_taps_length: how many FIR filter taps we need to reach a given transition BW (should be odd, thus the |1)
const int decimate_taps_length = (int)(4.0f/(decimate_transition_bw/samp_rate)) | 1;
//decimate_taps: FIR filter taps for the decimating FIR filter:
//complex float* decimate_taps = malloc(sizeof(complex float)*decimate_taps_length);
//int spcNd = sizeof(std::complex<float>)*decimate_taps_length;
int spcNd = CplxFltSz*decimate_taps_length;
//__complex__ float* decimate_taps = (__complex__ float*) malloc(spcNd);
__complex__ float decimate_taps[decimate_taps_length];
//decimate_buffer: the last <decimate_taps_length> pieces of shifted input samples, on which the decimating FIR is applied
//complex float* decimate_buffer = calloc(sizeof(complex float),decimate_taps_length);
//__complex__ float* decimate_buffer = (__complex__ float*) calloc(CplxFltSz,decimate_taps_length);
__complex__ float decimate_buffer[decimate_taps_length];
//decimate_taps_middle: the index of the item in the exact middle of <decimate_taps>
int decimate_taps_middle = decimate_taps_length/2;
//decimate_factor: only 1 out of <decimate_factor> samples will remain at the output of the decimating FIR filter
int decimate_factor = samp_rate / output_rate;
//decimate_dshift: in case of SSB mode, we shift the filter taps in the frequency domain, so that the filter will have an asymmetric transmission curve
const float decimate_dshift = (modulation=='u'?1:-1) * ((ssb_bw/2)/samp_rate)*2*M_PI;
//decimate_cutoff_rate: the cutoff frequency (in proportion to the sampling frequency) of the decimating FIR filter
const float decimate_cutoff_rate = (modulation=='u'||modulation=='l') ? (ssb_bw/2)/samp_rate : (amfm_bw/2)/samp_rate;

int decimate_counter = 0;
float last_phi = 0;
int demodulator_output;// in this version demodulator_output needs to be a global variable
unsigned long StrtTime =0;
/* End declaration of global SDR variables */


int main(void)
{
	halfCntr = 0;
	fullCntr = 0;
	HalfCpltFlg = true;
	FullCpltFlg = false;
	AGConFlg = false;
	SmplBufPntr = 0;
	SmplCntr = 0;
	LastLSmpl = 0;
	LastRSmpl = 0;
	float CurSmpl =0.0;
	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_I2S2_Init();
	MX_USB_DEVICE_Init();
	MX_TIM5_Init();
	HAL_TIM_Base_Start_IT(&htim5);

	arm_fir_instance_f32 S;
    arm_status status;

	// ====== design the FIR filter ===
	//calculate the tap in the middle:
	decimate_taps[decimate_taps_middle] = 2 * M_PI * decimate_cutoff_rate * hamming(0);
	//calculate the remaining taps:
	for(int i=1; i<=decimate_taps_middle; i++){
		decimate_taps[decimate_taps_middle+i] = (sin(2*M_PI*decimate_cutoff_rate*i)/i) * hamming((float)i/decimate_taps_middle);
		decimate_taps[decimate_taps_middle-i] = decimate_taps[decimate_taps_middle+i];
	}
	//in case of SSB, do the shift:
	if(modulation=='u'||modulation=='l'){
		for(int i=0; i<decimate_taps_length; i++) {
			decimate_taps[i] *= (__complex__ float)(sinf(shift_phase) + cosf(shift_phase) * I);
			//decimate_taps[i] = decimate_taps[i]*(sinf(shift_phase) + cosf(shift_phase) * I);
			shift_phase += decimate_dshift;
			while(shift_phase>2*M_PI) shift_phase-=2*M_PI;
		}
	}
	// ====== normalize FIR filter ===
	float decimate_taps_sum = 0;
	//we sum up the absolute value of taps:
	for(int i=0; i<decimate_taps_length; i++) decimate_taps_sum += cabsf(decimate_taps[i]);
	//and we divide by the sum:
	for(int i=0; i<decimate_taps_length; i++) decimate_taps[i] /= decimate_taps_sum;
	//we optionally print the filter taps to a file to analyze them using GNU Octave:
#ifdef PRINT_FILTER_TO_FILE
	FILE* filterfile = fopen("test.m", "w");
	fprintf(filterfile, "freqz([");
	for(int i=0; i<decimate_taps_length; i++) fprintf(filterfile, " %f+(%f*i)\n", creal(decimate_taps[i]), cimag(decimate_taps[i]));
	fprintf(filterfile, "]);input(\"\");");
#endif
	//    int decimate_counter = 0;
	//    float last_phi = 0;

	/* Start Sound Board DMA to begin IQ capture and stream demodulated audio */
	StrtTime = __HAL_TIM_GET_COUNTER(&htim5);
	HAL_I2SEx_TransmitReceive_DMA(&hi2s2, txBuf, rxBuf, 4);
	while(1) {
		int cnt = 0;
		cnt++;
	}// end While loop
	halfCntr = 0;
	fullCntr = 0;
} // end main
///////////////////////////////////////////////////////////////
float hamming(float x) //hamming window function used for FIR filter design
{
	return (0.54-0.46*(2*M_PI*(0.5+(x/2))));
}

//////////////////////////////////////////////////////////////
void SDRModule(int *LdataSmpl, int *RdataSmpl){
	const float PkinptSig = (float)1024*SHRT_MAX;
	int d_t_l = (int)decimate_taps_length;//(479)
	int d_f = (int)decimate_factor;//(2)
	int CplxFltSz_L = (int)CplxFltSz;//(8)
	int input_i = (int)* LdataSmpl;
	int input_q = (int)* RdataSmpl;
	/* Process the IQ data stream */
//	__complex__ float input = ((float)input_i/(UCHAR_MAX/2.0)-1.0) + I*((float)input_q/(UCHAR_MAX/2.0)-1.0);
	__complex__ float input = ((float)input_i/PkinptSig) + I*((float)input_q/PkinptSig);
	// ====== apply frequency translation (a.k.a. shift) ===
	//we increase the current LO phase by <d_shift_phase>:
	shift_phase += d_shift_phase;
	//we bring the current LO phase back into the range (0, 2*pi]:
	while(shift_phase>2*M_PI) shift_phase-=2*M_PI;
	//we multiply the input sample by the output of the LO (thus this is a mixer):
	//input *=(sinf(shift_phase) + cosf(shift_phase) * I);
	input = CmplxMult(input, (sinf(shift_phase) + cosf(shift_phase) * I));
//
//	// ====== apply decimating FIR filter ===
//	// we write the shifted input sample at the end of <decimate_buffer>:
//	// 1. we fill the end of <decimate_buffer> with <decimate_taps_length> samples,
//	// 2. we apply the decimating FIR filter once,
//	// 3. we move the data in the buffer back <decimate_taps_length> samples, and start again.
//	decimate_buffer[decimate_taps_length-decimate_factor+decimate_counter] = input;
//	if(++decimate_counter >= decimate_factor) {
//		//we only run this part 1 time out of <decimate_factor> times of getting here:
//		decimate_counter = 0;
//		//we apply the decimating FIR filter, the result of which is <decimated>:
//		//complex float decimated = CMPLX(0,0);
//		__complex__ float decimated = (0 + 0 * I);//(sinf(0) + cosf(M_PI/2) * I);
//		for(int i=0; i<=decimate_taps_length; i++){
//			decimated += decimate_buffer[i] * decimate_taps[i];
//		}
//		//we shift the items in the buffer back <decimate_taps_length> samples:
//		//memmove(decimate_buffer, decimate_buffer+decimate_factor, (decimate_taps_length-decimate_factor)*sizeof(complex float));
//		//memmove(decimate_buffer, decimate_buffer+decimate_factor, (decimate_taps_length-decimate_factor)*sizeof(__complex__ float));//sizeof(__complex__ float) evaluates to "8"
//		memmove(decimate_buffer, decimate_buffer+decimate_factor, (decimate_taps_length-decimate_factor)*CplxFltSz);
//		// ====== apply demodulator ===
////		short demodulator_output;
//		if(modulation=='f') {
//			//we apply the FM demodulator; phi is the current phase of the <decimated> sample:
//			float phi = cargf(decimated);
//			//we calculate the phase change between each <decimated> sample:
//			float dphi = phi - last_phi;
//			//...so we need to remember the last phase of it next time:
//			last_phi = phi;
//			//we want the phase to be in the range [-pi, pi]:
//			while(dphi<-M_PI) dphi += 2*M_PI;
//			while(dphi>M_PI) dphi -= 2*M_PI;
//			//we rescale the input to a 16-bit short, and there we have our audio sample:
//			demodulator_output = (SHRT_MAX-1)*(dphi/M_PI);
//		}
//		//we apply the AM demodulator, which just calculates the absolute value of each <decimated> sample:
//		else if(modulation=='a') demodulator_output = cabsf(decimated) * SHRT_MAX;
//		//we apply the SSB demodulator, which just calculates the real value of each <decimated> sample
//		//(this works as we already removed the other sideband at the decimating FIR filter):
//		else demodulator_output = crealf(decimated) * PkinptSig;
//	}
	demodulator_output = crealf(input) * PkinptSig;
	//we write the audio sample to stdout:
	//        fwrite(&demodulator_output, sizeof(short), 1, stdout);
	/* setup return audio values */
	*LdataSmpl = (int)demodulator_output;// GainCoefnt*( FLSmpl); //input_i;//
	*RdataSmpl = (int)demodulator_output;// GainCoefnt*( FRSmpl); input_q;//
	fullCntr++;
	if(fullCntr>96000){
		unsigned long Now = __HAL_TIM_GET_COUNTER(&htim5);
		float Intrvl =  ((float)(Now - StrtTime))/1000000.0;
		fullCntr=0;
		StrtTime = __HAL_TIM_GET_COUNTER(&htim5);
	}
	return;

}
__complex__ float CmplxMult(__complex__ float N1, __complex__ float N2)
{
	float x1= crealf(N1);
	float y1= cimagf(N1);
	float x2= crealf(N2);
	float y2= cimagf(N2);
	float x3 = x1 * x2 - y1 * y2;
	float y3 = x1 * y2 + y1 * x2;
	return (__complex__ float)(x3 + y3 * I);
}
void AGCModule(int *LdataSmpl, int *RdataSmpl){

    float FLSmpl = (float)*LdataSmpl;
   	float FRSmpl = (float)*RdataSmpl;
   	float ABSSmpl = fabs(FLSmpl)+fabs(FRSmpl);
    	SmplCntr +=1;
		if(SmplCntr >= 10){//grab every 10th sample
			SmplCntr =0;
			SmplBuf[SmplBufPntr]=ABSSmpl;
			SmplBufPntr += 1;
			if(SmplBufPntr >= 100) SmplBufPntr = 99;
		}
    if(AGConFlg){
		if(GainCoefnt*ABSSmpl > 2*maxTXmag){
    		//GainCoefnt = maxTXmag/ABSSmpl;
    		FLSmpl = LastLSmpl;
    		FRSmpl = LastRSmpl;
    		RuningAvg = ABSSmpl/(2*Pk2AvgCoef);
    		PeakVal = Pk2AvgCoef*RuningAvg;
    		GainCoefnt = (maxTXmag/PeakVal);
    		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);//LED on
    		halfCntr +=1;
    	}else{
    		LastLSmpl = FLSmpl;
    		LastRSmpl = FRSmpl;
    	}

    }else GainCoefnt = 1.0;

	*LdataSmpl = GainCoefnt*( FLSmpl);
	*RdataSmpl = GainCoefnt*( FRSmpl);
	//fullCntr +=1;//for record keeping debugging only
	return; //dataSmpl;
}

void HAL_I2SEx_TxRxHalfCpltCallback(I2S_HandleTypeDef *hi2s){
//	HalfCpltFlg = !HalfCpltFlg;
	if(!HalfCpltFlg) return;
	HalfCpltFlg = false;
	//restore signed 24 bit sample from two 16bit buffers
		int lSample = (int) (rxBuf[0]<<16 | rxBuf[1]);
		int rSample = (int) (rxBuf[2]<<16 | rxBuf[3]);
//		halfCntr +=1;
	// Manipulate Digital Stream
		SDRModule(&lSample, &rSample);
	//restore to buffer signed 24 bit sample
		txBuf[0] = (lSample>>16) & 0xFFFF;
		txBuf[1] = (lSample) & 0xFFFF;
		txBuf[2] = (rSample>>16) & 0xFFFF;
		txBuf[3] = (rSample) & 0xFFFF;
		FullCpltFlg = true;
}

void HAL_I2SEx_TxRxCpltCallback(I2S_HandleTypeDef *hi2s){
//		FullCpltFlg = !FullCpltFlg;
		if(!FullCpltFlg) return;
		FullCpltFlg = false;
	//restore signed 24 bit sample from two 16bit buffers
		int lSample = (int) (rxBuf[4]<<16 | rxBuf[5]);
		int rSample = (int) (rxBuf[6]<<16 | rxBuf[7]);
//		fullCntr +=1;
	// Manipulate Digital Stream
		SDRModule(&lSample, &rSample);
	//restore to buffer signed 24 bit sample
		txBuf[4] = (lSample>>16) & 0xFFFF;
		txBuf[5] = (lSample) & 0xFFFF;
		txBuf[6] = (rSample>>16) & 0xFFFF;
		txBuf[7] = (rSample) & 0xFFFF;
		HalfCpltFlg = true;
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 96;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 12;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_HSI, RCC_MCODIV_1);
}

/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S2_Init(void)
{

  /* USER CODE BEGIN I2S2_Init 0 */

  /* USER CODE END I2S2_Init 0 */

  /* USER CODE BEGIN I2S2_Init 1 */

  /* USER CODE END I2S2_Init 1 */
  hi2s2.Instance = SPI2;
  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s2.Init.DataFormat = I2S_DATAFORMAT_24B;
  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_96K;
  hi2s2.Init.CPOL = I2S_CPOL_LOW;
  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_ENABLE;
  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S2_Init 2 */

  /* USER CODE END I2S2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
  /* DMA1_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : Mode1_Pin */
  GPIO_InitStruct.Pin = Mode1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(Mode1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 96-1;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 4294967295;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

