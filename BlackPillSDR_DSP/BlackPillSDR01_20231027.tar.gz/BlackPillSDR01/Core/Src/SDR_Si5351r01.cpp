/*
* SDR_Si5351r01.cpp
*
*  Created on: Feb 13, 2022
*  Author: jim(KW4KD)
*  This version features FFT display, USSB Demodulation, Freq control via i2c3 link to si5351,
*  4 band selection, T/R relay Control, & Manual Key input
*  This version exploits the Built-in special computational features486 of the
*  Arm Cortext M4 Processor and the DSP functions found in the STM32F411 processor
*  This project was last compiled using STM32CubeIDE:
*  Version: 1.9.0
*  Build: 12015_20220302_0855 (UTC)
******************************************************************************
* @file           : SDR_Si5351r01.cpp
* @brief          : Main program body
******************************************************************************
* @attention
*
* <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
* All rights reserved.</center></h2>
*
* This software component is licensed by ST under BSD 3-Clause license,
* the "License"; You may not use this file except in compliance with the
* License. You may obtain a copy of the License at:
* opensource.org/licenses/BSD-3-Clause
*
******************************************************************************
*    Notes:
*        - Under "Options for target" > "C/C++" > "Define" you must add 2 defines (I've already add them):
*            - ARM_MATH_CM4 // Do this below -JMH
*            - __FPU_PRESENT=1 //stm32f411xe.h does this -JMH
* 	to line 939 of stm32f4xx_hal_i152s_ex.c
* 	add the following entry:
*   	HAL_I2SEx_TxRxCpltCallback(hi2s);//JMH 20210122 added per video
*  	Note: located in Drivers/STM32F4xx_HAL_Driver/Src folder.
******************************************************************************
*/
/* 20220227 converted sig reading (gain value) to S meter reading */
/* 20220228 Added memory2memory DMA method to decrease I2S interrupt execution time */
/* 20220301 Refined Button timing to make tuning easier to manage & modified TFTMsgBox.cpp file to solve display issue */
/* 20220302- replaced old show tune code with new tftmsgbx.TuneFreq(int RxFreq)" method */
/* 20220303 Added 2nd audio filter option via GUI (W= 1000Hz / N=500Hz) */
/* 20220304 Added WWV band Option */
/* 20220305 Added freq tune memory & band default setting to band buttons */
/* 20220309 Fixed issue with Selected Band getting lost when filter option changed */
/* 20220321 Fixed S meter not incrementing @ +6.0db; FFT view not following band changes */
/* 20220322 Added "Auto zero beat" Screen touches inside FFT zone */
/* 20220323 modified KeyEvntSR() routine to stop audio squeal*/
/* 20220327 Added 2nd layer to Auto-Zero beat routine; Now samples audio for 30
 * periods, and derives tone freq, to further "zero in" on the actual far
 * end carrier frequency */
/* 20220328 Changed gain calculation method to reduce side-tone clipping */
/* 20220331 Added Zero Beat Button & refined Zero Beat/ fine-tune routine */
/* 20220404 Added limited SDR->FLDIGI RigCatcontrol support */
/* 20220409 Added Frequency Tick marks15 to FFT display  */
/* 20220510 Added Fix for 2.8"displays that report their ID as "0xD3D3"  */
/* 20220519 Adjusted tp.z (touch sensitivity) to better capture left side of FFT space
 * 20220617 Minor code change to GenSideTone function to reduce keyclicks in output audio
 * 20220625 changed auto-tune to calc tone freq from raw audio output; not volume adjusted audio
 * 20220704 Added touch screen calibration as part of setup/config option
 * 20220705 Starting add of si5351 feq calibration settings screen
 * 20220706 Basic functionality of si5351 feq calibration settings screen
 * 20220713 Added Mixer Balance Setup/configure parameters; uses clk2 as reference injection signal
 * 20220715 moved touch screen calibrate routine into the Options Menu Collection; to do this had to modifiy the "diagnose pins" routine to stop PB8 configuration change messing up the Si5351 interface
 * 20220718 Added Cal/Chk Sound board Sample Applied Rate to Ballance Mixer Settings Screen
 * 20220719 added side-tone adjustment to Ballance Mixer Settings Screen
 * 20220721 Added EEprom Save/load parameters/settings to menu options list
 * 20220820 Minor changes to 2nd stage auto zero beat routines to improve its reliability
 * 20220916 Added stylus cursor to confirm/show how well the Touch Screen Cal routine works
 * 20220922 changed diagnose pins process in TchscrnCal.cpp yet again to better support/interpret blackpill ADC readings
 * 20220924 reworked LO+ & LO- button wording shape & position
 * 20221008 Added new TX delay routine that eliminates chopping 1st element in CW character by the delay interval
 * 20221011 Added TR timing screen/option; Allow builder to set their own timing parameters
 * 20221018 Added freq limits to spectrum/fft display
 * 20221019 Added  ShwVol(float) method & store to EEPROM
 * 20221021 Added the ability to change the LO frequency from the SDR screen
 * 20221026 reworked stepping LO frequency & Hi & Lo side FFT views/buttons and limit one operation/button press
 * 20221031 added out of band TX protection "Valid(int)", and red tune frequency indication
 * 20221101 Added green RIT marker to better indicate xcvr running in "split" mode
 * 20230815 Added volume parameter when calculating sidetone data points
 * 20230823 Setup/configured for full FFT spectrum
 * 20230830 Further refined button code to better support both narrow & wide spectrum displays
 * 20230901 Added CW/US(b)/LS(b) demod mode button & filter coefficients to support the new modes
 * 20230903 Added manual tuning via "status tune" & Up/Dwn buttons
 * 20230904 Added dither LO freq +/1 10Khz Button
 * 20230905 Added Jump to touch screen calibrate on startup w/ touch screen while reset
 * 20230908 Replaced 195 tap narrow FIR filter W/ 2 stage BP IIR filter
 * 20230910 replaced manual IIR filter with CMSIS-DSP based code
 * 20231009 Added Accept Frequency change from remote source (FLDIGI)
 * 20231013 reworked GetRmtCmd() to accept hamlib usb interface to mimic IC7300
 * 20231015 further enhancements to CI-v USB control code including reducing jerky key input response
 * 20231017 further enhancements to CI-v USB control code added RIT/SPLIT commands; reworked pole & CIV status output
 * 20231025 further enhancements to CI-v USB control code added A/B VFO, Audio Volume, Band & Filter Select, & S meter
 * 20231025 Minor Tweaks to CI-v code mostly improvements related to displaying results from User input
 * 20231027 More CI-v code tweaks to better support split & dual VFOs
 * */
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB4|PB9|
/*          |GRY|PUR|BLU|GRN|YEL|ORN|ORN|YEL| |GRN|BLU|PUR|GRY|WHT|
 *  Digilent Sound board connections:
 *    Black Pill			   Pmod I2S2
 * PA3.Signal=I2S2_MCK        Pin 1 & 7
 * PB10.Signal=I2S2_CK        Pin 3 & 9
 * PB12.Signal=I2S2_WS		  Pin 2 & 8
 * PB14.Signal=I2S2_ext_SD    Pin 10
 * PB15.Signal=I2S2_SD        Pin 4
 * 3.3V						  Pin 6 &DEBUG1 12od mode button & filter coefficients to support the new modes
 * 20230901 Added manual tuning via
 * Gnd 						  Pin 5 & 11
 *
 */

/* Si5351/SSMicro connections for I2c communications
 *
 * PB8 = I2C3 SDA PUR
 * PA8 = I2C3 SCL BLU
 * PA9 = BndD0    YEL
 * PA10= BndD1    grn //`ORN
 * PB13= TRrelay  GRY
 * PA15= KeyIn    WHT
 * +5V = 		  RED
 * GND =		  BLK
 * */
/* DeBug SWO Pin
 *       PB3
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
//#define DEBUG1
#define ARM_MATH_CM4
//#define __FPU_PRESENT = 1 //JMH - already declared in stm32f411xe.h

#define FFT_SIZE    (512) /* FFT size is always the same size as we have samples, so 256 in our case */
#define SAMPLES     (2*FFT_SIZE)         /* 256 real parts and 256 imaginary parts */
#include "main.h"  //"SDRtest01.h" //
//#include "SDR_Si5351r01.h"//Doing this caused un-fixable compile errors
#include "filter.h"
#include "TchScrnCal.h"
#include "CalSI5351Freq.h"
#include "BallanceMixer.h"
#include "SettingsMenu.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include "arm_math.h"
#include "arm_const_structs.h"
#include "Arduino.h"
#include "SerialClass.h"
#include "pgmstrings.h"
#include "TFTMsgBox.h"
#include "TouchScreen_kbv.h"
#include "FreeSerif9pt7b.h"
#include "gfxfont.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <complex.h>
#include <limits.h>
#include <math.h>
#include <eeprom.h>
/* includes for FFT support */
#include "STM32F411def.h"
#include "UTFTGLUE.h"
#include "si5351.h"
/* Private variables ---------------------------------------------------------*/

I2S_HandleTypeDef hi2s2;
DMA_HandleTypeDef hdma_spi2_tx;//sound board ring buffer
DMA_HandleTypeDef hdma_i2s2_ext_rx;//sound board ring buffer
DMA_HandleTypeDef hdma_memtomem_dma2_stream0;// advance ARMdecimate_buffer
/* Note: Timer 5 used by this program as well as some libraries
 * to do micro-second time measurements
 */
/* FFT Stuff */
const arm_cfft_instance_f32 CFFT_Instances[] = {
	{16, twiddleCoef_16, armBitRevIndexTable16, ARMBITREVINDEXTABLE__16_TABLE_LENGTH},
	{32, twiddleCoef_32, armBitRevIndexTable32, ARMBITREVINDEXTABLE__32_TABLE_LENGTH},
	{64, twiddleCoef_64, armBitRevIndexTable64, ARMBITREVINDEXTABLE__64_TABLE_LENGTH},
	{128, twiddleCoef_128, armBitRevIndexTable128, ARMBITREVINDEXTABLE_128_TABLE_LENGTH},
	{256, twiddleCoef_256, armBitRevIndexTable256, ARMBITREVINDEXTABLE_256_TABLE_LENGTH},
	{512, twiddleCoef_512, armBitRevIndexTable512, ARMBITREVINDEXTABLE_512_TABLE_LENGTH},
	{1024, twiddleCoef_1024, armBitRevIndexTable1024, ARMBITREVINDEXTABLE1024_TABLE_LENGTH},
	{2048, twiddleCoef_2048, armBitRevIndexTable2048, ARMBITREVINDEXTABLE2048_TABLE_LENGTH},
	{4096, twiddleCoef_4096, armBitRevIndexTable4096, ARMBITREVINDEXTABLE4096_TABLE_LENGTH}
};
typedef struct {
	float32_t* Input;               /*!< Pointer to data input buffer. Its length must be 2 * FFT_Size */
	float32_t* Output;              /*!< Pointer to data output buffer. Its length must be FFT_Size */
	uint16_t FFT_Size;              /*!< FFT size in units of samples. This parameter can be a value of 2^n where n is between 4 and 12 */
//	uint8_t UseMalloc;              /*!< Set to 1 when malloc is used for memory allocation for buffers. Meant for private use */
	uint16_t Count;                 /*!< Number of samples in buffer when using @ref TM_FFT_AddToBuffer function. Meant for private use */
	const arm_cfft_instance_f32* S; /*!< Pointer to @ref arm_cfft_instance_f32 structure. Meant for private use */
	float32_t MaxValue;             /*!< Max value in FTT result after calculation */
	uint32_t MaxIndex;              /*!< Index in output array where max value happened */
} TM_FFT_F32_t;
typedef struct {
	const int Lo;
	const int Hi;
} BandTXlimits;
/*setup TX limits*/
BandTXlimits BndStops[4]{
	{3500000, 3600000},
	{7000000, 7125000},
	{10100000, 10150000},
	{14000000, 14150000}
};
BandConfig_t BandSetting[5];
char RevDate[9] = "20231027";

float Vfos[2];//used primarily to support CiV commands & the concept of 2 VFOs A & B
int BVfo =0;//used primarily to support CiV commands & the concept of 2 VFOs A & B
unsigned long TnPrdStrt;
bool TstNegFlg = false;
uint8_t NoTnCntr = 10;
uint8_t ZeroXCntr = 0;
uint8_t PeriodCntr = 0;
int DemodFreq = 0;
bool FinTune = false;
bool FreqCalMode = false;
bool RITMode = false;
bool FFTWide = true;
bool USBflg = true;
unsigned long halfCntr;
unsigned long fullCntr;
unsigned long mainlpCntr;
unsigned long HalfCnt;
unsigned long FullCnt;
/* Variable listing used in AGC code */
const float maxTXmag = ((float)(0xFFFFFF))* 48.0;//800000000;//16777215 = 0xFFFFFF 24bit max val
const float maxGain = 100;
float strtfrqErase = 0;
int stepErase = 0;
float RuningAvg;
float PeakVal;
float GainCoefnt;
float LastLSmpl;
float LastRSmpl;
float SmplBuf[100];
int SmplBufPntr;
int SmplCntr;
int skipCnt;
int perioRefCnt = 50; // used in 2nd stage AutoZero Beat routine
bool HalfCpltFlg;
bool FullCpltFlg;
bool AGConFlg;
bool busy;
uint8_t Buffer[50];
const float Pk2AvgCoef = 1.58;
char StrdTxt[140] ={'\0'};

char Title[140];
//uint8_t Cmd[64]; //used in FLDIGI serial interface
/* TFT Touch Screen variables*/
/*copy and past the following two lines from report
  generated by running the STM32_TouchScreen_Calibr_native Sketch
*/
/* TFT 2.4" Display */
//const int XP=PB4,XM=PA1,YP=PA0,YM=PB7; //480x320 ID=0x9486
//const int TS_LEFT=74,TS_RT=890,TS_TOP=881,TS_BOT=156;//TS_RT=844

/* TFT 2.8" Display  */
//int XP=PB6,XM=PA7,YP=PA6,YM=PB7; //320x240 ID=0x4747
int XP = PB7, YP = PA1, XM = PA0, YM = PB4;// for N4HAY's touch screen
//int TS_LEFT=75,TS_RT=931,TS_TOP=103,TS_BOT=851;
int TS_BOT = 895, TS_LEFT = 118, TS_TOP = 136, TS_RT = 929;// for N4HAY's touch screen


int scrnHeight = 240;//pixel count
int scrnWidth = 320;//pixel count
TSPoint_kbv tp; //global point
int SkipRdBtns = 1000;
/* Si5351 variables */
/* A positive 'XtalErr' number lowers the output frequency.
 * On WWV the beep is 1Khz, & the tone can be either 600 or 500hz.
 * So for USB demodulation, if the tones are low, then the correction needs to
 * be a more positive value
 */
int XtalErr = -10400-(100*12);// integer value measured to 0.01 Hertz ie 100 = 1.00Hz
bool SetRX;
bool SetTX;
/*End variable listing used in original AGC code */
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
//static void MX_I2C3_Init(void);
static void MX_I2S2_Init(void);
//static void MX_TIM5_Init(void);
static void MX_ADC1_Init(void);
//static void MX_USB_OTG_FS_PCD_Init(void);
//void AGCModule(int *LdataSmpl, int *RdataSmpl);8; //12250
void SDRModule(void);//short *LdataSmpl, short *RdataSmpl
//__complex__ float CmplxMult(__complex__ float N1, __complex__ float N2);
int AutoZero(float32_t *maxSig, int TuneBin);
void FFTSel(bool FFTup, bool FFTWide);
float hamming(float x);
void EvalDMAtime(void);
void Jump2XtalCal(int ButNo);
void BldMainScrn(void);
extern uint8_t CDC_Transmit_FS(uint8_t* Buf, uint16_t Len);
//void delay_us (uint16_t us);
uint16_t SetRGB(byte r, byte g, byte b);
int ReadBtns(void);
void ConFigNuFreq(void);
void UpDtLOfreq(int rxcenter);
int GetTouchPts(int &px, int &py);
void readResistiveTouch(void);
bool ShowTunePos(float CurTunFreq, float LstBinfreq);
void BldButtons(void);
void BldBtn(int BtnNo, BtnParams Btns[]);
bool BtnActive(int BtnNo, BtnParams Btns[], int px, int py);
void ShwSlctdFFTbtn(bool FFTPlus);
void ShwDModbtn(int DmodMode);
void SetZeroBtbtn(int mode);
void SetRITbtn(int mode);
void ShwSlctdBndBtn(int BtnNo);
void ShwSlctdFltrBtn(int BtnNo);
bool GetRmtCmd(void);
void SayOK(void);
void SayNG(void);
int BCD2Int(uint8_t *SrcData, int ptr, int stop);
void Int2BCD(int Val, uint8_t *SrcData, int ptr, int stop);
void KeyEvntSR(void);
void StartTX(void);
void StopTX(void);
void InstalFltr(void);
void LdTXBuffer(int offset);
void UnPakRxBuf(int offset);
void GenSideTone(void);
void DrwFrqMrkrs(int TunePos);
void EraseOldMrkrs(void);
void sendFrequency(float HzFreq);
void SetUPFIR(const __complex__ float *Fltr, size_t TapCnt);
void Calc_IIR_BPFltrCoef(float Fc, float Fs, float Q);
void CalcIQfactors(void);
void ApplySmplRate(int SamplRateInt);
void ApplySideTone(int Freq);
void LdFactryVals(void);
bool ValidTX(int tstFreq);
/* USER CODE BEGIN PFP */
//PCD_HandleTypeDef hpcd_USB_OTG_FS; //JMH 20220505 commented this line out to avoid redefinition conflict when using CUBIDE1.9.0
MCUFRIEND_kbv tft;
//const GFXfont f = FreeSerif9pt7b; //= FreeSerif9pt7b ;
TFTMsgBox tftmsgbx(&tft, StrdTxt);
TouchScreen_kbv ts(XP, YP, XM, YM, 300);
//UTFTGLUE myGLCD(0,0,0,0,0,0);// needed/used for FFT display plot/draw calls

SerialClass Serial; // Arduino styuint8_t void PrintAllDescriptors(UsbDevice *pdev)getdevdescr( uint8_t addr, uint8_t &num_conf );le Serial class
Si5351 si5351; //Create I2c3 access to Si5351 programmable clocks
/* USER CODE END PFP */
/*EEprom support variables*/
uint16_t VirtAddVarTab[NB_OF_VAR] = {0x0000, 0x0002, 0x0004};//added to support EEPROM operation/library
uint16_t VarDataTab[NB_OF_VAR];//added to support EEPROM operation/library
struct DF_t DFault;
template <class T>
int EEPROM_read(uint16_t ee, T& value)
{
   uint16_t* p = (uint16_t*)(void*)&value;
   uint16_t tmp;
   int i=0;
   while (i < sizeof(value)){
       //*p++ = EEPROM.read(ee++);
	   EE_ReadVariable(ee, &tmp);
	   ee +=2;
	   i +=2;
	   *p = tmp;
	   p++;//p +=2;
   }
   return i;
}

//modulation: can be 'l', 'u', 'a', 'f' for LSB, USB, AM, FM respectively
char modulation = 'u';
bool AGCflg = true;
int rxcenter = 7040000;// 7060000; //3550000; //
//int rxfreq =  +11400;//WSPR 40 mtrs
int rxfreq = 7028000; //7072000;// 7071000;// 3561500;/
int txfreq =  rxfreq;
int txfreqOld = 0;
float32_t PhaseErr = 0.0;//+1.3;//
//samp_rate: sampling rate of the input signal (in samples per second)
float samp_rate = 48830;//48800;//48900;//48850;//97700;//;96000;//240000;
//decimate_factor: only 1 out of <decimate_factor> samples will remain at the output of the decimating FIR filter
const int decimate_factor = 8;
const int Halfdecimate_factor = decimate_factor/2;
//output_rate: sampling rate of the output audio signal (in samples per second)
//const int output_rate =  samp_rate/decimate_factor;
//ssb_bw: filter bandwidth for SSB in Hz
const float ssb_bw = 3000;
//amfm_bw: filter bandwidth for AM & FM in Hz
const float amfm_bw = 12000;
//decimate_transition_bw: transition bandwidth for decimating FIR filter
//note: a lower value will slow down processing but will "sharpen" the filter charactersitic
//const float decimate_transition_bw = 2000;//currently not used
/* I2S Transmit & Receive RingBuffers */
uint16_t rxBuf[decimate_factor*2*2*2];//8= decimate factor; 2 = double for whole ringbuffer; two 16 bit words per channel; two channels(i&q)
uint16_t txBuf[decimate_factor*2*2*2];
uint16_t Dmod[4];
float32_t NewiqData[decimate_factor*2];
//LO_Phase_Shift: how much the LO phase is changed from sample to sample when generating the LO (for the shift)
float SideTonefreq = 750;
float CwTunefreq = rxfreq - SideTonefreq;//rxfreq;//
float LastBinfreq = rxcenter+25;
float MinFreq;//initialized in ApplySmplRate()// = rxcenter-(samp_rate/2);
float MaxFreq; //initialized in ApplySmplRate()// = rxcenter+(samp_rate/2);
float LO_Phase_Shift;//initialized in ApplySmplRate()// = ((rxcenter-CwTunefreq)/samp_rate)*2*M_PI;
float LO_Phase = 0;
float ST_Phase = 0;//current angle of Side Tone note
float txd_shift_phase = ((rxcenter-txfreq)/samp_rate)*2*M_PI;
//shift_phase: actual LO phase (for shift)
float shift_phase = 0;
float txshift_phase = 0;
//deicmate_taps_length: how many FIR filter taps we need to reach a given transition BW (should be odd, thus the |1)
int decimate_taps_length;// = FILTER_TAP_NUMN;//(int)(4.0f/(decimate_transition_bw/samp_rate)) | 1;
//decimate_taps: FIR filter taps for the decimating FIR filter:

//__complex__ float decimate_taps[FILTER_TAP_NUMN];
//__complex__ float deMod_taps[DFILTER_TAP_NUM];
int TapCntx2 = FILTER_TAP_NUMN*2;
float32_t ARMdecimate_taps[FILTER_TAP_NUMN*2];
float32_t pDst[FILTER_TAP_NUMN*2];
float32_t ARMdecimate_buffer[FILTER_TAP_NUMN*2];
//float32_t Mag[FILTER_TAP_NUM];
//int decimate_taps_middle = decimate_taps_length/2;

/*CMSIS-DSP IIR Filter variables*/
const int numStages = 2;
float32_t State[2*numStages];
float32_t Coeffs[5*numStages];
float32_t ComputedCoeffs [8*numStages];
arm_biquad_cascade_df2T_instance_f32 S1;
float32_t Src[numStages];
float32_t Dst[numStages];

const float TwoPi = 2.0*M_PI;
/*Flter_Dshift: in case of SSB mode, we shift the filter taps in the frequency domain,
so that the filter will have an asymmetric transmission curve*/
const float Flter_Dshift = (modulation=='u'? +1:-1) *((1550/2)/samp_rate)*TwoPi;//((ssb_bw/2)/samp_rate)*2*M_PI;
//decimate_cutoff_rate: the cutoff frequency (in proportion to the sampling frequency) of the decimating FIR filter
const float decimate_cutoff_rate = (modulation=='u'||modulation=='l') ? (ssb_bw/2)/samp_rate : (amfm_bw/2)/samp_rate;
/* Set Key input "side tone" frequency */
float SideToneAngle = ((SideTonefreq*float(decimate_factor))/float(samp_rate))*M_PI; //750 = Side tone Freq

float maxPhasErr = 10; //(TwoPi/360)*15;//5 degrees converted to Radians
float DPhasCor = 0.1;//maxPhasErr/60;// step change to make in phase error after each pass
float PhasCorect = 0.041;//(TwoPi/360)*0.802140913;//*2.16; // Phase error to be applied during a given pass
float ICFactr; //the correction factor to be applied to the current data 'Q' sample
float QCFactr;
float AmpError = 0.0;
float AmpFactor = 1.0;
float maxAmpEr = 0.2;//0.02;
float DampCor = 0.0005;
float drxfreq = 50;
float drxfreqstop = 4000;
float32_t decimated;
float32_t decimatedA;
float32_t decimatedB;
float32_t decimatedMax;
float32_t DemodGain;
float32_t SideToneGain = 250000000;//Sets the volume level Key input side tone
float32_t Volume;
float32_t Txmag = 25000000;
float32_t Maxvol = 335544280;//83886070.0;//8388607.0
float32_t PhErRad = (TwoPi/360.0)*PhaseErr;
int stop = int((TapCntx2*4)/decimate_factor);////int(sizeof(ARMdecimate_buffer)/decimate_factor);
size_t NuDataByteCnt = sizeof(NewiqData);
size_t ARMdecimateByteCnt;// = sizeof(ARMdecimate_buffer);
int StrtNuNdx;// = (ARMdecimateByteCnt-NuDataByteCnt)/4;

int lastbin; //used by FFT display & TouchScreen frequency detection
int firstbin;
int FreqShft = 0; //select the negative (FreqShft = 0) portion, or positive portion (FreqShft = FFTsize/2) of the FFT to display
//bool decimateFlg = false;
bool printflg = false;
float last_phi = 0;
int demodulator_output;// in this version demodulator_output needs to be a global variable
int demodulator_outputA;
int demodulator_outputB;
unsigned long StrtTime =0;
unsigned long StrtLP =0;
unsigned long HStrtTime =0;
unsigned long FStrtTime =0;
unsigned long H2FIntrvl =0;
unsigned long F2HIntrvl =0;
unsigned long LPIntrvl =0;
/* End declaration of global SDR variables */
/* FFT Specific Variables */
bool AFlg =false;
bool ARdy =false;
bool FullIntrv =false;
int MicPin = PB1;
float32_t InputA[SAMPLES];   /*!< Input buffer is always 2 * FFT_SIZE */
//float32_t InputB[SAMPLES];   /*!< Input buffer is always 2 * FFT_SIZE */
//int Pntr =0;
float32_t OutputA[FFT_SIZE]; /*!< Output buffer is always FFT_SIZE */
TM_FFT_F32_t FFTA;
/*buttons*/
const int BtnCnt = 22;//added 20 for dither LO added 19 forDemod Mode//added 18 for Wide/Nar FFT
int IntrpAsec;//initialized in ApplySmplRate()// =int(samp_rate/decimate_factor);
BtnParams SetUpBtns[BtnCnt];
unsigned long PTTtimeOut = 0;
unsigned long ExecTXCmd = 0;
bool TXON = false;
unsigned long TXdelay = 8; //millisecond delay in applying Si5351 TX ON/ TX OFF commands
unsigned long TRHangTime = 160; //millisecond wait interval to resume RX mode after last key closure
/* 160 Ms hangtime => @WPM > 22.5, T/R relay will stay closed during characters sent as words */
bool PTT = false; // tracks the state of the TR relay (true = relay in TX state)
bool KeyClosed = false;  // tracks instantaneous state of an external key (true = Key in "Key Down" state
bool KeyActive;
int BntCntrStop;
int CurSelBnd;
int GrphBase = 223;
int GrphTop = 120;
int TuneBinTX = 0;
int TuneBinRX = 0;
int FltrBtn = 12;
int NoiseFlr;
bool NuTunFrq = true;
//bool UpdateRmt = true;
bool ShwLmts = true;
bool ShwVolLvl = true;
bool BtnEnable = true;
bool TXrdy = true;
bool EraseRIT = false;
//bool Plus = false;
float binfrqWdth; //initialized in ApplySmplRate()// = samp_rate/(FFT_SIZE);
int OldSpecVals[FFT_SIZE];
float CurSpecVals[FFT_SIZE]; //FFT display variable
int BinLimit;
int fftswopt =0;
int digPos =100;
bool SpecMode = true;
int DitherCnt = 0;
/*iir BP Filter delay buckets*/
float in_z2, in_z1, out_z2, out_z1;
float in_z3, in_z4, out_z3, out_z4;
bool IIRflg = false;
float a0 = 0.08599609327133607;
float a1 = 0.0;
float a2 = -0.08599609327133607;
float b0 = 1.0;
float b1 = -1.309777513510262;
float b2 = 0.8280078134573279;
bool CivON = false;
float32_t OldDBmVal;

int main(void)
{
	halfCntr = 0;
	fullCntr = 0;
	mainlpCntr = 0;
	decimatedMax= 0.0;
	DemodGain = 10;//2.32700134e-18;
	Volume = 1.0; //audio output volume
	HalfCpltFlg = true;
	FullCpltFlg = false;
	AGConFlg = false;
	busy = false;
	KeyActive = false; //tracks recent Key activity; true = key was operated recently
	SmplBufPntr = 0;
	SmplCntr = 0;
	LastLSmpl = 0;
	LastRSmpl = 0;
	uint16_t yellow = SetRGB(255,255,0); //yellow
	uint16_t black = SetRGB(0,0,0); //black
	uint16_t red = SetRGB(255,0,0); //red
	uint16_t green = SetRGB(0,255,0); //red
	uint16_t blue = SetRGB(0,0,255); //blue
	/* apply phase error correction to incoming I/Q data stream */
//	ICFactr = (1+ (0.5*arm_sin_f32(PhasCorect)));
//	QCFactr = 1/ICFactr;
	/*###########################################################################*/
	/*                      Begin FFT setup                                      */
	/* Init FFT, FFT_SIZE define is used for FFT_SIZE, sample count is 2*FFT_SIZE*/
	//TM_FFT_Init_F32(&FFTA, FFT_SIZE, 0);
	/* Check for proper pointer value */
	for (int i = 0; i < 9; i++) {
		/* Check for proper number */
		if (FFT_SIZE == CFFT_Instances[i].fftLen) {
			/* Set FFT size */
			FFTA.FFT_Size = FFT_SIZE;

			/* Save proper pointer */
			FFTA.S = &CFFT_Instances[i];

			/* Stop for loop */
			break;
		}
	}
	/* Input buffer must be 2*FFT_SIZE in length because of real and imaginary part */
	/* Output buffer must be FFT_SIZE in length */
	//TM_FFT_SetBuffers_F32(&FFTA, InputA, OutputA);
	FFTA.Input = InputA;
	FFTA.Output = OutputA;
	/*                         End FFT SetUp Code                               */
	/*###########################################################################*/
	/* Setup default band settings (5) */
	BandSetting[0].ButtonNo = 6;
	BandSetting[0].CwTunefreq = 3561500 - SideTonefreq;
	BandSetting[0].SideTonefreq = SideTonefreq;
	BandSetting[0].UpFFTflg = true;
	BandSetting[0].rxcenter = 3550000;
	BandSetting[0].FltrOpt = 1;
	BandSetting[0].PhasCorect = 11.5;
	BandSetting[0].AmpFactor = 0.9595;
	BandSetting[0].FFTWide = true;
	BandSetting[0].DmodMode =0; //CW

	BandSetting[1].ButtonNo = 7;
	BandSetting[1].CwTunefreq = 7028000 - SideTonefreq;
	BandSetting[1].SideTonefreq = SideTonefreq;
	BandSetting[1].UpFFTflg = false;
	BandSetting[1].rxcenter = 7040000;
	BandSetting[1].FltrOpt = 1;
	BandSetting[1].PhasCorect = 0.8;
	BandSetting[1].AmpFactor = 0.9580;
	BandSetting[1].FFTWide = true;
	BandSetting[1].DmodMode =0; //CW


	BandSetting[2].ButtonNo = 8;
	BandSetting[2].CwTunefreq =  10112000 - SideTonefreq;
	BandSetting[2].SideTonefreq = SideTonefreq;
	BandSetting[2].UpFFTflg = false;
	BandSetting[2].rxcenter = 10125000;
	BandSetting[2].FltrOpt = 1;// med
	BandSetting[2].PhasCorect = 0.2;
	BandSetting[2].AmpFactor = 0.9475;
	BandSetting[2].FFTWide = true;
	BandSetting[2].DmodMode =0; //CW

	BandSetting[3].ButtonNo = 9;
	BandSetting[3].CwTunefreq = 14047500 - SideTonefreq;//W1AW bulletin freq - sidetone freq(appears to be ~25hz higher than advertised)
	BandSetting[3].SideTonefreq = SideTonefreq;
	BandSetting[3].UpFFTflg = true;
	BandSetting[3].rxcenter = 14040000;
	BandSetting[3].FltrOpt = 1;// med
	BandSetting[3].PhasCorect = -2.20;
	BandSetting[3].AmpFactor = 0.8810;
	BandSetting[3].FFTWide = true;
	BandSetting[3].DmodMode =0; //CW

	BandSetting[4].ButtonNo = 10;
	BandSetting[4].CwTunefreq = 10000000;
	BandSetting[4].SideTonefreq = 0;
	BandSetting[4].UpFFTflg = false;
	BandSetting[4].rxcenter = 10010000;// LO freq
	BandSetting[4].FltrOpt = 0; //wide Filter
	BandSetting[4].PhasCorect = 2.2;
	BandSetting[4].AmpFactor = 0.994;
	BandSetting[4].FFTWide = false;
	BandSetting[4].DmodMode =1; //USB

	CurSelBnd = 1;

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();
	H2FIntrvl =0;
	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER StrtLP =__HAL_TIM_GET_COUNTER(&htim5);CODE BEGIN SysInit */
//	decimateFlg = false;
	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_USB_DEVICE_Init();
	MX_I2S2_Init();
	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, (GPIO_PinState)1);//LED Off
	SystemInit();
	coretick_init(); //JMH Added to support time measurements i.e millis() & micros() see Arduino.h & Arduino.cpp

	DFault.TS_BOT = TS_BOT;
	DFault.TS_LEFT = TS_LEFT;
	DFault.TS_RT = TS_RT;
	DFault.TS_TOP = TS_TOP;
	DFault.XM = XM;
	DFault.XP = XP;
	DFault.XtalErr = XtalErr;
	DFault.YM = YM;
	DFault.YP = YP;
	DFault.samp_rate = samp_rate;
	DFault.scrnHeight = scrnHeight;
	DFault.scrnWidth = scrnWidth;
	DFault.TXdelay = TXdelay; //millisecond delay in applying Si5351 TX ON/ TX OFF commands
	DFault.TRHangTime = TRHangTime;
	DFault.Volume = Volume;
	DFault.SideTonefreq = SideTonefreq;
	/* EEPROM Init */
	/*Start EEPROM read session by unlocking the EEprom Flash memory area */
	FLASH_Unlock();
	uint16_t reslt = EE_Init();
	if (reslt != fLASH_COMPLETE){
		tftmsgbx.InitDsplay();
		sprintf(Title, "EEPROM Init ERROR: %d", reslt);
		tftmsgbx.dispTitl(Title, TFT_RED);
		while(1){
			delay(100);
		}
	}

	int	n;
	int offset = 0;
	n = EEPROM_read(EEaddress+(offset),TS_BOT);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, TS_LEFT);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), TS_TOP);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), TS_RT);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, XM);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), XP);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, YM);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, YP);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, scrnHeight);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), scrnWidth);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), TXdelay);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), TRHangTime);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), Volume);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, XtalErr);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, samp_rate);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, SideTonefreq);
	offset += 2*n;

/*Close out EEPROM read session by locking the EEprom Flash memory area */
	FLASH_Lock();
	if((TS_BOT ==0) && (TS_LEFT ==0)){// no user settings found
		LdFactryVals();// restore startup settings
		tftmsgbx.InitDsplay();
		tftmsgbx.setTxtSize(0);
		tftmsgbx.setFont(8, 8);//setFont(w,h)
		sprintf( Title, "        No stored USER params Found       Using FACTORY values until params are   'Saved' via the Settings Screen");
		tftmsgbx.dispMsg(Title, TFT_ORANGE);
		tftmsgbx.dispMsg2();
		tftmsgbx.setTxtSize(1);
		delay(2000);
		TchScrnCal_MainLoop();
//		ts.ReDefineTchPins(XP, YP, XM, YM); //use the touch pin settings discovered during the screen calibration process
		tftmsgbx.setTxtSize(2);
		tftmsgbx.setFont(12, 16);//setFont(w,h)
	} else{

		/*Found some user settings;  Get the rest of them & map them to running params/variables */
		ts.ReDefineTchPins(XP, YP, XM, YM); //use the touch pin settings found on the EEPROM
		DFault.SideTonefreq = SideTonefreq;
#ifdef DEBUG1
	delay(6000);
	sprintf(Title, "TS_BOT: %d", TS_BOT);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "TS_LEFT: %d", TS_LEFT);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "TS_TOP: %d", TS_TOP);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "TS_RT: %d", TS_RT);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "XM %d", XM);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "XP: %d", XP);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "YM: %d", YM);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "YP: %d", YP);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "scrnHeight %d", scrnHeight);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "scrnWidth: %d", scrnWidth);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "XtalErr: %d", XtalErr);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "samp_rate: %f", samp_rate);
	Serial.println(Title);
	delay(60);

#endif

		FLASH_Unlock();
		for(int i = 0; i<4; i++){
			n= EEPROM_read(EEaddress+offset,BandSetting[i].CwTunefreq);
			offset += 2*n;
			n= EEPROM_read(EEaddress+offset,BandSetting[i].SideTonefreq);
			offset += 2*n;
			n= EEPROM_read(EEaddress+offset,BandSetting[i].UpFFTflg);
			offset += 2*n;
			n= EEPROM_read(EEaddress+offset,BandSetting[i].PhasCorect);
			offset += 2*n;
			n= EEPROM_read(EEaddress+offset,BandSetting[i].AmpFactor);
			offset += 2*n;
			n= EEPROM_read(EEaddress+offset,BandSetting[i].FFTWide);
			offset += 2*n;
			n= EEPROM_read(EEaddress+offset,BandSetting[i].DmodMode);
			offset += 2*n;
#ifdef DEBUG1
	sprintf(Title, "BandSetting[%d].CwTunefreq: %d",i, BandSetting[i].CwTunefreq);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "BandSetting[%d].SideTonefreq: %d",i, BandSetting[i].SideTonefreq);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "BandSetting[%d].UpFFTflg: %d",i, int(BandSetting[i].UpFFTflg));
	Serial.println(Title);
	delay(60);
	sprintf(Title, "BandSetting[%d].PhasCorect: %f",i, BandSetting[i].PhasCorect);
	Serial.println(Title);
	delay(60);
	sprintf(Title, "BandSetting[%d].AmpFactor: %f",i, BandSetting[i].AmpFactor);
	delay(60);
#endif
		}
		FLASH_Lock();
	}
	arm_fir_instance_f32 S;
	arm_status status;

	/* initialize Si5351 clocks */
	  si5351.init(SI5351_CRYSTAL_LOAD_10PF, 0, XtalErr);//si5351.init(SI5351_CRYSTAL_LOAD_8PF, 0, XtalErr);
	  si5351.set_ms_source(SI5351_CLK0, SI5351_PLLA);
	  si5351.set_ms_source(SI5351_CLK1, SI5351_PLLA);
	  si5351.set_ms_source(SI5351_CLK2, SI5351_PLLB);
	  si5351.set_clock_invert(SI5351_CLK0, 0);//*
	  si5351.set_clock_invert(SI5351_CLK1, 1);//*
	  si5351.set_phase(SI5351_CLK0, 0);
	  si5351.set_phase(SI5351_CLK1, 0);
	  si5351.drive_strength(SI5351_CLK0, SI5351_DRIVE_2MA);//* //SI5351_DRIVE_2MA ; SI5351_DRIVE_4MA ; SI5351_DRIVE_8MA
	  si5351.drive_strength(SI5351_CLK1, SI5351_DRIVE_2MA);//*
	  si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_8MA);//*// Tx Clock
	  si5351.set_clock_disable(SI5351_CLK2, SI5351_CLK_DISABLE_LOW);//* //enum si5351_clock_disable {SI5351_CLK_DISABLE_LOW, SI5351_CLK_DISABLE_HIGH, SI5351_CLK_DISABLE_HI_Z, SI5351_CLK_DISABLE_NEVER};

	  // Need to reset the PLL before Clocks will be in phase alignment
	  si5351.pll_reset(SI5351_PLLA);//*
	  SetRX = true;
	  SetTX = false;
	  CwTunefreq = BandSetting[CurSelBnd].CwTunefreq;
	  Vfos[0] = Vfos[1] = CwTunefreq; //initialize the vfo memory array
	  rxcenter = BandSetting[CurSelBnd].rxcenter;
	  SideTonefreq = BandSetting[CurSelBnd].SideTonefreq;
	  FFTWide = BandSetting[CurSelBnd].FFTWide;

	  sendFrequency(float(rxcenter));
	  /* Initialize using Medium audio filter */
	  SetUPFIR(filter_tapsM, FILTER_TAP_NUMM);

	/* begin touchscreen setup*/
	tftmsgbx.InitDsplay();//Need to do this or "readResistivetouch()" wont work
//	tftmsgbx.setTxtSize(2);
//	tftmsgbx.setFont(12, 16);//setFont(w,h)(12, 16)
//
//	sprintf( Title, "STM32F411 SDR/FFT(%s)\n", RevDate );
//	tftmsgbx.dispTitl(Title, TFT_CYAN);
//	tftmsgbx.LOFreq(rxcenter);
//	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));

	/* Prepare/Declare variables needed to display FFT results */
	const float Gain = 20;//1.2*20; //FFT display variable
//	NoiseFlr = 145;
	AFlg = true; //enable FFT data/sample collecting
	int BinsDsplyd = scrnWidth;

	int Grphspan = GrphBase - GrphTop;
	int tst_val = Grphspan;
	ApplySmplRate(int(samp_rate));
//	BldButtons();
//	txfreq = CwTunefreq + SideTonefreq;
//	if(!FFTWide)TuneBinTX = int((LastBinfreq-(txfreq))/binfrqWdth);//commented out for full fft spectrum
//	else TuneBinTX = int((LastBinfreq-(txfreq))/(2*binfrqWdth));//added for full fft spectrum
//	NuTunFrq = true;
	bool FFTStp3 = false;
//	UpdateRmt = true;
//	ShwLmts = true;
//	ShwVolLvl = true;
//	Cmd[0]=0;
	int autoZroCntr = 0; //auto zero-beat variable
	float32_t maxSig = 0.0; //auto zero-beat variable
	int BestBin = 0; //auto zero-beat variable
//	int oldTuneBinTX = TuneBinTX;
//	int oldTuneBinRX = 0;//TuneBinTX;//even though this is for RIT, initialize it with the TX bin value
	int rdbntcntr =0;
	int UpdtSmtrCntr = 0;
	int stepLvl =0;
	int step;
	bool DrwMrkrs = false;
	skipCnt =0;
	if(!FFTWide) step = (binfrqWdth);
	else step = (2*binfrqWdth);
	stepErase = step;
	OldDBmVal = -4000;
	CalcIQfactors();
	StrtTime = GetTimr5Cnt();//__HAL_TIM_GET_COUNTER(&htim5);
	/* Start Sound Board DMA to begin IQ capture and stream demodulated audio */
	HAL_I2SEx_TransmitReceive_DMA(&hi2s2, txBuf, rxBuf, decimate_factor*4);
	int lpcnt = 0;
	while(lpcnt < 20){
		lpcnt++;
		readResistiveTouch();
	}
	if (tp.z > 150){
		while(tp.z > 150){
		 delay(10);
		 readResistiveTouch();
		}
		tftmsgbx.setTxtSize(0);
		TchScrnCal_MainLoop();
		ts.ReDefineTchPins(XP, YP, XM, YM); //use the touch pin settings discovered during the screen calibration process
		//BldMainScrn();
	}
	BldMainScrn();
	txfreq = CwTunefreq + SideTonefreq;
	if(!FFTWide)TuneBinTX = int((LastBinfreq-(txfreq))/binfrqWdth);//commented out for full fft spectrum
	else TuneBinTX = int((LastBinfreq-(txfreq))/(2*binfrqWdth));//added for full fft spectrum
	int oldTuneBinTX = TuneBinTX;
	int oldTuneBinRX = 0;//TuneBinTX;//even though this is for RIT, initialize it with the TX bin value
	int CivOnCntr = 0;
	while(1) {

		while(KeyActive){// if true there's been recent key activity
			if(FinTune){
				FinTune = false;
				SetZeroBtbtn(0);
				SetRITbtn(0);
			}
			KeyEvntSR();
			if(HAL_GetTick() >= PTTtimeOut){
				/* Return T/R Relay to Receive position */
				KeyActive = false;
				StopTX(); //make absolutely certain that PA is shutdown
				HAL_GPIO_WritePin(TR_Relay_GPIO_Port, TR_Relay_Pin, GPIO_PIN_RESET);
				PTT = false;
				SetRX = true;//added this to make sure that radio would be configured to change RX freq, on exit from this wait loop.
				DemodGain = 13.5;//force the gain to look like an S9 signal at exit of external key activity
			}
			/*Added to support new approach to effecting delayed Si5351 TX commands*/
			if(HAL_GetTick() >= ExecTXCmd && ExecTXCmd !=0){
				/*Simple ON/OFF method for changing TX(Si5351/Clk2) state */
//				ExecTXCmd =0;
//				if(TXON) StartTX();
//				else StopTX();
				/*Ramped pwr method for turning TX ON & OFF */
				if(TXON){
					switch (stepLvl) {
						case 0:
							si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_2MA);
							StartTX();
							break;
						case 1:
							si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_4MA);
							break;
						case 2:
							si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_6MA);
							break;
						case 3:
							si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_8MA);
							break;
						default:
							break;
					}
					if(stepLvl<3)stepLvl +=1;
					else ExecTXCmd =0;
				}else{
					switch (stepLvl) {
						case 0:
							si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_2MA);
							StartTX();
							break;
						case 1:
							si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_4MA);
							break;
						case 2:
							si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_6MA);
							break;
						case 3:
							si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_8MA);
							break;
						default:
							break;
					}
					if(stepLvl>0)stepLvl -=1;
					else{
						ExecTXCmd =0;
						StopTX();
					}
				}
			}
		}
		int Rslt = 0;
		rdbntcntr++;
		if(CivON){
			CivOnCntr = 5000;
			CivON = false;
		}
		if(CivOnCntr >0){
			CivOnCntr--;
			if(CivOnCntr ==0){
				tftmsgbx.CivPole(TFT_BLACK);
			}
		}
		if(rdbntcntr > BntCntrStop){
			rdbntcntr= 0;
			if(skipCnt>0) skipCnt--;
			if(skipCnt ==0 )Rslt = ReadBtns(); //check to see if user is touching the screen/display
		}

		/* if user is touching the tft screen, scale the frequency change proportional to how far "off center"
		 * the touch point is
		 */
		if(Rslt !=0 ){// user has touched the screen; now figure out what it means
			if(Rslt >-7){//User touched in the inc/dec freq zone(ranges from -6 to +6)
				int DeltaFreq = Rslt*Rslt*5;
				if(Rslt<0) DeltaFreq = -DeltaFreq;
				CwTunefreq += DeltaFreq;
				if(CwTunefreq <MinFreq) CwTunefreq = MinFreq;// don't accept a change beyond 1/2 the sample rate
				if(CwTunefreq >MaxFreq) CwTunefreq = MaxFreq;
				BandSetting[CurSelBnd].CwTunefreq = CwTunefreq;
				LO_Phase_Shift = ((rxcenter-(CwTunefreq))/samp_rate)*TwoPi;
				tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));// post the current RX feq to the status line
				if(!RITMode){
					txfreq = CwTunefreq + SideTonefreq; //based on demod mode = USB & BFO sidetone = 750Hz
					TXrdy = ValidTX(txfreq);//validate that this is a ham legal frequency
					if(!FFTWide) TuneBinTX = int((LastBinfreq-(txfreq))/binfrqWdth);
					else TuneBinTX = int((LastBinfreq-(txfreq))/(2*binfrqWdth));//added for full FFT spectrum
				}else{
					if(FFTWide) TuneBinRX = int((LastBinfreq-(CwTunefreq + SideTonefreq))/(2*binfrqWdth));
					else TuneBinRX = int((LastBinfreq-(CwTunefreq + SideTonefreq))/binfrqWdth);
				}
				NuTunFrq = true;
			} else if(Rslt == -8){//user selected "upper" FFT
				FFTSel(true, FFTWide);
			}else if(Rslt == -9){//user selected "lower" FFT
				FFTSel(false, FFTWide);
			}else if(Rslt == -10){ // volume "up" button pressed
				Volume += Volume/16;
				if(Volume > 1) Volume = 1; //set maximum volume value
				ShwVolLvl = true;
			}else if(Rslt == -11){ // volume "down" button pressed
				Volume -= Volume/16;
				if(Volume <0.05) Volume = 0.05; //set minimum volume value
				ShwVolLvl = true;
			}else if(Rslt == -12){ // one of the band buttons was pressed
				if(!FFTWide) TuneBinTX = int((LastBinfreq-(txfreq))/binfrqWdth);
				else TuneBinTX = int((LastBinfreq-(txfreq))/(2*binfrqWdth));
				NuTunFrq = true;
				if(BandSetting[CurSelBnd].UpFFTflg) FreqShft = FFT_SIZE/2;//display FFT positive freqs
				else FreqShft = 0;//display FFT negative freqs
				tftmsgbx.LOFreq(rxcenter);
				tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
			}else if(Rslt <-100){// user touched inside FFT Display space
				TuneBinTX = lastbin+(Rslt+100);
				if(TuneBinTX> BinLimit) TuneBinTX = BinLimit;
				if((CurSelBnd != 4) && BandSetting[CurSelBnd].DmodMode == 0){ //initiate auto-zero-beat process
					autoZroCntr = 1;
					SetZeroBtbtn(0);
					SetRITbtn(0);
					maxSig = 0.0; //auto zero-beat variable
					BestBin = 0;
				} else if(CurSelBnd != 4){// are not in CW mode & We are not tuned to WWV
					NuTunFrq = true;
					if(!FFTWide) CwTunefreq = LastBinfreq-((TuneBinTX*binfrqWdth)+SideTonefreq);
					else CwTunefreq = LastBinfreq-((TuneBinTX*(2*binfrqWdth))+SideTonefreq);
					if(CwTunefreq <MinFreq) CwTunefreq = MinFreq;// don't accept a change beyond 1/2 the sample rate
					if(CwTunefreq >MaxFreq) CwTunefreq = MaxFreq;
					BandSetting[CurSelBnd].CwTunefreq = CwTunefreq;
					txfreq = CwTunefreq + SideTonefreq; //based on demod mode = USB & BFO sidetone = 750Hz
					TXrdy = ValidTX(txfreq);//validate that this is a ham legal frequency
					LO_Phase_Shift = ((rxcenter-(CwTunefreq))/samp_rate)*TwoPi;
					tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));

				}

			} //End of user touched inside FFT Display space
		}//End if(Rslt !=0)
		if (FFTA.Count >= FFTA.FFT_Size){
			arm_cfft_f32(FFTA.S, FFTA.Input, 0, 1);
			arm_cmplx_mag_f32(FFTA.Input, FFTA.Output, FFTA.FFT_Size);
			if(autoZroCntr > 0){
				int OldTuneBinTX = TuneBinTX;
				TuneBinTX = AutoZero(&maxSig, OldTuneBinTX);
				autoZroCntr++;
				if(autoZroCntr>10){
					autoZroCntr =0;
					SetZeroBtbtn(2);
					FinTune = true;//Step 1 is complete; Start phase 2 to better determine the "far-end" carrier frequency
					DemodFreq =0;
				}
				if(TuneBinTX != OldTuneBinTX){
					NuTunFrq = true;
					if(!FFTWide) CwTunefreq = LastBinfreq-((TuneBinTX*binfrqWdth)+SideTonefreq);
					else CwTunefreq = LastBinfreq-((TuneBinTX*(2*binfrqWdth))+SideTonefreq);
					if(CwTunefreq <MinFreq) CwTunefreq = MinFreq;// don't accept a change beyond 1/2 the sample rate
					if(CwTunefreq >MaxFreq) CwTunefreq = MaxFreq;
					BandSetting[CurSelBnd].CwTunefreq = CwTunefreq;
					txfreq = CwTunefreq + SideTonefreq; //based on demod mode = USB & BFO sidetone = 750Hz
					TXrdy = ValidTX(txfreq);//validate that this is a ham legal frequency
					LO_Phase_Shift = ((rxcenter-(CwTunefreq))/samp_rate)*TwoPi;
					tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
				}
			}
			if(FinTune &&(DemodFreq !=0)){// Phase2 has found the current side-tone frequency
				CwTunefreq = CwTunefreq+(DemodFreq-SideTonefreq);
				if(!RITMode){
					txfreq = CwTunefreq + SideTonefreq; //based on demod mode = USB & BFO sidetone = 750Hz
					TXrdy = ValidTX(txfreq);//validate that this is a ham legal frequency
					if(Abs(DemodFreq-SideTonefreq)<5){
						FinTune = false;// we're tuned close enough for government work. Stop the process
						SetZeroBtbtn(1); //Set zero beat button green
						BandSetting[CurSelBnd].CwTunefreq = CwTunefreq;
						if(!FFTWide) TuneBinTX = int((LastBinfreq-(CwTunefreq+SideTonefreq))/binfrqWdth);
						else TuneBinTX = int((LastBinfreq-(CwTunefreq+SideTonefreq))/(2*binfrqWdth));
						NuTunFrq = true;
					}
				}else{
					FinTune = false;// we're tuned close enough for government work. Stop the process
					if(!FFTWide) TuneBinRX = int((LastBinfreq-(CwTunefreq+SideTonefreq))/binfrqWdth);
					else TuneBinRX = int((LastBinfreq-(CwTunefreq+SideTonefreq))/(2*binfrqWdth));
					NuTunFrq = true;
					SetRITbtn(1); //Set RIT button green
				}
				DemodFreq =0;
				LO_Phase_Shift = ((rxcenter-(CwTunefreq))/samp_rate)*TwoPi;
				tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
			}
			FFTStp3 = true;
		}
		if(FFTStp3){

			FFTStp3 = false;
			/* Convert/Scale FFT results from linear to DB; Also Compute Bin Averages & Peak/Decay */
			float curbinval;//uncomment for full view of FFT
			int step;
			int offset = FreqShft;
			if(FFTWide) offset = 256;//uncomment for full view of FFT
			for (int i = 0; i < BinLimit; i++) {
				if(FFTWide){
					if(i>127) offset = -258;//uncomment for full view of FFT
					step = (2*i)+offset;
					if(FFTA.Output[step+1]> FFTA.Output[step]) step++;
				}else step = i+offset;

				curbinval = __builtin_log10f(FFTA.Output[step]);
				//float curbinval = __builtin_log10f(FFTA.Output[i+FreqShft]);//comment out for full view of FFT
				curbinval = 20*curbinval;
				if (curbinval>0){
					if (curbinval>CurSpecVals[i]) CurSpecVals[i] = (3*CurSpecVals[i]+  curbinval)/4;
					if (curbinval<=CurSpecVals[i])CurSpecVals[i] = (9*CurSpecVals[i]+  curbinval)/10;
				}
			}

			/* Display data bins on LCD */
			//tst_val--;
			//if(tst_val<0) tst_val = Grphspan;
			/* Draw FFT results */
			int lineLen =0;
			int binSum = 0;
			for (int Xpxl = lastbin; lastbin-Xpxl < BinLimit; Xpxl--) {
				int cur_bin = lastbin- Xpxl;
				binSum += CurSpecVals[cur_bin];
				int GOldVal = OldSpecVals[cur_bin];
				int GCurVal = int(CurSpecVals[cur_bin]-NoiseFlr);
				if(GCurVal<0) GCurVal = 0;
				if(GCurVal>Grphspan) GCurVal = Grphspan;
				int CurYpos = GrphBase-GCurVal;
				if((cur_bin!=TuneBinTX) && (cur_bin!=TuneBinRX)){
					if((CurYpos != GOldVal)){
						/* IF Mag < last time, We need to erase the difference */
						if(CurYpos > GOldVal){// FFT bin magnitude has dropped since last report
							lineLen = (CurYpos-GOldVal);
							if(lineLen > 0) tft.drawFastVLine(Xpxl, GOldVal, lineLen, black);
						}else{
							/* Now build the Current Magnitude segment of the spectrum bar */
							lineLen = (GOldVal-CurYpos);
							if(lineLen>0) tft.drawFastVLine(Xpxl, CurYpos, lineLen, yellow);//
						}
						OldSpecVals[cur_bin] = CurYpos;
					}//end GCurVal != GOldVal
				}else if((TuneBinRX != 0) && EraseRIT && (cur_bin==TuneBinRX)){//swapping back from RIT mode to TX = RX; need to erase obsolete green tuning marker
					EraseRIT = false;
					RITMode = false;
					int OldpxlT = lastbin- oldTuneBinRX;
					int FFTHght = (GrphBase-GrphTop);
					//lineLen = (GrphBase- OldSpecVals[OldpxlT]);
					lineLen = (GrphBase- CurYpos);
					if(lineLen>0 && (lineLen<=FFTHght)){
						tft.drawFastVLine(oldTuneBinRX, OldSpecVals[OldpxlT], lineLen, yellow);
					}
					/* Erase what remains of old tune marker */
					//lineLen = ((OldSpecVals[OldpxlT]-1)-GrphTop);
					lineLen = ((CurYpos-1)-GrphTop);
					if(lineLen>0 && (lineLen<=FFTHght)){
						tft.drawFastVLine(oldTuneBinRX, GrphTop,  lineLen, black);
					}
					OldSpecVals[cur_bin] = CurYpos;
					oldTuneBinRX = 0;//oldTuneBinRX = Xpxl;//
					TuneBinRX =0;
				}else if(NuTunFrq  && !RITMode && (cur_bin==TuneBinTX)){
					/*Insert/Draw Red Tune Freq Marker*/
					NuTunFrq = false;
					//UpdateRmt = true;
					int FFTHght = (GrphBase-GrphTop);
					int OldpxlT;
					/*1st,check & see if old RIT marker needs removing */
					if(oldTuneBinRX !=0){
						int OldpxlT = lastbin- oldTuneBinRX;
						lineLen = (GrphBase- OldSpecVals[OldpxlT]);//lastbin- Xpxl
						if(lineLen>0 && (lineLen<=FFTHght)) tft.drawFastVLine(oldTuneBinRX, OldSpecVals[OldpxlT], lineLen, yellow);
						/* Erase what remains of old tune marker */
						lineLen = ((OldSpecVals[OldpxlT]-1)-GrphTop);
						if(lineLen>0 && (lineLen<=FFTHght)){
							tft.drawFastVLine(oldTuneBinRX, GrphTop,  lineLen, black);
						}
						oldTuneBinRX = 0;
					}
					/*Now continue with updating TX (red) tuning marker */
					OldpxlT = lastbin- oldTuneBinTX;

					lineLen = (GrphBase- OldSpecVals[OldpxlT]);//lastbin- Xpxl
					if(lineLen>0 && (lineLen<=FFTHght)) tft.drawFastVLine(oldTuneBinTX, OldSpecVals[OldpxlT], lineLen, yellow);
					/* Erase what remains of old tune marker */
					lineLen = ((OldSpecVals[OldpxlT]-1)-GrphTop);
					if(lineLen>0 && (lineLen<=FFTHght)){
						tft.drawFastVLine(oldTuneBinTX, GrphTop,  lineLen, black);
					}
					/*Draw new Tune Freq Marker*/
					if(ShowTunePos(CwTunefreq, LastBinfreq)){
						tft.drawFastVLine(Xpxl, GrphTop, FFTHght, red);
					}
					oldTuneBinTX = Xpxl;
					//DrwFrqMrkrs(oldTuneBinTX);
					DrwMrkrs = true;
					//DrwFrqMrkrs(firstbin-1);//2023 changed to this to regenerate entire set of freg ticks

				}else if(NuTunFrq  && RITMode && (cur_bin==TuneBinRX)){
					/*Insert/Draw Tune Freq Marker*/
					NuTunFrq = false;
					//UpdateRmt = true;
					int FFTHght = (GrphBase-GrphTop);
					if(oldTuneBinRX !=0){
						int OldpxlT = lastbin- oldTuneBinRX;
						lineLen = (GrphBase- OldSpecVals[OldpxlT]);//lastbin- Xpxl
						if(lineLen>0 && (lineLen<=FFTHght)) tft.drawFastVLine(oldTuneBinRX, OldSpecVals[OldpxlT], lineLen, yellow);
						/* Erase what remains of old tune marker */
						lineLen = ((OldSpecVals[OldpxlT]-1)-GrphTop);
						if(lineLen>0 && (lineLen<=FFTHght)){
							tft.drawFastVLine(oldTuneBinRX, GrphTop,  lineLen, black);
						}
					}
					/*Draw new RX Freq Marker*/
					if(ShowTunePos(CwTunefreq, LastBinfreq)){
						tft.drawFastVLine(Xpxl, GrphTop, FFTHght, green);
					}
					oldTuneBinRX = Xpxl;
					/* Now check and see if there's space to show the TX tune Maker */
					if(oldTuneBinTX != oldTuneBinRX){
						tft.drawFastVLine((oldTuneBinTX), GrphTop, FFTHght, red);
					}
					//DrwFrqMrkrs(oldTuneBinRX);
					DrwMrkrs = true;
				}
			} /* End For loop - Display data bins on LCD */
			float curNoiseLvl = (binSum/BinLimit)-25;
			if ((curNoiseLvl< 135) || DrwMrkrs) DrwFrqMrkrs(oldTuneBinTX);// keep rebuilding freq markers during startup
			DrwMrkrs = false;
			NoiseFlr = int(((9*NoiseFlr)+curNoiseLvl)/10);
			float32_t DBm = -20 * __builtin_log10f(DemodGain/0.003);
			/*if needed update 'S' meter display value*/
			UpdtSmtrCntr++;
			if((DBm > OldDBmVal)|| (UpdtSmtrCntr > 20)){
				UpdtSmtrCntr = 0;// reset update counter
				OldDBmVal = DBm; // save this Dbm value
				/*convert DBm value to S meter value (based on -73DBm = S9) */
				int Smtr = 9;
				int SdbmREf = -73;
				while((SdbmREf-0.05)> DBm){
					SdbmREf -=6;
					Smtr--;
				}
				DBm = DBm-SdbmREf;
				if(DBm < 0.0) DBm = 0.0;
//				ShwSmtr(Smtr, DBm);
				sprintf( Title, "S%d %.1fdB", Smtr, DBm);
				tftmsgbx.SigSmtr(Title, TFT_GREEN);
				//Serial.println(DemodFreq);
			}
			FFTA.Count=0;
			mainlpCntr++;
		}//End if(FFTStp3)
		if(ShwLmts){
			ShwLmts = false;
			int plus = 0;
			if(!FFTWide){
				if(BandSetting[CurSelBnd].UpFFTflg) plus = 2;
				else plus = 1;
			}
			tftmsgbx.ShwSpctrmLmts(BandSetting[CurSelBnd].rxcenter, plus);
		}
		if(ShwVolLvl){
			ShwVolLvl = false;
			tftmsgbx.ShwVol(Volume);
		}
		if(1){//if(UpdateRmt){
			if(GetRmtCmd()){
				//UpdateRmt = false;
				//tftmsgbx.dispTitl(Cmd, TFT_CYAN);//for testing only
			}
		}

	}// end While loop
} // end main
///////////////////////////////////////////////////////////////
/*Step one, in the 2 step process to automatically tune to the incoming signal */
int AutoZero(float32_t *p_maxSig, int TuneBin){
	/*Auto Zero beat; look for the strongest signal +/-5bins of the user touch point*/
	int BestBin = TuneBin;
	for(int iBin= TuneBin-5; iBin <TuneBin+5; iBin++){
		if(FFTA.Output[iBin+FreqShft]> *p_maxSig){
			*p_maxSig = FFTA.Output[iBin+FreqShft];
			BestBin = iBin;
		}
	}
	return BestBin;
}
///////////////////////////////////////////////////////////////
void FFTSel(bool FFTup, bool FFTWide) {

	EraseOldMrkrs();
	/*recalculate fftswopt based off of last fftswopt & current LO Button press*/
	if (!FFTWide) {
		switch (fftswopt) {
		case 0: //last function, show lower side of FFT
			if (!FFTup)
				fftswopt = 3;
			else
				fftswopt = 1;
			break;
		case 1: //last function, show upper side of FFT
			if (!FFTup)
				fftswopt = 0;
			else
				fftswopt = 2;
			break;
		case 2: //last function, Shift LO up 40Khz & show low side of FFT
			if (FFTup)
				fftswopt = 1;
			else
				fftswopt = 3;
			break;
		case 3: //last function, Shift LO Down 40Khz & show upper side of FFT
			if (FFTup)
				fftswopt = 2;
			else
				fftswopt = 0;
			break;
		default:
			break;
		}
	}// end !FFTWide
	switch (fftswopt) {
	case 0: //lower side of FFT
		FreqShft = 0; //display FFT negative freqs
		if (!FFTWide)
			LastBinfreq = rxcenter; //comment out for Full screen FFT Spectrum
		else
			LastBinfreq = MaxFreq; //added for Full screen FFT Spectrum
		BandSetting[CurSelBnd].UpFFTflg = false;
		NuTunFrq = true;
		ShwSlctdFFTbtn(false);
		break;
	case 1: //upper side of FFT
		if (!FFTWide)
			FreqShft = FFT_SIZE / 2; //display FFT positive freqs//comment out for Full screen FFT Spectrum
		else
			FreqShft = 0; //added for Full screen FFT Spectrum
		LastBinfreq = MaxFreq;
		BandSetting[CurSelBnd].UpFFTflg = true;
		NuTunFrq = true;
		ShwSlctdFFTbtn(true);
		break;
	case 2: //Shift LO up 40Khz & show low side of FFT
		if (!FFTWide) rxcenter += 40000;
		else rxcenter += 25000;
		BandSetting[CurSelBnd].rxcenter = rxcenter;
		MinFreq = rxcenter - (samp_rate / 2);
		MaxFreq = rxcenter + (samp_rate / 2);
		UpDtLOfreq( rxcenter);
		DitherCnt = 0;//reset dither pointer
//		si5351.pll_reset(SI5351_PLLA); //*
//		SetRX = true;
//		SetTX = false;
//		sendFrequency(float(rxcenter));
		LO_Phase_Shift = ((rxcenter - (CwTunefreq)) / samp_rate) * TwoPi;
		/* begin touchscreen setup*/
//		tftmsgbx.LOFreq(rxcenter);
		FreqShft = 0; //display FFT negative freqs
		if (!FFTWide)
			LastBinfreq = rxcenter; //commented out for Full screen FFT Spectrum
		else
			LastBinfreq = MaxFreq; //added for Full screen FFT Spectrum
		BandSetting[CurSelBnd].UpFFTflg = false;
		NuTunFrq = true;
		ShwLmts = true;
//		if (!FFTWide) ShwSlctdFFTbtn(false);
//		else ShwSlctdFFTbtn(true);
		ShwSlctdFFTbtn(FFTWide);
		break;
	case 3: //Shift LO down 40Khz & show low side of FFT
		if (!FFTWide) rxcenter -= 40000;
				else rxcenter -= 25000;
		BandSetting[CurSelBnd].rxcenter = rxcenter;
		MinFreq = rxcenter - (samp_rate / 2);
		MaxFreq = rxcenter + (samp_rate / 2);
		UpDtLOfreq( rxcenter);
		DitherCnt = 0;//reset dither pointer
//		si5351.pll_reset(SI5351_PLLA); //*
//		SetRX = true;
//		SetTX = false;
//		sendFrequency(float(rxcenter));
		LO_Phase_Shift = ((rxcenter - (CwTunefreq)) / samp_rate) * TwoPi;
		/* begin touchscreen setup*/
//		tftmsgbx.LOFreq(rxcenter);
		FreqShft = FFT_SIZE / 2; //display FFT positive freqs
		LastBinfreq = MaxFreq;
		BandSetting[CurSelBnd].UpFFTflg = true;
		NuTunFrq = true;
		ShwLmts = true;
//		if (!FFTWide) ShwSlctdFFTbtn(true);
//		else ShwSlctdFFTbtn(false);
		ShwSlctdFFTbtn(!FFTWide);
		break;
	default:
		break;
	}
	//check if tune indicator is visible, & if yes, recalculate its X position (i.e., TuneBinTX)
	if ((txfreq >= MinFreq) && (txfreq <= MaxFreq)) {
		if (!FFTWide) {
			float FirstBinfreq = LastBinfreq -((MaxFreq-MinFreq)/2);
			if((txfreq >= FirstBinfreq) && (txfreq <= LastBinfreq)){
				TuneBinTX = int((LastBinfreq - (txfreq)) / binfrqWdth);
			} else TuneBinTX = 0;
		}else{
			TuneBinTX = int((LastBinfreq - (txfreq)) / (2 * binfrqWdth));
		}
	}
}
///////////////////////////////////////////////////////////////
float hamming(float x) //hamming window function used for FIR filter design
{
	return (0.54-0.46*(TwoPi*(0.5+(x/2))));
}

//////////////////////////////////////////////////////////////
void SDRModule(void){
	StrtLP = GetTimr5Cnt();//__HAL_TIM_GET_COUNTER(&htim5);
	busy = true;
	//DemodGain= DemodGain/2;
	float32_t MixData[decimate_factor*2];
	/*Build LO mixer array for the current dataset [8 samples collected @ 48.84 khz] */
	for(int i = 0; i<decimate_factor; i++){
		int two_i = i*2;
		int two_iPlus = two_i + 1;
		LO_Phase += LO_Phase_Shift;

		/* bring the current LO phase back into the range (0, 2*pi]*/
		if(LO_Phase<0) LO_Phase += TwoPi;
		if(LO_Phase>TwoPi) LO_Phase -= TwoPi;
		MixData[two_i] = arm_sin_f32(LO_Phase);
		MixData[two_iPlus] = arm_cos_f32(LO_Phase);

		/* correct amplitude/phasing error */
		NewiqData[two_iPlus] = AmpFactor*NewiqData[two_iPlus];//gain imbalance
		NewiqData[two_i] = NewiqData[two_i] + (ICFactr*NewiqData[two_iPlus]);//phase imbalance

		/* Fill FFT buffer until function returns 1 = Buffer full and samples ready to be calculated */
		if (FFTA.Count < FFTA.FFT_Size) {

			int pos = int(2 * FFTA.Count);
			/* Add to buffer, real part */
			FFTA.Input[pos] = NewiqData[two_i];//I value
			/* Imaginary part set to 0 */
			FFTA.Input[pos + 1] = NewiqData[two_iPlus];;//Q value

			/* Increase count */
			FFTA.Count++;
		}
	}
	/*multiply the input iq sample set by the synthesized LO (thus this is a mixer):*/
	arm_cmplx_mult_cmplx_f32( NewiqData, MixData, MixData, decimate_factor);
	/* Add new IQ data now mixed with LO (rx freq) data to the end of the decimate_buffer */
	memcpy(&ARMdecimate_buffer[StrtNuNdx], &MixData[0], (NuDataByteCnt));

	//we apply the decimating FIR filter, the result of which is <decimated>:
	arm_cmplx_mult_cmplx_f32( ARMdecimate_buffer, ARMdecimate_taps, pDst, stop);
	//we shift the items in the buffer back <decimate_taps_length> samples:
	float32_t *BuPtr0 = ARMdecimate_buffer;
	float32_t *BuPtr16 = ARMdecimate_buffer+16;

	/*DMA_SetConfig(DMA_HandleTypeDef *hdma, uint32_t SrcAddress, uint32_t DstAddress, uint32_t DataLength);*/
	HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream0, (uint32_t)BuPtr16, (uint32_t)BuPtr0, (uint32_t)((TapCntx2)-16));
	hdma_memtomem_dma2_stream0.Instance->CR |=  DMA_SxCR_EN; //enable DMA
	/*  Use this for normal SSB demod recovery */

	//arm_cmplx_mag_f32(pDst, Mag, stop);//Trying to go this route with a 97 tap filter takes too long
	/* Alternate method of using 'for loop',
	 * & looking at just the real component,
	 * of the complex array, proved to be faster
	 */
	decimated = 0;
	for(int i=0; i< decimate_taps_length; i++){
		decimated += pDst[(int(2)*i)];
	}
	/* look at raw mixer output, before its applied to anti-alias LP FIR filter */
	//		for(int i=0; i<= decimate_factor; i++){
	//			decimated += MixData[2*i];
	//		}
	/*apply 750Hz IIR BP Filter */
	/*
	 * float outSampleF =
			a0 * inSampleF
			+ a1 * rin_z1
			+ a2 * rin_z2
			- b1 * rout_z1
			- b2 * rout_z2;
	 */

	if(IIRflg){ /*Begin/Apply IIR BP Filter (SDR Narrow Filter ["fN"] Button) */
		/*IIR using CMSIS-DSP function calls*/
		Src[0]= 2*decimated; //load input for stage 1
		Src[1] = Dst[0]; // load input for stage 2, from stage 1 output
		arm_biquad_cascade_df2T_f32(&S1, Src, Dst, 2);
		decimated = Dst[1]; // get stage 2 result/output
		/*IIR manual method */
//		float IIRBPOut =
//			a0 * decimated
//			+ a1 * in_z1
//			+ a2 * in_z2
//			- b1 * out_z1
//			- b2 * out_z2;
//		in_z2 = in_z1;
//		in_z1 = decimated;
//		out_z2 = out_z1;
//		out_z1 = IIRBPOut;
//		decimated = IIRBPOut;
//		/*2nd stage */
//		IIRBPOut =
//			a0 * decimated
//			+ a1 * in_z3
//			+ a2 * in_z4
//			- b1 * out_z3
//			- b2 * out_z4;
//		in_z4 = in_z3;
//		in_z3 = decimated;
//		out_z4 = out_z3;
//		out_z3 = IIRBPOut;
//		decimated = IIRBPOut;
		/*end IIR manual method */
	}  /*end 750Hz IIR BP Filter */

	decimated = DemodGain*decimated;
	float NuGain = 0.0;
	if(decimated > Maxvol){
		decimated = decimated/DemodGain;
		NuGain = Maxvol/decimated;
		decimated = +Maxvol;
	}
	if(decimated < -Maxvol){
		decimated = decimated/DemodGain;
		NuGain = -Maxvol/decimated;
		decimated = -Maxvol;
	}
	if(NuGain>0.0){
		if(FinTune) DemodGain = ((float(49)*DemodGain)+NuGain)/float(50);
		else DemodGain = NuGain;//
	}
	demodulator_output = int(Volume*decimated);
	/*the following is part of the auto tune process */
	const int ToneThrsHld = (335544288 - 134217712);//minimum usable peak tone value; Anything less is noise
	if(FinTune){// true = 2nd part of auto-tune is active
		/*if we have a usable signal; capture the time it starts
		 * and count off the next continuous 50 cycles*/
		int RawAudio = int(decimated);
		if((TnPrdStrt == 0) && RawAudio > ToneThrsHld){
			TnPrdStrt = GetTimr5Cnt();
			TstNegFlg = true;
			NoTnCntr = 0;  //set "No Tone Counter" to zero
			perioRefCnt = 50;
		}else if((TnPrdStrt != 0) && (RawAudio < -ToneThrsHld) && TstNegFlg ){
			NoTnCntr = 0;  //set "No Tone Counter" to zero
			TstNegFlg = false;
		}else if((TnPrdStrt != 0) && (RawAudio > ToneThrsHld) && !TstNegFlg ){
			PeriodCntr++;
			NoTnCntr = 0;  //set "No Tone Counter" to zero
			TstNegFlg = true;
		}else NoTnCntr++;// increment "No Tone Counter"
		if(NoTnCntr==8){//NoTnCntr==6
			DemodFreq = 0;
			TnPrdStrt = 0;
			TstNegFlg = false;
			if(PeriodCntr>20) perioRefCnt = PeriodCntr;
			else PeriodCntr = 0;
		}
		if(PeriodCntr == perioRefCnt){
			/* we had a continuous tone that persisted for 30 or more periods
			 * so calculate its frequency; we will use the result elsewhere to
			 * refine the "tuned to" frequency */
			unsigned long TenPeriods = GetTimr5Cnt()-TnPrdStrt;
			DemodFreq = (perioRefCnt*1000000)/TenPeriods;
			if(Abs(DemodFreq-SideTonefreq)>600){
				DemodFreq = 0; //ignore; invalid result
			}
			TnPrdStrt = 0;
			TstNegFlg = false;
			PeriodCntr = 0;
		}
	}

	demodulator_outputA = int(demodulator_outputB+((demodulator_output-demodulator_outputB)/float(2)));//demodulator_output;//
	demodulator_outputB = demodulator_output;

	/*Now for WWV zero-beat SI5351 Freq Calibration, inject 750Hz audio reference tone*/
	if(FreqCalMode){
		ST_Phase += SideToneAngle;
		//we bring the current LO phase back into the range (0, 2*pi]:
		if(ST_Phase>TwoPi) ST_Phase -= TwoPi;
		demodulator_outputA += int(Volume*SideToneGain*arm_sin_f32(ST_Phase));
		ST_Phase += SideToneAngle;
		//we bring the current LO phase back into the range (0, 2*pi]:
		if(ST_Phase>TwoPi) ST_Phase -= TwoPi;
		demodulator_outputB += int(Volume*SideToneGain*arm_sin_f32(ST_Phase));
		/*End Reference tone injection steps */
	}
	/* pack the integer demod values into two 16 bit words
	 * which will be passed back to sound card audio output */
	Dmod[0] = (demodulator_outputA)>>16 & 0xFFFF;
	Dmod[1] = (demodulator_outputA) & 0xFFFF;
	Dmod[2] = (demodulator_outputB)>>16 & 0xFFFF;
	Dmod[3] = (demodulator_outputB) & 0xFFFF;
	//LPIntrvl =__HAL_TIM_GET_COUNTER(&htim5)-StrtLP;
	LPIntrvl = GetTimr5Cnt() - StrtLP;
	//mainlpCntr +=1;
	if(AGCflg) DemodGain  += 0.05;// 0.005;//AGC mode
	else DemodGain  =160.0;  //fixed gain mode
	busy = false;
	return;
}
void EvalDMAtime(void){
	//return;
	if((fullCntr + halfCntr)> IntrpAsec){ //165000
		unsigned long Now = GetTimr5Cnt();//__HAL_TIM_GET_COUNTER(&htim5);
//		int d_t_l = (int)decimate_taps_length;
		float Intrvl =  ((float)(Now - StrtTime))/float(1000000.0);
//		for(int i = 0; i<8192; i++){
//			Serial.println(Audio[i]);
//		}
		fullCntr=0;
		halfCntr = 0;
		mainlpCntr = 0;
//		FullIntrv = true;
//		printflg = true;
		HAL_GPIO_TogglePin(LED_GPIO_Port, LED_Pin);
		StrtTime = GetTimr5Cnt();//__HAL_TIM_GET_COUNTER(&htim5);
	}
}
/////////////////////////////////////////////////////////////////////////////////////
/* This routine is the "launch point" for the SDR configuration screens.
 * More importantly, on return from these screens/processes, it restores the old
 * xvcr settings, so that the radio will be returned to the configuration
 * that was in place before the respective process was started.
 */
void Jump2XtalCal(int ButNo){
	/* before jumping over to "options", set filter to medium width*/
	SetUPFIR(filter_tapsM, FILTER_TAP_NUMM);
	/* capture/"lock in" the current CWTune frequency */
	BandSetting[CurSelBnd].CwTunefreq = CwTunefreq;
	ShwDModbtn(0); //force back into CW mode
	//txfreq = CwTunefreq + DFault.SideTonefreq;
	txfreq = CwTunefreq + BandSetting[CurSelBnd].SideTonefreq;//20231024 changed to follow CiV i.e. FLRIG
	//Menu_MainLoop(BandSetting[CurSelBnd].rxcenter, txfreq, int(samp_rate), DFault.SideTonefreq); //Jump to "Option/setup" Screen
	Menu_MainLoop(BandSetting[CurSelBnd].rxcenter, txfreq, int(samp_rate),BandSetting[CurSelBnd].SideTonefreq);//20231024 changed to follow CiV i.e. FLRIG
	/*Ok now back from the Options area; Need to restore Xcvr to where it was when we left*/
	SetUPFIR(filter_tapsW, FILTER_TAP_NUMW);//for fastest recovery, install wideband filter
	BandSetting[CurSelBnd].PhasCorect = PhasCorect;
	BandSetting[CurSelBnd].AmpFactor = AmpFactor;
	CwTunefreq = BandSetting[CurSelBnd].CwTunefreq;
	rxcenter = BandSetting[CurSelBnd].rxcenter;
	SideTonefreq = BandSetting[CurSelBnd].SideTonefreq;
	FFTWide = BandSetting[CurSelBnd].FFTWide;

	MinFreq = rxcenter-(samp_rate/2);
	MaxFreq = rxcenter+(samp_rate/2);
	if(BandSetting[CurSelBnd].DmodMode == 0){
		txfreq = CwTunefreq + SideTonefreq;
	}else{
		txfreq = CwTunefreq;
	}
	TXrdy = ValidTX(txfreq);//validate that this is a ham legal frequency

	  // Need to reset the PLL before Clocks will be in phase alignment
    si5351.pll_reset(SI5351_PLLA);//*
	SetRX = true;
	SetTX = false;
	sendFrequency(float(rxcenter));
	LO_Phase_Shift = ((rxcenter-(CwTunefreq))/samp_rate)*TwoPi;
	BldMainScrn();
//	/* begin touchscreen setup*/
//	tftmsgbx.InitDsplay();
//	sprintf( Title, "STM32F411 SDR/FFT(%s)\n", RevDate );
//	tftmsgbx.dispTitl(Title, TFT_CYAN);
//	tftmsgbx.LOFreq(rxcenter);
//	tftmsgbx.TuneFreq(int(99999999), 0);//reset tune display to force a "complete" update
////	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
//	/*Do the following to force the "S" reading to update all characters
//	 * when it resumes normal SDR Xcvr loop*/
//	sprintf( Title, "        " );
//	tftmsgbx.SigSmtr(Title, TFT_GREEN);
//	BldButtons();
//	if (FFTWide) {
//		SetUpBtns[16].Captn = " WID";
//		LastBinfreq = MaxFreq;
//	} else {
//		SetUpBtns[16].Captn = " NAR";
//	}
//	BldBtn(16, SetUpBtns);
//	ShwSlctdFltrBtn(FltrBtn);
//	ShwSlctdBndBtn(CurSelBnd+6);
//	//ShwDModbtn(BandSetting[CurSelBnd].DmodMode);//"BldButtons" covers this
//	NoiseFlr = 145;
//	NuTunFrq = true;
//	UpdateRmt = true;
//	ShwLmts = true;
//	ShwVolLvl = true;
//	for(int i =0; i<FFT_SIZE ; i++){
//		OldSpecVals[i] =scrnHeight-17;
//	}
//	if(!FFTWide){
//		if(BandSetting[CurSelBnd].UpFFTflg){
//			if(!FFTWide) FreqShft = FFT_SIZE/2;//display FFT positive freqs
//			else FreqShft = 0;//added for full FFT Spectrum
//			LastBinfreq = MaxFreq;
//			ShwSlctdFFTbtn(true);
//			fftswopt =1;
//		}
//		else{
//			FreqShft = 0;//display FFT negative freqs
//			if(!FFTWide) LastBinfreq = rxcenter;
//			else LastBinfreq = MaxFreq;//added for full FFT Spectrum
//			ShwSlctdFFTbtn(false);
//			fftswopt =0;
//		}
//	}else{
//
//	}
//	/*last thing (because Narrow filter might have been in use),
//	 * restore the filter setting
//	 */
//	FltrBtn = BandSetting[CurSelBnd].FltrOpt+11;
//	ShwSlctdFltrBtn(FltrBtn);
//	/* Restore audio filter */
//	InstalFltr();
//	/*now post/show the tune frequency*/
//	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
}
//////////////////////////////////////////////////////////////////////////////////////
void BldMainScrn(void){

	/* begin touchscreen setup*/
	tftmsgbx.setTxtSize(2);
	tftmsgbx.setFont(12, 16);
	tftmsgbx.InitDsplay();
	sprintf( Title, "STM32F411 SDR/FFT(%s)\n", RevDate );
	tftmsgbx.dispTitl(Title, TFT_CYAN);
	tftmsgbx.LOFreq(rxcenter);
	tftmsgbx.TuneFreq(int(99999999), 0);//reset tune display to force a "complete" update
//	tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
	/*Do the following to force the "S" reading to update all characters
	 * when it resumes normal SDR Xcvr loop*/
	sprintf( Title, "        " );
	tftmsgbx.SigSmtr(Title, TFT_GREEN);
	BldButtons();
	if (FFTWide) {
		SetUpBtns[16].Captn = " WID";
		LastBinfreq = MaxFreq;
	} else {
		SetUpBtns[16].Captn = " NAR";
	}
	BldBtn(16, SetUpBtns);
	ShwSlctdFltrBtn(FltrBtn);
	ShwSlctdBndBtn(CurSelBnd+6);
	//ShwDModbtn(BandSetting[CurSelBnd].DmodMode);//"BldButtons" covers this
	NoiseFlr = 145;
	NuTunFrq = true;
	//UpdateRmt = true;
	ShwLmts = true;
	ShwVolLvl = true;
	for(int i =0; i<FFT_SIZE ; i++){
		OldSpecVals[i] =scrnHeight-17;
	}
	if(!FFTWide){
		if(BandSetting[CurSelBnd].UpFFTflg){
			if(!FFTWide) FreqShft = FFT_SIZE/2;//display FFT positive freqs
			else FreqShft = 0;//added for full FFT Spectrum
			LastBinfreq = MaxFreq;
			ShwSlctdFFTbtn(true);
			fftswopt =1;
		}
		else{
			FreqShft = 0;//display FFT negative freqs
			if(!FFTWide) LastBinfreq = rxcenter;
			else LastBinfreq = MaxFreq;//added for full FFT Spectrum
			ShwSlctdFFTbtn(false);
			fftswopt =0;
		}
	}else{

	}
	/*last thing (because Narrow filter might have been in use),
	 * restore the filter setting
	 */
	FltrBtn = BandSetting[CurSelBnd].FltrOpt+11;
	ShwSlctdFltrBtn(FltrBtn);
	/* Restore audio filter */
	InstalFltr();
	/*now post/show the tune frequency*/
	if(BandSetting[CurSelBnd].DmodMode == 0){
		tftmsgbx.TuneFreq(CwTunefreq, int(SideTonefreq));
	}else{
		tftmsgbx.TuneFreq(CwTunefreq, 0);
	}

}

/////////////////////////////////////////////////////////////////////////////////////
/*
   Setting the phase of a clock requires that you manually set the PLL and
   take the PLL frequency into account when calculation the value to place
   in the phase register. As shown on page 10 of Silicon Labs Application
   Note 619 (AN619), the phase register is a 7-bit register, where a bit
   represents a phase difference of 1/4 the PLL period. Therefore, the best
   way to get an accurate phase setting is to make the PLL an even multiple
   of the clock frequency, depending on what phase you need.

   If you need a 90 degree phase shift (as in many RF applications), then
   it is quite easy to determine your parameters. Pick a PLL frequency that
   is an even multiple of your clock frequency (remember that the PLL needs
   to be in the range of 600 to 900 MHz). Then to set a 90 degree phase shift,
   you simply enter that multiple into the phase register. Remember when
   setting multiple outputs to be phase-related to each other, they each need
   to be referenced to the same PLL.
*/

/////////////////////////////////////////////////////////////////////////////
void sendFrequency(float HzFreq) {
  unsigned long HiVal;
  unsigned long LoVal;
  char buf[25];
  float KhzFreq = (HzFreq) / 1000;
  int FreqMult = 0;
  int PllFrq = 0; // in Mhz
  int ClkMult = 0;
  int PllLoLim = 400;
  if ( KhzFreq > 4800) PllLoLim = 600;
  if (SetRX) {
//    Serial.print("Clock Freq: ");
//    Serial.print( KhzFreq);
//    Serial.println("Khz");
    //Set appropriate TX low pass filter via 2 bit input to 74145 BCD to Decimal converter
    //Band0
    if (KhzFreq < 6000) { //80 meters; lowest freg low pass filter
    	HAL_GPIO_WritePin(BndD0_GPIO_Port, BndD0_Pin, GPIO_PIN_RESET);
    	HAL_GPIO_WritePin(BndD1_GPIO_Port, BndD1_Pin, GPIO_PIN_RESET);

    }
    //Band1
    if (KhzFreq < 8000 && KhzFreq >= 6000) { //40 meters
    	HAL_GPIO_WritePin(BndD0_GPIO_Port, BndD0_Pin, GPIO_PIN_RESET);
    	HAL_GPIO_WritePin(BndD1_GPIO_Port, BndD1_Pin, GPIO_PIN_SET);
    }
    //Band3
    if (KhzFreq < 12000 && KhzFreq >= 8000) { //30 meters
    	HAL_GPIO_WritePin(BndD0_GPIO_Port, BndD0_Pin, GPIO_PIN_SET);
    	HAL_GPIO_WritePin(BndD1_GPIO_Port, BndD1_Pin, GPIO_PIN_SET);
    }
    //Band2
    if (KhzFreq >= 12000 && KhzFreq < 16000) { //20 meters
    	HAL_GPIO_WritePin(BndD0_GPIO_Port, BndD0_Pin, GPIO_PIN_SET);
    	HAL_GPIO_WritePin(BndD1_GPIO_Port, BndD1_Pin, GPIO_PIN_RESET);
    }
    /* At present only 2 wire band control has been implemented; So forget band setting >= 4 */
    //Band4
    if (KhzFreq >= 16000 && KhzFreq < 19500) { //17 meters
//      digitalWrite(A0, LOW);
//      digitalWrite(A1, LOW);
//      digitalWrite(A2, HIGH);
    }
    //Band5
    if (KhzFreq >= 19500 && KhzFreq < 22500) { //15 meters
//      digitalWrite(A0, HIGH);
//      digitalWrite(A1, LOW);
//      digitalWrite(A2, HIGH);
    }
    //Band6
    if (KhzFreq >= 22500 && KhzFreq < 26000) { //12 meters
//      digitalWrite(A0, LOW);
//      digitalWrite(A1, HIGH);
//      digitalWrite(A2, HIGH);
    }
    //Band7
    if (KhzFreq >= 26000) { //10 meters; highest freg low pass filter
//      digitalWrite(A0, HIGH);
//      digitalWrite(A1, HIGH);
//      digitalWrite(A2, HIGH);
    }
  }
  while ((PllFrq < 900) && (PllFrq < PllLoLim || FreqMult & 1 == 1 || ClkMult & 1 == 1) ) {
    FreqMult++;
    PllFrq = FreqMult * (KhzFreq / 1000);
    ClkMult = PllFrq / 25;
  }


  unsigned long long freq_2Decml = (KhzFreq * 100000)   ; //1410000000ULL;
  unsigned long long pll_freq = freq_2Decml * FreqMult; //70500000000ULL;
  if (SetRX) {
//    Serial.print("FreqMult: ");
//    Serial.print( FreqMult);
//    Serial.print(";  PllFrq: ");
//    Serial.print( PllFrq);
//    Serial.print("Mhz; ");
//    Serial.print(";  Pll_Frq: ");
  }
  HiVal = (unsigned long)(pll_freq / 1000000);
  LoVal = (unsigned long)(pll_freq - (HiVal * 1000000));
  if (pll_freq > 0xFFFFFFFFLL) sprintf(buf, "%ld %06ld" ,  (unsigned long)HiVal, (unsigned long)LoVal );
  else sprintf(buf, "%ld", (unsigned long)pll_freq);
  if (SetRX) {
//    Serial.print( buf);
//    Serial.print("Hz; ");
//    Serial.print( FreqMult);
//    Serial.print(";  ClkMult: ");
//    Serial.print( ClkMult);
//    Serial.println("");

    // Set CLK0 and CLK1 to use PLLA as the MS source.
    // This is not explicitly necessary in v2 of this library,
    // as these are already the default assignments.
    // si5351.set_ms_source(SI5351_CLK0, SI5351_PLLA);
    // si5351.set_ms_source(SI5351_CLK1, SI5351_PLLA);
    si5351.set_pll(pll_freq , SI5351_PLLA);
    // Set CLK0 and CLK1 to output 14.1 MHz with a fixed PLL frequency
    si5351.set_freq_manual(freq_2Decml, pll_freq, SI5351_CLK0);
    si5351.set_freq_manual(freq_2Decml, pll_freq, SI5351_CLK1);
    if (FreqMult > 126) FreqMult = 126;
    si5351.set_phase(SI5351_CLK0, FreqMult);//si5351.set_phase(SI5351_CLK1, 0);
    // We need to reset the PLL before they will be in phase alignment
    si5351.pll_reset(SI5351_PLLA);
  }

  if (SetTX) {
    si5351.set_pll(pll_freq , SI5351_PLLB);
    si5351.set_freq_manual(freq_2Decml, pll_freq, SI5351_CLK2);
  }
}// end sendFrequency() Function
//////////////////////////////////////////////////////////


void HAL_I2SEx_TxRxHalfCpltCallback(I2S_HandleTypeDef *hi2s){
	//if(!HalfCpltFlg) return;
	//HalfCpltFlg = false;
	/* Test/check interrupt interval timing */
	HStrtTime =GetTimr5Cnt();//__HAL_TIM_GET_COUNTER(&htim5);
	H2FIntrvl = HStrtTime - FStrtTime;
	/* Translate the signed 24 bit I/Q data (spread across two 16bit elements)
	 * from 1st half of the dma ringbuffer
	 * into the "newdata" floating pt, 8x2, complex array
	 */
	int offset = 4*decimate_factor;//2nd half of ringbuffer
	UnPakRxBuf(0);//0
	halfCntr++;
	if(!KeyActive) SDRModule();
	EvalDMAtime();
	/*Load Left & Right channels into 1st half of the DMA Tx Buffer
	 * from SDRModule decimated demodulated DSP routine
	 */
	LdTXBuffer(0);//0
	//FullCpltFlg = true;
//	DWT->CTRL |= ITM_TCR_ITMENA_Msk;
//	__enable_irq();
}

void HAL_I2SEx_TxRxCpltCallback(I2S_HandleTypeDef *hi2s){
	//if(!FullCpltFlg) return;
	//FullCpltFlg = false;
	/* Test/check interrupt interval timing */
	FStrtTime =GetTimr5Cnt();//__HAL_TIM_GET_COUNTER(&htim5);
	F2HIntrvl = FStrtTime - HStrtTime;
	/* Translate the signed 24 bit I/Q data (spread across two 16bit elements)
	 * from 2nd half of the dma ringbuffer
	 * into the "newdata" floating pt, 8x2, complex array */
	int offset = 4*decimate_factor;//2nd half of ringbuffer
	UnPakRxBuf(offset);//offset
	fullCntr++;
	// Manipulate Digital Stream
	if(!KeyActive) SDRModule();
	EvalDMAtime();
	/*Load Left & Right channels into 2nd half of the DMA Tx Buffer
	 * from SDRModule decimated demodulated DSP routine
	 */
	LdTXBuffer(offset);//offset
	//HalfCpltFlg = true;
//	DWT->CTRL |= ITM_TCR_ITMENA_Msk;
//	__enable_irq();
}
//////////////////////////////////////////////////////////////////////////////////////////////
void LdTXBuffer(int offset){// offset will be '0' or '32'
	if(KeyActive) GenSideTone();

	for(int i = 0; i < decimate_factor; i++){
		int txIndx = i*4+offset;
		if(i<Halfdecimate_factor){
			txBuf[txIndx+ 0] = Dmod[0]; //sound card out left channel MSB; 1st upconverted value
			txBuf[txIndx+ 1] = Dmod[1]; //sound card out left channel LSB; 1st upconverted value

		}else{
			txBuf[txIndx+ 0] = Dmod[2];  //sound card out left channel; 2nd upconverted value
			txBuf[txIndx+ 1] = Dmod[3];   //sound card out left channel; 2nd upconverted value
		}
		txBuf[txIndx+ 2] = txBuf[txIndx+ 0];// repeat for right channel
		txBuf[txIndx+ 3] = txBuf[txIndx+ 1];// repeat for right channel
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////
void UnPakRxBuf(int offset){// offset will be '0' or '32'
	/* convert 24 bit sound board stream to 32 bit floating point */
//	bool gud2Go = false;
//	while(!gud2Go){
	for(int i =0; i<decimate_factor; i++){//8 = decimate_factor
		int rxIndx = (i*4) + offset;
		int AdbIndx = i*2;
		/* 'I' data */
		NewiqData[AdbIndx] = (float32_t)(int)(rxBuf[rxIndx]<<16 | rxBuf[rxIndx+1]);
		/* 'Q' data */
		NewiqData[AdbIndx+1] = (float32_t)(int)(rxBuf[rxIndx+2]<<16 | rxBuf[rxIndx+3]);
	}
//	gud2Go = true;
//	for(int i =0; i<decimate_factor; i++){//8 = decimate_factor
//			int rxIndx = (i*4) + offset;
//			int AdbIndx = i*2;
//			/* 'I' data */
//			if(NewiqData[AdbIndx] != (float32_t)(int)(rxBuf[rxIndx]<<16 | rxBuf[rxIndx+1])){
//				gud2Go = false;
//			}
//			/* 'Q' data */
//			if(NewiqData[AdbIndx+1] != (float32_t)(int)(rxBuf[rxIndx+2]<<16 | rxBuf[rxIndx+3])){
//				gud2Go = false;;
//			}
//		}
//	}
}
///////////////////////////////////////////////////////////////////////////////////////////////
void GenSideTone(void){
	float STA = SideToneAngle;
	//	if(KeyClosed){
	for(int i=0; i<2; i++){
		if(KeyClosed || Abs(ST_Phase)>STA){//even if key is "open" continue to generate "tone" until its output is close to zero
			ST_Phase += STA;
			//we bring the current LO phase back into the range (0, 2*pi]:
			if(ST_Phase>TwoPi) ST_Phase -= TwoPi;
		}else ST_Phase = 0;
		demodulator_output = int(Volume*SideToneGain*arm_sin_f32(ST_Phase));
		if(i==0){
			Dmod[0] = (demodulator_output)>>16 & 0xFFFF;
			Dmod[1] = (demodulator_output) & 0xFFFF;
		}else{
			Dmod[2] = (demodulator_output)>>16 & 0xFFFF;
			Dmod[3] = (demodulator_output) & 0xFFFF;
		}
	}
	return;
	//	}
	Dmod[2] = Dmod[0];// =0;
	Dmod[3] = Dmod[1];// =0;
}
///////////////////////////////////////////////////////////////////////////////////////////////
/* Draw FFT Frequency Markers */
void DrwFrqMrkrs(int TunePos)
{
	const uint16_t red = SetRGB(255,0,0);
	const uint16_t green = SetRGB(0,255,0);
	const uint16_t yellow = SetRGB(255,255,0);
	const uint16_t blue = SetRGB(0,0,255);
	static float strtfrq =0.0;
	tft.drawFastHLine(firstbin, GrphBase,  lastbin-firstbin, blue);
	strtfrq = MinFreq;
	/* commented out for full FFT spectrum */
	if(!FFTWide){
		if(BandSetting[CurSelBnd].UpFFTflg){
			strtfrq = rxcenter;
		}
	}
	strtfrqErase = strtfrq;
	float tic1K = (float)(int(strtfrq/1000)+1)*1000;
	float tic10K = (float)(int(strtfrq/10000)+1)*10000;
	float tic5K = tic10K - 5000;
	int ticHgt =0;
	float tstfrq;
	int step;
	if(!FFTWide) step = (binfrqWdth);
	else step = (2*binfrqWdth);
	stepErase = step;
	for (int i=0; i<(lastbin-firstbin); i++){
		tstfrq = (i*step)+strtfrq;
		int Xpos = i+firstbin;
		if(tstfrq >= tic10K){
			tic5K = tic10K + 5000.0;
			tic1K = tic10K + 1000.0;
			tic10K += 10000.0;
			ticHgt = 16;
		}else if(tstfrq >= tic5K){
			tic1K = tic5K + 1000.0;
			tic5K += 5000.0;
			ticHgt = 8;
		}else if(tstfrq >=tic1K){
			tic1K +=1000.0;// bump the 1Khz check point out another 1000hz
			ticHgt = 4;
		}
		if((ticHgt >0) && (TunePos != Xpos)){
			tft.drawFastVLine(Xpos, GrphBase-ticHgt,  ticHgt, blue);
			ticHgt =0;// reset ticHgt
		}
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////
/* Erase Old Freq Tick Markers */
void EraseOldMrkrs()
{
//	const uint16_t red = SetRGB(255,0,0);
	const uint16_t yellow = SetRGB(255,255,0);

	float tic1K = (float)(int(strtfrqErase/1000)+1)*1000;
	float tic10K = (float)(int(strtfrqErase/10000)+1)*10000;
	float tic5K = tic10K - 5000;
	for (int i=0; i<(lastbin-firstbin); i++){
		float tstfrq = (i*stepErase)+strtfrqErase;
		int ticHgt =0;
		int Xpos = i+firstbin;
		if(tstfrq >= tic10K){
			tic10K += 10000.0;
			if(tstfrq >= tic5K) tic5K += 5000.0;
			if(tstfrq >= tic1K) tic1K +=1000.0;// do the 'if' just in case a match is found on i = 0
			ticHgt = 16;
		}else if(tstfrq >= tic5K){
			tic5K += 5000.0;
			if(tstfrq >= tic1K) tic1K +=1000.0;// do the 'if' just in case a match is found on i = 0
			ticHgt = 8;
		}else if(tstfrq >= tic1K){
			tic1K +=1000.0;
			ticHgt = 4;
		}
		if((ticHgt >0)){ // && (TunePos != Xpos)
			if(Xpos > firstbin) tft.drawFastVLine(Xpos-1, GrphBase-ticHgt,  ticHgt, yellow);
			tft.drawFastVLine(Xpos, GrphBase-ticHgt,  ticHgt, yellow);
			if(Xpos < lastbin) tft.drawFastVLine(Xpos+1, GrphBase-ticHgt,  ticHgt, yellow);
		}
	}
}
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
uint16_t SetRGB(byte r, byte g, byte b)
{ return ((r&0xF8) << 8) | ((g&0xFC) << 3) | (b>>3);
}

///////////////////////////////////////////////////////////////////////////////////////////////
void readResistiveTouch(void)
{
	tp = ts.getPoint();
	HAL_ADC_Stop(&hadc1);
	pinMode(YP, OUTPUT);      //restore shared pins
	pinMode(XM, OUTPUT);
	digitalWrite(YP, HIGH);  //because TFT control pins
	digitalWrite(XM, HIGH);

}
///////////////////////////////////////////////////////////////////////////////////////////////
int GetTouchPts(int &px, int &py){
	readResistiveTouch();
	if (tp.z > 200 ) { //150// 400if (tp.z > MINPRESSURE && tp.z < MAXPRESSURE) { //
		//use the following for Screen orientation set to 1 (LANDSCAPE)
		int LpCntr =0;
		int mAXCntr =0;
		py = map(tp.y, TS_TOP, TS_BOT, 0, scrnHeight);
		px = map(tp.x, TS_LEFT, TS_RT, 0, scrnWidth);
		while(LpCntr<4 && mAXCntr < 50){
			readResistiveTouch();
			if (tp.z > 200 ){
				LpCntr++;
				py += map(tp.y, TS_TOP, TS_BOT, 0, scrnHeight);
				px += map(tp.x, TS_LEFT, TS_RT, 0, scrnWidth);
			}
			mAXCntr++;
		}
		px = px / 5;
		py = py / 5;
		/* original code */
		/* Un-comment diagnostic test/verification of screen touch coordinates */
//		sprintf( Title, "px: %d", px);
//		Serial.println(Title);//ShwData(5, 30, Title);
//		sprintf( Title, "py: %d", py);
//		Serial.println(Title);//ShwData(5, 55, Title);
		if(LpCntr== 4) return tp.z;
		return 0;
	}else{
	 return 0;
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////
int ReadBtns(void) {
	int py;
	int px;
	if (FFTA.Count == FFTA.FFT_Size)
		return 0;		//skip if spectrum view needs updating
	if (GetTouchPts(px, py) > 150) {
		if ((px < lastbin) && (py < 220) && !SpecMode){
			/* we had been in the set freq by number mode;
			 * but user is now doing something different,
			 * so kill/reset set freq by number mode
			 * before acting on this new user choice
		    */
		    SpecMode = true;
		    tftmsgbx.TuneUpdate(CwTunefreq+SideTonefreq, 0);
		    digPos = 100;
		}
		if (BtnActive(BtnCnt-2, SetUpBtns, px, py)) {	//user touched "DitherLO" button, & wants to Adjust/check Mixer correction settings
			rxcenter = BandSetting[CurSelBnd].rxcenter;
			CwTunefreq = BandSetting[CurSelBnd].CwTunefreq;
			DitherCnt++;
			switch(DitherCnt){
			case 1:
				rxcenter +=10000;
				break;
			case 2:
				rxcenter -=20000;
				break;
			default:
				rxcenter +=10000;
				DitherCnt =0;
				break;
			}
			BandSetting[CurSelBnd].rxcenter = rxcenter;
			LO_Phase_Shift = ((rxcenter-(CwTunefreq))/samp_rate)*TwoPi;
			UpDtLOfreq( rxcenter);
			if (!BandSetting[CurSelBnd].FFTWide) {
			    if (CwTunefreq >= BandSetting[CurSelBnd].rxcenter) {
					LastBinfreq = MaxFreq;// this got updated above via "UpDtLOfreq()"
					fftswopt = 0;
					FFTSel(true, FFTWide);
				} else {
					LastBinfreq = rxcenter;
					fftswopt = 1;
					FFTSel(false, FFTWide);
				}
				TuneBinTX = int((LastBinfreq - (txfreq)) / binfrqWdth);
			} else {
				LastBinfreq = MaxFreq;// this got updated above via "UpDtLOfreq()"
				TuneBinTX = int((LastBinfreq - (txfreq)) / (2 * binfrqWdth));
			}
			NuTunFrq = true;
			py = -10;
			px = -10;
			return 0;
		} else if (BtnActive(BtnCnt-1, SetUpBtns, px, py)) {	//user touched "settings" button, & wants to Adjust/check Mixer correction settings
			Jump2XtalCal(BtnCnt-1);// go here so that we can restore current Xcvr config on return from calibration process
			while ((GetTouchPts(px, py) > 150)
					&& BtnActive(BtnCnt-1, SetUpBtns, px, py)) {//hang here until user lets go of button
				delay(50);
			}
			return 0;		// no further action/evaluation needed
		} else if (BtnActive(15, SetUpBtns, px, py)) { //check for "RIT" Button
			SetZeroBtbtn(0); //clear old zero beat button color
			SetRITbtn(2); //set RIT button to yellow(indicating its been activated)
			RITMode = true;
			delay(100);
			FinTune = true;
			DemodFreq = 0;
			TnPrdStrt = 0;
			NoTnCntr = 0;
			return 0;

		} else if (BtnActive(16, SetUpBtns, px, py)) { //test for FFT Narrow/Wide change
			int step;
			if (!FFTWide)
				step = (binfrqWdth);
			else
				step = (2 * binfrqWdth);
			stepErase = step; //use erase step value to match last time the freq markers were generated
			FFTWide = !FFTWide;
			if (FFTWide) {
				SetUpBtns[16].Captn = " WID";
				LastBinfreq = MaxFreq;
			} else {
				SetUpBtns[16].Captn = " NAR";
			}
			EraseOldMrkrs();
			BandSetting[CurSelBnd].FFTWide = FFTWide;
			BldBtn(16, SetUpBtns);
			ShwSlctdFFTbtn(BandSetting[CurSelBnd].UpFFTflg);
			ShwLmts = true; //ShwSpctrmLmts
			NuTunFrq = true;
			if ((txfreq >= MinFreq) && (txfreq <= MaxFreq)) {
				if (!FFTWide) {
					if (CwTunefreq >= BandSetting[CurSelBnd].rxcenter) {
						LastBinfreq = MaxFreq;
						fftswopt = 0;
						FFTSel(true, FFTWide);
					} else {
						LastBinfreq = rxcenter;
						fftswopt = 1;
						FFTSel(false, FFTWide);
					}
					TuneBinTX = int((LastBinfreq - (txfreq)) / binfrqWdth);
				} else {
					TuneBinTX = int(
							(LastBinfreq - (txfreq)) / (2 * binfrqWdth));
				}
			}
			skipCnt = 5;
			return 0;
		 //end test for FFT Narrow/Wide change
		} else if (BtnActive(17, SetUpBtns, px, py)) { //check for "Dmod" (CW/US/LS) Button
			BandSetting[CurSelBnd].DmodMode++;
			if(BandSetting[CurSelBnd].DmodMode ==3 ) BandSetting[CurSelBnd].DmodMode = 0;
			ShwDModbtn(BandSetting[CurSelBnd].DmodMode);
			SetZeroBtbtn(0);
			BandSetting[CurSelBnd].SideTonefreq = SideTonefreq;
			switch(BandSetting[CurSelBnd].DmodMode){
			case 0:
				BandSetting[CurSelBnd].CwTunefreq = BandSetting[CurSelBnd].CwTunefreq - DFault.SideTonefreq;
				break;
			case 1:
				BandSetting[CurSelBnd].CwTunefreq = BandSetting[CurSelBnd].CwTunefreq + DFault.SideTonefreq;
				break;
			default:
				break;
			}

			CwTunefreq = BandSetting[CurSelBnd].CwTunefreq;
			txfreq = CwTunefreq + SideTonefreq;
			LO_Phase_Shift = ((rxcenter - (CwTunefreq)) / samp_rate) * TwoPi;
			/* setup audio filter */
			InstalFltr();
			skipCnt = 5;
			return 0;
		} else if (BtnActive(18, SetUpBtns, px, py)) {//left set freq by number mode button pressed
			if(digPos < 10000) digPos = 10*digPos;
			tftmsgbx.TuneUpdate(txfreq, digPos);
			SpecMode = false;
			return 0;

		} else if (BtnActive(19, SetUpBtns, px, py)) {//right set freq by number mode button pressed
			if(digPos > 1) digPos =digPos/10;
			tftmsgbx.TuneUpdate(txfreq, digPos);
			SpecMode = false;
			return 0;

		}


		/* check/test Band Buttons */
		for (int butNo = 6; butNo < 11; butNo++) {
			if (BtnActive(butNo, SetUpBtns, px, py)) {
				/*Found selected Band button; restore last setting(s) for this band*/
				EraseOldMrkrs();
				if (RITMode) {
					RITMode = false;
					EraseRIT = true;
				}
				CurSelBnd = butNo - 6;
				CalcIQfactors();
				CwTunefreq = BandSetting[CurSelBnd].CwTunefreq;
				rxcenter = BandSetting[CurSelBnd].rxcenter;
				FFTWide = BandSetting[CurSelBnd].FFTWide;
				SideTonefreq = BandSetting[CurSelBnd].SideTonefreq;
				MinFreq = rxcenter - (samp_rate / 2);
				MaxFreq = rxcenter + (samp_rate / 2);
				if (FFTWide) {
					SetUpBtns[16].Captn = " WID";
					LastBinfreq = MaxFreq;
				} else {
					SetUpBtns[16].Captn = " NAR";
				}
				BldBtn(16, SetUpBtns);
				ShwSlctdFFTbtn(BandSetting[CurSelBnd].UpFFTflg);
				ShwDModbtn(BandSetting[CurSelBnd].DmodMode);
				EraseOldMrkrs();
				if (BandSetting[CurSelBnd].UpFFTflg)
					fftswopt = 1;
				else
					fftswopt = 0;
				txfreq = CwTunefreq + SideTonefreq;
				TXrdy = ValidTX(txfreq); //validate that this is a ham legal frequency
				if (!FFTWide) {
					if (BandSetting[CurSelBnd].UpFFTflg)
						LastBinfreq = MaxFreq;
					else
						LastBinfreq = rxcenter;
				} else
					LastBinfreq = MaxFreq;
				SetRX = true;
				SetTX = false;
				sendFrequency(float(rxcenter));
				LO_Phase_Shift = ((rxcenter - (CwTunefreq)) / samp_rate)
						* TwoPi;
				DitherCnt = 0;//reset dither pointer
				/*Now Setup/restore Band Filter option setting*/
				InstalFltr();
				ShwSlctdFltrBtn(BandSetting[CurSelBnd].FltrOpt + 11);
				ShwSlctdBndBtn(butNo);
				SetZeroBtbtn(0);
				SetRITbtn(0);
				ShwLmts = true;
				return -12;
			}

		}
		/* check/test Filter Buttons */
		for (int i = 11; i < 14; i++) {
			if (BtnActive(i, SetUpBtns, px, py)) {
				BandSetting[CurSelBnd].FltrOpt = i - 11;
				InstalFltr();
				ShwSlctdFltrBtn(i);
				ShwSlctdBndBtn(CurSelBnd + 6);
				return 0;
			}
		}
		//check for upper or lower ftt selection
		if (BtnActive(1, SetUpBtns, px, py)) {//check for upper ftt selection
			if (!FFTWide) {
				if (BtnEnable) {
					BtnEnable = false;
					ShwLmts = true;
					return -9; //LO+SR/2
				} else {
					py = -10;
					px = -10;
					return 0;
				}
			} else {//
				fftswopt = 3; // move LO up
				FFTSel(BandSetting[CurSelBnd].UpFFTflg, FFTWide );
				while ((GetTouchPts(px, py) > 150)
					&& BtnActive(BtnCnt-1, SetUpBtns, px, py)) {//hang here until user lets go of button
						delay(50);
				}
				py = -10;
				px = -10;
				return 0;
			}
		}
		if (BtnActive(0, SetUpBtns, px, py)) {//check for lower ftt selection
			if (!FFTWide) {
				if (BtnEnable) {
					BtnEnable = false;
					ShwLmts = true;
					return -8; //LO-SR/2
				} else {
					py = -10;
					px = -10;
					return 0;
				}
			} else {
				fftswopt = 2; // move LO down
				FFTSel(BandSetting[CurSelBnd].UpFFTflg, FFTWide );
				while ((GetTouchPts(px, py) > 150)
				 && BtnActive(BtnCnt-1, SetUpBtns, px, py)) {//hang here until user lets go of button
					delay(50);
				}
				py = -10;
				px = -10;
				return 0;
			}

		}
		if (px > lastbin) {
			/* User touched to the right of the spectrum display area.
			 * So change tuning proportional;
			 * Or step freq by the selected "tune" digit
			 */
			SetZeroBtbtn(0);
			SetRITbtn(0);
			if (py < 100) {
				// Inc Feq button was pressed
				if(SpecMode){//proportional tuning
					FinTune = false;
					int incfctr = int((100 - py) / 24) + 1;
					return incfctr; //value returned ranges from -1 to -6
				}else{//"stepped" tuning mode
					CwTunefreq += digPos;
					ConFigNuFreq();//this replaces the following code
					py = -10;
					px = -10;
					return 0;
				}

			} else if (py > 140) { // Dec Freq button was pressed
				if(SpecMode){
					FinTune = false;
					int decfctr = -(int((py - 140) / 24) + 1);
					return decfctr; //value returned ranges from -1 to -6
				}else{
					CwTunefreq -= digPos;
					ConFigNuFreq();//this replaces the following code
					py = -10;
					px = -10;
					return 0;
				}

			} else { //not too hot & not too cold, so zero Beat button was pressed
				if (RITMode) {
					/*erase RIT (green) tune marker */
					EraseRIT = true;
					RITMode = false;
				}
				SetZeroBtbtn(2);
				delay(100);
				FinTune = true;
				DemodFreq = 0;
				TnPrdStrt = 0;
				NoTnCntr = 0;
				return 0;
			}
		} else if (px < firstbin) { // ok, user touched in the space to the left of the FFT
			if (BtnActive(4, SetUpBtns, px, py))
				return -10; //Volume Up
			if (BtnActive(5, SetUpBtns, px, py))
				return -11; //Volume Dwn

		} else if (tp.z > 200 && py > 120 && py < 210) { //user is touching inside FFT Display area. So use relative bin location
		// to set the tune frequency
			if (RITMode) {
				RITMode = false;
				EraseRIT = true;
			}
			return -(px + 100);
		} else
			return 0;
	} else {
		BtnEnable = true;
		py = -10;
		px = -10;
		return 0;
	}
}
/////////////////////////////////////////////////////////////////////////////////////////////
void ConFigNuFreq(void) {
	bool updtLO = false;
	while (CwTunefreq > MaxFreq) {
		rxcenter += 40000;
		updtLO = true;
		MinFreq = rxcenter - (samp_rate / 2);
		MaxFreq = rxcenter + (samp_rate / 2);
	}
	while (CwTunefreq < MinFreq) {
		rxcenter -= 40000;
		updtLO = true;
		MinFreq = rxcenter - (samp_rate / 2);
		MaxFreq = rxcenter + (samp_rate / 2);
	}
	if(updtLO) {
		UpDtLOfreq(rxcenter);
		DitherCnt = 0;		//reset dither pointer
		/*Now figure which band is appropriate for this new freq*/
		int i;
		for (i = 0; i < 4; i++)
		{
			if((rxcenter>(BndStops[i].Lo)-500000) && (rxcenter<(BndStops[i].Hi)+500000)){
				break;
			}
		}
		//if(I<5){//took this out; if the new frequency is outside the known limits, then default to the WWV button
			CurSelBnd = i;
			ShwSlctdBndBtn(CurSelBnd+6);
		//}
	}
	if (!FFTWide) {
		if ((fftswopt == 0) && (CwTunefreq + SideTonefreq > rxcenter)) {
			FFTSel(true, FFTWide);
			LastBinfreq = MaxFreq;
			ShwLmts = true; //ShwSpctrmLmts
		} else if ((fftswopt == 1) && (CwTunefreq + SideTonefreq < rxcenter)) {
			FFTSel(false, FFTWide);
			LastBinfreq = rxcenter;
			ShwLmts = true; //ShwSpctrmLmts
		}
	} else
		LastBinfreq = MaxFreq; //added for Full screen FFT Spectrum
	BandSetting[CurSelBnd].rxcenter = rxcenter;
	BandSetting[CurSelBnd].CwTunefreq = CwTunefreq;
	Vfos[BVfo] = CwTunefreq;
	BandSetting[CurSelBnd].SideTonefreq = SideTonefreq;
	LO_Phase_Shift = ((rxcenter - (CwTunefreq)) / samp_rate) * TwoPi;
	SideToneAngle = ((SideTonefreq*float(decimate_factor))/float(samp_rate))*M_PI;//recalculate angle needed to produce current keydown CW sidetone
	//tftmsgbx.TuneUpdate(CwTunefreq + SideTonefreq, digPos);
	tftmsgbx.TuneFreq(CwTunefreq, SideTonefreq);
	if (!RITMode) {
		txfreq = CwTunefreq + SideTonefreq; //based on demod mode = USB & BFO sidetone = 750Hz
		TXrdy = ValidTX(txfreq); //validate that this is a ham legal frequency
		if (!FFTWide)
			TuneBinTX = int((LastBinfreq - (txfreq)) / binfrqWdth);
		else
			TuneBinTX = int((LastBinfreq - (txfreq)) / (2 * binfrqWdth)); //added for full FFT spectrum
	} else {
		if (FFTWide)
			TuneBinRX = int(
					(LastBinfreq - (CwTunefreq + SideTonefreq))
							/ (2 * binfrqWdth));
		else
			TuneBinRX = int(
					(LastBinfreq - (CwTunefreq + SideTonefreq)) / binfrqWdth);
	}
	NuTunFrq = true;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void UpDtLOfreq(int rxcenter){
	si5351.pll_reset(SI5351_PLLA);
	SetRX = true;
	SetTX = false;
	sendFrequency(float(rxcenter));
	MinFreq = rxcenter - (samp_rate / 2);
	MaxFreq = rxcenter + (samp_rate / 2);
	EraseOldMrkrs();
	tftmsgbx.LOFreq(rxcenter);
	ShwLmts = true; //ShwSpctrmLmts
}
/////////////////////////////////////////////////////////////////////////////////////////////
bool ShowTunePos(float CurTunFreq, float LstBinfreq){
	//float FrstBinFreq = LstBinfreq-((MaxFreq-MinFreq)/2);
	float FrstBinFreq = LstBinfreq-((MaxFreq-MinFreq));
	if((CurTunFreq+SideTonefreq<LstBinfreq) && (CurTunFreq>FrstBinFreq)){return true;
	}else return false;
}
void BldButtons(void){
	int btnHght = 39;
	int btnWdthS = firstbin;
	int btnWdthL = 2*btnWdthS;
	int row0;
	int row1;
	int row2;
	int row3;
	int row4;
	int row5; //band buttons
	row0 = int(scrnHeight/2) - (btnHght + 1);//Just above center Screen
	row1 = row0 + (btnHght + 1);//Just below center Screen
	row2 = row1 + (btnHght + 1);
	row3 = row2 + (btnHght + 1);
	row4 = scrnHeight - (5*btnHght + 1);
	row5 = row0 - (btnHght + 1);

	int BtnNo = 0;
	//Exit Button 0
	SetUpBtns[BtnNo].BtnXpos = 0;
	SetUpBtns[BtnNo].BtnWdth = 98;//(3*btnWdthS)+2;
	SetUpBtns[BtnNo].BtnHght = 20;//int(btnHght-19);//btnHght;
	SetUpBtns[BtnNo].BtnYpos = row0;
	SetUpBtns[BtnNo].Captn = "LO+25khz";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 1;
	SetUpBtns[BtnNo].BtnXpos = 0;
	SetUpBtns[BtnNo].BtnWdth =  98;//(3*btnWdthS)+2;
	SetUpBtns[BtnNo].BtnHght = 20;//int(btnHght-19);//btnHght;
	SetUpBtns[BtnNo].BtnYpos = (row1 - 20);//(row1 - int(btnHght-19));//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "LO-25khz";
	if(!FFTWide)SetUpBtns[BtnNo].BtnClr = TFT_GREEN;
	else SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 2;
	SetUpBtns[BtnNo].BtnXpos = lastbin;//130;  //Button X position
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//80;  //Button Width
	SetUpBtns[BtnNo].BtnHght =btnHght;
	SetUpBtns[BtnNo].BtnYpos = row0-int(btnHght/4);// scrnHeight - (SetUpBtns[0].BtnHght + 5);  //Button Y position
	SetUpBtns[BtnNo].Captn = "^^";
	SetUpBtns[BtnNo].BtnClr = TFT_BLUE;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 3;
	SetUpBtns[BtnNo].BtnXpos = lastbin;
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row1+int(btnHght/4);//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "vv";
	SetUpBtns[BtnNo].BtnClr = TFT_RED;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 4;
	SetUpBtns[BtnNo].BtnXpos = 0;//130;  //Button X position
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//80;  //Button Width
	SetUpBtns[BtnNo].BtnHght =btnHght;
	SetUpBtns[BtnNo].BtnYpos = 121;//row2-30;// scrnHeight - (SetUpBtns[0].BtnHght + 5);  //Button Y position
	SetUpBtns[BtnNo].Captn = "V+";
	SetUpBtns[BtnNo].BtnClr = TFT_ORANGE;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 5;
	SetUpBtns[BtnNo].BtnXpos = 0;
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = 161;//row3-30;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "V-";
	SetUpBtns[BtnNo].BtnClr = TFT_ORANGE;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
/* Band Buttons */
	BtnNo = 6;
	SetUpBtns[BtnNo].BtnXpos = 0;
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row5;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "80";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 7;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row5;//SetUpBtns[0].BtnYpos;  //Button Y positionelse if(BtnActive(16, SetUpBtns, px, py)){//user touched hidden button, & wants to checkSi5351 calibration
	SetUpBtns[BtnNo].Captn = "40";
	SetUpBtns[BtnNo].BtnClr = TFT_GREEN;//TFT_DARKCYAN;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 8;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row5;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "30";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 9;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row5;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "20";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 10;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row5;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = " wwv";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	/*Filter Buttons*/
	BtnNo = 11;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[BtnNo-1].BtnXpos+(int(1.5*(btnWdthS+1)));
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row5;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "fW";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 12;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row5;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "fM";
	SetUpBtns[BtnNo].BtnClr = TFT_GREEN;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 13;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[BtnNo-1].BtnXpos+(btnWdthS+1);
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[BtnNo].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[BtnNo].BtnYpos = row5;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[BtnNo].Captn = "fN";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 14;
	SetUpBtns[BtnNo].BtnXpos = lastbin;
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;
	SetUpBtns[BtnNo].BtnHght = int(btnHght/2);
	SetUpBtns[BtnNo].BtnYpos = row1-int(btnHght/4);
	SetUpBtns[BtnNo].Captn = "=0";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;

	BtnNo = 15;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[10].BtnXpos+(int(1.5*(btnWdthS+1)));;
	SetUpBtns[BtnNo].BtnWdth = (3*btnWdthS)+2;
	SetUpBtns[BtnNo].BtnHght = int(btnHght-19);
	SetUpBtns[BtnNo].BtnYpos = row0;
	SetUpBtns[BtnNo].Captn = "  RIT";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_WHITE;
	BtnNo = 16;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[8].BtnXpos+(btnWdthS+1);
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;
	SetUpBtns[BtnNo].BtnHght = int(btnHght);
	SetUpBtns[BtnNo].BtnYpos = row0;
	SetUpBtns[BtnNo].Captn = " WID";
	SetUpBtns[BtnNo].BtnClr = TFT_ORANGE;
	SetUpBtns[BtnNo].TxtClr = TFT_BLACK;
	BtnNo = 17;
	SetUpBtns[BtnNo].BtnXpos = SetUpBtns[10].BtnXpos;
	SetUpBtns[BtnNo].BtnWdth = btnWdthS;
	SetUpBtns[BtnNo].BtnHght = int(btnHght);
	SetUpBtns[BtnNo].BtnYpos = row0;
	switch(BandSetting[CurSelBnd].DmodMode){
	case 1:
		SetUpBtns[BtnNo].Captn = "US";
		break;
	case 2:
		SetUpBtns[BtnNo].Captn = "LS";
		break;
	default:
		SetUpBtns[BtnNo].Captn = "CW";
		break;
	}
	SetUpBtns[BtnNo].BtnClr = TFT_WHITE;
	SetUpBtns[BtnNo].TxtClr = TFT_BLACK;
//invisible buttons; don't actually draw these buttons
	BtnNo = 21;//settings button
	SetUpBtns[BtnNo].BtnXpos = 0;
	SetUpBtns[BtnNo].BtnWdth = 285;
	SetUpBtns[BtnNo].BtnHght = int(btnHght);
	SetUpBtns[BtnNo].BtnYpos = 2;
	SetUpBtns[BtnNo].Captn = "";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_BLACK;

	BtnNo = 20;//Dither LO
	SetUpBtns[BtnNo].BtnXpos = 44;
	SetUpBtns[BtnNo].BtnWdth = 60;
	SetUpBtns[BtnNo].BtnHght = int(btnHght/2);
	SetUpBtns[BtnNo].BtnYpos = 20;
	SetUpBtns[BtnNo].Captn = "";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_BLACK;

	BtnNo = 19;//right tune
	SetUpBtns[BtnNo].BtnXpos = 155;
	SetUpBtns[BtnNo].BtnWdth = 48;
	SetUpBtns[BtnNo].BtnHght = 20;
	SetUpBtns[BtnNo].BtnYpos = 220;
	SetUpBtns[BtnNo].Captn = "";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_BLACK;
	BtnNo = 18;//left tune
	SetUpBtns[BtnNo].BtnXpos = 106;
	SetUpBtns[BtnNo].BtnWdth = 48;
	SetUpBtns[BtnNo].BtnHght = 20;
	SetUpBtns[BtnNo].BtnYpos = 220;
	SetUpBtns[BtnNo].Captn = "";
	SetUpBtns[BtnNo].BtnClr = TFT_BLACK;
	SetUpBtns[BtnNo].TxtClr = TFT_BLACK;

	for(int i=0; i<BtnCnt-4; i++){//Don't draw the 4 last button. they are "hidden" buttons
		BldBtn(i, SetUpBtns); // Build the SetUp Button Set
		delay(20);
	}
	if(rxfreq>rxcenter){
		FreqShft = FFT_SIZE/2;//display FFT positive freqs
		LastBinfreq = MaxFreq;
		ShwSlctdFFTbtn(true);
		fftswopt =1;
	}else{
		FreqShft = 0;//display FFT negative freqs
		LastBinfreq = MaxFreq;// LastBinfreq = rxcenter;
		fftswopt =0;
		//		ShwSlctdFFTbtn(false);
	}

}
//////////////////////////////////////////////////////////////////////////
void BldBtn(int BtnNo, BtnParams Btns[]){ //, const char* Captn, unsigned int BtnClr, unsigned int TxtClr){
	tft.fillRect(Btns[BtnNo].BtnXpos, Btns[BtnNo].BtnYpos, Btns[BtnNo].BtnWdth, Btns[BtnNo].BtnHght, Btns[BtnNo].BtnClr);
	tft.drawRect(Btns[BtnNo].BtnXpos, Btns[BtnNo].BtnYpos, Btns[BtnNo].BtnWdth, Btns[BtnNo].BtnHght, TFT_WHITE);
	tft.setCursor(Btns[BtnNo].BtnXpos + 3, Btns[BtnNo].BtnYpos + int((Btns[BtnNo].BtnHght/2)-7));
	tft.setTextColor(Btns[BtnNo].TxtClr);
	if(BtnNo==10 || BtnNo==16) tft.setTextSize(1,2);// use small font
	tft.print(Btns[BtnNo].Captn);
	if(BtnNo==10 || BtnNo==16) tft.setTextSize(2,2);// restore normal font

}
///////////////////////////////////////////////////////////////////////////
bool BtnActive(int BtnNo, BtnParams Btns[], int px, int py){
	bool actv = false;
	if ((px > Btns[BtnNo].BtnXpos && px < Btns[BtnNo].BtnXpos+Btns[BtnNo].BtnWdth) && (py > Btns[BtnNo].BtnYpos && py < Btns[BtnNo].BtnYpos+Btns[BtnNo].BtnHght)) actv = true;
	return actv;
}
///////////////////////////////////////////////////////////////////////////
void ShwSlctdFFTbtn(bool FFTPlus){

	if(!FFTPlus){
		SetUpBtns[0].BtnClr = TFT_BLACK;
		SetUpBtns[1].BtnClr = TFT_GREEN;
	}else{
		SetUpBtns[0].BtnClr = TFT_GREEN;
		SetUpBtns[1].BtnClr = TFT_BLACK;
	}

	for(int i=0; i<2; i++){
		BldBtn(i, SetUpBtns); // Build the SetUp Button Set
		delay(20);
	}
	if(FFTWide){
		delay(100);
		SetUpBtns[0].BtnClr = TFT_BLACK;
		SetUpBtns[1].BtnClr = TFT_BLACK;
		for(int i=0; i<2; i++){
			BldBtn(i, SetUpBtns); // Build the SetUp Button Set
			delay(20);
		}
	}

}
///////////////////////////////////////////////////////////////////////////////////////////////
void ShwDModbtn(int DmodMode){
	switch(DmodMode){
	case 1:
		SetUpBtns[17].Captn = "US";
		SideTonefreq = 0;
		USBflg = true;
		break;
	case 2:
		SetUpBtns[17].Captn = "LS";
		SideTonefreq = 0;
		USBflg = false;
		break;
	default:
		SetUpBtns[17].Captn = "CW";
		SideTonefreq = DFault.SideTonefreq;
		USBflg = true;
		break;
	}
	BldBtn(17, SetUpBtns); //Refresh DmodMode Button
}
///////////////////////////////////////////////////////////////////////////////////////////////
void SetZeroBtbtn(int mode){
	if(RITMode){
		SetRITbtn(mode);
		return;
	}
	if(mode == 0){
		SetUpBtns[14].BtnClr = TFT_BLACK;
	}else if(mode == 1){
		SetUpBtns[14].BtnClr = TFT_GREEN;
	}else if(mode == 2){
		SetUpBtns[14].BtnClr = TFT_ORANGE;
	}
	BldBtn(14, SetUpBtns); //Refresh ZeroBeat Button

}
///////////////////////////////////////////////////////////////////////////////////////////////
void SetRITbtn(int mode){

	if(mode == 0){
		SetUpBtns[15].BtnClr = TFT_BLACK;
	}else if(mode == 1){
		SetUpBtns[15].BtnClr = TFT_GREEN;
//		RITMode = false;
	}else if(mode == 2){
		SetUpBtns[15].BtnClr = TFT_ORANGE;
	}
	BldBtn(15, SetUpBtns); //Refresh ZeroBeat Button

}
///////////////////////////////////////////////////////////////////////////////////////////////



void ShwSlctdBndBtn(int BtnNo){
	for(int i=6; i<11; i++){
		if(BtnNo!= i){
			SetUpBtns[i].BtnClr = TFT_BLACK;
		}else{
			SetUpBtns[i].BtnClr = TFT_GREEN;
		}
		BldBtn(i, SetUpBtns); // Build the SetUp Button Set
		//delay(20);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////
void ShwSlctdFltrBtn(int BtnNo){
	for(int i=10; i<15; i++){
		if(BtnNo!= i){
			SetUpBtns[i].BtnClr = TFT_BLACK;
		}else{
			SetUpBtns[i].BtnClr = TFT_GREEN;
		}
		BldBtn(i, SetUpBtns); // Build the SetUp Button Set
	}
}
/////////////////////////////////////////////////////////////////////////////
/*Originally written to capture USB serial "info request" messages sent by FLDGI
 * When A new info request is detected. It is evaluated and if this program supports it.
 * the routine will send via the USB Serial connection an appropriate response.
 * */
bool GetRmtCmd() {
	uint8_t Cmd[25];
	bool civtalk = false;
	char StatMsg[40];
	bool stringComplete = false;
	bool FreqSent = false;
	bool Exit = false;
	static int UpdtFrqCntr = 0;
	char inChar;
	int ptr = 0;
	while (!Exit) {

		if (!Serial.available())
			Exit = true; //return stringComplete;
		/*erase old buffer content*/
		if (!Exit) {
			if (!CivON) {
				tftmsgbx.CivPole(TFT_BLUE);
				CivON = true;
			}
			while (ptr < 25) {
				Cmd[ptr] = 0;
				ptr++;
			}

			ptr = 0;
			bool stop = false;
			uint8_t Fndit = 0;
			while (ptr < 25 && !stop) {
				Cmd[ptr] = (uint8_t) Serial.read(); // add it to the Cmd buffer String:
				/*fe fe 94 e0 25 00 fd*/
				/* uncomment for debugging */
//		if(ptr>=6){
//			if(Cmd[ptr-6] == 0xFE && Cmd[ptr-5] == 0xFE && Cmd[ptr-4] == 0x94 && Cmd[ptr-3] == 0xE0
//					&& Cmd[ptr-2] == 0x26 && Cmd[ptr-1] == 0x00 && Cmd[ptr] == 0xFD){
//				Fndit = 1;
//			}
//		}
				if (Cmd[ptr] == 0xFD) {
					stop = true;
				} else
					ptr++;
			}
			/* uncomment for debugging */
//	if(Fndit == 1){
//		sprintf(StatMsg, "!!FOUND IT!!",  (uint8_t)Cmd[4]);
//		tftmsgbx.dispTitl(StatMsg, TFT_RED);
//		Fndit =0;
//	}
			Vfos[BVfo] = CwTunefreq;//start by making sure that the active vfo knows the current operating frequency
			stringComplete = false;
			while (!stringComplete) {
				/* Test/Check has 7300 CIV preamble */
				if (Cmd[0] == 0xFE && Cmd[1] == 0xFE && Cmd[2] == 0x94
						&& Cmd[3] == 0xE0) { //if 7300 talking to this SDR

					switch (Cmd[4]) {
					/* test for frequency request; Cmd 0x03 */
					case 0x03:
						if (Cmd[5] == 0xFD || Cmd[5] == 0x00) {
							if (civtalk) {
								sprintf(StatMsg, "GET FREQ CMD:0x%02X",
										(uint8_t) Cmd[4]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[11] = { 0xFE, 0xFE, 0xE0, 0x94,
									Cmd[4], 0x00, 0x00, 0x00, 0x00, 0x00, 0xFD }; //send response preamble
							int freqTmp = BandSetting[CurSelBnd].CwTunefreq;
							Vfos[BVfo] = freqTmp;
							if (BandSetting[CurSelBnd].DmodMode == 0) {  //cw
								freqTmp += BandSetting[CurSelBnd].SideTonefreq;
							}
							uint8_t rmdr = 0;
							int WholPrt = 0;
							ptr = 5;
							while (ptr < 10) {
								WholPrt = freqTmp;
								WholPrt /= 10;
								WholPrt *= 10;
								rmdr = (uint8_t) (freqTmp - WholPrt);
								uint8_t LoBits = rmdr & 0b00001111;
								freqTmp /= 10;
								WholPrt = freqTmp;
								WholPrt /= 10;
								WholPrt *= 10;
								rmdr = ((uint8_t) (freqTmp - WholPrt)) << 4;
								uint8_t HiBits = rmdr & 0b11110000;
								uint8_t BCDFreq = HiBits | LoBits;
								reply[ptr] = BCDFreq;
								ptr++;
								freqTmp /= 10;
							}
							/* Send response */
							Serial.write(reply, 11);
							FreqSent = true;
							UpdtFrqCntr = 0;
							stringComplete = true;
						} else {  //didn't find the terminate command value
							SayNG();
						}

						break;
						/*Cmd 0x05 Set operating frequency*/
					case 0x05:
						if (civtalk) {
							sprintf(StatMsg, "SET OP FREQ CMD:0x%02X",
									(uint8_t) Cmd[4]);
							tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
						}
						if (1) { //not sure why I had to do this; compiler would throw an error without it
							uint8_t Bcd = 0;
							int NewFreq = 0;
							int Multiplr = 1;
							ptr = 6;
							int Stop = ptr + 4;
							/*Build integer Frequency value from Binary coded Decimal Bytes(2 digits/Byte) */
							while ((Cmd[ptr] != 0xFD) && (ptr < Stop)) {
								//Bcd = (uint8_t) Serial.read();// get next byte:
								Bcd = (uint8_t) Cmd[ptr];
								if (Bcd != 0xFD) {
									NewFreq += (Multiplr
											* (int) (Bcd & 0b00001111));
									Multiplr *= 10;
									uint8_t Bcd2 = Bcd >> 4;
									NewFreq += (Multiplr
											* (int) (Bcd2 & 0b00001111));
									Multiplr *= 10;
								}
								ptr++;
							}
							/*Send response back to controller*/
							if (NewFreq == 0) {
								SayNG(); //BAD
							}else SayOK();

							if (NewFreq > 0) {
								CwTunefreq = NewFreq;
								Vfos[BVfo] =CwTunefreq;
								if (BandSetting[CurSelBnd].DmodMode == 0) { //cw
									CwTunefreq -= SideTonefreq;
								}
								//digPos = 0;
								ConFigNuFreq();
							}
						}
						stringComplete = true;
						break;
						/*Cmd 0x25 send/get VFO Frequency*/
					case 0x25:
						//Cmd[5]can be 0x00 or 0x01; Selected Vfo or Unselected
						if (Cmd[6] == 0xFD) { //get SDR frequency
							if (civtalk) {
								sprintf(StatMsg, "GET VFO FREQ:0x%02X",
										(uint8_t) Cmd[5]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[12] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0x00, 0x00, 0x00,
									0x00, 0xFD }; //send response preamble
							//int freqTmp = BandSetting[CurSelBnd].CwTunefreq;
							int freqTmp;
							if(Cmd[5] == 0x00){//get selected VFO
								if(BVfo) freqTmp = Vfos[BVfo];
								else freqTmp = Vfos[0];
							}else{//get unslected VFO
								if(BVfo) freqTmp = Vfos[0];
								else freqTmp = Vfos[BVfo];
							}
							if (BandSetting[CurSelBnd].DmodMode == 0) { //cw
								freqTmp += BandSetting[CurSelBnd].SideTonefreq;
							}
							uint8_t rmdr = 0;
							int WholPrt = 0;
							ptr = 6;
							int stop = ptr + 5;
							while (ptr < stop) {
								WholPrt = freqTmp;
								WholPrt /= 10;
								WholPrt *= 10;
								rmdr = (uint8_t) (freqTmp - WholPrt);
								uint8_t LoBits = rmdr & 0b00001111;
								freqTmp /= 10;
								WholPrt = freqTmp;
								WholPrt /= 10;
								WholPrt *= 10;
								rmdr = ((uint8_t) (freqTmp - WholPrt)) << 4;
								uint8_t HiBits = rmdr & 0b11110000;
								//uint8_t BCDFreq = HiBits | LoBits;
								reply[ptr] = HiBits | LoBits;
								ptr++;
								freqTmp /= 10;
								//Serial.write(BCDFreq);
							}
							/* Send response termination designator */
							Serial.write(reply, 12);
						} else { //set frequency
							if (civtalk) {
								sprintf(StatMsg, "SET VFO FREQ:0x%02X",
										(uint8_t) Cmd[5]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t Bcd = 0;
							int NewFreq = 0;
							int Multiplr = 1;
							ptr = 5;
							int Stop = ptr + 5;
							/*Build integer Frequency value from Binary coded Decimal Bytes(2 digits/Byte) */
							while ((Cmd[ptr] != 0xFD) && (ptr < Stop)) {
								//Bcd = (uint8_t) Serial.read();// get next byte:
								Bcd = (uint8_t) Cmd[ptr];
								if (Bcd != 0xFD) {
									NewFreq += (Multiplr
											* (int) (Bcd & 0b00001111));
									Multiplr *= 10;
									uint8_t Bcd2 = Bcd >> 4;
									NewFreq += (Multiplr
											* (int) (Bcd2 & 0b00001111));
									Multiplr *= 10;
								}
								ptr++;
							}
							/*Send response back to controller*/
							if (NewFreq == 0) {
								SayNG(); //BAD
							}else SayOK();


							if (NewFreq > 0) {
								NewFreq /= 100; //10 digits sent; but we only need the first 8
								if (BandSetting[CurSelBnd].DmodMode == 0) { //cw
									NewFreq -= SideTonefreq;
								}
								if(Cmd[5] == 0x00){//Set selected VFO
									CwTunefreq = NewFreq;
									if(BVfo) Vfos[BVfo] = CwTunefreq;
									else Vfos[0] = CwTunefreq;
									/* Apply the new freq to the SDR */
									ConFigNuFreq();
								}else{//Set unslected VFO
									if(BVfo) Vfos[0] = NewFreq;//if true; VFO A is the "unselected VFO
									else Vfos[1] = NewFreq;
									/* Because this is the "unselected" VFO no need to changes anything else */
								}
							}
						}
						stringComplete = true;
						break;
						/*Cmd 0x07 Select VFO mode*/
					case 0x07:
						//Cmd[5]can be 0x00, 0x01 0xA0, 0xB0;
						if (Cmd[6] == 0xFD) { //valid command; send reply & then figure out how to handle
							uint8_t reply[6] = { 0xFE, 0xFE, 0xE0, 0x94, 0xFB,
									0xFD }; //send OK response
							Serial.write(reply, 6);
							switch (Cmd[5]){
							case 0x00://select VfoA
								BVfo = 0;
								break;
							case 0x01://select VfoB
								BVfo = 1;
								break;
							case 0xA0: //equalize A & B
								if(BVfo) Vfos[0] = Vfos[1];
								else Vfos[1] = Vfos[0];
								break;
							case 0xB0: //Swap A & B
								float temp = Vfos[1];
								Vfos[1] = Vfos[0];
								Vfos[0] = temp;
								break;
							}
							CwTunefreq = Vfos[BVfo];
							//digPos = 0;
							ConFigNuFreq();

						} else { //didn't find the terminate command value
							SayNG();
						}
						stringComplete = true;
						break;

						/*Cmd 0x19:0x00; Read the transceiver ID*/
					case 0x19:
						//Cmd[5]should be 0x00
						if (Cmd[6] == 0xFD) { //Read the transceiver ID
							uint8_t reply[12] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x94, 0xFD }; //send response preamble
							Serial.write(reply, 8);
							stringComplete = true;

						}
						break;

					case 0x15:
						if (Cmd[5] == 0x02 && Cmd[6] == 0xFD) { //Read S Meter
							uint8_t reply[9] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0x00, 0xFD }; //send response preamble
							ptr = 6;
							//int Sval = (int)(120*(-73.0/OldDBmVal));
							float s9 = -73.0;
							float s0 = -127.0;
							int Sval = map(OldDBmVal, s0, s9, 0, 120);
							Int2BCD(Sval,reply, ptr, ptr+2);
							Serial.write(reply, 9);
							stringComplete = true;
							/*Cmd 0x15:0x15; Read Vd meter level (not supported on blCKPILL SDR)*/
						}else if (Cmd[5] == 0x15 && Cmd[6] == 0xFD) { //Read the transceiver ID
							uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0xFD }; //send response preamble
							Serial.write(reply, 8);
							stringComplete = true;

						}
						break;

						/*Cmd 0x1C Send/Read Xcvr Misc setting*/
					case 0x1C:
						//Cmd[5]can be 0x00 or 0x01; for our needs, it doesn't matter

						if (Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET MISC Cmd:0x%02X:0x%02X",
										Cmd[4], Cmd[5]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							char reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0xFD };
							Serial.write(reply, 8);

						} else if (Cmd[7] == 0xFD) {/*set Misc feature*/
							if (civtalk) {
								sprintf(StatMsg,
										"SET MISC:0x%02X:0x%02X:0x%02X:0x%02X",
										Cmd[4], Cmd[5], Cmd[6], Cmd[7]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[6] = { 0xFE, 0xFE, 0xE0, 0x94, 0xFB,
									0xFD };/*Just say 'OK'*/
							Serial.write(reply, 6);
						} else { //unhandled command
							if (civtalk) {
								sprintf(StatMsg,
										"MISC Cmd:0x%02X:0x%02X:0x%02X:0x%02X",
										Cmd[4], Cmd[5], Cmd[6], Cmd[7]);
								tftmsgbx.dispTitl(StatMsg, TFT_RED);
							}
							uint8_t reply[6] = { 0xFE, 0xFE, 0xE0, 0x94, 0xFA,
									0xFD };/*Send 'Command FAILED'*/
							Serial.write(reply, 6);
							tftmsgbx.CivPole(TFT_RED);
							delay(100);
						}
						stringComplete = true;
						break;
					case 0x0E:
						/*Scan stop*/
						if (Cmd[5] == 0x00 && Cmd[7] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "SET Scan stop");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[6] = { 0xFE, 0xFE, 0xE0, 0x94, 0xFB,
								0xFD }; //OK
							Serial.write(reply, 6);
						}
						break;
						/*Cmd 0x0F get/set SPLIT configuration*/
					case 0x0F:
						//Cmd[5]can be 0x00 or 0x01; for our needs, it doesn't matter
						if (Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "SET SPLIT Mode:0x%02X",
										(uint8_t) Cmd[6]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							if (Cmd[5] == 0x01) { //activate RIT
								RITMode = true;
							} else { //kill RIT
								if (RITMode) {
									/*erase RIT (green) tune marker */
									EraseRIT = true;
									RITMode = false;
									CwTunefreq = Vfos[BVfo];
									ConFigNuFreq();
								}
							}
							uint8_t reply[6] = { 0xFE, 0xFE, 0xE0, 0x94, 0xFB,
									0xFD }; //OK
							Serial.write(reply, 6);
						} else if (Cmd[5] == 0xFD) {//Read Split setting (00=OFF, 01=ON)
							if (civtalk) {
								sprintf(StatMsg, "GET SPLIT Mode:0x%02X",
										(uint8_t) Cmd[6]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							char reply[7] = { 0xFE, 0xFE, 0xE0, 0x94, 0x0F,
									0x00, 0xFD }; //report split is OFF
							if(RITMode) reply[5] = 0x01;//change split to "ON"
							Serial.write(reply, 7);
						}
						stringComplete = true;
						break;
						/*Cmd 0x11 get/set Attenuator*/
					case 0x11:
						if (Cmd[5] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET Attenuator Setting");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[7] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], 0x00, 0xFD }; //(00=OFF, 20=20dB ON)
							Serial.write(reply, 7);
							stringComplete = true;
						}else if(Cmd[6] == 0xFD){
							if (civtalk) {
								sprintf(StatMsg, "SET Attenuator Setting");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							SayOK();
							stringComplete = true;
						}
						break;
						/*Cmd 0x14 get/set Audio/RF/Squelch level*/
					case 0x14:
						//Cmd[5]can be 0x01, 0x02 or 0x03; Audio, RF, or Squelch
						if (Cmd[6] == 0xFD) { // get setting
							uint8_t reply[9] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0x00, 0xFD }; //prepare response preamble
							if (Cmd[5] == 0x01) { //AUDIO
								if (civtalk) {
									sprintf(StatMsg, "GET AUDIO LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								//reply[6] = (uint8_t) (255 * Volume);
								ptr = 6;
								int Val = (int) (255.0 * Volume );
								Int2BCD(Val, reply, ptr, ptr + 2); //insert response value
								Serial.write(reply, 9);
								stringComplete = true;

							} else if (Cmd[5] == 0x02) { //RF
								if (civtalk) {
									sprintf(StatMsg, "GET RF LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								Int2BCD(255, reply, ptr, ptr + 2); //insert response value
								Serial.write(reply, 9);
								stringComplete = true;
							} else if (Cmd[5] == 0x03) { //read the squelch level
								if (civtalk) {
									sprintf(StatMsg, "GET SQUELCH LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								Int2BCD(0, reply, ptr, ptr + 2); //insert response value
								Serial.write(reply, 9);
								stringComplete = true;
							} else if (Cmd[5] == 0x06) { //read the NR level
								if (civtalk) {
									sprintf(StatMsg, "GET NR LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								Int2BCD(0, reply, ptr, ptr + 2); //insert response value
								Serial.write(reply, 9);
								stringComplete = true;
							} else if (Cmd[5] == 0x0A) { //PWR
								if (civtalk) {
									sprintf(StatMsg, "GET PWR LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								Int2BCD(255, reply, ptr, ptr + 2); //insert response value
								Serial.write(reply, 9);
								stringComplete = true;
							} else if (Cmd[5] == 0x0B) { //read [MIC] position
								if (civtalk) {
									sprintf(StatMsg, "GET MIC Position");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								Int2BCD(0, reply, ptr, ptr + 2); //insert response value
								Serial.write(reply, 9);
								stringComplete = true;
								/*read [NOTCH] position*/
							} else if (Cmd[5] == 0x0D) { //RF
								if (civtalk) {
									sprintf(StatMsg, "GET RF LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								/*(0000=max. CCW, 0128=center, 0255=max. CW)*/
								Int2BCD(0, reply, ptr, ptr + 2); //insert response value
								Serial.write(reply, 9);
								stringComplete = true;
							} else if (Cmd[5] == 0x0E) { ///read the COMP level
								if (civtalk) {
								    sprintf(StatMsg, "GET COMPRESS LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								Int2BCD(0, reply, ptr, ptr + 2); //insert response value
								Serial.write(reply, 9);
								stringComplete = true;
							}
						} else if (Cmd[8] == 0xFD) { // config setting
							/*Just say "OK" */
							SayOK();
							if (Cmd[5] == 0x01) { //AUDIO
								if (civtalk) {
									sprintf(StatMsg, "SET AUDIO LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								ptr = 6;
								float SclFctr = (float)BCD2Int(Cmd, ptr, ptr + 2);
								Volume = (SclFctr/ 255.0);
								tftmsgbx.ShwVol(Volume);
								stringComplete = true;
							} else if (Cmd[5] == 0x02) { //RF
								if (civtalk) {
									sprintf(StatMsg, "SET RF LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;
								/* CMD 0x14 sub cmd 0x03;0xnn;0xnn;0xFD Set squelch */
							} else if (Cmd[5] == 0x03) { //Send the squelch level*(0000=min. to 0255=max.)
								if (civtalk) {
									sprintf(StatMsg, "SET SQUELCH LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;
								/* CMD 0x14 sub cmd 0x06;0xnn;0xnn;0xFD Set NR level */
							} else if (Cmd[5] == 0x06) { //Send NR level*(0000=0% to 0255=100%)
								if (civtalk) {
									sprintf(StatMsg, "SET NR LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;
								/* CMD 0x14 sub cmd 0x0A;0xnn;0xnn;0xFD Set PWR LVL */
							} else if (Cmd[5] == 0x0A) { //PWR
								if (civtalk) {
									sprintf(StatMsg, "SET PWR LEVEL");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								SayOK();
								stringComplete = true;
								/* CMD 0x14 sub cmd 0x0B;0xnn;0xnn;0xFD Set squelch */
							} else if (Cmd[5] == 0x0B) { //Send/read [MIC] position*(0000=max. CCW, 0255=max. CW)
								if (civtalk) {
									sprintf(StatMsg, "SET MIC POSITION");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;
								/* CMD 0x14 sub cmd 0x0D;0xnn;0xnn;0xFD Set [NOTCH] position */
							} else if (Cmd[5] == 0x0D) { //Send the [NOTCH] position*(0000=max. CCW, 0128=center, 0255=max.CW))
								if (civtalk) {
									sprintf(StatMsg, "SET NOTCH POSITION");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;

								/* CMD 0x14 sub cmd 0x0E;0xnn;0xnn;0xFD Set compression */
							} else if (Cmd[5] == 0x0E) {
								if (civtalk) {
									sprintf(StatMsg, "Set Compression");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;
								/* CMD 0x14 sub cmd 0x07;0xnn;0xnn;0xFD Set inner [TWIN PBT] position */
							} else if (Cmd[5] == 0x07) {
								if (civtalk) {
									sprintf(StatMsg, "Set inner [TWIN PBT]");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;

								/* CMD 0x14 sub cmd 0x08;0xnn;0xnn;0xFD Set outer [TWIN PBT] position */
							} else if (Cmd[5] == 0x08) {
								if (civtalk) {
									sprintf(StatMsg, "Set outer [TWIN PBT]");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;

								/* CMD 0x14 sub cmd 0x09;0xnn;0xnn;0xFD Set Sidetone Freq */
							} else if (Cmd[5] == 0x09) {
								if (civtalk) {
									sprintf(StatMsg, "Set Sidetone Freq");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								/*convert BCD embeded value to integer*/
								ptr = 6;
								float SclFctr = (float) BCD2Int(Cmd, ptr,
										ptr + 2);
								float OldSTFreq =
										BandSetting[CurSelBnd].SideTonefreq;
								int intSTFeq = (int) (300.0
										+ (600.0 * (SclFctr / 256.0)));
								SideTonefreq = (float) intSTFeq;
								if (OldSTFreq != SideTonefreq) {
									if (BandSetting[CurSelBnd].DmodMode == 0) { //we're in CW mode
										CwTunefreq += OldSTFreq;
										CwTunefreq -= SideTonefreq;
									}
									//digPos = 0;
									ConFigNuFreq();
								}
								stringComplete = true;
								/*CMD 0x14 sub cmd 0x16;0xnn;0xnn;0xFD Set VOX gain*/
							} else if (Cmd[5] == 0x16) {
								if (civtalk) {
									sprintf(StatMsg, "Set VOX Gain");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								stringComplete = true;

								/*CMD 0x14 sub cmd 0x17;0xnn;0xnn;0xFD Set anti-VOX gain*/
							} else if (Cmd[5] == 0x17) {
								if (civtalk) {
									sprintf(StatMsg, "Set anti-VOX Gain");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								/*BlackPill SDR ignores value sent & simply returns "OK" */
								SayOK(); //OK
								stringComplete = true;
							}
//						} else if (Cmd[8] == 0xFD) {
//							if (Cmd[5] == 0x01) { //AUDIO
//								if (civtalk) {
//									sprintf(StatMsg, "SET AUDIO LEVEL: 0x%02X",
//											Cmd[6]);
//									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
//								}
//								ptr = 6;
//								float SclFctr = (float) BCD2Int(Cmd, ptr, ptr + 2);
//								Volume = 100*(SclFctr / (float) 255);
//								tftmsgbx.ShwVol(Volume);
//							} else if (Cmd[5] == 0x02) { //RF
//								if (civtalk) {
//									sprintf(StatMsg, "SET RF LEVEL: 0x%02X",
//											Cmd[6]);
//									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
//								}
//							}
//							uint8_t reply[6] = { 0xFE, 0xFE, 0xE0, 0x94, 0xFB,
//									0xFD }; //OK
//							Serial.write(reply, 6);
//							stringComplete = true;
						}
						break;
					case 0x16:
						/* CMD 0x16 sub cmd 0x02;0xnn; 0xFD Set Preamp (00=OFF, 01=Preamp 1 ON, 02=Preamp 2 ON) */
						if (Cmd[5] == 0x02) {
							if (Cmd[7] == 0xFD) {
								if (civtalk) {
									sprintf(StatMsg, "Set PreAmp");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								/*Blackpill SDR ignores setting; & simply replies "OK"*/
								SayOK(); //OK

								stringComplete = true;
							} else if (Cmd[6] == 0xFD) {
								if (civtalk) {
									sprintf(StatMsg, "Get PreAmp");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
										Cmd[4], Cmd[5], 0x01, 0xFD }; //(00=OFF, 01=Preamp 1 ON, 02=Preamp 2 ON)
								Serial.write(reply, 8);
								stringComplete = true;
							}
							/* CMD 0x16 sub cmd 0x44;0xnn; 0xFD Set Speech compressor *(00=OFF, 01=ON) */
						} else if (Cmd[5] == 0x44 && Cmd[7] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "Set Speech Compress");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							/*Blackpill SDR ignores setting; & simply replies "OK"*/
							SayOK();
							stringComplete = true;
							/*CMD 0x16 sub cmd 0x46;0xnn;0xFD Set VOX ON/OFF*/
						} else if (Cmd[5] == 0x46 && Cmd[7] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "Set VOX ON/OFF");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							/*BlackPill SDR ignores value sent & simply returns "OK" */
							SayOK();
							stringComplete = true;
							/*Cmd:0x16:0x47:0xFD - BK-IN function*/
						} else if (Cmd[5] == 0x47 && Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET BK-IN mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x01, 0xFD }; //(00=BK-IN OFF, 01=Semi BK-IN ON, 02=Full BK-IN ON)
							Serial.write(reply, 8);
							stringComplete = true;
							/*Cmd:0x16:0x12:0xFD - AGC mode*/
						} else if (Cmd[5] == 0x12 && Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET AGC mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x02, 0xFD }; //(00=OFF, 01= FAST, 02= MID, 03=SLOW)
							Serial.write(reply, 8);
							stringComplete = true;
							/*CMD 0x16 sub cmd 0x12;0xnn;0xFD Set AGC ON/OFF*/
						} else if (Cmd[5] == 0x12 && Cmd[7] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "Set AGC Mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							/*BlackPill SDR ignores value sent & simply returns "OK" */
							SayOK();
							stringComplete = true;
							/*Cmd:0x16:0x48:0xFD - Manual notch function*/
						} else if (Cmd[5] == 0x48 && Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET Manual Notch mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0xFD }; //*(00=OFF, 01=ON)
							Serial.write(reply, 8);
							stringComplete = true;
							/*CMD 0x16 sub cmd 0x48;0xnn;0xFD Set VOX ON/OFF*/
						} else if (Cmd[5] == 0x48 && Cmd[7] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "Set Manual Notch mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							/*BlackPill SDR ignores value sent & simply returns "OK" */
							SayOK();
							stringComplete = true;
							/*Cmd:0x16:0x41:0xFD - Auto notch function*/
						} else if (Cmd[5] == 0x41 && Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET Auto Notch mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0xFD }; //*(00=OFF, 01=ON)
							Serial.write(reply, 8);
							stringComplete = true;
							/* CMD 0x16 sub cmd 0x41;0xnn; 0xFD Set Auto notch *(00=OFF, 01=ON) */
						} else if (Cmd[5] == 0x41 && Cmd[7] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "Set Auto notch");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							/*Blackpill SDR ignores setting; & simply replies "OK"*/
							SayOK();
							stringComplete = true;
							/*Cmd:0x16:0x40:0xFD - Noise reduction function*/
						} else if (Cmd[5] == 0x40 && Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET Noise Reduction mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0xFD }; //*(00=OFF, 01=ON)
							Serial.write(reply, 8);
							stringComplete = true;
							/*Cmd:0x16:0x40:0xnn:0xFD - SetNoise reduction *(00=OFF, 01=ON)*/
						} else if (Cmd[5] == 0x40 && Cmd[7] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "SET Noise Reduction");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							SayOK();
							stringComplete = true;

							/*Cmd:0x16:0x22:0xFD - Noise blanker function*/
						} else if (Cmd[5] == 0x22 && Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET Noise Blanker mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0xFD }; //*(00=OFF, 01=ON)
							Serial.write(reply, 8);
							stringComplete = true;
							/*Cmd:0x16:0x22:0xnn:0xFD - Noise blanker function*(00=OFF, 01=ON)*/
						} else if (Cmd[5] == 0x22 && Cmd[7] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "SET Noise Blanker mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							SayOK();
							stringComplete = true;
							/*Cmd:0x16:0x44:0xFD - Speech compress function*/
						} else if (Cmd[5] == 0x44 && Cmd[6] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET Speech Compress mode");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0xFD }; //*(00=OFF, 01=ON)
							Serial.write(reply, 8);
							stringComplete = true;
						}

						break;
						/* RIT Command  */
					case 0x21:
						if (Cmd[5] == 0x00) { //Send/read RIT offset
							if (Cmd[6] == 0xFD) {
								if (civtalk) {
									sprintf(StatMsg, "GET RIT OFFSET");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								uint8_t reply[10] = { 0xFE, 0xFE, Cmd[3],
										Cmd[2], Cmd[4], Cmd[5], 0x00, 0x00,
										0x00, 0xFD }; //prepare response

								int rxfreq = BandSetting[CurSelBnd].CwTunefreq;
								if (BandSetting[CurSelBnd].DmodMode == 0) { //cw
									rxfreq +=
											BandSetting[CurSelBnd].SideTonefreq;
								}
								int offset = rxfreq - txfreq;
								if (offset < 0)
									reply[8] = 0x01; //negative symbol

								uint8_t rmdr = 0;
								int WholPrt = 0;
								ptr = 6;
								int stop = ptr + 2;
								while (ptr < stop) {
									WholPrt = offset;
									WholPrt /= 10;
									WholPrt *= 10;
									rmdr = (uint8_t) (offset - WholPrt);
									uint8_t LoBits = rmdr & 0b00001111;
									offset /= 10;
									WholPrt = offset;
									WholPrt /= 10;
									WholPrt *= 10;
									rmdr = ((uint8_t) (offset - WholPrt)) << 4;
									uint8_t HiBits = rmdr & 0b11110000;
									reply[ptr] = HiBits | LoBits;
									ptr++;
									offset /= 10;
								}
								Serial.write(reply, 10);
								stringComplete = true;
							} else { // wants to set the RIT offset
								if (civtalk) {
									sprintf(StatMsg,
											"SET RIT 0x%02X:0x%02X:0x%02X:0x%02X",
											Cmd[6], Cmd[7], Cmd[8], Cmd[9]);
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								uint8_t Bcd = 0;
								int NewFreq = 0;
								int Multiplr = 1;
								ptr = 6;
								int Stop = ptr + 2;
								/*Build integer Frequency value from Binary coded Decimal Bytes(2 digits/Byte) */
								while ((Cmd[ptr] != 0xFD) && (ptr < Stop)) {
									//Bcd = (uint8_t) Serial.read();// get next byte:
									Bcd = (uint8_t) Cmd[ptr];
									if (Bcd != 0xFD) {
										NewFreq += (Multiplr
												* (int) (Bcd & 0b00001111));
										Multiplr *= 10;
										uint8_t Bcd2 = Bcd >> 4;
										NewFreq += (Multiplr
												* (int) (Bcd2 & 0b00001111));
										Multiplr *= 10;
									}
									ptr++;
								}
								if (NewFreq > 0) {
									if (Cmd[8] != 0x01)
										NewFreq *= -1;
									int rxfreq =
											BandSetting[CurSelBnd].CwTunefreq;
									if (BandSetting[CurSelBnd].DmodMode == 0) { //cw
										rxfreq +=
												BandSetting[CurSelBnd].SideTonefreq;
									}
									CwTunefreq = NewFreq + rxfreq;
									;
									if (BandSetting[CurSelBnd].DmodMode == 0) { //cw
										CwTunefreq -= SideTonefreq;
									}
									//digPos = 0;
									ConFigNuFreq();
								}

								if (Cmd[9] != 0xFD) {
									SayNG(); //BAD
								} else SayOK();
									stringComplete = true;
							}
						} else if (Cmd[5] == 0x01) { //Send/read RIT state (ON/OFF)
							if (Cmd[6] == 0xFD) {
								if (civtalk) {
									sprintf(StatMsg, "GET RIT STATE");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								uint8_t reply[8] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
										Cmd[4], Cmd[5], 0x00, 0xFD }; //RIT mode off
								if (RITMode)
									reply[6] = 0x01; //RIT mode on
								stringComplete = true;
								Serial.write(reply, 8);
							} else if (Cmd[7] == 0xFD) {
								if (civtalk) {
									sprintf(StatMsg, "SET RIT STATE");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								if (Cmd[6] = 0x01) {
									//sprintf(StatMsg, "SET RIT ON");
									RITMode = true;
								} else {
									//sprintf(StatMsg, "SET RIT OFF");
									RITMode = false;
								}
								//tftmsgbx.dispTitl(StatMsg, TFT_YELLOW);
								uint8_t reply[6] = { 0xFE, 0xFE, 0xE0, 0x94,
										0xFB, 0xFD }; //OK
								Serial.write(reply, 6);
								stringComplete = true;
							}
						}
						break;

						/* Cmd 0x26 Mode request */
					case 0x26:
						if (Cmd[6] == 0xFD) { //the Controller wants to Get the mode
							if (civtalk) {
								sprintf(StatMsg,
										"GET DEMOD Mode:0x%02X:0x%02X:0x%02X",
										(uint8_t) Cmd[6], (uint8_t) Cmd[7],
										(uint8_t) Cmd[8]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							/*Fixed reply of "CW" w/ 500Hz Filter*/
							uint8_t Dmod;
							switch (BandSetting[CurSelBnd].DmodMode) {
							case 0: //cw
								Dmod = 0x03;
								break;
							case 1: //usb
								Dmod = 0x01;
								break;
							case 2: //lsb
								Dmod = 0x00;
								break;
							}

							uint8_t Fltr;
							switch (BandSetting[CurSelBnd].FltrOpt) {
							case 0: //Wide
								Fltr = 0x29; //0x03;
								break;
							case 1: //med
								Fltr = 0X14; //0x02;
								break;
							case 2: //narrow
								Fltr = 0x09; //0x01;
								break;
							}
							/*FE FE E0 94 26 00*/
							uint8_t reply[10] = { 0xFE, 0xFE, 0xE0, 0x94, 0x26,
									Cmd[5], Dmod, 0x00, Fltr, 0xFD };
							Serial.write(reply, 10);
						} else { //the Controller wants to configure the mode

							if (civtalk) {
								sprintf(StatMsg,
										"SET DEMOD Mode:0x%02X:0x%02X:0x%02X",
										(uint8_t) Cmd[6], (uint8_t) Cmd[7],
										(uint8_t) Cmd[8]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							int oldMode = BandSetting[CurSelBnd].DmodMode;
							switch (Cmd[6]) {
							case 0: //LSB
								BandSetting[CurSelBnd].DmodMode = 2;
								break;
							case 1: //USB
								BandSetting[CurSelBnd].DmodMode = 1;
								break;
							case 3: //CW
								BandSetting[CurSelBnd].DmodMode = 0;
								break;
							}

							switch (Cmd[8]) { //Filter setting
							case 1: //fN
								if (BandSetting[CurSelBnd].DmodMode == 0) { //only usable in CW mode
									BandSetting[CurSelBnd].FltrOpt = 2; //set filter to 500hz
								}
								break;
							case 2: //fM
								BandSetting[CurSelBnd].FltrOpt = 1; //set filter to 1000hz
								break;
							case 3: //fW
								BandSetting[CurSelBnd].FltrOpt = 0; //set filter to 2500hz
								break;
								//alternate definitions
							case 0x09: //fN
								if (BandSetting[CurSelBnd].DmodMode == 0) { //only usable in CW mode
									BandSetting[CurSelBnd].FltrOpt = 2; //set filter to 500hz
								}
								break;
							case 0X14: //fM
								BandSetting[CurSelBnd].FltrOpt = 1; //set filter to 1000hz
								break;
							case 0X29: //fW
								BandSetting[CurSelBnd].FltrOpt = 0; //set filter to 2500hz
								break;
							}

							ShwDModbtn(BandSetting[CurSelBnd].DmodMode);
							//SetZeroBtbtn(0);
							//BandSetting[CurSelBnd].SideTonefreq = SideTonefreq;
							bool updtflg = false;
							switch (BandSetting[CurSelBnd].DmodMode) {
							case 0:				//CW
								if (oldMode != 0) {
									BandSetting[CurSelBnd].CwTunefreq =
											BandSetting[CurSelBnd].CwTunefreq
													- DFault.SideTonefreq;
									CwTunefreq =
											BandSetting[CurSelBnd].CwTunefreq;
									txfreq = CwTunefreq + SideTonefreq;
									updtflg = true;
								}

								break;
							case 1:				//USB
								if (oldMode == 0) {
									BandSetting[CurSelBnd].CwTunefreq =
											BandSetting[CurSelBnd].CwTunefreq
													+ DFault.SideTonefreq;
									CwTunefreq =
											BandSetting[CurSelBnd].CwTunefreq;
									txfreq = CwTunefreq;
									updtflg = true;
								}
								break;
							case 2:				//LSB
								if (oldMode == 0) {
									BandSetting[CurSelBnd].CwTunefreq =
											BandSetting[CurSelBnd].CwTunefreq
													+ DFault.SideTonefreq;
									CwTunefreq =
											BandSetting[CurSelBnd].CwTunefreq;
									txfreq = CwTunefreq;
									updtflg = true;
								}
								break;
							default:
								break;
							}
							if (updtflg) {
								//digPos = 0;
								ConFigNuFreq();
//								LO_Phase_Shift = ((rxcenter - (CwTunefreq))
//										/ samp_rate) * TwoPi;
							}
							/* setup audio filter */
							InstalFltr();
							ShwSlctdFltrBtn(
									BandSetting[CurSelBnd].FltrOpt + 11);
							/*Send response back to controller*/
							if (Cmd[9] != 0xFD) {
								SayNG(); //BAD
							}else SayOK();


						}
						stringComplete = true;
						break;

					case 0x1A:
						/*CMD 0x1A:0x01:0xnn:0xnn:0xnn set/get Band stacking register(s)*/
						if (Cmd[5] == 0x01) {
							if (Cmd[6] == 0xFD){
								if (civtalk) {
									sprintf(StatMsg, "GET BAND");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								uint8_t reply[9] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], 0x00, 0x01, 0xFD };

								switch(CurSelBnd){
								case 0:
									reply[6] = 0x02;
									break;
								case 1:
									reply[6] = 0x03;
									break;
								case 2:
									reply[6] = 0x04;
									break;
								case 3:
									reply[6] = 0x05;
									break;

								}
								Serial.write(reply, 9);
								stringComplete = true;

							}else if(Cmd[8] == 0xFD){
								if (civtalk) {
									sprintf(StatMsg, "SET BAND");
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}

								switch(Cmd[6]){
								case 0x02:
									CurSelBnd = 0;
									SayOK();
									break;
								case 0x03:
									CurSelBnd = 1;
									SayOK();
									break;
								case 0x04:
									CurSelBnd = 2;
									SayOK();
									break;
								case 0x05:
									CurSelBnd = 3;
									SayOK();
									break;
								default:
									SayNG();
									break;
								}
								CwTunefreq = BandSetting[CurSelBnd].CwTunefreq;
								SideTonefreq = BandSetting[CurSelBnd].SideTonefreq;
								FFTWide = BandSetting[CurSelBnd].FFTWide;
								//DmodMode = BandSetting[CurSelBnd].DmodMode;
								//FltrOpt = BandSetting[CurSelBnd].FltrOpt;
								InstalFltr();
								ShwSlctdFltrBtn(
										BandSetting[CurSelBnd].FltrOpt
												+ 11);
								//digPos = 0;
								ConFigNuFreq();
								stringComplete = true;
							}

						/* CMD 0x1A sub cmd 0x03 send/read Filter Setting */
						}else if (Cmd[5] == 0x03) {
							//&& Cmd[6] == 0xFD) {
							if (Cmd[6] == 0xFD || Cmd[6] == 0x00) { //send remote SDR's current filter (BandWidth) selection
								if (civtalk) {
									sprintf(StatMsg, "GET Fltr:0x%02X",
											(uint8_t) Cmd[6]);
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}
								uint8_t fltrval;
								switch (BandSetting[CurSelBnd].FltrOpt) {
								case 0:
									fltrval = 0x29; //2500Hz
									break;
								case 1:
									fltrval = 0x14; //1000Hz
									break;
								case 2:
									fltrval = 0x09; //500Hz
									break;
								}
								/*FE FE E0 94 1A 03*/
								char reply[8] = { 0xFE, 0xFE, 0xE0, 0x94, 0x1A,
										0x03, fltrval, 0xFD };
								Serial.write(reply, 8);
							} else { //remote wants to configure/set the SDR's filter (BandWidth)
								/*This section of code as yet to be tested verified*/
								/*Cmd2[0] x09; x14; 0x29 = 500; 1000; & 2500 Hz*/
								if (civtalk) {
									sprintf(StatMsg, "SET Fltr:0x%02X",
											(uint8_t) Cmd[6]);
									tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
								}

								/*Send response back to controller*/

								if (Cmd[6] == 0x09 || Cmd[6] == 0x14
										|| Cmd[6] == 0x29) {

									switch (Cmd[6]) {
									case 0x09:
										BandSetting[CurSelBnd].FltrOpt = 2;
										break;
									case 0x14:
										BandSetting[CurSelBnd].FltrOpt = 1;
										break;
									case 0x29:
										BandSetting[CurSelBnd].FltrOpt = 0;
										break;
									}
									InstalFltr();
									ShwSlctdFltrBtn(
											BandSetting[CurSelBnd].FltrOpt
													+ 11);
									SayOK();
								} else {
									SayNG(); //BAD
								}

							}
							stringComplete = true;
							/* CMD 0x1A sub cmd 0x05;0x00;0x53;0xFD Send/read CW normal side set */
						} else if (Cmd[5] == 0x05 && Cmd[6] == 0x00
								&& Cmd[7] == 0x53 && Cmd[8] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET CW normal side set");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[10] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], Cmd[6], Cmd[7], 0x01, 0xFD }; //USB
							Serial.write(reply, 10);
							stringComplete = true;
							/* CMD 0x1A sub cmd 0x05;0x00;0x58;0xFD read reference frequency (range: 0 to 255)*/
						} else if (Cmd[5] == 0x05 && Cmd[6] == 0x00
								&& Cmd[7] == 0x58 && Cmd[8] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "GET CW normal side set");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							uint8_t reply[11] = { 0xFE, 0xFE, Cmd[3], Cmd[2],
									Cmd[4], Cmd[5], Cmd[6], Cmd[7], 0x00, 0x00,
									0xFD }; //return "0"
							Serial.write(reply, 11);
							stringComplete = true;

							/* CMD 0x1A sub cmd 0x05;0x00;0x94;0x20 Send date setting */
						} else if (Cmd[5] == 0x05 && Cmd[6] == 0x00
								&& Cmd[7] == 0x94 && Cmd[8] == 0x20) {
							if (civtalk) {
								sprintf(StatMsg, "Send date setting");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							SayOK();
							stringComplete = true;
							/* CMD 0x1A sub cmd 0x05;0x00;0x94;0x20 Send time setting */
						} else if (Cmd[5] == 0x05 && Cmd[6] == 0x00
								&& Cmd[7] == 0x95) {
							if (civtalk) {
								sprintf(StatMsg, "Send Time setting");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							/*BlackPill SDR ignores value sent & simply returns "OK" */
							SayOK();
							stringComplete = true;
							/*Set VOX delay*/
						} else if (Cmd[5] == 0x05 && Cmd[6] == 0x01
								&& Cmd[7] == 0x91 && Cmd[9] == 0xFD) {
							if (civtalk) {
								sprintf(StatMsg, "Set VOX delay");
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							/*BlackPill SDR ignores value sent & simply returns "OK" */
							SayOK();
							stringComplete = true;

							/* CMD 0x1A sub cmd 0x06 Config Data mode */
						} else if (Cmd[5] == 0x06) {
							if (civtalk) {
								sprintf(StatMsg, "SET Data Mode:0x%02X0x%02X",
										(uint8_t) Cmd[6], (uint8_t) Cmd[7]);
								tftmsgbx.dispTitl(StatMsg, TFT_CYAN);
							}
							if (Cmd[6] == 0x01) {
								int OldMode = BandSetting[CurSelBnd].DmodMode;
								break;
								BandSetting[CurSelBnd].DmodMode = 1; // set to USB
								ShwDModbtn(BandSetting[CurSelBnd].DmodMode);
								if (OldMode == 0) {
									BandSetting[CurSelBnd].CwTunefreq =
											BandSetting[CurSelBnd].CwTunefreq
													+ DFault.SideTonefreq;
									CwTunefreq =
											BandSetting[CurSelBnd].CwTunefreq;
									txfreq = CwTunefreq;
									//digPos = 0;
									ConFigNuFreq();
									LO_Phase_Shift = ((rxcenter - (CwTunefreq))
											/ samp_rate) * TwoPi;
								}
								/* setup audio filter */
								BandSetting[CurSelBnd].FltrOpt = 0; //set filter to wide
								InstalFltr();
								ShwSlctdFltrBtn(
										BandSetting[CurSelBnd].FltrOpt + 11);
							}
							/*Send response back to controller*/
							SayOK();
							stringComplete = true;

						}
						break;

					} //end Switch cmd[4]

//				} //end if 7300 talking to this SDR
					if (!stringComplete) { //Unknown command/request
						uint8_t reply[6] =
								{ 0xFE, 0xFE, 0xE0, 0x94, 0xFA, 0xFD };
						Serial.write(reply, 6);
					}
				} //end if 7300 talking to this SDR
				if (!stringComplete) { //Unkown command/request
					sprintf(StatMsg, "Cmd0x%02X:0x%02X:0x%02X:0x%02X:0x%02X",
							Cmd[4], Cmd[5], Cmd[6], Cmd[7], Cmd[8]);
					//		Cmd[2], Cmd[3], Cmd[4], Cmd[5], Cmd[6]);
					tftmsgbx.dispTitl(StatMsg, TFT_RED); //for testing only
					tftmsgbx.CivPole(TFT_RED);
					stringComplete = true;
				}
			} //end while (!stringComplete)
		} //end if(!exit)
	} //end while(!exit)
	return FreqSent;
} // end GetRmtCmd()

/////////////////////////////////////////////////////////////////////////////
void SayOK(void){
	char reply[6] = { 0xFE, 0xFE, 0xE0, 0x94, 0xFB, 0xFD }; //OK
	Serial.write(reply, 6);
}
/////////////////////////////////////////////////////////////////////////////
void SayNG(void){
	char reply[6] = { 0xFE, 0xFE, 0xE0, 0x94, 0xFA, 0xFD }; //OK
	Serial.write(reply, 6);
}
////////////////////////////////////////////////////////////////////////////
/*convert BCD bytes to integer value */
int BCD2Int(uint8_t *SrcData, int ptr, int stop){
	uint8_t Bcd = 0;
	int IntVal = 0;
	int Multiplr = 1;
//	ptr = 5;
//	int Stop = ptr + 5;
	/*Build integer Frequency value from Binary coded Decimal Bytes(2 digits/Byte) */
	while ((SrcData[ptr] != 0xFD) && (ptr < stop)) {
		IntVal *= 100;
		Bcd = (uint8_t) SrcData[ptr];
		IntVal += (int)(Bcd & 0b00001111);
		uint8_t Bcd2 = Bcd >> 4;
		IntVal += (10* (int)(Bcd2 & 0b00001111));
		ptr++;
	}
	return IntVal;
}
////////////////////////////////////////////////////////////////////////////////////////////////
void Int2BCD(int Val, uint8_t *SrcData, int ptr, int stop){
	uint8_t rmdr = 0;
	int WholPrt = 0;
	int wide = stop-ptr;
	while (wide > 0) {
		wide--;
		WholPrt = Val;
		WholPrt /= 10;
		WholPrt *= 10;
		rmdr = (uint8_t) (Val - WholPrt);
		uint8_t LoBits = rmdr & 0b00001111;
		Val /= 10;
		WholPrt = Val;
		WholPrt /= 10;
		WholPrt *= 10;
		rmdr = ((uint8_t) (Val - WholPrt)) << 4;
		uint8_t HiBits = rmdr & 0b11110000;
		//uint8_t BCDFreq = HiBits | LoBits;
		SrcData[ptr+wide] = HiBits | LoBits;
		Val /= 10;
		//Serial.write(BCDFreq);
	}

}
////////////////////////////////////////////////////////////////////////////////////////////////
/* PB13 KeyIN interrupt routine. */
void KeyEvntSR(void) {
	if(!TXrdy) return;
	//KeyActive = true; //to ensure best timing,  moved this to stm32f4xx_it.c
	if (!HAL_GPIO_ReadPin(KeyIn_ExtI15_GPIO_Port, KeyIn_ExtI15_Pin)) { // looks like SSMicro/Radio is being manually keyed by an external key
		//KeyDown
        int contactcntr = 1;
        while(contactcntr >0){//while(contactcntr >0 && !KeyClosed){
        	if(HAL_GPIO_ReadPin(KeyIn_ExtI15_GPIO_Port, KeyIn_ExtI15_Pin)) return; //False Alarm
        	contactcntr += 1;
        	if (contactcntr > 15) { //Contact DeBounce check/pass
        		contactcntr = 0;
        		if (!PTT) { //if T/R relay is not in the TX position, Give it a chance to pickup before applying carrier
        			/* Set T/R Relay to Transmit position */
        			HAL_GPIO_WritePin(TR_Relay_GPIO_Port, TR_Relay_Pin, GPIO_PIN_SET);
        			/* Added the next 2 lines to stop Audio squeal when switching from Rx to Tx */
        			LdTXBuffer(0);// this effectively flushes the Audio out buffer
        			LdTXBuffer(32);// this effectively flushes the Audio out buffer
//        			delay(8);//commented out & replaced by new approach to effecting delayed Si5351 TX commands
        			PTT = true;
				}
        	}
        }
		SetRX = false;
//		StartTX();//commented out & replaced by new approach to effecting delayed Si5351 TX commands
		/*Added to support new approach to effecting delayed Si5351 TX commands*/
		if(!TXON){
			ExecTXCmd = HAL_GetTick()+TXdelay;//Added to support new approach to effecting delayed Si5351 TX commands
			TXON = true;//Added to support new approach to effecting delayed Si5351 TX commands
		}
		PTTtimeOut = HAL_GetTick()+TRHangTime;//keep adavncing the T/R "hang time" as long as the key is closed; This approach allows for sustained "key down" state
	}
	else { //Manual KeyUp
        int contactcntr = 1;
        while(contactcntr >0 ){
        	if (HAL_GPIO_ReadPin(KeyIn_ExtI15_GPIO_Port, KeyIn_ExtI15_Pin))  contactcntr += 1;//key pin is High
        	else return; //False Alarm
        	if (contactcntr > 15) { //Contact DeBounce check/pass
        		contactcntr = 0; //Ok, key is "Up"
//				StopTX(); //commented out & replaced by new approach to effecting delayed Si5351 TX commands
        		/*Added to support new approach to effecting delayed Si5351 TX commands*/
        		if(TXON){
        			TXON = false;
        			ExecTXCmd = HAL_GetTick()+TXdelay;
        		}
        	}
        }

/* TODO Still have to manage PTT & KeyActive flags; And returning T/R pin back to RX state */
//		if (!KeyClosed && (((unsigned long)(micros() - lastTime) >= DlyIntrvl)) && DlyIntrvl && KeyActive) { //Added the 'KeyActive" to ensure this code does not operate while streaming CW keying via QUISK/FLDIGI
//			DlyIntrvl = 0;
//			PTT = false;
//			KeyActive = false;
//			digitalWrite(PTTPin, LOW);  //Return T/R Relay to RX position after delay
//			Serial.println("KEYUP");
//		}
	}
}//End Manual Keying
///////////////////////////////////////////////////////////////////////////////////////////////

void StartTX(void) {
//  if (!KeyClosed) { // Turn Tx On
    si5351.output_enable(SI5351_CLK0, 0);
    si5351.output_enable(SI5351_CLK1, 0);
    SetTX = true;
    if(txfreqOld !=txfreq){
    	if (txfreq >= 3500000.0){
    		sendFrequency(float(txfreq));//don't activate TX RF below 80 mtrs
    		txfreqOld =txfreq;
    	}
    }
    si5351.output_enable(SI5351_CLK2, 1);
    SetTX = false;
    KeyClosed = true;
//  } //end if (!KeyClosed)
}
///////////////////////////////////////////////////////////////////////////////////////////////

void StopTX(void) {
//  if (KeyClosed) { // Turn Tx Off
    KeyClosed = false;
// }
  si5351.output_enable(SI5351_CLK2, 0);// disable xmit clock/oscillator.
  si5351.output_enable(SI5351_CLK0, 1);// Activate I phase RX clock/oscillator
  si5351.output_enable(SI5351_CLK1, 1);// Activate Q phase RX clock/oscillator
}
///////////////////////////////////////////////////////////////////////////////////////////////
void InstalFltr(void){
	IIRflg = false;
	switch(BandSetting[CurSelBnd].FltrOpt) {
	case 0: //FW (Filter Wide)
		if(USBflg) SetUPFIR(filter_tapsW, FILTER_TAP_NUMW);
		else SetUPFIR(filter_tapsWL, FILTER_TAP_NUMW);
		break;
	case 1: //FM (Filter Medium)
		if(USBflg) SetUPFIR(filter_tapsM, FILTER_TAP_NUMM);
		else SetUPFIR(filter_tapsML, FILTER_TAP_NUMM);
		break;
	case 2: //FN (Filter Narrow)
		Calc_IIR_BPFltrCoef(BandSetting[CurSelBnd].SideTonefreq, samp_rate, 3.7071);
		IIRflg = true;
//		if(USBflg) SetUPFIR(filter_tapsN, FILTER_TAP_NUMN);
//		else SetUPFIR(filter_tapsNL, FILTER_TAP_NUMN);
		break;
	}
	return;
}
///////////////////////////////////////////////////////////////////////////////////////////////
void SetUPFIR(const __complex__ float *Fltr, size_t TapCnt)
{
	decimate_taps_length = TapCnt;
	TapCntx2 = TapCnt*2;
	stop = int((TapCntx2*4)/decimate_factor);
	ARMdecimateByteCnt = 2*4*TapCnt;//sizeof(ARMdecimate_buffer);
	StrtNuNdx = (ARMdecimateByteCnt-NuDataByteCnt)/4;
	if(TapCnt<100) BntCntrStop = 15360;
	else BntCntrStop = 1;
	// ====== normalize FIR filter ===
	float decimate_taps_sum = 0;
	//we sum up the absolute value of taps:
	for(int i=0; i<decimate_taps_length; i++){
		decimate_taps_sum += cabsf(Fltr[i]);
	}
	/* map normalized complex tap values/coefficients to arm dsp array */
	for(int i=0; i< decimate_taps_length; i++){
		ARMdecimate_taps[(2*i)+0] = crealf(Fltr[i])/decimate_taps_sum;
		ARMdecimate_taps[(2*i)+1] = cimagf(Fltr[i])/decimate_taps_sum;
	}

	/* we can optionally print the filter taps to a file to analyze them using GNU Octave.
	 * To do this copy and past the output generated below to a file called, say "test.m".
	 * Then start "Octave", and navigate to the directory where test has been stored.
	 * Once that directory has been opened/selected, type "test", and octave should run this
	 * test.m script, and generate a normalize plot of the filter's frequency response */
#ifdef PRINT_FILTER_TO_FILE
	delay(4000);
	char PBufr[50];
	Serial.print("freqz([");
	for(int i=0; i<decimate_taps_length; i++){
		sprintf(PBufr, " %f+(%f*i)\n", ARMdecimate_taps[(2*i)+0]), ARMdecimate_taps[(2*i)+1]);
		Serial.print(PBufr);
	}
	sprintf(PBufr, "]);\n");
	Serial.print(PBufr);
#endif
}
/////////////////////////////////////////////////////////////////////////////////////////
void Calc_IIR_BPFltrCoef(float Fc, float Fs, float Q) {

	//float K = tan(M_PI * ((Fc*8) / Fs));//manual method
	float K = tan(M_PI * ((Fc*4) /(0.96 * Fs))); // CMSIS-DSP process; Note Decimate factor is 1/2 that of the manual method
	float norm = 1 / (1 + K / Q + K * K);

	a0 = (K / Q) * norm;
	a1 = 0;
	a2 = -a0;
	b1 = 2 * (K * K - 1) * norm;
	b2 = (1 - K / Q + K * K) * norm;
	Coeffs[0] = Coeffs[5] = +a0;
	Coeffs[1] = Coeffs[6] = +a1;
	Coeffs[2] = Coeffs[7] = +a2;
	Coeffs[3] = Coeffs[8] = -b1;
	Coeffs[4] = Coeffs[9] = -b2;
	/*initialize CMSIS IIR Filter global state structure "S1" */
	arm_biquad_cascade_df2T_init_f32(&S1, numStages, Coeffs, State);

}
/////////////////////////////////////////////////////////////////////////////////////////
void CalcIQfactors(void){
	PhasCorect = BandSetting[CurSelBnd].PhasCorect;
	AmpFactor = BandSetting[CurSelBnd].AmpFactor;
//	ICFactr = (1+ (0.5*arm_sin_f32((TwoPi/360)*PhasCorect)));
//	QCFactr = AmpFactor/ICFactr;
	ICFactr = (arm_sin_f32((TwoPi/360)*PhasCorect));
	QCFactr = AmpFactor;
}
//////////////////////////////////////////////////////////////////////////////////////
void ApplySmplRate(int SamplRateInt){
	samp_rate = (float) SamplRateInt;
//	??const int output_rate =  samp_rate/decimate_factor;
	MinFreq = rxcenter-(samp_rate/2);
	MaxFreq = rxcenter+(samp_rate/2);
	LO_Phase_Shift = ((rxcenter-CwTunefreq)/samp_rate)*2*M_PI;
//	??float txd_shift_phase = ((rxcenter-txfreq)/samp_rate)*2*M_PI;
	SideToneAngle = ((SideTonefreq*float(decimate_factor))/float(samp_rate))*M_PI;
	IntrpAsec =int(samp_rate/decimate_factor);
	binfrqWdth = samp_rate/(FFT_SIZE);
	float  FreqLimit = samp_rate/2;
	BinLimit = int(FreqLimit/binfrqWdth);// (256)

	lastbin = BinLimit +int((scrnWidth-BinLimit)/2);
	firstbin = int((scrnWidth-BinLimit)/2);
	/* initialize OldSpecVals */
	for (int i = 0; i < BinLimit; i++) {
		OldSpecVals[i] = GrphBase;
		CurSpecVals[i] = NoiseFlr;
	}
}
///////////////////////////////////////////////////////////////////////////////////
/*The following is only used by the balance mixer process */
void ApplySideTone(int Freq){
	SideTonefreq = (float) Freq;
	SideToneAngle = ((SideTonefreq*float(decimate_factor))/float(samp_rate))*M_PI;
	/*ensure all CW bands are set to the same side-tone */
	for( int i =0; i< 4; i++ ){
		BandSetting[i].CwTunefreq = (BandSetting[i].CwTunefreq +BandSetting[i].SideTonefreq) - SideTonefreq;
		BandSetting[i].SideTonefreq = SideTonefreq;
	}
	CwTunefreq = BandSetting[CurSelBnd].CwTunefreq;

	if(!FFTWide) TuneBinTX = int((LastBinfreq-(CwTunefreq+SideTonefreq))/binfrqWdth);//commented out for full FFT spectrum
	else TuneBinTX = int((LastBinfreq-(CwTunefreq+SideTonefreq))/(2*binfrqWdth));//added for full FFT spectrum
	txfreq = CwTunefreq + SideTonefreq;
	TXrdy = ValidTX(txfreq);//validate that this is a ham legal frequency
}
///////////////////////////////////////////////////////////////////////////////////
void LdFactryVals(void){
	XP = DFault.XP ;
	XM = DFault.XM;
	YP = DFault.YP;
	YM = DFault.YP;
	TS_LEFT = DFault.TS_LEFT;
	TS_RT = DFault.TS_RT;
	TS_TOP = DFault.TS_TOP;
	TS_BOT = DFault.TS_BOT ;
	scrnHeight = DFault.scrnHeight ;
	scrnWidth = DFault.scrnWidth;
	TXdelay = DFault.TXdelay;
	TRHangTime = DFault.TRHangTime;
	Volume = DFault.Volume;
	XtalErr = DFault.XtalErr;
	samp_rate = DFault.samp_rate ;
	SideTonefreq = DFault.SideTonefreq;
}
///////////////////////////////////////////////////////////////////////////////////
bool ValidTX(int tstFreq){
	bool TXvalid = false;
	int i;
	for (i = 0; i < 4; i++)
		{
			if((tstFreq>BndStops[i].Lo) && (tstFreq<BndStops[i].Hi)){
				TXvalid = true;
				break;
			}
		}
	return TXvalid;
}
///////////////////////////////////////////////////////////////////////////////////
void ZeroBtFltr(void){
//	SetUPFIR(filter_tapsN, FILTER_TAP_NUMN);
	SetUPFIR(filter_tapsM, FILTER_TAP_NUMM);
}
//////////////////////////////////////////////////////////////////////////////////////////////
//void ShwSmtr(int Smtr, float DBm){
//sprintf( Title, "S%d %.1fdB", Smtr, DBm);
//tftmsgbx.SigSmtr(Title, TFT_GREEN);
//}
//////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 96;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 12;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_HSI, RCC_MCODIV_1);
}

/**
    * @brief USB_OTG_FS Initialization Function
    * @param None
    * @retval None
    */
//  static void MX_USB_OTG_FS_PCD_Init(void)
//  {
//
//    /* USER CODE BEGIN USB_OTG_FS_Init 0 */
//
//    /* USER CODE END USB_OTG_FS_Init 0 */
//
//    /* USER CODE BEGIN USB_OTG_FS_Init 1 */
//
//    /* USER CODE END USB_OTG_FS_Init 1 */
//    hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
//    hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
//    hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
//    hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
//    hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
//    if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    /* USER CODE BEGIN USB_OTG_FS_Init 2 */
//
//    /* USER CODE END USB_OTG_FS_Init 2 */
//
//  }



static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

///**
//  * @brief I2C3 Initialization Function
//  * @param None
//  * @retval None
//  */
//static void MX_I2C3_Init(void)
//{
//
//  /* USER CODE BEGIN I2C3_Init 0 */
//
//  /* USER CODE END I2C3_Init 0 */
//
//  /* USER CODE BEGIN I2C3_Init 1 */
//
//  /* USER CODE END I2C3_Init 1 */
//  hi2c3.Instance = I2C3;
//  hi2c3.Init.ClockSpeed = 100000;
//  hi2c3.Init.DutyCycle = I2C_DUTYCYCLE_2;
//  hi2c3.Init.OwnAddress1 = 0;
//  hi2c3.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
//  hi2c3.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
//  hi2c3.Init.OwnAddress2 = 0;
//  hi2c3.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
//  hi2c3.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
//  if (HAL_I2C_Init(&hi2c3) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN I2C3_Init 2 */
//
//  /* USER CODE END I2C3_Init 2 */
//
//}


/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S2_Init(void)
{

  /* USER CODE BEGIN I2S2_Init 0 */

  /* USER CODE END I2S2_Init 0 */

  /* USER CODE BEGIN I2S2_Init 1 */

  /* USER CODE END I2S2_Init 1 */
  hi2s2.Instance = SPI2;
  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s2.Init.DataFormat = I2S_DATAFORMAT_24B;
  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_48K;//I2S_AUDIOFREQ_96K;
  hi2s2.Init.CPOL = I2S_CPOL_LOW;
  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_ENABLE;
  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S2_Init 2 */

  /* USER CODE END I2S2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* Configure DMA request hdma_memtomem_dma2_stream0 on DMA2_Stream0 */
  hdma_memtomem_dma2_stream0.Instance = DMA2_Stream0;
  hdma_memtomem_dma2_stream0.Init.Channel = DMA_CHANNEL_0;
  hdma_memtomem_dma2_stream0.Init.Direction = DMA_MEMORY_TO_MEMORY;
  hdma_memtomem_dma2_stream0.Init.PeriphInc = DMA_PINC_ENABLE;
  hdma_memtomem_dma2_stream0.Init.MemInc = DMA_MINC_ENABLE;
  hdma_memtomem_dma2_stream0.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
  hdma_memtomem_dma2_stream0.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
  hdma_memtomem_dma2_stream0.Init.Mode = DMA_NORMAL;
  hdma_memtomem_dma2_stream0.Init.Priority = DMA_PRIORITY_LOW;
  hdma_memtomem_dma2_stream0.Init.FIFOMode = DMA_FIFOMODE_ENABLE;
  hdma_memtomem_dma2_stream0.Init.FIFOThreshold = DMA_FIFO_THRESHOLD_FULL;
  hdma_memtomem_dma2_stream0.Init.MemBurst = DMA_MBURST_INC4;
  hdma_memtomem_dma2_stream0.Init.PeriphBurst = DMA_PBURST_INC4;
  if (HAL_DMA_Init(&hdma_memtomem_dma2_stream0) != HAL_OK)
  {
    Error_Handler( );
  }
  __HAL_DMA_ENABLE_IT(&hdma_memtomem_dma2_stream0, DMA_IT_TC);
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 4); //shift decimate buffer interrupt
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);



  /* DMA interrupt init */
  /* DMA1_Stream3_IRQn (I2S RX data in) interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 3);//Sound board ring buffer interrupt
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
  /* DMA1_Stream4_IRQn (I2S TX data out)interrupt configuration */
//  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 3);
//  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

//  /*Configure GPIO pin : PA8 */
//  GPIO_InitStruct.Pin = GPIO_PIN_8;
//  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//  GPIO_InitStruct.Pull = GPIO_NOPULL;
//  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//  GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
//  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* Set Port A GPIO pins Low */
  HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin|BndD1_Pin
                          |BndD0_Pin, GPIO_PIN_RESET);

  /* Set Port B GPIO pins Low */
  HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|TR_Relay_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);

  /*Configure Port A GPIO pins  */
  GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin|BndD1_Pin
                          |BndD0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure Port B GPIO pins  */
  GPIO_InitStruct.Pin = LCD_D3_Pin|TR_Relay_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : KeyIn_ExtI15_Pin */
  GPIO_InitStruct.Pin = KeyIn_ExtI15_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP; //GPIO_NOPULL;
  HAL_GPIO_Init(KeyIn_ExtI15_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 1);// keyer interrupt
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
//static void MX_TIM5_Init(void)
//{
//
//  /* USER CODE BEGIN TIM5_Init 0 */
//
//  /* USER CODE END TIM5_Init 0 */
//
//  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
//  TIM_MasterConfigTypeDef sMasterConfig = {0};
//
//  /* USER CODE BEGIN TIM5_Init 1 */
//
//  /* USER CODE END TIM5_Init 1 */
//  htim5.Instance = TIM5;
//  htim5.Init.Prescaler = 96-1;
//  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
//  htim5.Init.Period = 4294967295;
//  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
//  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
//  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
//  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
//  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
//  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN TIM5_Init 2 */
//
//  /* USER CODE END TIM5_Init 2 */
//
//}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
