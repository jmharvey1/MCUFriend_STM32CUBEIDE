/*
 * SDR_Si5351r01.h
 *
 *  Created on: Jul 3, 2022
 *      Author: jim
 */

#ifndef INC_SDR_SI5351R01_H_
#define INC_SDR_SI5351R01_H_
//extern unsigned long PTTtimeOut;
//extern unsigned long ExecTXCmd;
//extern bool TXON;
//extern bool PTT; // tracks the state of the TR relay (true = relay in TX state)
void readResistiveTouch(void);
int GetTouchPts(int &px, int &py);
void sendFrequency(float HzFreq);
bool GetRmtCmd();
void ApplySmplRate(int SamplRateInt);
void ApplySideTone(int Freq);
void ZeroBtFltr(void);
void configSi5351(void);
void StopTX(void);
void StartTX(void);
bool ValidTX(int tstFreq);


#endif /* INC_SDR_SI5351R01_H_ */
