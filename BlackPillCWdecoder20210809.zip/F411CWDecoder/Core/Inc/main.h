/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
extern DMA_HandleTypeDef hdma_spi2_tx;
//extern MCUFRIEND_kbv tft;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
//extern int scrnHeight;
//extern int scrnWidth;
extern int KeyState, BIAS, TonSig, ltrCmplt;
extern int textSrtX;
extern int textSrtY;
extern uint8_t Toggle;
extern uint16_t adc_buf[];
extern float DimFctr, SAMPLING_RATE, PhazAng;
extern float  magH, magL, magC, SqlchLvl, CurNoise, TSF, NSF, AdjSqlch, NoiseFlr, SigPk;
extern uint8_t NuMagData;
extern volatile unsigned long noSigStrt, EvntStart, LpCnt;
extern volatile unsigned long wordBrk, avgDit;
extern long ManSqlch;
extern uint8_t GudSig;
extern uint8_t LongSmplFlg;
extern struct DF_t DFault;


/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void InitGoertzel(void);
void CalcFrqParams(float NewToneFreq);
void delay_us (uint16_t us);
void delay(int Millis);
void USBprintln(const char *msg);
void USBprint(const char *msg);
void USBprintInt(int val);
void USBprintIntln( int val);
void KeyEvntSR(void);
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_Pin GPIO_PIN_13
#define LED_GPIO_Port GPIOC
#define LCD_D0_Pin GPIO_PIN_0
#define LCD_D0_GPIO_Port GPIOA
#define LCD_D1_Pin GPIO_PIN_1
#define LCD_D1_GPIO_Port GPIOA
#define LCD_D2_Pin GPIO_PIN_2
#define LCD_D2_GPIO_Port GPIOA
#define LCD_D4_Pin GPIO_PIN_4
#define LCD_D4_GPIO_Port GPIOA
#define LCD_D5_Pin GPIO_PIN_5
#define LCD_D5_GPIO_Port GPIOA
#define LCD_D6_Pin GPIO_PIN_6
#define LCD_D6_GPIO_Port GPIOA
#define LCD_D7_Pin GPIO_PIN_7
#define LCD_D7_GPIO_Port GPIOA
#define LCD_D3_Pin GPIO_PIN_0
#define LCD_D3_GPIO_Port GPIOB
#define DMA_Evnt_Pin GPIO_PIN_12
#define DMA_Evnt_GPIO_Port GPIOB
#define KeyIn_EXT13_Pin GPIO_PIN_13
#define KeyIn_EXT13_GPIO_Port GPIOB
#define KeyIn_EXT13_EXTI_IRQn EXTI15_10_IRQn
#define LCD_RD_Pin GPIO_PIN_5
#define LCD_RD_GPIO_Port GPIOB
#define LCD_WR_Pin GPIO_PIN_6
#define LCD_WR_GPIO_Port GPIOB
#define LCD_RS_Pin GPIO_PIN_7
#define LCD_RS_GPIO_Port GPIOB
#define LCD_CS_Pin GPIO_PIN_8
#define LCD_CS_GPIO_Port GPIOB
#define LCD_RST_Pin GPIO_PIN_9
#define LCD_RST_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
//#define ADC_BUF_LEN  4096 //2048 //
#define ADC_BUF_LEN  2048
//#define ADC_BUF_LEN  1024
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
