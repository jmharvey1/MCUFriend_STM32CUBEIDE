/*
 * BtnSuprt.cpp
 *
 *  Created on: Mar 26, 2021
 *      Author: jim
 */

/* Includes ------------------------------------------------------------------*/
#include <eeprom.h>
#include "BtnSuprt.h"
#include "FFTdemo.h"
#include "ScopeDemo.h"
#include "LEDDemo.h"
#include "SetUpCwDecoder.h"
//#include "TestADC_DMA01.h"
#include "STM32F411def.h"
#include "WS2812B.h"
#include "Arduino.h"
#include "MCUFRIEND_kbv.h"
#include "Adafruit_GFX.h"
#include "TouchScreen_kbv.h"
#include "UTFTGLUE.h"              //use GLUE class and constructor
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB8|PB9|

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF
#define LED_NO    1
//#define TITLE "Buttons Demo"
//#define REVDT "03/20/2021"
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
//ADC_HandleTypeDef hadc1;

//int scrnHeight; //main.h now passes this variable to this code
//int scrnWidth; //main.h now passes this variable to this code
int px = 0; //mapped 'x' display touch value
int py = 0;

/*Touch Pin Wiring XP=PB7 XM=PA6 YP=PA7 YM=PB6
LANDSCAPE CALIBRATION    320 x 480 */
//const int XP=PB7, XM=PA6, YP=PA7, YM=PB6;
//const int TS_LEFT=634,TS_RT=399,TS_TOP=492,TS_BOT=522;
/*  Added for buttons support */
char textMsg[51];
int DeBug = 0;// added just to get button setup loop going without error
int tchcnt =0;// needed global variable for read/detect button support
bool BlkIntrpt = false; // needed global variable for read/detect button support
int btnPrsdCnt = 0; // needed global variable for read/detect button support
const int fontH = 16;// needed global variable for read/detect button support
const int fontW = 12;// needed global variable for read/detect button support
bool buttonEnabled = true; // needed global variable for read/detect button support
int value; // needed global variable for debugging button support
bool FrstTime = true; // needed global variable for readResistiveTouch() function
/* Begin Button Definitions */
int loopcnt;
int btnHght = 40;
int btnWdthS = 80;
int btnWdthL = 2*btnWdthS;
int row0;
int row1;
int row2;
int row3;
int row4;
int col0 = 0;
int col1 = btnWdthS+1;
int col2 = col1 + btnWdthS+1;
int col3 = col2+ btnWdthS+1;
int col4 = col3+ btnWdthS+1;
int col5 = col4+ btnWdthS+1;
char BtnCaptn[14];
char BtnCaptn1[14];
char BtnCaptn2[14];
char BtnCaptn3[14];
//bool NoiseSqlch = true;//included here just to keep the BldButtons routine happy
//bool AutoTune = true;//included here just to keep the BldButtons routine happy
BtnParams SetUpBtns[19]; //currently the Setup screen has 19 buttons




/* End Button Definitions */

ADC_HandleTypeDef OLDhadc1;
ADC_ChannelConfTypeDef OLDsConfig;
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* USER CODE BEGIN PFP */
TouchScreen_kbv ts(XP, YP, XM, YM, 300);
//TouchScreen_kbv ts(YM, XM, YP, XP, 300);
TSPoint_kbv tp; //global point
template <class T>
int EEPROM_write(uint16_t ee, const T& value)
{
   //const byte* p = (const byte*)(const void*)&value;
   const uint16_t* p = (const uint16_t*)(const void*)&value;
   int i=0;
   while (i < sizeof(value)){
       //EEPROM.write(ee++, *p++);
	   EE_WriteVariable(ee, *p);
   	   ee +=2;
   	   i +=2;
   	   p++;// +=2;
   }
   return i;
}

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  Button entry point.
  * @retval int
  */
//////////////////////////////////////////////////////////////////////////
void BldButtons(void){
	row0 = scrnHeight - (btnHght + 5);
	row1 = scrnHeight - (2*btnHght + 5);
	row2 = scrnHeight - (3*btnHght + 5);
	row3 = scrnHeight - (4*btnHght + 5);
	row4 = scrnHeight - (5*btnHght + 5);
	//Exit Button 0
	SetUpBtns[0].BtnXpos = col2;//130;  //Button X position
	SetUpBtns[0].BtnWdth = btnWdthS;//80;  //Button Width
	SetUpBtns[0].BtnHght =btnHght;
	SetUpBtns[0].BtnYpos = row0;// scrnHeight - (SetUpBtns[0].BtnHght + 5);  //Button Y position
	SetUpBtns[0].Captn = "Exit";
	SetUpBtns[0].BtnClr = YELLOW;
	SetUpBtns[0].TxtClr = WHITE;
	//  Save Button position parameters
	SetUpBtns[1].BtnXpos = col3;//SetUpBtns[0].BtnXpos+ SetUpBtns[0].BtnWdth+1;  //Button X position
	SetUpBtns[1].BtnWdth = btnWdthS;//SetUpBtns[0].BtnWdth;  //Button Width
	SetUpBtns[1].BtnHght = btnHght;//SetUpBtns[0].BtnHght;
	SetUpBtns[1].BtnYpos = row0;//SetUpBtns[0].BtnYpos;  //Button Y position
	SetUpBtns[1].Captn = "Save";
	SetUpBtns[1].BtnClr = GREEN;
	SetUpBtns[1].TxtClr = WHITE;

	//IncFreq Button parameters Button 2
	SetUpBtns[2].BtnXpos = col4;//SetUpBtns[1].BtnXpos+SetUpBtns[1].BtnWdth+1;  //Button X position
	SetUpBtns[2].BtnWdth = 80;  //Button Width
	SetUpBtns[2].BtnHght = 40;
	SetUpBtns[2].BtnYpos = row1;//scrnHeight - (SetUpBtns[0].BtnHght + SetUpBtns[2].BtnHght + 5);  //Button Y position
	//SetUpBtns[2].Captn = "SMPL+";
	SetUpBtns[2].Captn = "Freq+";
	SetUpBtns[2].BtnClr = BLUE;
	SetUpBtns[2].TxtClr = WHITE;

	//DecFreq Button parameters Button 3
	SetUpBtns[3].BtnXpos = col1;//SetUpBtns[0].BtnXpos-(80+1);  //Button X position
	SetUpBtns[3].BtnWdth = 80;  //Button Width
	SetUpBtns[3].BtnHght = 40;
	SetUpBtns[3].BtnYpos = row1;//scrnHeight - (SetUpBtns[0].BtnHght+SetUpBtns[3].BtnHght + 5);  //Button Y position
	//SetUpBtns[3].Captn = "SMPL-";
	SetUpBtns[3].Captn = "Freq-";
	SetUpBtns[3].BtnClr = BLUE;
	SetUpBtns[3].TxtClr = WHITE;

	//IncLED Button parameters Button 4
	SetUpBtns[4].BtnXpos = col5;//SetUpBtns[2].BtnXpos+SetUpBtns[2].BtnWdth+1;  //Button X position
	SetUpBtns[4].BtnWdth = 80;  //Button Width
	SetUpBtns[4].BtnHght = 40;
	SetUpBtns[4].BtnYpos = row2;//SetUpBtns[2].BtnYpos-SetUpBtns[4].BtnHght;  //Button Y position
	SetUpBtns[4].Captn = "LED +";
	SetUpBtns[4].BtnClr = BLUE;
	SetUpBtns[4].TxtClr = WHITE;

	//DecLED Button parameters  Button 5
	SetUpBtns[5].BtnXpos = col0;//SetUpBtns[0].BtnXpos-((2*80)+1);  //Button X position
	SetUpBtns[5].BtnWdth = 80;  //Button Width
	SetUpBtns[5].BtnHght = 40;
	SetUpBtns[5].BtnYpos = row2;//SetUpBtns[2].BtnYpos-SetUpBtns[5].BtnHght;  //Button Y position
	SetUpBtns[5].Captn = "LED -";
	SetUpBtns[5].BtnClr = BLUE;
	SetUpBtns[5].TxtClr = WHITE;

	//IncTone Scale Factor Button Position parameters Button 6
	SetUpBtns[6].BtnXpos = col5;//SetUpBtns[4].BtnXpos;  //Button X position
	SetUpBtns[6].BtnWdth = 80;  //Button Width
	SetUpBtns[6].BtnHght = 40;
	SetUpBtns[6].BtnYpos = row3;//SetUpBtns[5].BtnYpos-SetUpBtns[6].BtnHght;  //Button Y position
	SetUpBtns[6].Captn = "TSF +";
	SetUpBtns[6].BtnClr = RED;
	SetUpBtns[6].TxtClr = WHITE;



	//DecTone Scale Factor Button Position  parameters Button 7
	SetUpBtns[7].BtnXpos = col0;//SetUpBtns[5].BtnXpos;  //Button X position
	SetUpBtns[7].BtnWdth = 80;  //Button Width
	SetUpBtns[7].BtnHght = 40;
	SetUpBtns[7].BtnYpos = row3;//SetUpBtns[4].BtnYpos - SetUpBtns[7].BtnHght;  //Button Y position
	SetUpBtns[7].Captn = "TSF -";
	SetUpBtns[7].BtnClr = RED;
	SetUpBtns[7].TxtClr = WHITE;


	//IncNoise Scale Factor Button Position parameters Button 8
	SetUpBtns[8].BtnWdth = 80;  //Button Width
	SetUpBtns[8].BtnHght = 40;
	SetUpBtns[8].BtnXpos = col4;//SetUpBtns[6].BtnXpos-(SetUpBtns[8].BtnWdth+1);  //Button X position
	SetUpBtns[8].BtnYpos = row3;//SetUpBtns[4].BtnYpos-SetUpBtns[8].BtnHght;  //Button Y position
	SetUpBtns[8].Captn = "NSF +";
	SetUpBtns[8].BtnClr = RED;
	SetUpBtns[8].TxtClr = WHITE;

	//DecNoise Scale Factor Button Position  parameters Button 9
	SetUpBtns[9].BtnWdth = 80;  //Button Width
	SetUpBtns[9].BtnHght = 40;
	SetUpBtns[9].BtnXpos = col1;//SetUpBtns[7].BtnXpos+(SetUpBtns[7].BtnWdth+1);  //Button X position
	SetUpBtns[9].BtnYpos = row3;//SetUpBtns[4].BtnYpos-SetUpBtns[9].BtnHght;  //Button Y position
	SetUpBtns[9].Captn = "NSF -";
	SetUpBtns[9].BtnClr = RED;
	SetUpBtns[9].TxtClr = WHITE;

	//IncBIAS Button parameters Button 10
	SetUpBtns[10].BtnXpos = col5;  //Button X position
	SetUpBtns[10].BtnWdth = btnWdthS;  //Button Width
	SetUpBtns[10].BtnHght = btnHght;
	SetUpBtns[10].BtnYpos = row4;  //Button Y position
	SetUpBtns[10].Captn = "BIAS+";
	SetUpBtns[10].BtnClr = YELLOW;
	SetUpBtns[10].TxtClr = WHITE;

	//DecBIAS Button parameters Button 11
	SetUpBtns[11].BtnXpos = col0;  //Button X position
	SetUpBtns[11].BtnWdth = btnWdthS;  //Button Width
	SetUpBtns[11].BtnHght = btnHght;
	SetUpBtns[11].BtnYpos = row4;  //Button Y position
	SetUpBtns[11].Captn = "BIAS-";
	SetUpBtns[11].BtnClr = YELLOW;
	SetUpBtns[11].TxtClr = WHITE;

	//IncSQLCH Button parameters Button 12
	SetUpBtns[12].BtnXpos = col4;  //Button X position
	SetUpBtns[12].BtnWdth = btnWdthS;  //Button Width
	SetUpBtns[12].BtnHght = btnHght;
	SetUpBtns[12].BtnYpos = row4;  //Button Y position
	SetUpBtns[12].Captn = "MSQL+";
	SetUpBtns[12].BtnClr = MAGENTA;
	SetUpBtns[12].TxtClr = WHITE;

	//DecSQLCH Button parameters Button 13
	SetUpBtns[13].BtnXpos = col1;  //Button X position
	SetUpBtns[13].BtnWdth = btnWdthS;  //Button Width
	SetUpBtns[13].BtnHght = btnHght;
	SetUpBtns[13].BtnYpos = row4;  //Button Y position
	SetUpBtns[13].Captn = "MSQL-";
	SetUpBtns[13].BtnClr = MAGENTA;
	SetUpBtns[13].TxtClr = WHITE;

	if (NoiseSqlch) sprintf(BtnCaptn1, "NOISE SQLCH");
	else sprintf(BtnCaptn1, " MAN SQLCH");
	//SqMode Button parameters Button 14
	SetUpBtns[14].BtnXpos = col2;  //Button X position
	SetUpBtns[14].BtnWdth = btnWdthL;  //Button Width
	SetUpBtns[14].BtnHght = btnHght;
	SetUpBtns[14].BtnYpos = row4;  //Button Y position
	SetUpBtns[14].Captn = BtnCaptn1;
	SetUpBtns[14].BtnClr = MAGENTA;
	SetUpBtns[14].TxtClr = WHITE;

	//Dfault Button parameters Button 15
	SetUpBtns[15].BtnXpos = col2;  //Button X position
	SetUpBtns[15].BtnWdth = btnWdthL;  //Button Width
	SetUpBtns[15].BtnHght = btnHght;
	SetUpBtns[15].BtnYpos = row3;  //Button Y position
	SetUpBtns[15].Captn = "FACTORY VALS";
	SetUpBtns[15].BtnClr = GREEN;
	SetUpBtns[15].TxtClr = WHITE;


	//DeBug Button parameters Button 16
	SetDBgCptn(BtnCaptn);
	SetUpBtns[16].BtnXpos = col2;  //Button X position
	SetUpBtns[16].BtnWdth = btnWdthL;  //Button Width
	SetUpBtns[16].BtnHght = btnHght;
	SetUpBtns[16].BtnYpos = row2;  //Button Y position
	SetUpBtns[16].Captn = BtnCaptn;
	SetUpBtns[16].BtnClr = MAGENTA;
	SetUpBtns[16].TxtClr = WHITE;

	//Freq Mode Button parameters Button 17
	if (AutoTune) sprintf(BtnCaptn2, " AUTO TUNE");
	else sprintf(BtnCaptn2, "FREQ LOCKED");
	SetUpBtns[17].BtnXpos = col2;  //Button X position
	SetUpBtns[17].BtnWdth = btnWdthL;  //Button Width
	SetUpBtns[17].BtnHght = btnHght;
	SetUpBtns[17].BtnYpos = row1;  //Button Y position
	SetUpBtns[17].Captn = BtnCaptn2;
	SetUpBtns[17].BtnClr = RED;
	SetUpBtns[17].TxtClr = WHITE;

	//  Program Select Button position parameters
	SetPrgmCptn(BtnCaptn3);
	SetUpBtns[18].BtnXpos = col1;//
	SetUpBtns[18].BtnWdth = btnWdthS;
	SetUpBtns[18].BtnHght = btnHght;
	SetUpBtns[18].BtnYpos = row0;
	SetUpBtns[18].Captn = BtnCaptn3; //"CW";
	SetUpBtns[18].BtnClr = TFT_ORANGE;
	SetUpBtns[18].TxtClr = TFT_BLACK;

	enableDisplay();
	tft.fillScreen(BLACK);

	for(int i=0; i<19; i++){
		BldBtn(i, SetUpBtns); // Build the SetUp Button Set
	}

}
//////////////////////////////////////////////////////////////////////////
/* This is for external calls to the BtnSuprt code to test a special button set or group */
int ReadBtns(void){
	readResistiveTouch();
	if (tp.z > 150) { // if (tp.z > MINPRESSURE && tp.z < MAXPRESSURE) { //
		//use the following for Screen orientation set to 1
		py = map(tp.y, TS_TOP, TS_BOT, 0, scrnHeight);
		px = map(tp.x, TS_LEFT, TS_RT, 0, scrnWidth);
		/* original code */
//		py = map(tp.x, 890, 116, 0, 320);
//		px = map(tp.y, 100, 950, 0, 480);
		/* Un-comment diagnostic test/verification of screen touch coordinates */
//		sprintf( textMsg, "px: %d", px);
//		ShwData(5, 30, textMsg);
//		sprintf( textMsg, "py: %d", py);
//		ShwData(5, 55, textMsg);
//		delay(200);

	}else{
		py=-10;
		px=-10;
		buttonEnabled = true; //set true here just for this demo code;
		//normally a completed action would set this back to true
	}

	if (BtnActive(2, SetUpBtns, px, py)){
		// Inc Feq button was pressed
		RptActvBtn(strdup("Inc Freq"));
		loopcnt =0;
		return 1;
	}

	if (BtnActive(3, SetUpBtns, px, py)){
		// Dec Feq button was pressed
		RptActvBtn(strdup("Dec Freq"));
		loopcnt =0;
		return 2;
	}
	RptActvBtn(strdup(""));
	return 0;
}
//////////////////////////////////////////////////////////////////////////

void setuploop(void){
	loopcnt = 100;
	py = 0;
	px = 0;
	tchcnt = 100;
	BldButtons();
	delay(250);
	unsigned long NxtChk = HAL_GetTick()+4;
	bool setupflg = true;
	SetScrnActv = true;
	while(setupflg){ // run inside this loop until user exits setup mode
		delay(4);
		LpCnt++;
		if(LpCnt>2){
		//if(HAL_GetTick()>NxtChk){
			//NxtChk = HAL_GetTick()+128;
			LpCnt = 0;
			ShwUsrParams();
			readResistiveTouch();

		}
		if (tp.z > 150) { // if (tp.z > MINPRESSURE && tp.z < MAXPRESSURE) { //
			//use the following for Screen orientation set to 1
			/*20210827 added adaptive screen touch mapping */
			py = map(tp.y, TS_TOP, TS_BOT, 0, scrnHeight);
			px = map(tp.x, TS_LEFT, TS_RT, 0, scrnWidth);
			/* original code */
			/* Un-comment diagnostic test/verification of screen touch coordinates */
//			sprintf( textMsg, "px: %d", px);
//			ShwData(5, 30, textMsg);
//			sprintf( textMsg, "py: %d", py);
//			ShwData(5, 55, textMsg);
//			delay(200);
			/* original code 20210827 */
			//py = map(tp.x, 890, 116, 0, 320);
			//px = map(tp.y, 100, 950, 0, 480);
		}else{
			py=-10;
			px=-10;
			buttonEnabled = true; //set true here just for this demo code;
			//normally a completed action would set this back to true
			PlotIfNeed2();
		}

		if (BtnActive(2, SetUpBtns, px, py)){
			// Inc Feq button was pressed
			//RptActvBtn(strdup("Inc Freq"));
			loopcnt =0;
			buttonEnabled = false;
			//SAMPLING_RATE += 100;
			TARGET_FREQUENCYC +=5;
			CalcFrqParams(TARGET_FREQUENCYC);
			InitGoertzel();
			ShwUsrParams();
		}

		if (BtnActive(3, SetUpBtns, px, py)){
			// Dec Feq button was pressed
			//RptActvBtn(strdup("Dec Freq"));
			loopcnt =0;
			buttonEnabled = false;
			//SAMPLING_RATE -= 100;
			TARGET_FREQUENCYC -=5;
			CalcFrqParams(TARGET_FREQUENCYC);
			InitGoertzel();
			ShwUsrParams();
		}

		if (BtnActive(4, SetUpBtns, px, py)){
			//RptActvBtn(strdup("Inc LED"));
			loopcnt =0;
			// Increment LED button was pressed
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			DimFctr += 0.05;
			if(DimFctr>1.0) DimFctr= 1.0;
			ShwUsrParams();
			//			}

		}

		if (BtnActive(5, SetUpBtns, px, py)){
			//RptActvBtn(strdup("Dec LED"));
			loopcnt =0;
			// Decrement LED button was pressed
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			DimFctr -= 0.05;
			if(DimFctr<0.05) DimFctr= 0.05;
			ShwUsrParams();
			//			}
		}

		if (BtnActive(6, SetUpBtns, px, py)){
			// Increment TONE Scale Factor button was pressed
			//RptActvBtn(strdup("Inc Tone Scale"));
			loopcnt =0;
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			TSF += 0.05;
			if(TSF>3.0) TSF= 3.0;
			ShwUsrParams();
			//			}

		}

		if (BtnActive(7, SetUpBtns, px, py)){
			// Decrement TONE Scale Factor button was pressed
			//RptActvBtn(strdup("Dec Tone Scale"));
			loopcnt =0;
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			TSF -= 0.05;
			if(TSF<0.05) TSF= 0.05;
			ShwUsrParams();
			//			}
		}

		if (BtnActive(8, SetUpBtns, px, py)){
			// Increment NOISE Scale Factor button was pressed
			//RptActvBtn(strdup("Inc Noise"));
			loopcnt =0;
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			NSF += 0.05;
			if(NSF>12.5) NSF= 12.5;//if(NSF>2.5) NSF= 2.5;
			ShwUsrParams();
			//			}

		}

		if (BtnActive(9, SetUpBtns, px, py)){
			// Decrement NOISE Scale Factor button was pressed
			//RptActvBtn(strdup("Dec Noise"));
			loopcnt =0;
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			NSF -= 0.05;
			if(NSF<0.05) NSF= 0.05;
			ShwUsrParams();
			//			}
		}

		if (BtnActive(10, SetUpBtns, px, py)){
			// Increment BIAS button was pressed
			//RptActvBtn(strdup("Inc BIAS"));
			loopcnt =0;
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			BIAS += 10;
			if(BIAS>2500) BIAS= 2500;
			ShwUsrParams();
			//			}
		}

		if (BtnActive(11, SetUpBtns, px, py)){
			// Decrement BIAS button was pressed
			//RptActvBtn(strdup("Dec BIAS"));
			loopcnt =0;
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			BIAS -= 10;
			if(BIAS<1500) BIAS= 1500;
			ShwUsrParams();
			//			}
		}

		if (BtnActive(12, SetUpBtns, px, py)){
			// Increment SQLCH button was pressed
			RptActvBtn(strdup("Inc SQLCH"));
			loopcnt =0;
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 10000;
			//				//ShwUsrParams();
			//			}
		}

		if (BtnActive(13, SetUpBtns, px, py)){
			// Decrement SQLCH button was pressed
			RptActvBtn(strdup("Dec SQLCH"));
			loopcnt =0;
			//			LEDLpcnt -=1;
			//			if(LEDLpcnt ==0){
			//				LEDLpcnt = 20000;
			//				//ShwUsrParams();
			//			}
		}

		if (BtnActive(14, SetUpBtns, px, py) && buttonEnabled){
			// SQLCH Mode button was pressed
			RptActvBtn(strdup("SQLCH Mode"));
			loopcnt =0;
			//			buttonEnabled = false;
			//			NoiseSqlch = !NoiseSqlch;
			//			if (NoiseSqlch) sprintf(BtnCaptn1, "NOISE SQLCH");
			//			else sprintf(BtnCaptn1, " MAN SQLCH");
			//			SetUpBtns[14].Captn = BtnCaptn1;
			//			BldBtn(14, SetUpBtns);
			//			//ShwUsrParams();

		}

		if (BtnActive(16, SetUpBtns, px, py) && buttonEnabled){
			// Debug Mode button was pressed
			RptActvBtn(strdup("DEBUG Mode"));
			buttonEnabled = false;
			DeBug +=1;
			if(DeBug ==3) DeBug = 0;
			SetDBgCptn(BtnCaptn);
			SetUpBtns[16].Captn = BtnCaptn;
			BldBtn(16, SetUpBtns);
			//ShwUsrParams();

		}

		if (BtnActive(15, SetUpBtns, px, py) && buttonEnabled){
			// Restore Defaults button was pressed
			RptActvBtn(strdup("DEFAULTS"));
			loopcnt =0;
			buttonEnabled = false;
			SetUpBtns[15].BtnClr = BLACK;
			BldBtn(15, SetUpBtns);
			LdFactryVals();
//			DimFctr = DFault.DimFctr;
//			TSF = DFault.TSF;
//			NSF = DFault.NSF;
//			BIAS = DFault.BIAS;
//			ManSqlch = DFault.ManSqlch;
//			NoiseSqlch = DFault.NoiseSqlch;
//			DeBug =	DFault.DeBug;
//			AutoTune = DFault.AutoTune;
//			TARGET_FREQUENCYC = DFault.TARGET_FREQUENCYC;
//			SAMPLING_RATE = DFault.SAMPLING_RATE;
			if (NoiseSqlch) sprintf(BtnCaptn1, "NOISE SQLCH");
			else sprintf(BtnCaptn1, " MAN SQLCH");
			SetUpBtns[14].Captn = BtnCaptn1;
			BldBtn(14, SetUpBtns);
			SetDBgCptn(BtnCaptn);
			SetUpBtns[16].Captn = BtnCaptn;
			BldBtn(16, SetUpBtns);
			if (AutoTune) sprintf(BtnCaptn2, " AUTO TUNE");
			else sprintf(BtnCaptn2, "FREQ LOCKED");
			SetUpBtns[17].Captn = BtnCaptn2;
			BldBtn(17, SetUpBtns);
			//ShwUsrParams();
			delay(150);
			SetUpBtns[15].BtnClr = GREEN;
			BldBtn(15, SetUpBtns);
		}

		if (BtnActive(17, SetUpBtns, px, py) && buttonEnabled){
			// SQLCH Mode button was pressed
			RptActvBtn(strdup("SQLCH Mode2"));
			loopcnt =0;
			buttonEnabled = false;
			AutoTune = !AutoTune;
			if (AutoTune) sprintf(BtnCaptn2, " AUTO TUNE");
			else sprintf(BtnCaptn2, "FREQ LOCKED");
			SetUpBtns[17].Captn = BtnCaptn2;
			BldBtn(17, SetUpBtns);
			py = 0;
			px = 0;
		}
		if (BtnActive(18, SetUpBtns, px, py) && buttonEnabled){
			// Debug Mode button was pressed
			RptActvBtn(strdup("PRGM Mode"));
			buttonEnabled = false;
			PrgmNdx +=1;
			if(PrgmNdx == 4) PrgmNdx = 0;
			SetPrgmCptn(BtnCaptn3);
			SetUpBtns[18].Captn = BtnCaptn3;
			BldBtn(18, SetUpBtns);
			//ShwUsrParams();

		}



		if (BtnActive(0, SetUpBtns, px, py) && buttonEnabled){
			RptActvBtn(strdup("EXIT"));
			loopcnt =0;
			buttonEnabled = false;
			tft.fillScreen(BLACK);
			if(PrgmNdx == 1 ){
				HAL_ADC_Stop_DMA(&hadc1);
				HAL_ADC_Stop(&hadc1);
				RunFFT_DEMO = true;
				MX_TIM2_Init();
				SetScrnActv = false;
				FFTLoop();
				SetScrnActv = true;
				PrgmNdx = 1;
			}else if(PrgmNdx == 2 ){
				HAL_ADC_Stop_DMA(&hadc1);
				HAL_ADC_Stop(&hadc1);
				SetScrnActv = false;
				ScopeLoop();
				SetScrnActv = true;
				PrgmNdx = 2;
			}else if(PrgmNdx == 3 ){
				HAL_ADC_Stop_DMA(&hadc1);
				HAL_ADC_Stop(&hadc1);
				SetScrnActv = false;
				LEDLoop();
				SetScrnActv = true;
				PrgmNdx = 3;
			}
			else if(PrgmNdx == 0 ){
				SetScrnActv = true;
				MX_TIM2_Init();
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buf, ADC_BUF_LEN);
				HAL_ADC_Start(&hadc1);
				SetPrgmCptn(BtnCaptn);
				setupflg = false;
			}
			if(PrgmNdx != 0) BldButtons();
		}

		if (BtnActive(1, SetUpBtns, px, py)&& buttonEnabled){
			buttonEnabled = false;
			RptActvBtn(strdup("SAVE"));
			loopcnt =0;
			// Save button was pressed. So store current User params to virtual EEPROM (STM flash memory)
			//Draw SaveBtn
			// make "SAVE" button "BLACK" to give a visual confirmation of button press
			SetUpBtns[1].BtnClr = BLACK;
			BldBtn(1, SetUpBtns);
			SaveUsrVals();
			delay(250);
			//ReDraw SaveBtn
			SetUpBtns[1].BtnClr = GREEN;
			BldBtn(1, SetUpBtns);
		}
//		loopcnt -=1;
//		if (loopcnt <= 0){
//			loopcnt = 10;
//			//int cursorX = 0;
//			//int cursorY = 2 * (fontH + 10);
//			//char StatMsg[40];
//
//			//sprintf( StatMsg, "   X: %d;    Y: %d; tp.z %d", (int)px, (int)py, (int)tp.z );
//			//ShwData(cursorX, cursorY, StatMsg);
//			//cursorY +=(fontH + 10);;
//			//sprintf( StatMsg, "tp.x: %d; tp.y: %d; tp.z %d",
//			//		(int)tp.x, (int)tp.y, (int)tp.z );
//			//ShwData(cursorX, cursorY, StatMsg);
//
//		}// end if(loopcnt == 0)
	}//End While Loop

	return;
}//end of SetUp Loop
//////////////////////////////////////////////////////////////////////////////////////////////////////
void PlotIfNeed2(void){
	if (TonPltFlg && NuMagData) {
		int PltGudSig = -20000;
		if(GudSig) PltGudSig = -10000;
		NuMagData = 0x0;
		char PlotTxt[70];
		//sprintf(PlotTxt, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", (int)magH, (int)magL, (int)magC, (int)AdjSqlch, (int)NoiseFlr, KeyState, (int)CurNoise, PltGudSig, (int)SigPk);
		sprintf(PlotTxt, "%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", (int)magH, (int)magL, (int)magC, (int)AdjSqlch, (int)NoiseFlr, KeyState, (int)CurNoise, ltrCmplt);
		//sprintf(PlotTxt, "%d\t%d\t%d\t%d\t%d\t%d", (int)(100*PhazAng), (int)magL, (int)magC, (int)SqlchLvl, KeyState, (int)CurNoise);
		USBprint(PlotTxt);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
void readResistiveTouch(void)
{
	if((PrgmNdx == 0)|| SetScrnActv){
		HAL_ADC_Stop_DMA(&hadc1);
		HAL_ADC_Stop(&hadc1);
	}

	if(FrstTime){
		FrstTime = !FrstTime;
		OLDhadc1 = hadc1;
		sConfig.Channel = ADC_CHANNEL_9;
		sConfig.Rank = 1;
		sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;
		OLDsConfig = sConfig;
	}
	//hadc1 = {0};
	tp = ts.getPoint();
	HAL_ADC_Stop(&hadc1);
	hadc1 = OLDhadc1;
	sConfig =OLDsConfig;
	if (HAL_ADC_Init(&hadc1) != HAL_OK)
	{
		Error_Handler();
	}
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}
	if((PrgmNdx == 0)|| SetScrnActv){
		HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buf, ADC_BUF_LEN);
		HAL_ADC_Start(&hadc1);
	}
	pinMode(YP, OUTPUT);      //restore shared pins
	pinMode(XM, OUTPUT);
	digitalWrite(YP, HIGH);  //because TFT control pins
	digitalWrite(XM, HIGH);

}
////////////////////////////////////////////////////////////////////////////////////////////////////////
void SetDBgCptn(char *textMsg){
	//char textMsg[15];
	switch(DeBug){
	case 0:
		TonPltFlg = false;
		Test = false;
		sprintf(textMsg, " DEBUG Off");
		break;
	case 1:
		Test = false;
		sprintf(textMsg, " DEBUG Plot");
		TonPltFlg = true;
		break;
	case 2:
		TonPltFlg = false;
		Test = true;
		sprintf(textMsg, "DEBUG Decode");
		break;
	default:
		sprintf(textMsg, "DB Val: %d", DeBug);
		break;

	}
}

///////////////////////////////////////////////////////////////////////////

void SetPrgmCptn(char *textMsg){

	switch(PrgmNdx){
	case 0:
		//TonPltFlg = false;
		//Test = false;
		sprintf(textMsg, " CW");
		break;
	case 1:
		//Test = false;
		sprintf(textMsg, " FFT");
		TonPltFlg = true;
		break;
	case 2:
		//TonPltFlg = false;
		//Test = true;
		sprintf(textMsg, "SCOPE");
		break;
	case 3:
			//TonPltFlg = false;
			//Test = true;
			sprintf(textMsg, " LED");
			break;
	default:
		sprintf(textMsg, "Ndx:%d", PrgmNdx);
		break;

	}
}

///////////////////////////////////////////////////////////////////////////
void RptActvBtn(char msg[]){
	char StatMsg[15];
	int cursorY = 20;
	int cursorX = 150;
	sprintf( StatMsg, "%s", msg);
	ShwData(cursorX, cursorY, StatMsg);
}
//////////////////////////////////////////////////////////////////////////

void ShwData(int MsgX, int MsgY, char* TxtMsg){
	//Serial.println(StatMsg);
	int msgpntr = 0;
	//int cnt = 0;
	//int offset = 0;
	tft.setTextColor(TFT_WHITE);
	tft.setCursor(MsgX, MsgY);
	while (TxtMsg[msgpntr] != 0) {
		tft.fillRect(MsgX, MsgY, fontW+4, (fontH + 10), BLACK);
		char curChar =TxtMsg[msgpntr];
		tft.print(curChar);
		msgpntr++;
		//cnt++;
		MsgX += (fontW);
		//        if (((cnt) - offset)*fontW >= displayW) {
		//          curRow++;
		//          MsgX = 0;
		//          MsgY = curRow * (fontH + 10);
		//          offset = cnt;
		//          tft.setCursor(MsgX, MsgY);
		//        }
		//        else MsgX = (cnt - offset) * fontW;
		tft.setCursor(MsgX, MsgY);
		PlotIfNeed2();
	}
	/* Black Out remaining character positions */
	while (msgpntr<39) {
		tft.fillRect(MsgX, MsgY, fontW+4, (fontH + 10), BLACK);
		msgpntr++;
		//cnt++;
		//MsgX = (cnt - offset) * fontW;
		MsgX += (fontW);
		PlotIfNeed2();
	}

}

//////////////////////////////////////////////////////////////////////////
void BldBtn(int BtnNo, BtnParams Btns[]){ //, const char* Captn, unsigned int BtnClr, unsigned int TxtClr){
	tft.fillRect(Btns[BtnNo].BtnXpos, Btns[BtnNo].BtnYpos, Btns[BtnNo].BtnWdth, Btns[BtnNo].BtnHght, Btns[BtnNo].BtnClr);
	tft.drawRect(Btns[BtnNo].BtnXpos, Btns[BtnNo].BtnYpos, Btns[BtnNo].BtnWdth, Btns[BtnNo].BtnHght, WHITE);
	tft.setCursor(Btns[BtnNo].BtnXpos + 11, Btns[BtnNo].BtnYpos + 12);
	tft.setTextColor(Btns[BtnNo].TxtClr);
	tft.setTextSize(2);
	tft.print(Btns[BtnNo].Captn);

}
///////////////////////////////////////////////////////////////////////////
bool BtnActive(int BtnNo, BtnParams Btns[], int px, int py){
	bool actv = false;
	if ((px > Btns[BtnNo].BtnXpos && px < Btns[BtnNo].BtnXpos+Btns[BtnNo].BtnWdth) && (py > Btns[BtnNo].BtnYpos && py < Btns[BtnNo].BtnYpos+Btns[BtnNo].BtnHght)) actv = true;
	return actv;
}
///////////////////////////////////////////////////////////////////////////
void enableDisplay(void) {
	//This is important, because the libraries are sharing pins
	pinMode(XM, OUTPUT);
	pinMode(YP, OUTPUT);
}
///////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void ShwUsrParams(void)
{
  int ToneCfreq = int(TARGET_FREQUENCYC);
  int ToneDeci = int(10*(TARGET_FREQUENCYC-ToneCfreq));
  int DimFctrInt = int(DimFctr);
  int DimFctrDeci = int(100*(DimFctr-DimFctrInt));
  char StatMsg[40];
  //Serial.print("TARGET_FREQUENCYC: "); Serial.println(TARGET_FREQUENCYC);
  //sprintf( Title, "Current Center Freq: %d.%d Hz", ToneCfreq, ToneDeci );
  sprintf( StatMsg, "Center Freq: %d.%d Hz; LEDBright:%d.%d", ToneCfreq, ToneDeci, DimFctrInt, DimFctrDeci );
  //tft.setCursor(textSrtX, textSrtY);
  //ShwData(textSrtX, textSrtY, StatMsg)
  int cursorX = 0;
  int cursorY = 0;
  //tft.fillRect(cursorX, cursorY, scrnWidth, (1 * (fontH + 10)), BLACK); //erase top 2 rows
  ShwData(cursorX, cursorY, StatMsg);

  cursorX = 0;
  cursorY = 1 * (fontH + 10);
  int TSFintval = (int)TSF;
  int TSFfract = 100*(TSF-TSFintval);
  int NSFintval = (int)NSF;
  int NSFfract = 100*(NSF-NSFintval);
  sprintf( StatMsg, "TSF:%d.%d; BIAS:%d; MSQL:%d; NSF:%d.%d; ", TSFintval, TSFfract, BIAS, ManSqlch, NSFintval, NSFfract);
  ShwData(cursorX, cursorY, StatMsg);
  cursorY += 1 * (fontH + 10);
  sprintf( StatMsg, "SAMPLING_RATE:%d; ToneSig:%d",(int)SAMPLING_RATE, TonSig);
  ShwData(cursorX, cursorY, StatMsg);
  cursorY += 1 * (fontH + 10);
    sprintf( StatMsg, "lastDit1:%d",(int)lastDit1 );
    ShwData(cursorX, cursorY, StatMsg);
  return;
}
//////////////////////////////////////////////////////////////////////////
void LdFactryVals(void){
	DimFctr = DFault.DimFctr;
	TSF = DFault.TSF;
	NSF = DFault.NSF;
	BIAS = DFault.BIAS;
	ManSqlch = DFault.ManSqlch;
	NoiseSqlch = DFault.NoiseSqlch;
	DeBug =	DFault.DeBug;
	AutoTune = DFault.AutoTune;
	TARGET_FREQUENCYC = DFault.TARGET_FREQUENCYC;
	SAMPLING_RATE = DFault.SAMPLING_RATE;
}
//////////////////////////////////////////////////////////////////////////
void SaveUsrVals(void){
	/* Unlock the Flash Program Erase controller */
	FLASH_Unlock();

	/* EEPROM Init */
	uint16_t reslt = EE_Init();
	if (reslt != fLASH_COMPLETE){
		char buf[150];
		sprintf(buf, "EE_Init() ERROR: %d", reslt);
		USBprintln(buf);
		while(1);
	}

	int n= EEPROM_write(EEaddress+0, DimFctr);
	n= EEPROM_write(EEaddress+4, TSF);
	n= EEPROM_write(EEaddress+8, NSF);
	n= EEPROM_write(EEaddress+12, BIAS);
	n= EEPROM_write(EEaddress+16, ManSqlch);
	n= EEPROM_write(EEaddress+20, NoiseSqlch);
	n= EEPROM_write(EEaddress+22, DeBug);
	n= EEPROM_write(EEaddress+26, AutoTune);
	n= EEPROM_write(EEaddress+28, TARGET_FREQUENCYC);
	n= EEPROM_write(EEaddress+32, SAMPLING_RATE);
	FLASH_Lock();
}

