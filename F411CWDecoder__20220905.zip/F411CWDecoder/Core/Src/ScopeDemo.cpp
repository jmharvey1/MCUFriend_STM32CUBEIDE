/*
 * ScopeDemo.cpp
 *
 *  Created on: Feb 19, 2021
 *      Author: jim
 */

/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "SetUpCwDecoder.h"
#include "BtnSuprt.h"
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include "MCUFRIEND_kbv.h"
#include "Adafruit_GFX.h"
#include "STM32F411def.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include <stdbool.h>
#include "TouchScreen_kbv.h"
#include "Arduino.h"
#include "UTFTGLUE.h"
//#define PORTRAIT  1
//#define LANDSCAPE 0
//#define TOUCH_ORIENTATION  PORTRAIT
//#define ARSIZE 4
//#define WHITE 0xFFFF
//#define RED   0xF800
//#define GRAY  0x8410
//#define BLACK 0x0000
//#define TITLE "BLACK PILL TouchScreen Calibration - 20210215"
//#define MAPLEMINI 0
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//################################################
// GLUE class that implements the UTFT API
// replace UTFT include and constructor statements
// remove UTFT font declaration e.g. SmallFont
//################################################

            //use GLUE class and constructor
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB8|PB9|

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

//TIM_HandleTypeDef htim2;
//TIM_HandleTypeDef htim3;

//PCD_HandleTypeDef hpcd_USB_OTG_FS;
float AvgBias =0;
//int captrBuf[480];
int OldBuf[480];
uint8_t ScopeSpace[479][291]; // width & Height
//uint16_t ID;
//int toggle = 0;

float sx = 0, sy = 1, mx = 1, my = 0, hx = -1, hy = 0;    // Saved H, M, S x & y multipliers
float sdeg=0, mdeg=0, hdeg=0;
uint16_t osx=120, osy=120, omx=120, omy=120, ohx=120, ohy=120;  // Saved H, M, S x & y coords
uint16_t x00=0, x11=0, y00=0, y11=0;
//boolean initial = 1;
//char Bufr[14];

static uint8_t conv2d(const char* p) {
  uint8_t v = 0;
  if ('0' <= *p && *p <= '9')
    v = *p - '0';
  return 10 * v + *++p - '0';
}

//uint8_t hh=conv2d(__TIME__), mm=conv2d(__TIME__+3), ss=conv2d(__TIME__+6);  // Get H, M, S from compile time

//unsigned long millisval = 0;
//unsigned long Secruntime =0;
//unsigned long LastRanNum =0;
/* Private variables END---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
//void SystemClock_Config(void);
//static void MX_GPIO_Init(void);
//static void MX_DMA_Init(void);
//static void MX_USB_OTG_FS_PCD_Init(void);
//static void MX_TIM2_Init(void);
//static void MX_TIM3_Init(void);
///////////////////////////////
//void USBprintln(const char *msg);
//void USBprint(const char *msg);
//void USBprintStr(String *msg);
//void USBprintInt(int val);
//void delay_us (uint16_t us);
//void delay(int Millis);
//int random(int max);
//unsigned long millis(void);
void disMsgScp(char Msgbuf[32], int cursorX, int cursorY, int FontSz);
int MicSig(int curPin);
//uint16_t setrgb(byte r, byte g, byte b);
void SndDispl(void);
//void BldScopDispl(void);
//void ClrScpSpace(void);
//void FrameScpSpc(void);
//void MkXhairs(void);
void MapTrace(void);
//MCUFRIEND_kbv tft;
//UTFTGLUE myGLCD(0,0,0,0,0,0); //all dummy args
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
void ScopeLoop(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
//	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
//	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
//	MX_GPIO_Init();
//	MX_USB_OTG_FS_PCD_Init();
//	MX_TIM2_Init();
//	MX_TIM3_Init();
	/* USER CODE BEGIN 2 */
//	HAL_TIM_Base_Start_IT(&htim2);
//	HAL_TIM_Base_Start(&htim3);
	/*###########################################################################*/
	//                       Begin Arduino SetUp Code

	myGLCD.InitLCD();
	myGLCD.setFont(SmallFont);
	// Clear the screen and draw the frame
	myGLCD.clrScr();

	myGLCD.setColor(255, 0, 0);
	myGLCD.fillRect(0, 0, 479, 13);
	myGLCD.setColor(64, 64, 64);
	myGLCD.fillRect(0, 306, 479, 319);
	myGLCD.setColor(255, 255, 255);
	myGLCD.setBackColor(255, 0, 0);
	myGLCD.print("* My Scope Demo *", CENTER, 1);
	myGLCD.setBackColor(64, 64, 64);
	myGLCD.setColor(255,255,0);
	myGLCD.print("Rev Date: 08/30/2021", CENTER, 307);
	myGLCD.setColor(0, 0, 0);
	myGLCD.fillRect(0, 14, 479, 305);
	myGLCD.setColor(0, 0, 255);
	myGLCD.drawRect(0, 14, 479, 305);

	// Draw crosshairs
	myGLCD.setColor(0, 0, 255);
	myGLCD.setBackColor(0, 0, 0);
	myGLCD.drawLine(239, 15, 239, 304);
	myGLCD.drawLine(1, 159, 478, 159);
	for (int i=9; i<470; i+=10)
		myGLCD.drawLine(i, 157, i, 161);
	for (int i=19; i<220; i+=10)
		myGLCD.drawLine(237, i, 241, i);

	/*                         End Arduino SetUp Code                               */
	/*###########################################################################*/


	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	int curPin = PB1; //Mic Board Analog output connection point
	int k = 0;
    bool ScpAbort = false;
	while (!ScpAbort)
	{
		/* USER CODE END WHILE */
		int buf[478];
		int x, x2;
		int y, y2;
		int r;

		//      Black out the Scope Display Space
		myGLCD.setColor(0, 0, 0); //Black
		for (int i=1; i<478; i++)
		{
			myGLCD.drawPixel(i,(159-OldBuf[i]));

		}
		myGLCD.fillRect(5, 15, 33, 25);// erase last avgbias report
		//myGLCD.fillRect(0, 14, 479, 305);
		// Place a Border Around the Scope Display Space
		myGLCD.setColor(0, 0, 255);// Set the color of the border
		myGLCD.drawRect(0, 14, 479, 305);

		// Draw crosshairs
		//		myGLCD.setColor(0, 0, 255);
		myGLCD.setBackColor(0, 0, 0);
		myGLCD.drawLine(239, 15, 239, 304);
		myGLCD.drawLine(1, 159, 478, 159);
		for (int i=9; i<470; i+=10)
			myGLCD.drawLine(i, 157, i, 161);
		for (int i=19; i<220; i+=10)
			myGLCD.drawLine(237, i, 241, i);

		myGLCD.setColor(0,255,255);// set the color to the Scope trace
		//      Post to scope space the current Bias value
		char biasbuf[15];
		sprintf(biasbuf, "%d", (int)AvgBias);
		myGLCD.print(biasbuf, 5, 15);

		// Plot Data Trace
		for (int i=1; i<478; i++)
		{
			myGLCD.drawPixel(i,(159-captrBuf[i]));
		}
		//save this trace for next screen refresh (erase)
		for (int i=1; i<478; i++)
		{
			OldBuf[i] =captrBuf[i];
		}

		delay(50);
		while(MicSig(curPin)< 200 && !ScpAbort){
			readResistiveTouch();
			if (tp.z > 150) { // if (tp.z > MINPRESSURE && tp.z < MAXPRESSURE) { //
				//use the following for Screen orientation set to 1
				py = map(tp.y, TS_TOP, TS_BOT, 0, scrnHeight);
				px = map(tp.x, TS_LEFT, TS_RT, 0, scrnWidth);
				PrgmNdx = 4;
				ScpAbort = true;
				/* Un-comment diagnostic test/verification of screen touch coordinates */
				//		sprintf( textMsg, "px: %d", px);
				//		ShwData(5, 30, textMsg);
				//		sprintf( textMsg, "py: %d", py);
				//		ShwData(5, 55, textMsg);
				//		delay(200);

			}else{
				py=-10;
				px=-10;
			}
		}
		for (int i=1; i<478; i++)
		{
			int ScldSig = (MicSig(curPin))/10;
			//Make sure we don't print outside the scope display space
			if(ScldSig > 145) ScldSig= 145;//if(159 - ScldSig < 14) ScldSig= 145;
			if(ScldSig < -146) ScldSig=-146;//if(159 - ScldSig > 305) ScldSig=-146;
			captrBuf[i] = ScldSig;
		}

	}
}
////////////////////////////////////////////////////////////////////////////////////////////////
//void BldScopDispl(void){
//	ClrScpSpace();
//}
////////////////////////////////////////////////////////////////////////////////////////////////
void SndDispl(void){
  uint8_t _MW = 0b101100;
  int w=479, h=291, x=0, y=14;
  int end;
  tft.setAddrWindow(x, y, x + w - 1, y + h - 1);
	CS_ACTIVE;
	WriteCmd(_MW);
	if (h > w) {
		end = h;
		h = w;
		w = end;
	}

	while (h-- > 0) {
		end = w;
		do {
			uint16_t color = ScopeSpace[end][h];
			uint8_t hi = color >> 8, lo = color & 0xFF;
			write8(hi);
			write8(lo);
		} while (--end != 0);
	}
	CS_IDLE;

}
////////////////////////////////////////////////////////////////////////////////////////////////
void MapTrace(void)
{
	uint8_t TrcClr = 2; //setrgb(0x0, 0xFF, 0xFF); //trace color
	//for (int i=1; i<sizeof(captrBuf); i++)
	for (int i=1; i < 480; i++)
	{
		//myGLCD.drawPixel(i,(159-captrBuf[i]));
		ScopeSpace[i][(159-captrBuf[i])] = TrcClr;
	}

}
////////////////////////////////////////////////////////////////////////////////////////////////
//void MkXhairs(void)
//{
//	uint8_t BdrClr = 1; //setrgb(0x0, 0x0, 0xFF); //blue
//	for(int i =0; i<479; i++){
//		ScopeSpace[i][145] = BdrClr;
//	}
//	for(int i =0; i<291; i++){
//		ScopeSpace[239][i] = BdrClr;
//	}
//	for (int i=9; i<470; i+=10){
//		//myGLCD.drawLine(i, 157, i, 161);
//		for(int j =157; i<=161; j++){
//			ScopeSpace[i][j] = BdrClr;
//		}
//	}
//	for (int i=19; i<220; i+=10){
//		myGLCD.drawLine(237, i, 241, i);
//		for(int j =237; i<=241; j++){
//			ScopeSpace[j][i] = BdrClr;
//		}
//	}
//
//}
////////////////////////////////////////////////////////////////////////////////////////////////
//void FrameScpSpc(void){
//	uint8_t BdrClr = 1; //setrgb(0x0, 0x0, 0xFF); //blue
//	for(int i =0; i<479; i++){
//		ScopeSpace[i][0] = BdrClr;
//		ScopeSpace[i][290] = BdrClr;
//	}
//	for(int i =0; i<291; i++){
//		ScopeSpace[0][i] = BdrClr;
//		ScopeSpace[478][i] = BdrClr;
//	}
//}
////////////////////////////////////////////////////////////////////////////////////////////////
//void ClrScpSpace(void)
//{
//	for(int i =0; i<479; i++){
//		for(int j =0; i<291; j++){
//			ScopeSpace[i][j] = (uint16_t)0;
//		}
//	}
//}
/////////////////////////////////////////////////////////////////////////////////////////////////
//uint16_t setrgb(byte r, byte g, byte b)
//{
//	return ((r&0xF8) << 8) | ((g&0xFC) << 3) | (b>>3);
//}
/////////////////////////////////////////////////////////////////////////////////////////////////
int MicSig(int curPin)
{
	delay_us (15);
	int k = analogRead(curPin);
	AvgBias = ((999*AvgBias)+((float)k))/1000.0;
	return (k - (int)AvgBias);
}
  //////////////////////////////////////////////////////////////////////
  //20210206 JMH Added "delay_us" function to provide a us delay via STM32CubeIDE platform
//  void delay_us (uint16_t us)
//  {
//  	__HAL_TIM_SET_COUNTER(&htim3,0);  // set the counter value a 0
//  	while (__HAL_TIM_GET_COUNTER(&htim3) < us);  // wait for the counter to reach the us input in the parameter
//  }

  //////////////////////////////////////////////////////////////////////
//  void delay(int Millis){
//  	while(Millis>0){
//  		delay_us(1000);
//  		--Millis;
//  	}
//  }
  //////////////////////////////////////////////////////////////////////
//  int random(int max){
//  	int Frctn =0;
//  	unsigned long curCnt = (3*LastRanNum)+ millis();
//  	unsigned long Multpl = curCnt/max;
//  	Frctn = (curCnt-(max*Multpl));
//  	LastRanNum = Frctn;
//  	return Frctn;
//  }

//  //////////////////////////////////////////////////////////////////////
//  unsigned long millis(void){
//  	millisval = (__HAL_TIM_GET_COUNTER(&htim2))/10;
//  	millisval += 1000*Secruntime;
//  	return millisval;
//  }
  /////////////////////////////////////////////////////////////////////
//  void USBprintInt( int val){
//  	char buf[15];
//  	sprintf(buf, "%d", val);
//  	USBprint(buf);
//  }
  /////////////////////////////////////////////////////////////////////
//  void USBprintStr(String *msg){
//  	char buf[150];
//  	sprintf(buf, "%s", msg);
//  	USBprint(buf);
//  }
  /////////////////////////////////////////////////////////////////////
//  void USBprintln(const char *msg)
//  {
//  	  char buf[150];
//  	  sprintf(buf, "%s\n\r", msg);
//  	  USBprint(buf);
//  }
//  void USBprint(const char *msg)
//  {
//  	  char buf[150];
//  	  uint8_t Buffer[150];
//  	  sprintf(buf, "%s", msg);
//  	  int i = 0;
//  	  for(i = 0; i<=sizeof(buf); i++ ){
//  		  Buffer[i] = (uint8_t)buf[i];
//  		  if(buf[i] ==0) break;
//  	  }
//  	  CDC_Transmit_FS(Buffer, i);
//  	  delay_us(1000);
//  //  USBprintln(buf);
//  }

  /////////////////////////////////////////////////////////////////////
  void disMsgScp(char Msgbuf[32], int cursorX, int cursorY, int FontSz) {
    int msgpntr = 0;
    int curRow = 0;
    int offset =0;
    int fontH = 16;
    int fontW = 18;//12;
    int displayW = 320;
    int cnt = 0;
    while (Msgbuf[msgpntr] != 0) ++msgpntr;

    //clear previous entry
    tft.fillRect(cursorX , (cursorY), msgpntr * fontW, fontH + 10, TFT_LIGHTGREY);
    tft.setCursor(cursorX, cursorY);
    tft.setTextColor(TFT_BLACK);//tft.setTextColor(WHITE, BLACK);
    tft.setTextSize(FontSz);
    msgpntr = 0;
    while ( Msgbuf[msgpntr] != 0) {
      char curChar = Msgbuf[msgpntr];
      tft.print(curChar);
      msgpntr++;
      cnt++;
      if (((cnt) - offset)*fontW >= displayW) {
        curRow++;
        cursorX = 0;
        cursorY = curRow * (fontH + 10);
        offset = cnt;
        tft.setCursor(cursorX, cursorY);
  //      if (curRow + 1 > row) {
  //        scrollpg();
  //      }
      }
      else cursorX = (cnt - offset) * fontW;
    }
  }
  //////////////////////////////////////////////////////////////////////


  /**
    * @brief System Clock Configuration
    * @retval None
    */
//  void SystemClock_Config(void)
//  {
//    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
//    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
//    RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};
//
//    /** Configure the main internal regulator output voltage
//    */
//    __HAL_RCC_PWR_CLK_ENABLE();
//    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
//    /** Initializes the RCC Oscillators according to the specified parameters
//    * in the RCC_OscInitTypeDef structure.
//    */
//    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
//    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
//    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
//    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
//    RCC_OscInitStruct.PLL.PLLM = 25;
//    RCC_OscInitStruct.PLL.PLLN = 192;
//    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
//    RCC_OscInitStruct.PLL.PLLQ = 4;
//    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    /** Initializes the CPU, AHB and APB buses clocks
//    */
//    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
//                                |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
//    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
//    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
//    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
//    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
//
//    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
//    PeriphClkInitStruct.PLLI2S.PLLI2SN = 96;
//    PeriphClkInitStruct.PLLI2S.PLLI2SM = 12;
//    PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
//    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
//    {
//      Error_Handler();
//    }
//  }

  /**
    * @brief I2S2 Initialization Function
    * @param None
    * @retval None
    */


  /**
    * @brief TIM2 Initialization Function
    * @param None
    * @retval None
    */
//  static void MX_TIM2_Init(void)
//  {
//
//    /* USER CODE BEGIN TIM2_Init 0 */
//
//    /* USER CODE END TIM2_Init 0 */
//
//    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
//    TIM_MasterConfigTypeDef sMasterConfig = {0};
//
//    /* USER CODE BEGIN TIM2_Init 1 */
//
//    /* USER CODE END TIM2_Init 1 */
//    htim2.Instance = TIM2;
//    htim2.Init.Prescaler = 9600-1;
//    htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
//    htim2.Init.Period = 10000;
//    htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
//    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
//    if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
//    if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
//    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
//    if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    /* USER CODE BEGIN TIM2_Init 2 */
//
//    /* USER CODE END TIM2_Init 2 */
//
//  }

  /**
    * @brief TIM3 Initialization Function
    * @param None
    * @retval None
    */
//  static void MX_TIM3_Init(void)
//  {
//
//    /* USER CODE BEGIN TIM3_Init 0 */
//
//    /* USER CODE END TIM3_Init 0 */
//
//    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
//    TIM_MasterConfigTypeDef sMasterConfig = {0};
//
//    /* USER CODE BEGIN TIM3_Init 1 */
//
//    /* USER CODE END TIM3_Init 1 */
//    htim3.Instance = TIM3;
//    htim3.Init.Prescaler = 96-1;
//    htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
//    htim3.Init.Period = 65535;
//    htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
//    htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
//    if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
//    if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
//    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
//    if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    /* USER CODE BEGIN TIM3_Init 2 */
//
//    /* USER CODE END TIM3_Init 2 */
//
//  }

  /**
    * @brief USB_OTG_FS Initialization Function
    * @param None
    * @retval None
    */
//  static void MX_USB_OTG_FS_PCD_Init(void)
//  {
//
//    /* USER CODE BEGIN USB_OTG_FS_Init 0 */
//
//    /* USER CODE END USB_OTG_FS_Init 0 */
//
//    /* USER CODE BEGIN USB_OTG_FS_Init 1 */
//
//    /* USER CODE END USB_OTG_FS_Init 1 */
//    hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
//    hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
//    hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
//    hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
//    hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
//    hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
//    if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
//    {
//      Error_Handler();
//    }
//    /* USER CODE BEGIN USB_OTG_FS_Init 2 */
//
//    /* USER CODE END USB_OTG_FS_Init 2 */
//
//  }

  /**
    * Enable DMA controller clock
    */
//  static void MX_DMA_Init(void)
//  {
//
//    /* DMA controller clock enable */
//    __HAL_RCC_DMA1_CLK_ENABLE();
//
//    /* DMA interrupt init */
//    /* DMA1_Stream3_IRQn interrupt configuration */
//    HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 0);
//    HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
//    /* DMA1_Stream4_IRQn interrupt configuration */
//    HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
//    HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
//
//  }

  /**
    * @brief GPIO Initialization Function
    * @param None
    * @retval None
    */
//  static void MX_GPIO_Init(void)
//  {
//  	GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//  	/* GPIO Ports Clock Enable */
//  	__HAL_RCC_GPIOC_CLK_ENABLE();
//  	__HAL_RCC_GPIOH_CLK_ENABLE();
//  	__HAL_RCC_GPIOA_CLK_ENABLE();
//  	__HAL_RCC_GPIOB_CLK_ENABLE();
//
//  	/*Configure GPIO pin Output Level */
//  	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
//
//  	/*Configure GPIO pin Output Level */
//  	HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
//  			|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin, GPIO_PIN_RESET);
//
//  	/*Configure GPIO pin Output Level */
//  	HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin
//  			|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);
//
//  	/*Configure GPIO pin : LED_Pin */
//  	GPIO_InitStruct.Pin = LED_Pin;
//  	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//  	GPIO_InitStruct.Pull = GPIO_NOPULL;
//  	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//  	HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);
//
//  	/*Configure GPIO pins : LCD_D0_Pin LCD_D1_Pin LCD_D2_Pin LCD_D4_Pin
//                             LCD_D5_Pin LCD_D6_Pin LCD_D7_Pin */
//  //	GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
//  //			|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin;
//  //	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//  //	GPIO_InitStruct.Pull = GPIO_NOPULL;
//  //	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//  //	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
//
//  	/*Configure GPIO pins : LCD_D3_Pin LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin
//                             LCD_CS_Pin LCD_RST_Pin */
//  	GPIO_InitStruct.Pin = LCD_D3_Pin|LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin
//  			|LCD_CS_Pin|LCD_RST_Pin;
//  	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//  	GPIO_InitStruct.Pull = GPIO_NOPULL;
//  	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//  	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
//  }

  /* USER CODE BEGIN 4 */
//  void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
//  	//HAL_GPIO_TogglePin(,);
//  	toggle ^= 1;
//  	Secruntime++;
//  	//digitalWrite(LED_BUILTIN, toggle);//Arduino call syntax
//  	if(toggle) PIN_HIGH(LED_GPIO_Port, LED_Pin);
//  	else PIN_LOW(LED_GPIO_Port, LED_Pin);
//  }
  /* USER CODE END 4 */

  /**
    * @brief  This function is executed in case of error occurrence.
    * @retval None
    */
//  void Error_Handler(void)
//  {
//    /* USER CODE BEGIN Error_Handler_Debug */
//    /* User can add his own implementation to report the HAL error return state */
//    __disable_irq();
//    while (1)
//    {
//    }
//    /* USER CODE END Error_Handler_Debug */
//  }
//
//  #ifdef  USE_FULL_ASSERT
//  /**
//    * @brief  Reports the name of the source file and the source line number
//    *         where the assert_param error has occurred.
//    * @param  file: pointer to the source file name
//    * @param  line: assert_param error line source number
//    * @retval None
//    */
//  void assert_failed(uint8_t *file, uint32_t line)
//  {
//    /* USER CODE BEGIN 6 */
//    /* User can add his own implementation to report the file name and line number,
//       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
//    /* USER CODE END 6 */
//  }
//  #endif /* USE_FULL_ASSERT */
//
  /************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/







