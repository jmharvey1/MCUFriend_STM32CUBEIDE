/* JMH 20210917 copied from Github Repository Nucleo_F446RE_USBhost/Lauszus */
#include "SerialClass.h"
#include "usbd_cdc_if.h" //JMH added to support Black Pill's on-board USB connector
#include "usb_device.h"  //JMH added to support Black Pill's on-board USB connector
#include "KeyBoardR01.h"  //JMH added to support Black Pill's on-board USB connector & arduino "delay()" function
#include "TouchScreen_kbv.h"
#include "UTFTGLUE.h"
#include "Arduino.h"

//#define TFTOUTPUT
size_t SerialClass::write(uint8_t data) {
	return write(&data, 1);
}

size_t SerialClass::write(const uint8_t *buffer, size_t size) {
	/* rewrote this to be compatible with blackpill's (stm32F411) USB serial process */
	uint8_t *pBuffer = (uint8_t*)buffer;
#ifdef TFTOUTPUT
	char Buffer[50]; //JMH added/changed to print to tft display
	int i = 0;
	int offset =0;
	if(size>48) size = 49;
	for(i = 0; i<size; i++ ){
		if(buffer[i]!=13)Buffer[i-offset] = (char)buffer[i];
		else offset++;
		if(buffer[i] ==0) break;
	}
	if(i-offset == 0) return 0;
	Buffer[i-offset] = 0;
	dispMsg(Buffer, TFT_WHITE);
	return i;

	/////////////////////////////////////////////////////////////////////////////
#else
	/*	    JMH: use this for native Black Pill USB serial                */
	uint8_t Buffer[150];
	int i = 0;
	for(i = 0; i<size; i++ ){
		Buffer[i] = (uint8_t)buffer[i];
		if(buffer[i] ==0) break;
	}
	int BsyCntr = 0;
	uint8_t USBstat = USBD_BUSY;
	while(USBstat != USBD_OK){
		USBstat = CDC_Transmit_FS(pBuffer, i);

		BsyCntr++;
		if(BsyCntr >1000) break;
	}
	delay(2);
	/* JMH: Set to "1" for testing debug to TT display */
	if(0){ /*Set to "1" when debugging USB serial print*/
		switch (USBstat){
		case USBD_BUSY:
			//sprintf(buf, "#USB BUSY# - %s", buffer);
			//dispMsg(buf);
			break;
		case USBD_FAIL:
			//sprintf(buf, "#USB FAIL# - %s", msg);
			//dispMsg(buf);
			break;
		}
	}
	//if(tstState) Test = true;
	return i;
	//HAL_UART_Transmit(pUART_Handle, pBuffer, size, HAL_MAX_DELAY);
	//return size;
#endif
}

int SerialClass::read() {
	uint8_t data;
	/*JMH commented out to compile with STMCUBEIDE */
//	HAL_UART_Receive(pUART_Handle, &data, 1, HAL_MAX_DELAY);
	return data;
}

int SerialClass::available() {
	return -1;
}

int SerialClass::peek() {
	return -1;
}

void SerialClass::flush() {
}
