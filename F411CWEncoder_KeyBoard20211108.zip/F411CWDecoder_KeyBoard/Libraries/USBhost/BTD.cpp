/* Copyright (C) 2012 Kristian Lauszus, TKJ Electronics. All rights reserved.

 This software may be distributed and modified under the terms of the GNU
 General Public License version 2 (GPL2) as published by the Free Software
 Foundation and appearing in the file GPL2.TXT included in the packaging of
 this file. Please note that GPL2 Section 2[b] requires that all works based
 on this software must also be made publicly available under the terms of
 the GPL2 ("Copyleft").

 Contact information
 -------------------

 Kristian Lauszus, TKJ Electronics
 Web      :  http://www.tkjelectronics.com
 e-mail   :  kristianl@tkjelectronics.com
 */

#include "BTD.h"
#include "Arduino.h"
#include "BTcodes.h"
// To enable serial debugging see "settings.h"
//#define EXTRADEBUG // Uncomment to get even more debugging data
//#define EXTRADEBUG1 // Uncomment to get even more debugging data
//#define SHOWEVENTSEQNC
const uint8_t BTD::BTD_CONTROL_PIPE = 0;
const uint8_t BTD::BTD_EVENT_PIPE = 1;
const uint8_t BTD::BTD_DATAIN_PIPE = 2;
const uint8_t BTD::BTD_DATAOUT_PIPE = 3;
uint8_t *ProdPtr; //JMH added
//bool EIRflg = false;

BTD::BTD(USB *p) :
connectToWii(false),
pairWithWii(false),
connectToHIDDevice(false),
pairWithHIDDevice(false),
useSimplePairing(false),
sendKey(false), //JMH added
done(false), //JMH added
paired(false), //JMH added
pUsb(p), // Pointer to USB class instance - mandatory
bAddress(0), // Device address - mandatory
LastEvent(0), //JMH added
hci_status(0), //JMH added
hci_lastEvnt(0), //JMH added
rmsfcCnt(0), //JMH added
bNumEP(1), // If config descriptor needs to be parsed
qNextPollTime(0), // Reset NextPollTime
pollInterval(0),
simple_pairing_supported(false),
bPollEnable(false), // Don't start polling before dongle is connected
StrtDeBug(false), //JMH Added
DevcFnd(false)  //JMH Added
 {
        for(uint8_t i = 0; i < BTD_NUM_SERVICES; i++)
                btService[i] = NULL;

        Initialize(); // Set all variables, endpoint structs etc. to default values

        if(pUsb) // Register in USB subsystem
                pUsb->RegisterDeviceClass(this); // Set devConfig[] entry
}

uint8_t BTD::ConfigureDevice(uint8_t parent, uint8_t port, bool lowspeed) {
        const uint8_t constBufSize = sizeof (USB_DEVICE_DESCRIPTOR);
        uint8_t buf[constBufSize];
        USB_DEVICE_DESCRIPTOR * udd = reinterpret_cast<USB_DEVICE_DESCRIPTOR*>(buf);
        uint8_t rcode;
        UsbDevice *p = NULL;
        EpInfo *oldep_ptr = NULL;

        Initialize(); // Set all variables, endpoint structs etc. to default values

        AddressPool &addrPool = pUsb->GetAddressPool(); // Get memory address of USB device address pool
        hci_status = 1;
        #ifdef EXTRADEBUG
        Notify(PSTR("\r\nBTD ConfigureDevice"), 0x80);
#endif

        if(bAddress) { // Check if address has already been assigned to an instance
        	 hci_status = 2;
        	#ifdef EXTRADEBUG
                Notify(PSTR("\r\nAddress in use"), 0x80);
#endif
                return USB_ERROR_CLASS_INSTANCE_ALREADY_IN_USE;
        }

        p = addrPool.GetUsbDevicePtr(0); // Get pointer to pseudo device with address 0 assigned
        if(!p) {
        	hci_status = 3;
#ifdef EXTRADEBUG
                Notify(PSTR("\r\nAddress not found"), 0x80);
#endif
                return USB_ERROR_ADDRESS_NOT_FOUND_IN_POOL;
        }

        if(!p->epinfo) {
        	hci_status = 4;
#ifdef EXTRADEBUG
                Notify(PSTR("\r\nepinfo is null"), 0x80);
#endif
                return USB_ERROR_EPINFO_IS_NULL;
        }

        oldep_ptr = p->epinfo; // Save old pointer to EP_RECORD of address 0
        p->epinfo = epInfo; // Temporary assign new pointer to epInfo to p->epinfo in order to avoid toggle inconsistence
        p->lowspeed = lowspeed;
        rcode = pUsb->getDevDescr(0, 0, constBufSize, (uint8_t*)buf); // Get device descriptor - addr, ep, nbytes, data

        p->epinfo = oldep_ptr; // Restore p->epinfo

        if(rcode)
                goto FailGetDevDescr;

        bAddress = addrPool.AllocAddress(parent, false, port); // Allocate new address according to device class

        if(!bAddress) {
        	hci_status = 5;
#ifdef EXTRADEBUG
                Notify(PSTR("\r\nOut of address space"), 0x80);
#endif
                return USB_ERROR_OUT_OF_ADDRESS_SPACE_IN_POOL;
        }

        if (udd->bDeviceClass == 0x09) // Some dongles have an USB hub inside
                goto FailHub;

        epInfo[0].maxPktSize = udd->bMaxPacketSize0; // Extract Max Packet Size from device descriptor
        epInfo[1].epAddr = udd->bNumConfigurations; // Steal and abuse from epInfo structure to save memory

        VID = udd->idVendor;
        PID = udd->idProduct;
        VER = udd->bcdDevice;
        //ProdPtr = &udd->iProduct; //JMH added

        return USB_ERROR_CONFIG_REQUIRES_ADDITIONAL_RESET;

FailHub:
	hci_status = 6;
#ifdef EXTRADEBUG
        Notify(PSTR("\r\nPlease create a hub instance in your code: \"USBHub Hub1(&Usb);\""), 0x80);
#endif
        pUsb->setAddr(bAddress, 0, 0); // Reset address
        rcode = USB_DEV_CONFIG_ERROR_DEVICE_NOT_SUPPORTED;
        Release();
        return rcode;

FailGetDevDescr:
#ifdef EXTRADEBUG
        NotifyFailGetDevDescr(rcode);
#endif
        if(rcode != hrJERR)
                rcode = USB_ERROR_FailGetDevDescr;
        Release();
        return rcode;
};

uint8_t BTD::Init(uint8_t parent __attribute__((unused)), uint8_t port __attribute__((unused)), bool lowspeed) {
        uint8_t rcode;
        uint8_t num_of_conf = epInfo[1].epAddr; // Number of configurations
        epInfo[1].epAddr = 0;
        EIRflg = false;
        RHSFflg = false;
        LastEvent = 0;
        rmsfcCnt = 0; //JMH added
        sendKey = false; //JMH Added to support keyboard reconnect
        done = false; //JMH Added to support keyboard reconnect
        paired = false; //JMH Added to support keyboard reconnect
        hci_status = 0; //JMH added
        AddressPool &addrPool = pUsb->GetAddressPool();
//        hci_status = 7;
#ifdef EXTRADEBUG
        Notify(PSTR("\r\nBTD Init"), 0x80);
#endif
        UsbDevice *p = addrPool.GetUsbDevicePtr(bAddress); // Get pointer to assigned address record

        if(!p) {
#ifdef EXTRADEBUG
                Notify(PSTR("\r\nAddress not found"), 0x80);
#endif
                return USB_ERROR_ADDRESS_NOT_FOUND_IN_POOL;
        }

        delay(300); // Assign new address to the device

        rcode = pUsb->setAddr(0, 0, bAddress); // Assign new address to the device
        if(rcode) {
#ifdef EXTRADEBUG
                Notify(PSTR("\r\nsetAddr: "), 0x80);
                D_PrintHex<uint8_t > (rcode, 0x80);
#endif
                p->lowspeed = false;
                goto Fail;
        }
#ifdef EXTRADEBUG
        Notify(PSTR("\r\nAddr: "), 0x80);
        D_PrintHex<uint8_t > (bAddress, 0x80);
#endif

        p->lowspeed = false;

        p = addrPool.GetUsbDevicePtr(bAddress); // Get pointer to assigned address record
        if(!p) {
#ifdef EXTRADEBUG
                Notify(PSTR("\r\nAddress not found"), 0x80);
#endif
                return USB_ERROR_ADDRESS_NOT_FOUND_IN_POOL;
        }

        p->lowspeed = lowspeed;

        rcode = pUsb->setEpInfoEntry(bAddress, 1, epInfo); // Assign epInfo to epinfo pointer - only EP0 is known
        if(rcode)
                goto FailSetDevTblEntry;

        if(VID == PS3_VID && (PID == PS3_PID || PID == PS3NAVIGATION_PID || PID == PS3MOVE_PID)) {
                delay(100);
                rcode = pUsb->setConf(bAddress, epInfo[ BTD_CONTROL_PIPE ].epAddr, 1); // We only need the Control endpoint, so we don't have to initialize the other endpoints of device
                if(rcode)
                        goto FailSetConfDescr;

#ifdef EXTRADEBUG
                if(PID == PS3_PID || PID == PS3NAVIGATION_PID) {
                        if(PID == PS3_PID)
                                Notify(PSTR("\r\nDualshock 3 Controller Connected"), 0x80);
                        else // It must be a navigation controller
                                Notify(PSTR("\r\nNavigation Controller Connected"), 0x80);
                } else // It must be a Motion controller
                        Notify(PSTR("\r\nMotion Controller Connected"), 0x80);
#endif

                if(my_bdaddr[0] == 0x00 && my_bdaddr[1] == 0x00 && my_bdaddr[2] == 0x00 && my_bdaddr[3] == 0x00 && my_bdaddr[4] == 0x00 && my_bdaddr[5] == 0x00) {
#ifdef EXTRADEBUG
                        Notify(PSTR("\r\nPlease plug in the dongle before trying to pair with the PS3 Controller\r\nor set the Bluetooth address in the constructor of the PS3BT class"), 0x80);
#endif
                } else {
                        if(PID == PS3_PID || PID == PS3NAVIGATION_PID)
                                setBdaddr(my_bdaddr); // Set internal Bluetooth address
                        else
                                setMoveBdaddr(my_bdaddr); // Set internal Bluetooth address
#ifdef EXTRADEBUG
                        Notify(PSTR("\r\nBluetooth Address was set to: "), 0x80);
                        for(int8_t i = 5; i > 0; i--) {
                                D_PrintHex<uint8_t > (my_bdaddr[i], 0x80);
                                Notify(PSTR(":"), 0x80);
                        }
                        D_PrintHex<uint8_t > (my_bdaddr[0], 0x80);
#endif
                }

                pUsb->setConf(bAddress, epInfo[ BTD_CONTROL_PIPE ].epAddr, 0); // Reset configuration value
                pUsb->setAddr(bAddress, 0, 0); // Reset address
                Release(); // Release device
                return USB_DEV_CONFIG_ERROR_DEVICE_NOT_SUPPORTED; // Return
        } else {
                // Check if attached device is a Bluetooth dongle and fill endpoint data structure
                // First interface in the configuration must have Bluetooth assigned Class/Subclass/Protocol
                // And 3 endpoints - interrupt-IN, bulk-IN, bulk-OUT, not necessarily in this order
                for(uint8_t i = 0; i < num_of_conf; i++) {
                        if((VID == IOGEAR_GBU521_VID && PID == IOGEAR_GBU521_PID) || (VID == BELKIN_F8T065BF_VID && PID == BELKIN_F8T065BF_PID)) {
                                ConfigDescParser<USB_CLASS_VENDOR_SPECIFIC, WI_SUBCLASS_RF, WI_PROTOCOL_BT, CP_MASK_COMPARE_ALL> confDescrParser(this); // Workaround issue with some dongles
                                rcode = pUsb->getConfDescr(bAddress, 0, i, &confDescrParser);
                        } else {
                                ConfigDescParser<USB_CLASS_WIRELESS_CTRL, WI_SUBCLASS_RF, WI_PROTOCOL_BT, CP_MASK_COMPARE_ALL> confDescrParser(this); // Set class id according to the specification
                                rcode = pUsb->getConfDescr(bAddress, 0, i, &confDescrParser);
                        }
                        if(rcode) // Check error code
                                goto FailGetConfDescr;
                        if(bNumEP >= BTD_MAX_ENDPOINTS) // All endpoints extracted
                                break;
                }

                if(bNumEP < BTD_MAX_ENDPOINTS)
                        goto FailUnknownDevice;

                // Assign epInfo to epinfo pointer - this time all 3 endpoins
                rcode = pUsb->setEpInfoEntry(bAddress, bNumEP, epInfo);
                if(rcode)
                        goto FailSetDevTblEntry;

                // Set Configuration Value
                rcode = pUsb->setConf(bAddress, epInfo[ BTD_CONTROL_PIPE ].epAddr, bConfNum);
                if(rcode)
                        goto FailSetConfDescr;

                hci_num_reset_loops = 100; // only loop 100 times before trying to send the hci reset command
                hci_counter = 0;
                hci_state = HCI_INIT_STATE;
                waitingForConnection = false;
                bPollEnable = true;

//#ifdef EXTRADEBUG
                /* JMH Added Vendor & Product Details */
                hci_status = 8;
                Notify(PSTR("\r\nBluetooth Dongle Initialized"), 0x80);
                Notify(PSTR("\r\n[VenID: "), 0x80);
                D_PrintHex<uint16_t > (VID, 0x80);
                Notify(PSTR(" ProdID: "), 0x80);
                D_PrintHex<uint16_t > (PID, 0x80);
                Notify(PSTR(" RevId: "), 0x80);
                D_PrintHex<uint16_t > (VER, 0x80);
                Notify(PSTR("]\n"), 0x80);
//#endif
        }
        return 0; // Successful configuration

        /* Diagnostic messages */
FailSetDevTblEntry:
#ifdef EXTRADEBUG
        NotifyFailSetDevTblEntry();
        goto Fail;
#endif

FailGetConfDescr:
#ifdef EXTRADEBUG
        NotifyFailGetConfDescr();
        goto Fail;
#endif

FailSetConfDescr:
#ifdef EXTRADEBUG
        NotifyFailSetConfDescr();
#endif
        goto Fail;

FailUnknownDevice:
#ifdef EXTRADEBUG
        NotifyFailUnknownDevice(VID, PID);
#endif
        pUsb->setAddr(bAddress, 0, 0); // Reset address
        rcode = USB_DEV_CONFIG_ERROR_DEVICE_NOT_SUPPORTED;
Fail:
#ifdef EXTRADEBUG
        Notify(PSTR("\r\nBTD Init Failed, error code: "), 0x80);
        NotifyFail(rcode);
#endif
        Release();
        return rcode;
}

void BTD::Initialize() {
        uint8_t i;
        for(i = 0; i < BTD_MAX_ENDPOINTS; i++) {
                epInfo[i].epAddr = 0;
                epInfo[i].maxPktSize = (i) ? 0 : 8;
                epInfo[i].bmSndToggle = 0;
                epInfo[i].bmRcvToggle = 0;
                epInfo[i].bmNakPower = (i) ? USB_NAK_NOWAIT : USB_NAK_MAX_POWER;
        }
        for(i = 0; i < BTD_NUM_SERVICES; i++) {
                if(btService[i])
                        btService[i]->Reset(); // Reset all Bluetooth services
        }
        VID = 0;
        PID = 0;
        connectToWii = false;
        incomingWii = false;
        connectToHIDDevice = false;
        incomingHIDDevice = false;
        incomingPSController = false;
        l2capConnectionClaimed = false; //JMH added, in an attempt to support Plug & Play restart
        StrtDeBug = false; // JMH Added for better breakpoint control
        DevcFnd = false;
        bAddress = 0; // Clear device address
        bNumEP = 1; // Must have to be reset to 1
        qNextPollTime = 0; // Reset next poll time
        pollInterval = 0;
        bPollEnable = false; // Don't start polling before dongle is connected
        simple_pairing_supported = false;
        hci_lastEvnt =0;
        /*JMH Added clear Class Id*/
        for(int i = 0; i<3; i++){
        	classOfDevice[i]= 0x00;
        }

}

/* Extracts interrupt-IN, bulk-IN, bulk-OUT endpoint information from config descriptor */
void BTD::EndpointXtract(uint8_t conf, uint8_t iface __attribute__((unused)), uint8_t alt, uint8_t proto __attribute__((unused)), const USB_ENDPOINT_DESCRIPTOR *pep) {
        //ErrorMessage<uint8_t>(PSTR("Conf.Val"),conf);
        //ErrorMessage<uint8_t>(PSTR("Iface Num"),iface);
        //ErrorMessage<uint8_t>(PSTR("Alt.Set"),alt);

        if(alt) // Wrong interface - by BT spec, no alt setting
                return;

        bConfNum = conf;
        uint8_t index;

        if((pep->bmAttributes & bmUSB_TRANSFER_TYPE) == USB_TRANSFER_TYPE_INTERRUPT && (pep->bEndpointAddress & 0x80) == 0x80) { // Interrupt In endpoint found
                index = BTD_EVENT_PIPE;
                epInfo[index].bmNakPower = USB_NAK_NOWAIT;
        } else if((pep->bmAttributes & bmUSB_TRANSFER_TYPE) == USB_TRANSFER_TYPE_BULK) // Bulk endpoint found
                index = ((pep->bEndpointAddress & 0x80) == 0x80) ? BTD_DATAIN_PIPE : BTD_DATAOUT_PIPE;
        else
            return;

        // Fill the rest of endpoint data structure
        epInfo[index].epAddr = (pep->bEndpointAddress & 0x0F);
        epInfo[index].maxPktSize = (uint8_t)pep->wMaxPacketSize;
#ifdef EXTRADEBUG
        PrintEndpointDescriptor(pep);
#endif
        if(pollInterval < pep->bInterval) // Set the polling interval as the largest polling interval obtained from endpoints
                pollInterval = pep->bInterval;
        bNumEP++;
}

void BTD::PrintEndpointDescriptor(const USB_ENDPOINT_DESCRIPTOR* ep_ptr __attribute__((unused))) {
#ifdef EXTRADEBUG
        Notify(PSTR("\r\nEndpoint descriptor:"), 0x80);
        Notify(PSTR("\r\nLength:\t\t"), 0x80);
        D_PrintHex<uint8_t > (ep_ptr->bLength, 0x80);
        Notify(PSTR("\r\nType:\t\t"), 0x80);
        D_PrintHex<uint8_t > (ep_ptr->bDescriptorType, 0x80);
        Notify(PSTR("\r\nAddress:\t"), 0x80);
        D_PrintHex<uint8_t > (ep_ptr->bEndpointAddress, 0x80);
        Notify(PSTR("\r\nAttributes:\t"), 0x80);
        D_PrintHex<uint8_t > (ep_ptr->bmAttributes, 0x80);
        Notify(PSTR("\r\nMaxPktSize:\t"), 0x80);
        D_PrintHex<uint16_t > (ep_ptr->wMaxPacketSize, 0x80);
        Notify(PSTR("\r\nPoll Intrv:\t"), 0x80);
        D_PrintHex<uint8_t > (ep_ptr->bInterval, 0x80);
#endif
}

/* Performs a cleanup after failed Init() attempt */
uint8_t BTD::Release() {
        Initialize(); // Set all variables, endpoint structs etc. to default values
        pUsb->GetAddressPool().FreeAddress(bAddress);
        hci_status = 0x1E;//JMH Added
        return 0;
}

uint8_t BTD::Poll() {
        if(!bPollEnable)
                return 0;
        if((int32_t)((uint32_t)millis() - qNextPollTime) >= 0L) { // Don't poll if shorter than polling interval
                qNextPollTime = (uint32_t)millis() + pollInterval; // Set new poll time
                HCI_event_task(); // Poll the HCI event pipe
                HCI_task(); // HCI state machine
                ACL_event_task(); // Poll the ACL input pipe too; ACL (Asynchronous Connectionless Link)
        }
        return 0;
}

void BTD::disconnect() {
		rmsfcCnt = 0;
        for(uint8_t i = 0; i < BTD_NUM_SERVICES; i++)
                if(btService[i])
                        btService[i]->disconnect();
};

void BTD::HCI_event_task() {
	uint16_t length = BULK_MAXPKTSIZE; // Request more than 16 bytes anyway, the inTransfer routine will take care of this
	uint8_t rcode = pUsb->inTransfer(bAddress, epInfo[ BTD_EVENT_PIPE ].epAddr, &length, hcibuf, pollInterval); // Input on endpoint 1

	if(!rcode || rcode == hrNAK) { // Check for errors
		if(EIRflg && (hcibuf[0] != EV_EXTENDED_INQUIRY_RESULT) && (hcibuf[0] != 0x00)){
			delay(0);
		}

		if(LastEvent != hcibuf[0]){
			LastEvent = hcibuf[0];
#ifdef SHOWEVENTSEQNC
			/* Display Even Name & Status */
			if(LastEvent != 0){
				Notify(PSTR("\r\n  HCI EVENT: "), 0x80);
				D_PrintHex<uint8_t > (LastEvent, 0x80);
				if(LastEvent != 0){
					rprt_HCI_event(LastEvent);
					switch(hcibuf[0]){
					case EV_INQUIRY_COMPLETE:
						rprt_HCI_error(hcibuf[2]);
						break;
					case EV_INQUIRY_RESULT:
						Notify(PSTR("ClassId("), 0x80);
						for(int i=0; i < 3; i++){
							//Notify(PSTR(" "), 0x80);
							D_PrintHex<uint8_t > (hcibuf[14-i], 0x80); // JMH Added
						}
						Notify(PSTR(")"), 0x80);
//						for(int i=0; i < hcibuf[1]+2; i++){
//							Notify(PSTR(" "), 0x80);
//							D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
//						}
						break;
					case EV_CONNECT_COMPLETE:
						rprt_HCI_error(hcibuf[2]);
						for(int i=0; i < hcibuf[1]+2; i++){
							Notify(PSTR(" "), 0x80);
							D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
						}
						break;
					case EV_INCOMING_CONNECT:
						//rprt_HCI_error(hcibuf[5]);
//						for(int i=0; i < hcibuf[1]+2; i++){
//							Notify(PSTR(" "), 0x80);
//							D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
//						}
						Notify(PSTR(" ClassID:"), 0x80);
						D_PrintHex<uint8_t > (hcibuf[10], 0x80); // JMH Added
						D_PrintHex<uint8_t > (hcibuf[9], 0x80); // JMH Added
						D_PrintHex<uint8_t > (hcibuf[8], 0x80); // JMH Added
						if(hcibuf[11]) Notify(PSTR("; ACL"), 0x80);
						else Notify(PSTR("; SOC"), 0x80);
						break;
					case EV_DISCONNECT_COMPLETE:
						rprt_HCI_error(hcibuf[2]);//Status
						rprt_HCI_error(hcibuf[5]);//Reason
						break;
					case EV_AUTHENTICATION_COMPLETE:
						rprt_HCI_error(hcibuf[2]);
						break;
					case EV_REMOTE_NAME_COMPLETE:
						rprt_HCI_error(hcibuf[2]);
						break;
					case EV_ENCRYPTION_CHANGE:
						rprt_HCI_error(hcibuf[2]);
#ifdef EXTRADEBUG
						Notify(PSTR("\r\nEV_ENCRYPTION_CHANGE\n "), 0x80);
						for(int i=0; i < hcibuf[1]+2; i++){
							Notify(PSTR(" "), 0x80);
							D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
						}
#endif
						break;
					case EV_CHANGE_CONNECTION_LINK:
						rprt_HCI_error(hcibuf[1]);
						break;
					case EV_READ_REMOTE_SUPPORTED_FEATURES_COMPLETE:
						rprt_HCI_error(hcibuf[1]);
						break;
					case EV_READ_REMOTE_VERSION_INFORMATION_COMPLETE:
						rprt_HCI_error(hcibuf[1]);
						break;
					case EV_QOS_SETUP_COMPLETE:
						rprt_HCI_error(hcibuf[1]);
						break;
					case EV_COMMAND_COMPLETE:
						rprt_HCI_error(hcibuf[5]);
						Notify(PSTR(" CmndBufSz:"), 0x80);
						D_PrintHex<uint8_t > (hcibuf[2], 0x80);
						Notify(PSTR(" Cmnd:"), 0x80);
						D_PrintHex<uint8_t > (hcibuf[3], 0x80);
						Notify(PSTR(" "), 0x80);
						D_PrintHex<uint8_t > (hcibuf[4], 0x80);
						break;
					case EV_COMMAND_STATUS:
						rprt_HCI_error(hcibuf[2]);
						break;
					case EV_ROLE_CHANGED:
						rprt_HCI_error(hcibuf[2]);
#ifdef EXTRADEBUG
						Notify(PSTR("\r\nEV_ROLE_CHANGED\n "), 0x80);
						for(int i=0; i < hcibuf[1]+2; i++){
							Notify(PSTR(" "), 0x80);
							D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
						}
#endif
						break;
					case EV_NUM_COMPLETE_PKT:
						Notify(PSTR("["), 0x80);
						D_PrintHex<uint8_t > (hcibuf[6], 0x80);
						D_PrintHex<uint8_t > (hcibuf[5], 0x80);
						Notify(PSTR("]"), 0x80);
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_PIN_CODE_REQUEST:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_LINK_KEY_REQUEST:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_LINK_KEY_NOTIFICATION:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_DATA_BUFFER_OVERFLOW:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_MAX_SLOTS_CHANGE:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_LOOPBACK_COMMAND:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_PAGE_SCAN_REP_MODE:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_READ_REMOTE_EXTENDED_FEATURES_COMPLETE:
						rprt_HCI_error(hcibuf[1]);
						break;
					case EV_EXTENDED_INQUIRY_RESULT:
						Notify(PSTR(" ("), 0x80);
						Notify(PSTR("Dev Name: "), 0x80);
						for(uint8_t i = 0; i < hcibuf[17]-1; i++) {
							E_Notifyc((char)hcibuf[19 + i], 0x80);
						}
//						for(int i=0; i < 48; i++){
//							Notify(PSTR(" "), 0x80);
//							D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
//						}
						Notify(PSTR(")"), 0x80);
						break;
					case EV_IO_CAPABILITY_REQUEST:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_IO_CAPABILITY_RESPONSE:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_USER_CONFIRMATION_REQUEST:
						//rprt_HCI_error(hcibuf[1]);
						break;
					case EV_SIMPLE_PAIRING_COMPLETE:
						rprt_HCI_error(hcibuf[1]);break;
					}
				}
			}
#endif  //
		}else if((hcibuf[0] != EV_COMMAND_COMPLETE) && (hcibuf[0] != EV_INQUIRY_RESULT) && (hcibuf[0] != EV_INQUIRY_COMPLETE)&& (hcibuf[0] != EV_EXTENDED_INQUIRY_RESULT) && (hcibuf[0] != EV_READ_REMOTE_SUPPORTED_FEATURES_COMPLETE)) return;

		switch(hcibuf[0]) { // Switch on event type
		case EV_COMMAND_COMPLETE:
			if(paired && (hci_state == HCI_WAIT_STATE)){
				hci_state = HCI_SCANNING_STATE;
				break;
			}
			if(hci_state == HCI_EVENT_MASK_STATE){
				if(done) {
					hci_state = HCI_CLASS_STATE;
					done  = false;
				}

				break;
			}
			if(hci_state == HCI_CLASS_STATE){
				if(done){
					done = false;
					hci_set_flag(HCI_FLAG_CMD_COMPLETE);
				}
				break;
			}

			if(sendKey){//JMH Added to support keyboard reconnect after timeout
				if(done){
					//sendKey = false;
					done = false;
					pairWithHIDDevice = false;
					//hci_state = HCI_SCANNING_STATE;
					//hci_state = HCI_CONNECT_DEVICE_STATE;
					hci_state = HCI_CONNECTED_DEVICE_STATE;
					hci_set_flag(HCI_FLAG_CONNECT_EVENT);
					hci_set_flag(HCI_FLAG_CONNECT_COMPLETE);
					break;
				}
//				Notify(PSTR("\r\nSend Key Cmnd Complete Event:"), 0x80);
//				for(int i = 0; i < hcibuf[1]+2; i++){
//					Notify(PSTR(" "), 0x80);
//					D_PrintHex<uint8_t > (hcibuf[i], 0x80);
//				}
//				if(hcibuf[5] != 0x00){
//					Notify(PSTR("\r\nSend Key Cmnd FAILED, err: "), 0x80);
//					D_PrintHex<uint8_t > (hcibuf[5], 0x80);
//
//				}else Notify(PSTR("\r\nSend Key Cmnd GOOD!!! "), 0x80);
				hci_state = HCI_CONNECT_DEVICE_STATE;
				hci_set_flag(HCI_FLAG_CMD_COMPLETE);
				break;
			}
			if(!hcibuf[5]) { // Check if command succeeded
				hci_set_flag(HCI_FLAG_CMD_COMPLETE); // Set command complete flag
				if((hcibuf[3] == 0x01) && (hcibuf[4] == 0x10)) { // Parameters from read local version information
					hci_version = hcibuf[6]; // Used to check if it supports 2.0+EDR - see http://www.bluetooth.org/Technical/AssignedNumbers/hci.htm
#ifdef EXTRADEBUG
			if(!hci_check_flag(HCI_FLAG_READ_VERSION)) {
				Notify(PSTR("\r\nEV_READ_VERSION_COMPLETE\n  "), 0x80);
				for(int i=0; i < hcibuf[1]+2; i++){
					Notify(PSTR(" "), 0x80);
					D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
				}
				Notify(PSTR("\r\nHCI version: "), 0x80);
				D_PrintHex<uint8_t > (hci_version, 0x80);
				rprt_HCI_versn(hci_version);
			}
#endif
					hci_set_flag(HCI_FLAG_READ_VERSION);
				} else if((hcibuf[3] == 0x04) && (hcibuf[4] == 0x10)) { // Parameters from read local extended features
					if(!hci_check_flag(HCI_FLAG_LOCAL_EXTENDED_FEATURES)) {
#ifdef EXTRADEBUG
						Notify(PSTR("\r\nPage number: "), 0x80);
						D_PrintHex<uint8_t > (hcibuf[6], 0x80);
						Notify(PSTR("\r\nMaximum page number: "), 0x80);
						D_PrintHex<uint8_t > (hcibuf[7], 0x80);
						Notify(PSTR("\r\nExtended LMP features:"), 0x80);
						for(uint8_t i = 0; i < 8; i++) {
							Notify(PSTR(" "), 0x80);
							D_PrintHex<uint8_t > (hcibuf[8 + i], 0x80);
						}
#endif
						if(hcibuf[6] == 0) { // Page 0
#ifdef EXTRADEBUG
							Notify(PSTR("\r\nDongle "), 0x80);
#endif
							if(hcibuf[8 + 6] & (1U << 3)) {
								simple_pairing_supported = true;
#ifdef EXTRADEBUG
								Notify(PSTR("supports"), 0x80);
#endif
							} else {
								simple_pairing_supported = false;
#ifdef EXTRADEBUG
								Notify(PSTR("does NOT support"), 0x80);
#endif
							}
#ifdef EXTRADEBUG
							Notify(PSTR(" secure simple pairing (controller support)"), 0x80);
#endif
						} else if(hcibuf[6] == 1) { // Page 1
#ifdef EXTRADEBUG
							Notify(PSTR("\r\nDongle "), 0x80);
							if(hcibuf[8 + 0] & (1U << 0))
								Notify(PSTR("supports"), 0x80);
							else
								Notify(PSTR("does NOT support"), 0x80);
							Notify(PSTR(" secure simple pairing (host support)"), 0x80);
#endif
						}
					}

					hci_set_flag(HCI_FLAG_LOCAL_EXTENDED_FEATURES);
				} else if((hcibuf[3] == 0x09) && (hcibuf[4] == 0x10)) { // Parameters from read local bluetooth address
					for(uint8_t i = 0; i < 6; i++)
						my_bdaddr[i] = hcibuf[6 + i];
					hci_set_flag(HCI_FLAG_READ_BDADDR);
				}
			}
			break;

		case EV_COMMAND_STATUS:
			if(hcibuf[2]) { // Show status on serial if not OK
#ifdef EXTRADEBUG1
				Notify(PSTR("\r\nHCI Command Failed: "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[2], 0x80);
				Notify(PSTR("\r\nNum HCI Command Packets: "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[3], 0x80);
				Notify(PSTR("\r\nCommand Opcode: "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[4], 0x80);
				Notify(PSTR(" "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[5], 0x80);
#endif
			}
			break;

		case EV_INQUIRY_COMPLETE:
			/*JMH Added the following counter reset */
			if((classOfDevice[0]==0x3C) && (classOfDevice[1]== 0x04) && (classOfDevice[2]== 0x08) && (hcibuf[2] == 0x00)){
				if(hci_lastEvnt == EV_INQUIRY_RESULT) hci_inquiry();
				hci_state = HCI_INQUIRY_STATE;
				hci_set_flag(HCI_FLAG_DEVICE_FOUND);
			}
//			Notify(PSTR("\r\nClass:"), 0x80);
//			for(int i = 0; i<3; i++){
//				Notify(PSTR(" "), 0x80);
//				D_PrintHex<uint8_t > (classOfDevice[i], 0x80);
//			}
//			Notify(PSTR(" Status: "), 0x80);
//			D_PrintHex<uint8_t > (hcibuf[2], 0x80);

			if(inquiry_counter >= 4 && (pairWithWii || pairWithHIDDevice)) {
				inquiry_counter = 0;

#ifdef EXTRADEBUG
				if(pairWithWii)
					Notify(PSTR("\r\nCouldn't find Wiimote"), 0x80);
				else
					Notify(PSTR("\r\nCouldn't find HID device"), 0x80);
#endif
				connectToWii = false;
				pairWithWii = false;
				connectToHIDDevice = false;
				pairWithHIDDevice = false;
				hci_state = HCI_SCANNING_STATE;
				hci_status = 0x1C;
			}
			if(!hcibuf[2]) inquiry_counter++; //JMH added if, dont advance count if inquiry wasn't successful
			break;

		case EV_INQUIRY_RESULT: //JMH Can go through this event repeatedly, until the desired device is found
			if(hcibuf[2]) { // Check that there is more than zero response
				for(uint8_t i = 0; i < hcibuf[2]; i++) {
					uint8_t offset = 8 * hcibuf[2] + 3 * i;

					for(uint8_t j = 0; j < 3; j++)
						classOfDevice[j] = hcibuf[j + 4 + offset];

#ifdef EXTRADEBUG1
					Notify(PSTR("\r\nNumber of responses: "), 0x80);
					Notify(hcibuf[2], 0x80);
					Notify(PSTR("\r\nClass of device: "), 0x80);
					D_PrintHex<uint8_t > (classOfDevice[2], 0x80);
					Notify(PSTR(" "), 0x80);
					D_PrintHex<uint8_t > (classOfDevice[1], 0x80);
					Notify(PSTR(" "), 0x80);
					D_PrintHex<uint8_t > (classOfDevice[0], 0x80);
#endif

					if(pairWithWii && classOfDevice[2] == 0x00 && (classOfDevice[1] == 0x05) && (classOfDevice[0] & 0x0C)) { // See http://wiibrew.org/wiki/Wiimote#SDP_information
						checkRemoteName = true; // Check remote name to distinguish between the different controllers

						for(uint8_t j = 0; j < 6; j++)
							disc_bdaddr[j] = hcibuf[j + 3 + 6 * i];

						hci_set_flag(HCI_FLAG_DEVICE_FOUND);
						break;
					} else if(pairWithHIDDevice && (classOfDevice[1] & 0x0F) == 0x05 && (classOfDevice[0] & 0xC8)) { // Check if it is a mouse, keyboard or a gamepad - see: http://bluetooth-pentest.narod.ru/software/bluetooth_class_of_device-service_generator.html
						checkRemoteName = true; // Used to print name in the serial monitor if serial debugging is enabled
#ifdef EXTRADEBUG


						if(classOfDevice[0] & 0x80)
							Notify(PSTR("\r\nMouse found"), 0x80);
						if(classOfDevice[0] & 0x40)
							Notify(PSTR("\r\nKeyboard found"), 0x80);
						if(classOfDevice[0] & 0x08)
							Notify(PSTR("\r\nGamepad found"), 0x80);
#endif
						for(uint8_t j = 0; j < 6; j++)
							disc_bdaddr[j] = hcibuf[j + 3 + 6 * i];
						/*       JMH Added just for testing
						 *                              */
#ifdef EXTRADEBUG
						Notify(PSTR("\r\nDevice Addr: "), 0x80);
						D_PrintHex<uint8_t > (disc_bdaddr[5], 0x80);
						Notify(PSTR(":"), 0x80);
						D_PrintHex<uint8_t > (disc_bdaddr[4], 0x80);
						Notify(PSTR(":"), 0x80);
						D_PrintHex<uint8_t > (disc_bdaddr[3], 0x80);
						Notify(PSTR(":"), 0x80);
						D_PrintHex<uint8_t > (disc_bdaddr[2], 0x80);
						Notify(PSTR(":"), 0x80);
						D_PrintHex<uint8_t > (disc_bdaddr[1], 0x80);
						Notify(PSTR(":"), 0x80);
						D_PrintHex<uint8_t > (disc_bdaddr[0], 0x80);
#endif
						hci_set_flag(HCI_FLAG_DEVICE_FOUND);
						break;
					}
				}
			}
			break;

		case EV_CONNECT_COMPLETE:
			/*new CSR4.0 dongle sometimes reports a bogus connect complete after reset
			 * check and if found ignore it */
			if((hcibuf[1]==0x0C)&&(hcibuf[3]==0x00)&&(hcibuf[4]==0x00)) return;
			hci_set_flag(HCI_FLAG_CONNECT_EVENT);
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nEV_CONNECT_COMPLETE\n  "), 0x80);
			for(int i=0; i < hcibuf[1]+2; i++){
				D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
				Notify(PSTR(" "), 0x80);
			}
#endif
			if(!hcibuf[2]) { // Check if connected OK
				hci_status = 0x09;
#ifdef EXTRADEBUG1
				Notify(PSTR("\r\nConnection established"), 0x80);
#endif
				hci_handle = hcibuf[3] | ((hcibuf[4] & 0x0F) << 8); // Store the handle for the ACL connection
				hci_set_flag(HCI_FLAG_CONNECT_COMPLETE); // Set connection complete flag
				if(disc_key[0]!=0 && disc_key[1]!=0 && disc_key[2]!=0 ){ //JMH Added
					//hci_state = HCI_CONNECT_IN_STATE; //JMH Added statement to support reconnect after board inactivity timeout
					hci_state = HCI_CONNECTED_DEVICE_STATE;
					//checkRemoteName = true;
					//hci_set_flag(HCI_FLAG_CMD_COMPLETE);
					paired = false;
					sendKey = true;
					unsigned long i = 0;
					while(i < 1000000) i++;
					//Notify(PSTR("\r\n  ******"), 0x80);
					i = 0;
				}



			} else if (hcibuf[2]== 0x0B){
				hci_set_flag(HCI_FLAG_CONNECT_COMPLETE);
//				hci_state = HCI_SCANNING_STATE;
				hci_status = 0x0A;
#ifdef EXTRADEBUG1
				Notify(PSTR("\r\nConnection Already Exists"), 0x80);
#endif
			}
			else{
				hci_state = HCI_CHECK_DEVICE_SERVICE;

			}
			break;

		case EV_DISCONNECT_COMPLETE:

			Notify(PSTR("\r\nEV_DISCONNECT\n "), 0x80);
#ifdef EXTRADEBUG
			for(int i=0; i < hcibuf[1]+2; i++){
				Notify(PSTR(" "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
			}
#endif
			if(!hcibuf[2]) { // Check if disconnected OK
				if(hci_status != 0x12) hci_status = 0x0B; // update if we just didn't experience a failed pairing
				done = false;
				paired = false;
				hci_set_flag(HCI_FLAG_DISCONNECT_COMPLETE); // Set disconnect command complete flag
				hci_clear_flag(HCI_FLAG_CONNECT_COMPLETE); // Clear connection complete flag
				if(hcibuf[5] == 0x05){
					if(hci_status != 0x12) hci_status = 0x1D;
					delay(6000);
//					if(hci_status == 0x12){ //had a pairing failure due to bad KB entry
//						hci_pin_code_request_reply();//try to entry pin# again
//						break;
//					}
				}


			}
			break;
		case EV_READ_REMOTE_SUPPORTED_FEATURES_COMPLETE:
			rmsfcCnt++;
			if(rmsfcCnt == 100){
				hci_state = HCI_CONNECTED_DEVICE_STATE;
			}
			if(rmsfcCnt > 100) rmsfcCnt = 102;//freeze the counters max value
			break;

		case EV_REMOTE_NAME_COMPLETE:
//			hci_status = 0x0C;
#ifdef EXTRADEBUG1
			Notify(PSTR("\r\nEV_REMOTE_NAME_COMPLETE:\n"), 0x80);
			for(int i=0; i < hcibuf[1]+2; i++){
				Notify(PSTR(" "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
				if(hcibuf[i] == '\0' && i> 16) break; // End of string
			}
#endif
			if(!hcibuf[2]) { // Check if reading is OK
				for(uint8_t i = 0; i < min(sizeof (remote_name), sizeof (hcibuf) - 9); i++) {
					remote_name[i] = hcibuf[9 + i];
					if(remote_name[i] == '\0') // End of string
						break;
				}
				// TODO: Always set '\0' in remote name!
				hci_set_flag(HCI_FLAG_REMOTE_NAME_COMPLETE);
				hci_status = 0x0C;
			}else if(paired){
				hci_status = 0x0C;
				break;
			}
			break;

		case EV_INCOMING_CONNECT:
			for(uint8_t i = 0; i < 6; i++)
				disc_bdaddr[i] = hcibuf[i + 2];

			for(uint8_t i = 0; i < 3; i++)
				classOfDevice[i] = hcibuf[i + 8];

			if((classOfDevice[1] & 0x0F) == 0x05 && (classOfDevice[0] & 0xC8)) { // Check if it is a mouse, keyboard or a gamepad
//#ifdef EXTRADEBUG
				if(classOfDevice[0] & 0x80)
					Notify(PSTR("\r\nMouse is connecting"), 0x80);
				if(classOfDevice[0] & 0x40){
					hci_status = 0x0D;
					Notify(PSTR("\r\nKeyboard connecting"), 0x80);
					if(disc_key[0]!=0 && disc_key[1]!=0 && disc_key[2]!=0 ){ //JMH Added
						hci_state = HCI_CONNECT_IN_STATE; //JMH Added statement to support reconnect after board inactivity timeout
						sendKey = true;
					}
				}
				if(classOfDevice[0] & 0x08)
					Notify(PSTR("\r\nGamepad is connecting"), 0x80);
//#endif
				incomingHIDDevice = true;
			}

#ifdef EXTRADEBUG
			Notify(PSTR("\r\nBT dev Address: "), 0x80);
			for(uint8_t i = 0; i < 6; i++){
				D_PrintHex<uint8_t > (disc_bdaddr[5-i], 0x80);
				Notify(PSTR(":"), 0x80);
			}
			Notify(PSTR("\r\nClass of BT dev: "), 0x80);
			D_PrintHex<uint8_t > (classOfDevice[2], 0x80);
			Notify(PSTR(" "), 0x80);
			D_PrintHex<uint8_t > (classOfDevice[1], 0x80);
			Notify(PSTR(" "), 0x80);
			D_PrintHex<uint8_t > (classOfDevice[0], 0x80);
#endif
			hci_set_flag(HCI_FLAG_INCOMING_REQUEST);
			delay(250);//JMH added to reduce "flooding" the display
			break;

		case EV_PIN_CODE_REQUEST:
			if(pairWithWii) {
#ifdef EXTRADEBUG
				Notify(PSTR("\r\nPairing with Wiimote"), 0x80);
#endif
				hci_pin_code_request_reply();
			} else if(btdPin != NULL) {
//#ifdef EXTRADEBUG
				hci_status = 0x0E;
				Notify(PSTR("\r\nSet Bluetooth pin to: "), 0x80);
				NotifyStr(btdPin, 0x80);
//#endif
				hci_pin_code_request_reply();
			} else {
				hci_status = 0x0F;
#ifdef EXTRADEBUG
				Notify(PSTR("\r\nNo pin was set"), 0x80);
#endif
				hci_pin_code_negative_request_reply();
			}
			break;

		case EV_LINK_KEY_REQUEST:
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nReceived Key Request"), 0x80);
#endif
			if(!sendKey) hci_link_key_request_negative_reply();
			else{
				Notify(PSTR("\r\n  Send Stored Link KeyCmnd"), 0x80);
				hci_link_Key_Request_Reply();
			}
			break;

		case EV_AUTHENTICATION_COMPLETE:
			if(!hcibuf[2]) { // Check if pairing was successful
				if(pairWithWii && !connectToWii) {
#ifdef EXTRADEBUG
					Notify(PSTR("\r\nPairing successful with Wiimote"), 0x80);
#endif
					connectToWii = true; // Used to indicate to the Wii service, that it should connect to this device
				} else if(pairWithHIDDevice && !connectToHIDDevice) {
					hci_status = 0x10;
//#ifdef EXTRADEBUG
					Notify(PSTR("\r\nPairing successful with HID device"), 0x80);
//#endif
					connectToHIDDevice = true; // Used to indicate to the BTHID service, that it should connect to this device
				} else {
					hci_status = 0x11;
//					delay(2000);
//					if(hci_state != 0x0A){ //state == ???

//#ifdef EXTRADEBUG
						uint8_t curstate = hci_state;
						Notify(PSTR("\r\n*** hci_state: "), 0x80);
						D_PrintHex<uint8_t > (curstate, 0x80);
						Notify(PSTR("\r\n*** hci_status: "), 0x80);
						D_PrintHex<uint8_t > (hci_status, 0x80);
						Notify(PSTR("\r\nPairing Successful"), 0x80);
//#endif
						connectToHIDDevice = true;
						l2capConnectionClaimed = false;
						btService[0]->Reset1();
						paired = true;
//					}
				}
			} else {
				hci_status = 0x12;
#ifdef EXTRADEBUG
				Notify(PSTR("\r\nPairing Failed: "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[2], 0x80);
#endif
				hci_disconnect(hci_handle);
				hci_state = HCI_DISCONNECT_STATE;
			}
			break;

		case EV_IO_CAPABILITY_REQUEST:
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nReceived IO Capability Request"), 0x80);
#endif
			hci_io_capability_request_reply();
			break;

		case EV_IO_CAPABILITY_RESPONSE:
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nReceived IO Capability Response: "), 0x80);
			Notify(PSTR("\r\nIO capability: "), 0x80);
			D_PrintHex<uint8_t > (hcibuf[8], 0x80);
			Notify(PSTR("\r\nOOB data present: "), 0x80);
			D_PrintHex<uint8_t > (hcibuf[9], 0x80);
			Notify(PSTR("\r\nAuthentication request: "), 0x80);
			D_PrintHex<uint8_t > (hcibuf[10], 0x80);
#endif
			break;

		case EV_USER_CONFIRMATION_REQUEST:
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nUser confirmation Request"), 0x80);
#ifdef EXTRADEBUG
			Notify(PSTR(": \r\nNumeric value: "), 0x80);
			for(uint8_t i = 0; i < 4; i++) {
				Notify(PSTR(" "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[8 + i], 0x80);
			}
#endif
#endif
			// Simply confirm the connection, as the host has no "NoInputNoOutput" capabilities
			hci_user_confirmation_request_reply();
			break;

		case EV_SIMPLE_PAIRING_COMPLETE:
#ifdef EXTRADEBUG
			if(!hcibuf[2]) { // Check if connected OK
				Notify(PSTR("\r\nSimple Pairing succeeded"), 0x80);
			} else {
				Notify(PSTR("\r\nSimple Pairing failed: "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[2], 0x80);
			}
#endif
			break;
			/*     JMH added this event code */
		case EV_LINK_KEY_NOTIFICATION:
#ifdef EXTRADEBUG1
			Notify(PSTR("\r\nEV_LINK_KEY_NOTIFICATION\n  "), 0x80);
			for(int i=0; i < hcibuf[1]+2; i++){
				D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
				Notify(PSTR(" "), 0x80);
			}
#endif
			//store bdaddr
			for(uint8_t i = 0; i < 6; i++) {
				disc_bdaddr[5-i] = hcibuf[8 - i];
			}
			//store key code
			for(int i=0; i < 16; i++){
				disc_key[i] = hcibuf[i+8];
			}
			break;
			/*     JMH added this event code to Support New CSR 4.0./5.0 Dongle     */
		case EV_REMOTE_HOST_SUPRTD_FEATURS_NOTIFICATION:
			hci_set_flag(HCI_FLAG_DEVICE_FOUND);
			if(!RHSFflg){
				RHSFflg = true;
#ifdef EXTRADEBUG1
				Notify(PSTR("\r\n*Remote Host Suprtd Features: "), 0x80);
				Notify(PSTR("\r\n  Class of device: "), 0x80);
				D_PrintHex<uint8_t > (classOfDevice[2], 0x80);
				Notify(PSTR(" "), 0x80);
				D_PrintHex<uint8_t > (classOfDevice[1], 0x80);
				Notify(PSTR(" "), 0x80);
				D_PrintHex<uint8_t > (classOfDevice[0], 0x80);
				Notify(PSTR("\r\n  Device Addr: "), 0x80);
				D_PrintHex<uint8_t > (disc_bdaddr[5], 0x80);
				Notify(PSTR(":"), 0x80);
				D_PrintHex<uint8_t > (disc_bdaddr[4], 0x80);
				Notify(PSTR(":"), 0x80);
				D_PrintHex<uint8_t > (disc_bdaddr[3], 0x80);
				Notify(PSTR(":"), 0x80);
				D_PrintHex<uint8_t > (disc_bdaddr[2], 0x80);
				Notify(PSTR(":"), 0x80);
				D_PrintHex<uint8_t > (disc_bdaddr[1], 0x80);
				Notify(PSTR(":"), 0x80);
				D_PrintHex<uint8_t > (disc_bdaddr[0], 0x80);
#endif
			}
			break;

			/*     JMH added this event code to Support New CSR 4.0./5.0 Dongle     */
		case EV_EXTENDED_INQUIRY_RESULT:
			if(!EIRflg){
				EIRflg = true;
#ifdef EXTRADEBUG
				Notify(PSTR("\r\nEV_EXTENDED_INQUIRY_RESULT\n  "), 0x80);
				int stop = 75; //set the maximum number event response bytes to unpack to 75
				if(hcibuf[1]+2 < stop) stop = hcibuf[1]+2;
				for(int i=0; i < stop; i++){
					D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
					Notify(PSTR(" "), 0x80);
				}
				Notify(PSTR("\nDev Addr: "), 0x80);
				for(uint8_t i = 0; i < 6; i++) {
					D_PrintHex<uint8_t > (hcibuf[8 - i], 0x80);
					if(i!=5) Notify(PSTR(":"), 0x80);
				}
				Notify(PSTR("  "), 0x80);
				Notify(PSTR("Dev Class: "), 0x80);
				for(uint8_t i = 0; i < 3; i++) {
					D_PrintHex<uint8_t > (hcibuf[13 - i], 0x80);
				}
				Notify(PSTR("  "), 0x80);
				Notify(PSTR("Dev Name: "), 0x80);
				for(uint8_t i = 0; i < hcibuf[17]; i++) {
					E_Notifyc((char)hcibuf[19 + i], 0x80);
				}
#endif
				if(!hci_check_flag(HCI_FLAG_DEVICE_FOUND)){
					for(uint8_t i = 0; i < 3; i++) {
						classOfDevice[2-i] = hcibuf[13 - i];
					}
					for(uint8_t i = 0; i < 6; i++) {
						disc_bdaddr[5-i] = hcibuf[8 - i];
					}
				}
				//#ifdef EXTRADEBUG1
				//				Notify(PSTR("\r\n Class of device: "), 0x80);
				//				D_PrintHex<uint8_t > (classOfDevice[2], 0x80);
				//				Notify(PSTR(" "), 0x80);
				//				D_PrintHex<uint8_t > (classOfDevice[1], 0x80);
				//				Notify(PSTR(" "), 0x80);
				//				D_PrintHex<uint8_t > (classOfDevice[0], 0x80);
				//				Notify(PSTR("\r\n Device Addr: "), 0x80);
				//				D_PrintHex<uint8_t > (disc_bdaddr[5], 0x80);
				//				Notify(PSTR(":"), 0x80);
				//				D_PrintHex<uint8_t > (disc_bdaddr[4], 0x80);
				//				Notify(PSTR(":"), 0x80);
				//				D_PrintHex<uint8_t > (disc_bdaddr[3], 0x80);
				//				Notify(PSTR(":"), 0x80);
				//				D_PrintHex<uint8_t > (disc_bdaddr[2], 0x80);
				//				Notify(PSTR(":"), 0x80);
				//				D_PrintHex<uint8_t > (disc_bdaddr[1], 0x80);
				//				Notify(PSTR(":"), 0x80);
				//				D_PrintHex<uint8_t > (disc_bdaddr[0], 0x80);
				//#endif
//				hci_set_event_mask();
				if(pairWithWii && classOfDevice[2] == 0x00 && (classOfDevice[1] == 0x05) && (classOfDevice[0] & 0x0C)) { // See http://wiibrew.org/wiki/Wiimote#SDP_information
					checkRemoteName = true; // Check remote name to distinguish between the different controllers
					hci_set_flag(HCI_FLAG_DEVICE_FOUND);

					break;
				} else if(pairWithHIDDevice && (classOfDevice[1] & 0x0F) == 0x05 && (classOfDevice[0] & 0xC8)) { // Check if it is a mouse, keyboard or a gamepad - see: http://bluetooth-pentest.narod.ru/software/bluetooth_class_of_device-service_generator.html
					if(classOfDevice[0] & 0x40){
						hci_status = 0x13;
						checkRemoteName = true;//JMH added
						hci_set_flag(HCI_FLAG_DEVICE_FOUND);
					}
					else if(!hci_check_flag(HCI_FLAG_DEVICE_FOUND)) hci_status = 0x14;
#ifdef EXTRADEBUG
					checkRemoteName = true; // Used to print name in the serial monitor if serial debugging is enabled
					if(classOfDevice[0] & 0x80)
						Notify(PSTR("\r\nMouse found"), 0x80);
					if(classOfDevice[0] & 0x40)
						Notify(PSTR("\r\nKeyboard found"), 0x80);
					if(classOfDevice[0] & 0x08)
						Notify(PSTR("\r\nGamepad found"), 0x80);
#endif
					//hci_set_flag(HCI_FLAG_DEVICE_FOUND);
					break;
				}
			}
			break;
	/*JMH Added  */
		case EV_ENCRYPTION_CHANGE:
			if(!hcibuf[2] && (hcibuf[5]==0x01)){
				hci_state = HCI_SET_ENCRYPTION_STATE;
				done = false;
			}else if(!hcibuf[2] && (hcibuf[5]==0x00)){
				done = false;
				hci_state = HCI_CONNECTED_DEVICE_STATE;
//				hci_state = HCI_WAIT_STATE; //at this point in the command /event sequence the WAIT STATE should cause no further action
			}
			break;


			/* We will just ignore the following events */
		case EV_MAX_SLOTS_CHANGE:
			break; //JMH added
		case EV_NUM_COMPLETE_PKT:
			break;
		case EV_ROLE_CHANGED:
		case EV_PAGE_SCAN_REP_MODE:
		case EV_LOOPBACK_COMMAND:
		case EV_DATA_BUFFER_OVERFLOW:
		case EV_CHANGE_CONNECTION_LINK:
		case EV_QOS_SETUP_COMPLETE:
			//		case EV_LINK_KEY_NOTIFICATION:
		//case EV_ENCRYPTION_CHANGE:
		case EV_READ_REMOTE_VERSION_INFORMATION_COMPLETE:

			if(hcibuf[0] != 0x00) {
#ifdef EXTRADEBUG1
				Notify(PSTR("\r\nIgnore HCI Event: "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[0], 0x80);
#endif
			}
			break;

		default:

			if(hcibuf[0] != 0x00) {
#ifdef EXTRADEBUG1
				Notify(PSTR("\r\nUnmanaged HCI Event: "), 0x80);
				D_PrintHex<uint8_t > (hcibuf[0], 0x80);
				Notify(PSTR(", data: "), 0x80);
				uint8_t stop = hcibuf[1];
				if(hcibuf[1] > BULK_MAXPKTSIZE) stop = BULK_MAXPKTSIZE; //JMH do this so we don't report garbage
				for(uint16_t i = 0; i < stop; i++) {
					D_PrintHex<uint8_t > (hcibuf[2 + i], 0x80);
					Notify(PSTR(" "), 0x80);
				}
#endif
			}

			break;
		} // Switch
		hci_lastEvnt = hcibuf[0];
	}
	else {
		hci_status = 0x15;
#ifdef SHOWEVENTSEQNC

		Notify(PSTR("\r\nHCI event error: "), 0x80);
		D_PrintHex<uint8_t > (rcode, 0x80);

#endif
	}
}

/* Poll Bluetooth and print result */
void BTD::HCI_task() {
	if(StrtDeBug){
		Notify(PSTR("\r\nHCISTATE: "), 0x80); // JMH Added
	    D_PrintHex<uint8_t > (hci_state, 0x80); // JMH Added
	}
	switch(hci_state) {
	case HCI_INIT_STATE:
		hci_counter++;
		if(hci_counter > hci_num_reset_loops) { // wait until we have looped x times to clear any old events
			/* JMH reset stored values */
			for(int i =0; i< sizeof(my_bdaddr); i++){
				my_bdaddr[i] = 0x00;
			}
			for(int i =0; i< sizeof(disc_bdaddr); i++){
				disc_bdaddr[i] = 0x00;
			}
			for(int i =0; i< sizeof(disc_key); i++){
				disc_key[i] = 0x00;
			}

			hci_handle = 0;
			pairWithHIDDevice = true;
			/* JMH END reset stored values */
			hci_reset();
			hci_state = HCI_RESET_STATE;
			hci_counter = 0;
		}
		break;

	case HCI_RESET_STATE:
		hci_counter++;
		if(hci_check_flag(HCI_FLAG_CMD_COMPLETE)) {
			hci_counter = 0;
			hci_status = 0x1F;
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nHCI Reset complete"), 0x80);
#endif
			hci_state = HCI_EVENT_MASK_STATE;
			//StrtDeBug = true;
			//hci_state = HCI_CLASS_STATE;
			//hci_write_class_of_device();
		} else if(hci_counter > hci_num_reset_loops) {
			hci_counter = 0;
			hci_num_reset_loops *=5 ;
			if(hci_num_reset_loops > 16000){
				hci_num_reset_loops = 16000;
				hci_status = 0x20;
#ifdef EXTRADEBUG
				Notify(PSTR("\r\nNo response to HCI Reset"), 0x80);
#endif
				hci_state = HCI_INIT_STATE;
				hci_counter = 0;
			}
		}
		break;

	case HCI_CLASS_STATE:
		if(hci_check_flag(HCI_FLAG_CMD_COMPLETE)) {
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nWrite class of device"), 0x80);
#endif
			hci_state = HCI_BDADDR_STATE;
			hci_read_bdaddr();
		}else if(!done){
			hci_write_class_of_device();
			done = true;
		}
		break;

	case HCI_BDADDR_STATE:
		if(hci_check_flag(HCI_FLAG_READ_BDADDR)) {
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nDongle BT Address: "), 0x80);
			for(int8_t i = 5; i > 0; i--) {
				D_PrintHex<uint8_t > (my_bdaddr[i], 0x80);
				Notify(PSTR(":"), 0x80);
			}
			D_PrintHex<uint8_t > (my_bdaddr[0], 0x80);
#endif
			hci_read_local_version_information();
			hci_state = HCI_LOCAL_VERSION_STATE;
		}
		break;

	case HCI_LOCAL_VERSION_STATE: // The local version is used by the PS3BT class
		if(hci_check_flag(HCI_FLAG_READ_VERSION)) {
			if(btdName != NULL) {
				hci_write_local_name(btdName);
				hci_state = HCI_WRITE_NAME_STATE;
			} else if(useSimplePairing) {
				hci_read_local_extended_features(0); // "Requests the normal LMP features as returned by Read_Local_Supported_Features"
				//hci_read_local_extended_features(1); // Read page 1
				hci_state = HCI_LOCAL_EXTENDED_FEATURES_STATE;
			} else
				hci_state = HCI_CHECK_DEVICE_SERVICE;
		}
		break;

	case HCI_WRITE_NAME_STATE:
		if(hci_check_flag(HCI_FLAG_CMD_COMPLETE)) {
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nThe name was set to: "), 0x80);
			NotifyStr(btdName, 0x80);
#endif
			if(useSimplePairing) {
				hci_read_local_extended_features(0); // "Requests the normal LMP features as returned by Read_Local_Supported_Features"
				//hci_read_local_extended_features(1); // Read page 1
				hci_state = HCI_LOCAL_EXTENDED_FEATURES_STATE;
			} else
				hci_state = HCI_CHECK_DEVICE_SERVICE;
		}
		break;

	case HCI_LOCAL_EXTENDED_FEATURES_STATE:
		if(hci_check_flag(HCI_FLAG_LOCAL_EXTENDED_FEATURES)) {
			if(simple_pairing_supported) {
				hci_write_simple_pairing_mode(true);
				hci_state = HCI_WRITE_SIMPLE_PAIRING_STATE;
			} else
				hci_state = HCI_CHECK_DEVICE_SERVICE;
		}
		break;

	case HCI_WRITE_SIMPLE_PAIRING_STATE:
		if(hci_check_flag(HCI_FLAG_CMD_COMPLETE)) {
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nSimple pairing was enabled"), 0x80);
#endif
			hci_set_event_mask();
			hci_state = HCI_SET_EVENT_MASK_STATE;
		}
		break;

	case HCI_SET_EVENT_MASK_STATE:
		if(hci_check_flag(HCI_FLAG_CMD_COMPLETE)) {
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nSet event mask completed"), 0x80);
#endif
			hci_state = HCI_CHECK_DEVICE_SERVICE;
		}
		break;

	case HCI_CHECK_DEVICE_SERVICE:
		if(pairWithHIDDevice || pairWithWii) { // Check if it should try to connect to a Wiimote

//#ifdef EXTRADEBUG
			if(pairWithWii)
				Notify(PSTR("\r\nStarting inquiry\r\nPress 1 & 2 on the Wiimote\r\nOr press the SYNC button if you are using a Wii U Pro Controller or a Wii Balance Board"), 0x80);
			else
				hci_status = 0x17;
				Notify(PSTR("\r\nPlease enable discovery of your device\n"), 0x80);
//#endif
			hci_inquiry();
			inquiry_counter =0;//JMH Added to prevent "device not found" result on restart
			hci_state = HCI_INQUIRY_STATE;
		} else
			hci_state = HCI_SCANNING_STATE; // Don't try to connect to a Wiimote
		break;

	case HCI_INQUIRY_STATE:
		if(hci_check_flag(HCI_FLAG_DEVICE_FOUND)) {
			hci_inquiry_cancel(); // Stop inquiry

#ifdef EXTRADEBUG
			if(pairWithWii)
				Notify(PSTR("\r\nWiimote found"), 0x80);
			else
				Notify(PSTR("\r\nHID device found"), 0x80);

			Notify(PSTR("\r\nNow just create the instance like so:"), 0x80);
			if(pairWithWii)
				Notify(PSTR("\r\nWII Wii(&Btd);"), 0x80);
			else
				Notify(PSTR("\r\nBTHID bthid(&Btd);"), 0x80);

			Notify(PSTR("\r\nAnd then press any button on the "), 0x80);
			if(pairWithWii)
				Notify(PSTR("Wiimote"), 0x80);
			else
				Notify(PSTR("device"), 0x80);
#endif
			if(checkRemoteName) {
				//StrtDeBug = true;
//				delay(200);//JMH Added to allow time for TFT DIsplay to catch up
				//Notify(PSTR("\r\n+++ checkRemoteName +++"), 0x80);
				hci_remote_name(); // We need to know the name to distinguish between the Wiimote, the new Wiimote with Motion Plus inside, a Wii U Pro Controller and a Wii Balance Board
				hci_state = HCI_REMOTE_NAME_STATE;
			} else
				hci_state = HCI_CONNECT_DEVICE_STATE;
//			// JMH added this code to help support restarting a "lost" connection
			l2capConnectionClaimed = false;
			btService[0]->Reset(); //the purpose of this call is to set l2cap_state = L2CAP_WAIT;
			delay(0);
		}
		break;

	case HCI_CONNECT_DEVICE_STATE:
		if(hci_check_flag(HCI_FLAG_CMD_COMPLETE)) {
#ifdef EXTRADEBUG
			if(pairWithWii)
				Notify(PSTR("\r\nConnecting to Wiimote"), 0x80);
			else
				Notify(PSTR("\r\nConnecting to HID device"), 0x80);
#endif
			checkRemoteName = false;
			hci_connect();
			hci_state = HCI_CONNECTED_DEVICE_STATE;
		}
		break;

	case HCI_CONNECTED_DEVICE_STATE:
		if(hci_check_flag(HCI_FLAG_CONNECT_EVENT)) {
			if(hci_check_flag(HCI_FLAG_CONNECT_COMPLETE)) {
				if(!paired) hci_status = 0x18;
#ifdef EXTRADEBUG
				if(pairWithWii)
					Notify(PSTR("\r\nConnected to Wiimote"), 0x80);
				else
					Notify(PSTR("\r\nConnected to HID device"), 0x80);
#endif
				//paired = false;
				if(!paired){
					hci_authentication_request(); // This will start the pairing with the device
					paired = true;
				}
				if(sendKey){
					sendKey = false;
					hci_state = HCI_WAIT_STATE;
				}
				else hci_state = HCI_SCANNING_STATE;
			} else {
#ifdef EXTRADEBUG
				Notify(PSTR("\r\nTrying to connect one more time..."), 0x80);
#endif
				hci_connect(); // Try to connect one more time
			}
		}
		break;

	case HCI_SCANNING_STATE:
		if(!connectToWii && !pairWithWii && !connectToHIDDevice && !pairWithHIDDevice) {
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nWait For Incoming Connection Request\n"), 0x80);
#endif
			hci_write_scan_enable();
			waitingForConnection = true;
			hci_state = HCI_CONNECT_IN_STATE;
		}
		break;

	case HCI_CONNECT_IN_STATE:
		if(hci_check_flag(HCI_FLAG_INCOMING_REQUEST)) {
			waitingForConnection = false;
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nIncoming Connection Request Response:"), 0x80);
#endif
			if(sendKey){
				if(!done){
#ifdef EXTRADEBUG
					Notify(PSTR("\r\n  Send Accept ConnectionCmnd"), 0x80);
#endif
					hci_accept_connection();
					//hci_link_Key_Request_Reply();
					done = true;
					pairWithHIDDevice = false;
					hci_clear_flag(HCI_FLAG_DISCONNECT_COMPLETE); // restore disconnect command complete flag
					hci_set_flag(HCI_FLAG_CONNECT_COMPLETE); // restore connection complete flag
					hci_clear_flag(HCI_FLAG_INCOMING_REQUEST);
				}else{
#ifdef EXTRADEBUG
					Notify(PSTR("\r\n  Ignoring 2nd Stored Key LinkCmnd"), 0x80);
#endif
					Notify(PSTR("\r\n  Send hci_link_Key_Request_Reply"), 0x80);
					hci_link_Key_Request_Reply();
					hci_state = HCI_WAIT_STATE;
					break;
				}
			}
			else if(!done){
//#ifdef EXTRADEBUG
			Notify(PSTR("\r\n  Remote Name LinkCmnd"), 0x80);
//#endif
			hci_remote_name();
			hci_state = HCI_REMOTE_NAME_STATE;
			}
		} else if(hci_check_flag(HCI_FLAG_DISCONNECT_COMPLETE))
			hci_state = HCI_DISCONNECT_STATE;
		break;


	case HCI_REMOTE_NAME_STATE:
//		if(StrtDeBug)
//				delay(0); // JMH Added
		if(hci_check_flag(HCI_FLAG_REMOTE_NAME_COMPLETE)) {
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nRemote Name: "), 0x80);
			for(uint8_t i = 0; i < strlen(remote_name); i++)
				Notifyc(remote_name[i], 0x80);
#endif
			if(strncmp((const char*)remote_name, "Nintendo", 8) == 0) {
				incomingWii = true;
				motionPlusInside = false;
				wiiUProController = false;
				pairWiiUsingSync = false;
#ifdef EXTRADEBUG
				Notify(PSTR("\r\nWiimote is connecting"), 0x80);
#endif
				if(strncmp((const char*)remote_name, "Nintendo RVL-CNT-01-TR", 22) == 0) {
#ifdef EXTRADEBUG
					Notify(PSTR(" with Motion Plus Inside"), 0x80);
#endif
					motionPlusInside = true;
				} else if(strncmp((const char*)remote_name, "Nintendo RVL-CNT-01-UC", 22) == 0) {
#ifdef EXTRADEBUG
					Notify(PSTR(" - Wii U Pro Controller"), 0x80);
#endif
					wiiUProController = motionPlusInside = pairWiiUsingSync = true;
				} else if(strncmp((const char*)remote_name, "Nintendo RVL-WBC-01", 19) == 0) {
#ifdef EXTRADEBUG
					Notify(PSTR(" - Wii Balance Board"), 0x80);
#endif
					pairWiiUsingSync = true;
				}
			}
			if(classOfDevice[2] == 0 && classOfDevice[1] == 0x25 && classOfDevice[0] == 0x08 && strncmp((const char*)remote_name, "Wireless Controller", 19) == 0) {
#ifdef EXTRADEBUG
				Notify(PSTR("\r\nPS4/PS5 controller is connecting"), 0x80);
#endif
				incomingPSController = true;
			}
			if((pairWithWii || pairWithHIDDevice) && checkRemoteName)
				hci_state = HCI_CONNECT_DEVICE_STATE;
			else {
				hci_accept_connection();
				hci_state = HCI_CONNECTED_STATE;
			}
		}
		break;

	case HCI_CONNECTED_STATE:
		if(hci_check_flag(HCI_FLAG_CONNECT_COMPLETE)) {
			hci_status = 0x19;
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nConnected to Device: "), 0x80);
			for(int8_t i = 5; i > 0; i--) {
				D_PrintHex<uint8_t > (disc_bdaddr[i], 0x80);
				Notify(PSTR(":"), 0x80);
			}
			D_PrintHex<uint8_t > (disc_bdaddr[0], 0x80);
#endif
			if(incomingPSController)
				connectToHIDDevice = true; // We should always connect to the PS4/PS5 controller

			// Clear these flags for a new connection
			l2capConnectionClaimed = false;
			sdpConnectionClaimed = false;
			rfcommConnectionClaimed = false;

			hci_event_flag = 0;
			hci_state = HCI_DONE_STATE;
		}
		break;

	case HCI_DONE_STATE:
		hci_counter++;
		if(hci_counter > 1000) { // Wait until we have looped 1000 times to make sure that the L2CAP connection has been started
			hci_counter = 0;
			hci_state = HCI_SCANNING_STATE;
		}
		break;

	case HCI_DISCONNECT_STATE:
		if(hci_check_flag(HCI_FLAG_DISCONNECT_COMPLETE)) {
			hci_status = 0x1A;
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nHCI Disconnected from Device"), 0x80);
#endif
			hci_event_flag = 0; // Clear all flags

			// Reset all buffers
			memset(hcibuf, 0, BULK_MAXPKTSIZE);
			memset(l2capinbuf, 0, BULK_MAXPKTSIZE);

			connectToWii = incomingWii = pairWithWii = false;
			connectToHIDDevice = incomingHIDDevice = pairWithHIDDevice = checkRemoteName = false;
			pairWithHIDDevice = checkRemoteName = true;//JMH- Added this line to get "Plug & Play" behavior
			incomingPSController = false;
			hci_state = HCI_SCANNING_STATE;
		}
		break;
/* JMH added this state to provide a "hold" position for reconnect
 * (as a result of a key press, after keyboard inactivity timeout)
 * of the ACL control and interrupt channels in the BTHID code*/
	case HCI_WAIT_STATE:
//		Notify(PSTR("\r\nHCI_WAIT_STATE"), 0x80);
		sendKey = true;
		if(paired && !connectToHIDDevice && !pairWithHIDDevice){
			hci_state = HCI_SCANNING_STATE;
		}
		break;
/* JMH added this state */
	case HCI_SET_ENCRYPTION_STATE:
		if(!done){
			hci_set_connection_encryption();
			done = true;
		}
//		hci_state = HHCI_EVENT_MASK_STATE;
		break;

	case HCI_EVENT_MASK_STATE:
		if(!done){
#ifdef EXTRADEBUG
			Notify(PSTR("\r\nhci_set_event_mask"), 0x80);
#endif
			hci_set_event_mask();
			done = true;
		}
		//hci_state = HCI_CLASS_STATE;
		break;

	default:
		break;
	}
}

void BTD::ACL_event_task() {// JMH - ACL (Asynchronous Connectionless Link); This is a control data link
	uint16_t length = BULK_MAXPKTSIZE;
	uint8_t rcode = pUsb->inTransfer(bAddress, epInfo[ BTD_DATAIN_PIPE ].epAddr, &length, l2capinbuf, pollInterval); // Input on endpoint 2

	if(!rcode) { // Check for errors
		if(length > 0) { // Check if any data was read
			for(uint8_t i = 0; i < BTD_NUM_SERVICES; i++) {
				if(btService[i])
					btService[i]->ACLData(l2capinbuf);
			}
		}
	}
#ifdef EXTRADEBUG
	else if(rcode != hrNAK) {
		Notify(PSTR("\r\nACL data in error: "), 0x80);
		D_PrintHex<uint8_t > (rcode, 0x80);
	}
#endif
	for(uint8_t i = 0; i < BTD_NUM_SERVICES; i++)
		if(btService[i])
			btService[i]->Run();
}

/************************************************************/
/*                    HCI Commands                        */

/************************************************************/
void BTD::HCI_Command(uint8_t* data, uint16_t nbytes) {
	delay(2);//JMH Added Delay for NEW CSR4.0 Dongle to follow commands
#ifdef SHOWEVENTSEQNC
	if(1){//StrtDeBug; use this to better control debug messaging
		Notify(PSTR("\r\n  HCI_Command: "), 0x80); // JMH Added
		for(int i=0; i < nbytes; i++){
			D_PrintHex<uint8_t > (hcibuf[i], 0x80); // JMH Added
			Notify(PSTR(" "), 0x80);
		}
	}
#endif
    hci_clear_flag(HCI_FLAG_CMD_COMPLETE);
    LastEvent = 0x00;
    pUsb->ctrlReq(bAddress, epInfo[ BTD_CONTROL_PIPE ].epAddr, bmREQ_HCI_OUT, 0x00, 0x00, 0x00, 0x00, nbytes, nbytes, data, NULL);
}

void BTD::hci_reset() {
        hci_event_flag = 0; // Clear all the flags
        hcibuf[0] = 0x03; // HCI OCF = 3
        hcibuf[1] = 0x03 << 2; // HCI OGF = 3
        hcibuf[2] = 0x00;

        HCI_Command(hcibuf, 3);
        hci_status = 0x1B;
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(HCI_RESET)"), 0x80); // JMH Added
#endif
}

void BTD::hci_write_scan_enable() {
        hci_clear_flag(HCI_FLAG_INCOMING_REQUEST);
        hcibuf[0] = 0x1A; // HCI OCF = 1A
        hcibuf[1] = 0x03 << 2; // HCI OGF = 3
        hcibuf[2] = 0x01; // parameter length = 1
        if(btdName != NULL)
                hcibuf[3] = 0x03; // Inquiry Scan enabled. Page Scan enabled.
        else
                hcibuf[3] = 0x02; // Inquiry Scan disabled. Page Scan enabled.

        HCI_Command(hcibuf, 4);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(HCI_WRITE_SCAN_ENABLE)"), 0x80); // JMH Added
#endif
}

void BTD::hci_write_scan_disable() {
        hcibuf[0] = 0x1A; // HCI OCF = 1A
        hcibuf[1] = 0x03 << 2; // HCI OGF = 3
        hcibuf[2] = 0x01; // parameter length = 1
        hcibuf[3] = 0x00; // Inquiry Scan disabled. Page Scan disabled.

        HCI_Command(hcibuf, 4);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(HCI_WRITE_SCAN_DISABLE)"), 0x80); // JMH Added
#endif
}

void BTD::hci_read_bdaddr() {
        hci_clear_flag(HCI_FLAG_READ_BDADDR);
        hcibuf[0] = 0x09; // HCI OCF = 9
        hcibuf[1] = 0x04 << 2; // HCI OGF = 4
        hcibuf[2] = 0x00;

        HCI_Command(hcibuf, 3);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(INFO_READ_BDADDR)"), 0x80); // JMH Added
#endif
}

void BTD::hci_read_local_version_information() {
        hci_clear_flag(HCI_FLAG_READ_VERSION);
        hcibuf[0] = 0x01; // HCI OCF = 1
        hcibuf[1] = 0x04 << 2; // HCI OGF = 4
        hcibuf[2] = 0x00;

        HCI_Command(hcibuf, 3);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(INFO_READ_LOCAL_VERSION_INFO)"), 0x80); // JMH Added
#endif
}

void BTD::hci_read_local_extended_features(uint8_t page_number) {
        hci_clear_flag(HCI_FLAG_LOCAL_EXTENDED_FEATURES);
        hcibuf[0] = 0x04; // HCI OCF = 4
        hcibuf[1] = 0x04 << 2; // HCI OGF = 4
        hcibuf[2] = 0x01; // parameter length = 1
        hcibuf[3] = page_number;

        HCI_Command(hcibuf, 4);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(INFO_READ_LOCAL_EXTENTED_FEATURES)"), 0x80); // JMH Added
#endif
}

void BTD::hci_accept_connection() {
        hci_clear_flag(HCI_FLAG_CONNECT_COMPLETE);
        hcibuf[0] = 0x09; // HCI OCF = 9
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x07; // parameter length 7
        hcibuf[3] = disc_bdaddr[0]; // 6 octet bdaddr
        hcibuf[4] = disc_bdaddr[1];
        hcibuf[5] = disc_bdaddr[2];
        hcibuf[6] = disc_bdaddr[3];
        hcibuf[7] = disc_bdaddr[4];
        hcibuf[8] = disc_bdaddr[5];
        hcibuf[9] = 0x00; // Switch role to master

        HCI_Command(hcibuf, 10);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_ACCEPT_CONNECTION)"), 0x80); // JMH Added
#endif
}

void BTD::hci_remote_name() {
        hci_clear_flag(HCI_FLAG_REMOTE_NAME_COMPLETE);
        hcibuf[0] = 0x19; // HCI OCF = 19
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x0A; // parameter length = 10
        hcibuf[3] = disc_bdaddr[0]; // 6 octet bdaddr
        hcibuf[4] = disc_bdaddr[1];
        hcibuf[5] = disc_bdaddr[2];
        hcibuf[6] = disc_bdaddr[3];
        hcibuf[7] = disc_bdaddr[4];
        hcibuf[8] = disc_bdaddr[5];
        hcibuf[9] = 0x01; // Page Scan Repetition Mode
        hcibuf[10] = 0x00; // Reserved
        hcibuf[11] = 0x00; // Clock offset - low byte
        hcibuf[12] = 0x00; // Clock offset - high byte

        HCI_Command(hcibuf, 13);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_REMOTE_NAME_REQUEST)"), 0x80); // JMH Added
#endif

}

void BTD::hci_write_local_name(const char* name) {
        hcibuf[0] = 0x13; // HCI OCF = 13
        hcibuf[1] = 0x03 << 2; // HCI OGF = 3
        hcibuf[2] = strlen(name) + 1; // parameter length = the length of the string + end byte
        uint8_t i;
        for(i = 0; i < strlen(name); i++)
                hcibuf[i + 3] = name[i];
        hcibuf[i + 3] = 0x00; // End of string

        HCI_Command(hcibuf, 4 + strlen(name));
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(HCI_WRITE_LOCAL_NAME)"), 0x80); // JMH Added
#endif

}

void BTD::hci_set_event_mask() {
        hcibuf[0] = 0x01; // HCI OCF = 01
        hcibuf[1] = 0x03 << 2; // HCI OGF = 3
        hcibuf[2] = 0x08; // parameter data length = 8 bytes
        // The first 6 bytes are the default of 1FFF FFFF FFFF
        // However we need to set bits 48-55 for simple pairing to work
        hcibuf[3] = 0xFF;  //bits 7 - 0
        hcibuf[4] = 0xFF;  //bits 15 - 8
        hcibuf[5] = 0xFF;  //bits 23 -16
        hcibuf[6] = 0xFD;  //bits 31 -24 //JMH Don't report Data Buffer Ovr Flow 0xFD;
        hcibuf[7] = 0xFF;  //bits 39 -32
        hcibuf[8] = 0b01111000;//0x1F;  //bits 47 -40 (JMH bits 40, 41,& 42 unassigned)
        hcibuf[9] = 0xFF;  // Enable bits 48-55 used for simple pairing
        hcibuf[10] = 0x00; //bits 63 -56
#ifdef EXTRADEBUG1
//        StrtDeBug = true;
        Notify(PSTR("\r\n***hci_set_event_mask***"), 0x80); // JMH Added
        HCI_Command(hcibuf, 11);
//        StrtDeBug = false;
#else
        HCI_Command(hcibuf, 11);
#endif
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(HCI_SET_EVENT_MASK)"), 0x80); // JMH Added
#endif

}
/*JMH Added to support older BlueTooth 2.1 dongles  */
void BTD::hci_set_connection_encryption(){
	hcibuf[0] = 0x13; // HCI OCF = 01
	hcibuf[1] = 0x01 << 2; // HCI OGF = 1
	hcibuf[2] = 0x03; // parameter data length = 8 bytes
	/* load current connection handle */
	hcibuf[3] = (uint8_t)(hci_handle & 0xFF); //connection handle - low byte
	hcibuf[4] = (uint8_t)((hci_handle >> 8) & 0x0F); //connection handle - high byte
	hcibuf[5] = 0x00; // turn encryption off
	HCI_Command(hcibuf, 6);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(HCI_SET_CONNECTION_ENCRYPTION)"), 0x80); // JMH Added
#endif

}


void BTD::hci_write_simple_pairing_mode(bool enable) {
        hcibuf[0] = 0x56; // HCI OCF = 56
        hcibuf[1] = 0x03 << 2; // HCI OGF = 3
        hcibuf[2] = 1; // parameter length = 1
        hcibuf[3] = enable ? 1 : 0;

        HCI_Command(hcibuf, 4);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(HCI_WRITE_SIMPLE_PAIRING_MODE)"), 0x80); // JMH Added
#endif

}

void BTD::hci_inquiry() {
        hci_clear_flag(HCI_FLAG_DEVICE_FOUND);
        hcibuf[0] = 0x01;
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x05; // Parameter Total Length = 5
        hcibuf[3] = 0x33; // LAP: General/Unlimited Inquiry Access Code (GIAC = 0x9E8B33) - see https://www.bluetooth.org/Technical/AssignedNumbers/baseband.htm
        hcibuf[4] = 0x8B;
        hcibuf[5] = 0x9E;
        hcibuf[6] = 0x30; // Inquiry time = 61.44 sec (maximum)
        hcibuf[7] = 0x0A; // 10 number of responses

        HCI_Command(hcibuf, 8);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_INQUIRY_START)"), 0x80); // JMH Added
#endif

}

void BTD::hci_inquiry_cancel() {
        hcibuf[0] = 0x02;
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x00; // Parameter Total Length = 0

        HCI_Command(hcibuf, 3);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_INQUIRY_CANCEL)"), 0x80); // JMH Added
#endif

}

void BTD::hci_connect() {
        hci_connect(disc_bdaddr); // Use last discovered device
}

void BTD::hci_connect(uint8_t *bdaddr) {
        hci_clear_flag(HCI_FLAG_CONNECT_COMPLETE | HCI_FLAG_CONNECT_EVENT);
        hcibuf[0] = 0x05; // HCI OCF = 5
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x0D; // parameter Total Length = 13
        hcibuf[3] = bdaddr[0]; // 6 octet bdaddr (LSB)
        hcibuf[4] = bdaddr[1];
        hcibuf[5] = bdaddr[2];
        hcibuf[6] = bdaddr[3];
        hcibuf[7] = bdaddr[4];
        hcibuf[8] = bdaddr[5];
        hcibuf[9] = 0x18; // DM1 or DH1 may be used
        hcibuf[10] = 0xCC; // DM3, DH3, DM5, DH5 may be used
        hcibuf[11] = 0x01; // Page repetition mode R1
        hcibuf[12] = 0x00; // Reserved
        hcibuf[13] = 0x00; // Clock offset
        hcibuf[14] = 0x00; // Invalid clock offset
        hcibuf[15] = 0x00; // Do not allow role switch

        HCI_Command(hcibuf, 16);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_CONNECT)"), 0x80); // JMH Added
#endif

}

void BTD::hci_pin_code_request_reply() {
        hcibuf[0] = 0x0D; // HCI OCF = 0D
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x17; // parameter length 23
        hcibuf[3] = disc_bdaddr[0]; // 6 octet bdaddr
        hcibuf[4] = disc_bdaddr[1];
        hcibuf[5] = disc_bdaddr[2];
        hcibuf[6] = disc_bdaddr[3];
        hcibuf[7] = disc_bdaddr[4];
        hcibuf[8] = disc_bdaddr[5];
        if(pairWithWii) {
                hcibuf[9] = 6; // Pin length is the length of the Bluetooth address
                if(pairWiiUsingSync) {
#ifdef EXTRADEBUG
                        Notify(PSTR("\r\nPairing with Wii controller via SYNC"), 0x80);
#endif
                        for(uint8_t i = 0; i < 6; i++)
                                hcibuf[10 + i] = my_bdaddr[i]; // The pin is the Bluetooth dongles Bluetooth address backwards
                } else {
                        for(uint8_t i = 0; i < 6; i++)
                                hcibuf[10 + i] = disc_bdaddr[i]; // The pin is the Wiimote's Bluetooth address backwards
                }
                for(uint8_t i = 16; i < 26; i++)
                        hcibuf[i] = 0x00; // The rest should be 0
        } else {
                hcibuf[9] = strlen(btdPin); // Length of pin
                uint8_t i;
                for(i = 0; i < strlen(btdPin); i++) // The maximum size of the pin is 16
                        hcibuf[i + 10] = btdPin[i];
                for(; i < 16; i++)
                        hcibuf[i + 10] = 0x00; // The rest should be 0
        }

        HCI_Command(hcibuf, 26);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_PINCODE_REQUEST_REPLY)"), 0x80); // JMH Added
#endif

}

void BTD::hci_pin_code_negative_request_reply() {
        hcibuf[0] = 0x0E; // HCI OCF = 0E
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x06; // parameter length 6
        hcibuf[3] = disc_bdaddr[0]; // 6 octet bdaddr
        hcibuf[4] = disc_bdaddr[1];
        hcibuf[5] = disc_bdaddr[2];
        hcibuf[6] = disc_bdaddr[3];
        hcibuf[7] = disc_bdaddr[4];
        hcibuf[8] = disc_bdaddr[5];

        HCI_Command(hcibuf, 9);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_PINCODE_NEGATIVE_REQUEST_REPLY)"), 0x80); // JMH Added
#endif

}

void BTD::hci_link_key_request_negative_reply() {
        hcibuf[0] = 0x0C; // HCI OCF = 0C
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x06; // parameter length 6
        hcibuf[3] = disc_bdaddr[0]; // 6 octet bdaddr
        hcibuf[4] = disc_bdaddr[1];
        hcibuf[5] = disc_bdaddr[2];
        hcibuf[6] = disc_bdaddr[3];
        hcibuf[7] = disc_bdaddr[4];
        hcibuf[8] = disc_bdaddr[5];

        HCI_Command(hcibuf, 9);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_KEY_NEGATIVE_REQUEST_REPLY)"), 0x80); // JMH Added
#endif

}
/* JMH added command/method */
void BTD::hci_link_Key_Request_Reply() {
        hcibuf[0] = 0x0B; // HCI OCF = 0B
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        /*parameters BD_ADDR, Status, Link_Key */
        hcibuf[2] = 0x16; // parameter length 6
        hcibuf[3] = disc_bdaddr[0]; // 6 octet bdaddr
        hcibuf[4] = disc_bdaddr[1];
        hcibuf[5] = disc_bdaddr[2];
        hcibuf[6] = disc_bdaddr[3];
        hcibuf[7] = disc_bdaddr[4];
        hcibuf[8] = disc_bdaddr[5];

        hcibuf[ 9] = disc_key[0]; // 16 octet key
        hcibuf[10] = disc_key[1];
        hcibuf[11] = disc_key[2];
        hcibuf[12] = disc_key[3];
        hcibuf[13] = disc_key[4];
        hcibuf[14] = disc_key[5];
        hcibuf[15] = disc_key[6];
        hcibuf[16] = disc_key[7];
		hcibuf[17] = disc_key[8];
		hcibuf[18] = disc_key[9];
		hcibuf[19] = disc_key[10];
		hcibuf[20] = disc_key[11];
		hcibuf[21] = disc_key[12];
		hcibuf[22] = disc_key[13];
		hcibuf[23] = disc_key[14];
		hcibuf[24] = disc_key[15];

        HCI_Command(hcibuf, 25);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_KEY_REPLY)"), 0x80); // JMH Added
#endif

}


void BTD::hci_io_capability_request_reply() {
        hcibuf[0] = 0x2B; // HCI OCF = 2B
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x09;
        hcibuf[3] = disc_bdaddr[0]; // 6 octet bdaddr
        hcibuf[4] = disc_bdaddr[1];
        hcibuf[5] = disc_bdaddr[2];
        hcibuf[6] = disc_bdaddr[3];
        hcibuf[7] = disc_bdaddr[4];
        hcibuf[8] = disc_bdaddr[5];
        hcibuf[9] = 0x03; // NoInputNoOutput
        hcibuf[10] = 0x00; // OOB authentication data not present
        hcibuf[11] = 0x00; // MITM Protection Not Required – No Bonding. Numeric comparison with automatic accept allowed

        HCI_Command(hcibuf, 12);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_IO_CAPABILITY_REQUEST_REPLY)"), 0x80); // JMH Added
#endif

}

void BTD::rprt_HCI_event(uint8_t EvntCd){
	int i;
	int EvntCdSz = 39;
//	if(EvntCd == 0x38)
//		delay(0);
	for(i = 0; i < EvntCdSz; i++){
		if(HCIevents[i].Ecode == EvntCd) break;
	}
	if(i == EvntCdSz){
		Notify(PSTR("(UNDOCUMENTED EVENT)"), 0x80);
		return;
	}
//	char buf[45];
//    for(int ptr =0; ptr < sizeof(buf); ptr++){
//    	buf[ptr] = HCIevents[i].EventName[ptr];
//    	if(HCIevents[i].EventName[ptr]==0) break;
//    }
	Notify(PSTR("("), 0x80);
	Serial.print(HCIevents[i].EventName);
	Notify(PSTR(")"), 0x80);
}

void BTD::hci_user_confirmation_request_reply() {
        hcibuf[0] = 0x2C; // HCI OCF = 2C
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x06; // parameter length 6
        hcibuf[3] = disc_bdaddr[0]; // 6 octet bdaddr
        hcibuf[4] = disc_bdaddr[1];
        hcibuf[5] = disc_bdaddr[2];
        hcibuf[6] = disc_bdaddr[3];
        hcibuf[7] = disc_bdaddr[4];
        hcibuf[8] = disc_bdaddr[5];

        HCI_Command(hcibuf, 9);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_USER_CONFIRMATION_REQUEST_REPLY)"), 0x80); // JMH Added
#endif

}

void BTD::hci_authentication_request() {
        hcibuf[0] = 0x11; // HCI OCF = 11
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x02; // parameter length = 2
        hcibuf[3] = (uint8_t)(hci_handle & 0xFF); //connection handle - low byte
        hcibuf[4] = (uint8_t)((hci_handle >> 8) & 0x0F); //connection handle - high byte

        HCI_Command(hcibuf, 5);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_AUTHENTICATION_REQUEST)"), 0x80); // JMH Added
#endif

}

void BTD::hci_disconnect(uint16_t handle) { // This is called by the different services
        hci_clear_flag(HCI_FLAG_DISCONNECT_COMPLETE);
        hcibuf[0] = 0x06; // HCI OCF = 6
        hcibuf[1] = 0x01 << 2; // HCI OGF = 1
        hcibuf[2] = 0x03; // parameter length = 3
        hcibuf[3] = (uint8_t)(handle & 0xFF); //connection handle - low byte
        hcibuf[4] = (uint8_t)((handle >> 8) & 0x0F); //connection handle - high byte
        hcibuf[5] = 0x13; // reason

        HCI_Command(hcibuf, 6);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_DISCONNECT)"), 0x80); // JMH Added
#endif

}

void BTD::hci_write_class_of_device() { // See http://bluetooth-pentest.narod.ru/software/bluetooth_class_of_device-service_generator.html
        hcibuf[0] = 0x24; // HCI OCF = 24
        hcibuf[1] = 0x03 << 2; // HCI OGF = 3
        hcibuf[2] = 0x03; // parameter length = 3
        hcibuf[3] = 0x04; // Robot
        hcibuf[4] = 0x08; // Toy
        hcibuf[5] = 0x00;

        HCI_Command(hcibuf, 6);
#ifdef SHOWEVENTSEQNC
        Notify(PSTR("(LINK_WRITE_CLASS_OF_DEVICE)"), 0x80); // JMH Added
#endif

}

void BTD::rprt_HCI_error(uint8_t ErrCd){//JMH added
	int i;
		for(i = 0; i <sizeof(HCIerrs); i++){
			if(HCIerrs[i].Ecode == ErrCd) break;
		}
		if(i == sizeof(HCIerrs)) return;
		Notify(PSTR("["), 0x80);
		Serial.print(HCIerrs[i].EventName);
		Notify(PSTR("]"), 0x80);
}

void BTD::rprt_HCI_versn(uint8_t ErrCd){//JMH added
	int i;
		for(i = 0; i <sizeof(DnglVer); i++){
			if(DnglVer[i].Ecode == ErrCd) break;
		}
		if(i == sizeof(DnglVer)) return;
		Notify(PSTR("["), 0x80);
		Serial.print(DnglVer[i].EventName);
		Notify(PSTR("]"), 0x80);
}

void BTD::Rtn_StateStr(uint8_t ErrCd, char* bufptr){//JMH added
	unsigned int i;
		for(i = 0; i <sizeof(HCIstatus); i++){
			if(HCIstatus[i].Ecode == ErrCd) break;
		}
		if(i == sizeof(HCIstatus)) return;
		sprintf(bufptr,"%s",HCIstatus[i].EventName);

}
/*******************************************************************
 *                                                                 *
 *                        HCI ACL Data Packet                      *
 *                                                                 *
 *   buf[0]          buf[1]          buf[2]          buf[3]
 *   0       4       8    11 12      16              24            31 MSB
 *  .-+-+-+-+-+-+-+-|-+-+-+-|-+-|-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-.
 *  |      HCI Handle       |PB |BC |       Data Total Length       |   HCI ACL Data Packet
 *  .-+-+-+-+-+-+-+-|-+-+-+-|-+-|-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-.
 *
 *   buf[4]          buf[5]          buf[6]          buf[7]
 *   0               8               16                            31 MSB
 *  .-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-.
 *  |            Length             |          Channel ID           |   Basic L2CAP header
 *  .-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-.
 *
 *   buf[8]          buf[9]          buf[10]         buf[11]
 *   0               8               16                            31 MSB
 *  .-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-.
 *  |     Code      |  Identifier   |            Length             |   Control frame (C-frame)
 *  .-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-|-+-+-+-+-+-+-+-.   (signaling packet format)
 */
/************************************************************/
/*                    L2CAP Commands                        */

/************************************************************/
void BTD::L2CAP_Command(uint16_t handle, uint8_t* data, uint8_t nbytes, uint8_t channelLow, uint8_t channelHigh) {
        uint8_t buf[8 + nbytes];
        buf[0] = (uint8_t)(handle & 0xff); // HCI handle with PB,BC flag
        buf[1] = (uint8_t)(((handle >> 8) & 0x0f) | 0x20);
        buf[2] = (uint8_t)((4 + nbytes) & 0xff); // HCI ACL total data length
        buf[3] = (uint8_t)((4 + nbytes) >> 8);
        buf[4] = (uint8_t)(nbytes & 0xff); // L2CAP header: Length
        buf[5] = (uint8_t)(nbytes >> 8);
        buf[6] = channelLow;
        buf[7] = channelHigh;

        for(uint16_t i = 0; i < nbytes; i++) // L2CAP C-frame
                buf[8 + i] = data[i];

        uint8_t rcode = pUsb->outTransfer(bAddress, epInfo[ BTD_DATAOUT_PIPE ].epAddr, (8 + nbytes), buf);
        if(rcode) {
                delay(100); // This small delay prevents it from overflowing if it fails
#ifdef EXTRADEBUG
                Notify(PSTR("\r\nError sending L2CAP message: 0x"), 0x80);
                D_PrintHex<uint8_t > (rcode, 0x80);
                Notify(PSTR(" - Channel ID: "), 0x80);
                D_PrintHex<uint8_t > (channelHigh, 0x80);
                Notify(PSTR(" "), 0x80);
                D_PrintHex<uint8_t > (channelLow, 0x80);
#endif
        }
}

void BTD::l2cap_connection_request(uint16_t handle, uint8_t rxid, uint8_t* scid, uint16_t psm) {
        l2capoutbuf[0] = L2CAP_CMD_CONNECTION_REQUEST; // Code
        l2capoutbuf[1] = rxid; // Identifier
        l2capoutbuf[2] = 0x04; // Length
        l2capoutbuf[3] = 0x00;
        l2capoutbuf[4] = (uint8_t)(psm & 0xff); // PSM
        l2capoutbuf[5] = (uint8_t)(psm >> 8);
        l2capoutbuf[6] = scid[0]; // Source CID
        l2capoutbuf[7] = scid[1];

        L2CAP_Command(handle, l2capoutbuf, 8);
}

void BTD::l2cap_connection_response(uint16_t handle, uint8_t rxid, uint8_t* dcid, uint8_t* scid, uint8_t result) {
        l2capoutbuf[0] = L2CAP_CMD_CONNECTION_RESPONSE; // Code
        l2capoutbuf[1] = rxid; // Identifier
        l2capoutbuf[2] = 0x08; // Length
        l2capoutbuf[3] = 0x00;
        l2capoutbuf[4] = dcid[0]; // Destination CID
        l2capoutbuf[5] = dcid[1];
        l2capoutbuf[6] = scid[0]; // Source CID
        l2capoutbuf[7] = scid[1];
        l2capoutbuf[8] = result; // Result: Pending or Success
        l2capoutbuf[9] = 0x00;
        l2capoutbuf[10] = 0x00; // No further information
        l2capoutbuf[11] = 0x00;

        L2CAP_Command(handle, l2capoutbuf, 12);
}

void BTD::l2cap_config_request(uint16_t handle, uint8_t rxid, uint8_t* dcid) {
        l2capoutbuf[0] = L2CAP_CMD_CONFIG_REQUEST; // Code
        l2capoutbuf[1] = rxid; // Identifier
        l2capoutbuf[2] = 0x08; // Length
        l2capoutbuf[3] = 0x00;
        l2capoutbuf[4] = dcid[0]; // Destination CID
        l2capoutbuf[5] = dcid[1];
        l2capoutbuf[6] = 0x00; // Flags
        l2capoutbuf[7] = 0x00;
        l2capoutbuf[8] = 0x01; // Config Opt: type = MTU (Maximum Transmission Unit) - Hint
        l2capoutbuf[9] = 0x02; // Config Opt: length
        l2capoutbuf[10] = 0xFF; // MTU
        l2capoutbuf[11] = 0xFF;

        L2CAP_Command(handle, l2capoutbuf, 12);
}

void BTD::l2cap_config_response(uint16_t handle, uint8_t rxid, uint8_t* scid) {
        l2capoutbuf[0] = L2CAP_CMD_CONFIG_RESPONSE; // Code
        l2capoutbuf[1] = rxid; // Identifier
        l2capoutbuf[2] = 0x0A; // Length
        l2capoutbuf[3] = 0x00;
        l2capoutbuf[4] = scid[0]; // Source CID
        l2capoutbuf[5] = scid[1];
        l2capoutbuf[6] = 0x00; // Flag
        l2capoutbuf[7] = 0x00;
        l2capoutbuf[8] = 0x00; // Result
        l2capoutbuf[9] = 0x00;
        l2capoutbuf[10] = 0x01; // Config
        l2capoutbuf[11] = 0x02;
        l2capoutbuf[12] = 0xA0;
        l2capoutbuf[13] = 0x02;

        L2CAP_Command(handle, l2capoutbuf, 14);
}

void BTD::l2cap_disconnection_request(uint16_t handle, uint8_t rxid, uint8_t* dcid, uint8_t* scid) {
        l2capoutbuf[0] = L2CAP_CMD_DISCONNECT_REQUEST; // Code
        l2capoutbuf[1] = rxid; // Identifier
        l2capoutbuf[2] = 0x04; // Length
        l2capoutbuf[3] = 0x00;
        l2capoutbuf[4] = dcid[0];
        l2capoutbuf[5] = dcid[1];
        l2capoutbuf[6] = scid[0];
        l2capoutbuf[7] = scid[1];

        L2CAP_Command(handle, l2capoutbuf, 8);
}

void BTD::l2cap_disconnection_response(uint16_t handle, uint8_t rxid, uint8_t* dcid, uint8_t* scid) {
        l2capoutbuf[0] = L2CAP_CMD_DISCONNECT_RESPONSE; // Code
        l2capoutbuf[1] = rxid; // Identifier
        l2capoutbuf[2] = 0x04; // Length
        l2capoutbuf[3] = 0x00;
        l2capoutbuf[4] = dcid[0];
        l2capoutbuf[5] = dcid[1];
        l2capoutbuf[6] = scid[0];
        l2capoutbuf[7] = scid[1];

        L2CAP_Command(handle, l2capoutbuf, 8);
}

void BTD::l2cap_information_response(uint16_t handle, uint8_t rxid, uint8_t infoTypeLow, uint8_t infoTypeHigh) {
        l2capoutbuf[0] = L2CAP_CMD_INFORMATION_RESPONSE; // Code
        l2capoutbuf[1] = rxid; // Identifier
        l2capoutbuf[2] = 0x08; // Length
        l2capoutbuf[3] = 0x00;
        l2capoutbuf[4] = infoTypeLow;
        l2capoutbuf[5] = infoTypeHigh;
        l2capoutbuf[6] = 0x00; // Result = success
        l2capoutbuf[7] = 0x00; // Result = success
        l2capoutbuf[8] = 0x00;
        l2capoutbuf[9] = 0x00;
        l2capoutbuf[10] = 0x00;
        l2capoutbuf[11] = 0x00;

        L2CAP_Command(handle, l2capoutbuf, 12);
}

/* PS3 Commands - only set Bluetooth address is implemented in this library */
void BTD::setBdaddr(uint8_t* bdaddr) {
        /* Set the internal Bluetooth address */
        uint8_t buf[8];
        buf[0] = 0x01;
        buf[1] = 0x00;

        for(uint8_t i = 0; i < 6; i++)
                buf[i + 2] = bdaddr[5 - i]; // Copy into buffer, has to be written reversed, so it is MSB first

        // bmRequest = Host to device (0x00) | Class (0x20) | Interface (0x01) = 0x21, bRequest = Set Report (0x09), Report ID (0xF5), Report Type (Feature 0x03), interface (0x00), datalength, datalength, data
        pUsb->ctrlReq(bAddress, epInfo[BTD_CONTROL_PIPE].epAddr, bmREQ_HID_OUT, HID_REQUEST_SET_REPORT, 0xF5, 0x03, 0x00, 8, 8, buf, NULL);
}

void BTD::setMoveBdaddr(uint8_t* bdaddr) {
        /* Set the internal Bluetooth address */
        uint8_t buf[11];
        buf[0] = 0x05;
        buf[7] = 0x10;
        buf[8] = 0x01;
        buf[9] = 0x02;
        buf[10] = 0x12;

        for(uint8_t i = 0; i < 6; i++)
                buf[i + 1] = bdaddr[i];

        // bmRequest = Host to device (0x00) | Class (0x20) | Interface (0x01) = 0x21, bRequest = Set Report (0x09), Report ID (0x05), Report Type (Feature 0x03), interface (0x00), datalength, datalength, data
        pUsb->ctrlReq(bAddress, epInfo[BTD_CONTROL_PIPE].epAddr, bmREQ_HID_OUT, HID_REQUEST_SET_REPORT, 0x05, 0x03, 0x00, 11, 11, buf, NULL);
}

