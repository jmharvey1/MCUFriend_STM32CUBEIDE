/*
 * KeyBoardR01.h
 *
 *  Created on: Oct 6, 2021
 *      Author: jim
 */

#ifndef INC_KEYBOARDR01_H_
#define INC_KEYBOARDR01_H_

#include "CWSndEngn.h"
#include "TFTMsgBox.h"
//#define TFTOUTPUT //enable to direct Serial.print calls to the TFT Display
extern CWSNDENGN CWsndengn;
extern TFTMsgBox tftmsgbx;
extern char MyCall[10];
void dispMsg(char Msgbuf[50], uint16_t Color);
template <class T>
void HexStr(T val, char* bufptr) {
        int num_nibbles = sizeof (T) * 2;
        int i = 0;
        do {
                char v = 48 + (((val >> (num_nibbles - 1) * 4)) & 0x0f);
                if(v > 57) v += 7;
                bufptr[i] = v;
                i++;
        } while(--num_nibbles);
        bufptr[i] = 0;
}
#endif /* INC_KEYBOARDR01_H_ */
