/*
 * TFTMsgBox.cpp
 *
 *  Created on: Oct 7, 2021
 *      Author: jim
 */
#include "TFTMsgBox.h"

TFTMsgBox::TFTMsgBox( MCUFRIEND_kbv *tft_ptr){
	ptft = tft_ptr;
	RingbufPntr1 =0;
	RingbufPntr2 =0;

	CPL = 40; //number of characters each line that a 3.5" screen can contain
	row = 10; //number of usable rows on a 3.5" screen
	fontH = 16;
	fontW = 12;
	CursorPntr = 0;
	cursorY = 0;
	cursorX = 0;
	cnt = 0; //used in scrollpage routine
	curRow = 0;
	offset = 0;
	BlkState = false;
};

void TFTMsgBox::InitDsplay(void){
	ptft->reset();
	uint16_t ID = ptft->readID();
	if (ID == 0x9090) ID = 0x9486; //do this to fix color issues
	ptft->begin(ID);//  The value here is screen specific & depends on the chipset used to drive the screen,
	ptft->setRotation(1); // valid values 1 or 3
	ptft->fillScreen(TFT_BLACK);
	ptft->fillScreen(TFT_BLACK);
	ptft->setCursor(cursorX, cursorY);
	ptft->setTextColor(TFT_WHITE);//tft.setTextColor(WHITE, BLACK);
	ptft->setTextSize(2);
	ptft->setTextWrap(false);
	displayW = ptft->width();
};
/* normally called by the Keyboard parser process
 * the main feature of this entry point is to set
 * the cursor position pointer
 */
void TFTMsgBox::KBentry(char Ascii) {
	char buf[2];
	buf[0] = Ascii;
	buf[1] = 0;
	if(CursorPntr == 0) CursorPntr = cnt;
	dispMsg(buf, TFT_WHITE);
};
void TFTMsgBox::dispMsg(char Msgbuf[50], uint16_t Color) {
	int msgpntr = 0;
	/* Add the contents of the Msgbuf to ringbuffer */
	/* But 1st, Kill interrupts from MAX3421 */
//	uint8_t CPUCTLval = Usb.regRd(rCPUCTL);
//	CPUCTLval = CPUCTLval & 0xFE;
//	Usb.regWr(rCPUCTL, CPUCTLval); //Disable interrupt pin
	while ( Msgbuf[msgpntr] != 0) {
		if(RingbufPntr1 < RingBufSz-1) RingbufChar[RingbufPntr1+1] = 0;
		else RingbufChar[0] = 0;
		RingbufChar[RingbufPntr1] = Msgbuf[msgpntr];
		RingbufClr[RingbufPntr1] = Color;
		RingbufPntr1++;
		if(RingbufPntr1 == RingBufSz) RingbufPntr1 = 0;
		msgpntr++;
	}
	/* Restore interrupts from MAX3421 */
//	CPUCTLval = Usb.regRd(rCPUCTL);
//	CPUCTLval = CPUCTLval | 0x01;
//	Usb.regWr(rCPUCTL, CPUCTLval); //enable interrupt pin
};
/* timer interrupt driven method. drives the Ringbuffer pointer to ensure that
 * character(s) sent to TFT Display actually get printed (when time permits)
 */
void TFTMsgBox::dispMsg2(void) {
	while ( RingbufPntr2!= RingbufPntr1) {
		ptft->setCursor(cursorX, cursorY);

		char curChar = RingbufChar[RingbufPntr2];
		uint16_t Color = RingbufClr[RingbufPntr2];
		if(curChar != 10){ //test for "line feed" character
			ptft->setTextColor( RingbufClr[RingbufPntr2] );
			ptft->print(curChar);
			/* If needed add this character to the Pgbuf */
			if (curRow > 0) {
				Pgbuf[cnt-CPL] = curChar;
				Pgbuf[cnt-(CPL-1)] = 0;
				PgbufColor[cnt-CPL] = Color;
			}
			cnt++;
			if ((cnt - offset)*fontW >= displayW) {
				curRow++;
				cursorX = 0;
				cursorY = curRow * (fontH + 10);
				offset = cnt;
				ptft->setCursor(cursorX, cursorY);
				if (curRow + 1 > row) {
					scrollpg();
				}
			}
			else{
				cursorX = (cnt - offset) * fontW;
			}
		}else{
			DisplCrLf();
		}
		RingbufPntr2++;
		if(RingbufPntr2 == RingBufSz) RingbufPntr2 = 0;
	}// End while loop
};
//////////////////////////////////////////////////////////////////////
void TFTMsgBox::Delete(int ChrCnt){
	while(ChrCnt !=0){// delete display of ever how many characters were printed in the last decodeval (may be more than one letter generated)
		//first,buzz thru the pgbuf array until we find the the last character (delete the last character in the pgbuf)
		int TmpPntr = 0;
		while(Pgbuf[TmpPntr]!=0) TmpPntr++;
		if(TmpPntr>0) Pgbuf[TmpPntr-1] =0;// delete last character in the array by replacing it with a "0"
		cnt--;
		int xoffset = cnt;
		//use xoffset to locate the character position (on the display's x axis)
		curRow = 0;
		while (xoffset >= CPL){
			xoffset -=CPL;
			curRow++;
		}
		cursorX  =  xoffset*(fontW);
		cursorY = curRow * (fontH + 10);
		if(xoffset==(CPL-1)) offset= offset-CPL; //we just jump back to last letter in the previous line, So we need setup to properly calculate what display row we will be on, come the next character
		ptft->fillRect(cursorX, cursorY, fontW+4, (fontH + 10), TFT_BLACK); //black out/erase last displayed character
		ptft->setCursor(cursorX, cursorY);
		--ChrCnt;
	}
};
//////////////////////////////////////////////////////////////////////
void TFTMsgBox::DisplCrLf(void){
	/* Pad the remainder of the line with space */
	if((cnt-offset)==0) return;
	int curOS = offset;
	ptft->setTextColor( TFT_BLACK);
	while((cnt - curOS)*fontW <= displayW) {
		ptft->print(" "); //ASCII "Space"
		/* If needed add this character to the Pgbuf */
		if (curRow > 0) {
			Pgbuf[cnt-CPL] = 32;
			Pgbuf[cnt-(CPL-1)] = 0;
			PgbufColor[cnt-CPL] = TFT_BLACK;
		}
		cnt++;
		if ((cnt - offset)*fontW >= displayW) {
			curRow++;
			cursorX = 0;
			cursorY = curRow * (fontH + 10);
			offset = cnt;
			ptft->setCursor(cursorX, cursorY);
			if (curRow + 1 > row) {
				scrollpg();
				return;
			}
		}
		else{
			cursorX = (cnt - offset) * fontW;
		}
		if(((curOS+CPL)-cnt)==0) break;
	}
};
//////////////////////////////////////////////////////////////////////
void TFTMsgBox::scrollpg() {
	//buttonEnabled =false;
	BlkState = true;
	cursorX = 0;
	cnt = 0;
	cursorY = 0;
	curRow = 0;
	offset = 0;
	bool PrintFlg = true;
	int curptr = RingbufPntr1;
	if(RingbufPntr2> RingbufPntr1) curptr = RingbufPntr1+RingBufSz;
	if((curptr-RingbufPntr2)>CPL-1) PrintFlg = false;
	//  enableDisplay(); //this is for touch screen support
	if(PrintFlg){
		ptft->fillRect(cursorX, cursorY, displayW, row * (fontH + 10), TFT_BLACK); //erase current page of text
		ptft->setCursor(cursorX, cursorY);
	}
	while (Pgbuf[cnt] != 0 && curRow + 1 < row) { //print current page buffer and move current text up one line
		if(PrintFlg){
			ptft->setTextColor(PgbufColor[cnt]);
			ptft->print(Pgbuf[cnt]);
		}
		Pgbuf[cnt] = Pgbuf[cnt + CPL]; //shift existing text character forward by one line
		PgbufColor[cnt] = PgbufColor[cnt+CPL];
		cnt++;
		if (((cnt) - offset)*fontW >= displayW) {
			curRow++;
			offset = cnt;
			cursorX = 0;
			cursorY = curRow * (fontH + 10);
			if(PrintFlg) ptft->setCursor(cursorX, cursorY);
		}
		else cursorX = (cnt - offset) * fontW;

	}//end While Loop
	if(!PrintFlg){ //clear last line of text
		ptft->fillRect(cursorX, cursorY, displayW, (fontH + 10), TFT_BLACK); //erase current page of text
		ptft->setCursor(cursorX, cursorY);
	}
	/* And if needed, move the CursorPntr up on line*/
	if(CursorPntr - CPL> 0) CursorPntr = CursorPntr - CPL;
	BlkState = false;
};

void TFTMsgBox::IntrCrsr(int state){
	/* state codes
		0 No activity
		1 Processing
		2 Letter Complete
		3 Start Space
		4 Start Character
		5 End Space & Start Next Character
	 */
	if(BlkState) return;
	switch (state){
	case 0:// No activity
		CursorPntr = cnt;
		break; //do nothing
	case 1:// Processing
		break; //do nothing
	case 2:// Letter Complete
		RestoreBG();//restore normal Background
		break;
	case 3:// Start Space
		HiLiteBG();//Highlight Background
		break;
	case 4:// Start Letter
		HiLiteBG();//Highlight Background
		break;
	case 5:// restore Backgound & Highlight Next Character or Space
		if(CursorPntr+1 >=cnt) CursorPntr = cnt-1;//test, just in case something got screwed up
		RestoreBG();//restore normal Background
		HiLiteBG();//Highlight Background
		break;
	}
	return;

};
void TFTMsgBox::HiLiteBG(void){
	PosHiLiteCusr();
	ptft->setTextColor(PgbufColor[CursorPntr-CPL], TFT_RED);
	ptft->print(Pgbuf[CursorPntr-CPL]);
	ptft->setTextColor(TFT_WHITE, TFT_BLACK);// restore normal color scheme
    // dont need to put Cursor back, other calls to print will do that
};
void TFTMsgBox::RestoreBG(void){
	PosHiLiteCusr();
	ptft->setTextColor(PgbufColor[CursorPntr-CPL], TFT_BLACK);
	ptft->print(Pgbuf[CursorPntr-CPL]);
	CursorPntr++;
	//if(CursorPntr == cnt) CursorPntr = 0;
};
void TFTMsgBox::PosHiLiteCusr(void){
	/* figure out where the HighLight Y cursor needs to be set */
	int HLY = 0;
	int HLX = 0;
	int tmppntr = 0;
	int tmprow = 1;
	while(tmppntr +CPL<=CursorPntr){
		tmprow++;
		tmppntr +=CPL;
	}
	HLY = (tmprow-1) * (fontH + 10);
	HLX = (CursorPntr -((tmprow-1) * CPL))*fontW;
	ptft->setCursor(HLX, HLY);
};

void TFTMsgBox::dispStat(char Msgbuf[50], uint16_t Color){
	int i;
	//	ptft->fillRect(StatusX, StatusY, (displayW-StatusX), (fontH + 10), TFT_BLACK);
	ptft->setCursor(StatusX, StatusY);
	ptft->setTextColor(Color, TFT_BLACK);
	/* 1st figure out how many leading spaces to print to "center"
	 * the Status message
	 */
	int availspace = int((410-StatusX)/fontW);
	i = 0;
	while(Msgbuf[i] != 0) i++;
	int LdSpaceCnt = int((availspace- i)/2);
	if(LdSpaceCnt>0){
		for(i = 0; i<LdSpaceCnt; i++){
			ptft->print(" ");
		}
	}
	for(i = 0; i< 50; i++){
		if(Msgbuf[i] == 0) break;
		if(i*fontW >= (410-StatusX)) break;//410 is where the WPM text starts
		ptft->print(Msgbuf[i]);
	}
	/*finish out remainder of line with blank space */
	//	ptft->setTextColor(TFT_BLACK);
	while((i+LdSpaceCnt)*fontW <= (410-StatusX)) {
		ptft->print(" ");
		i++;
	}
};

