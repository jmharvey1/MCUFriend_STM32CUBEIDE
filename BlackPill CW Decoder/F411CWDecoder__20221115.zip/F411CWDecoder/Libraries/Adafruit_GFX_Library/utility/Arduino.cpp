/*
 * Arduino.cpp
 *
 *  Created on: Feb 16, 2021
 *      Author: jim
 */
#include "Arduino.h"
#include "STM32F411def.h"
#include "main.h"
//typedef struct PinPrt {
//	uint16_t Pin;
//	GPIO_TypeDef* Port;
//}PinPrtdef;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim3;
ADC_HandleTypeDef hadc1  = {0};
ADC_ChannelConfTypeDef sConfig  = {0};
int OldPin = 255;

PinPrt PinXlate(uint8_t pin){
	PinPrt def = {0};
	int intPin = (int)pin;
	switch(intPin) {
	      case 0 :
	         def.Pin = GPIO_PIN_0;
	         def.Port = GPIOA;
	         break;
	      case 1 :
	    	  def.Pin = GPIO_PIN_1;
	    	  def.Port = GPIOA;
	    	  break;
	      case 2 :
	         def.Pin = GPIO_PIN_2;
	         def.Port = GPIOA;
	         break;
	      case 3 :
	    	  def.Pin = GPIO_PIN_3;
	    	  def.Port = GPIOA;
	    	  break;
	      case 4 :
	         def.Pin = GPIO_PIN_4;
	         def.Port = GPIOA;
	         break;
	      case 5 :
	    	  def.Pin = GPIO_PIN_5;
	    	  def.Port = GPIOA;
	    	  break;
	      case 6 :
	         def.Pin = GPIO_PIN_6;
	         def.Port = GPIOA;
	         break;
	      case 7 :
	    	  def.Pin = GPIO_PIN_7;
	    	  def.Port = GPIOA;
	    	  break;
	      case 16 :
	         def.Pin = GPIO_PIN_0;
	         def.Port = GPIOB;
	         break;
	      case 17 :
	    	  def.Pin = GPIO_PIN_1;
	    	  def.Port = GPIOB;
	    	  break;
	      case 18 :
	         def.Pin = GPIO_PIN_2;
	         def.Port = GPIOB;
	         break;
	      case 19 :
	    	  def.Pin = GPIO_PIN_3;
	    	  def.Port = GPIOB;
	    	  break;
	      case 20 :
	         def.Pin = GPIO_PIN_4;
	         def.Port = GPIOB;
	         break;
	      case 21 :
	    	  def.Pin = GPIO_PIN_5;
	    	  def.Port = GPIOB;
	    	  break;
	      case 22 :
	         def.Pin = GPIO_PIN_6;
	         def.Port = GPIOB;
	         break;
	      case 23 :
	    	  def.Pin = GPIO_PIN_7;
	    	  def.Port = GPIOB;
	    	  break;
	      case 24 ://20210825 JMH added this pin definition
	    	  def.Pin = GPIO_PIN_8;
	    	  def.Port = GPIOB;
	    	  break;
	      default :
	    	  def.Pin = 0xFFF;
	    	  //def.Port = 0xFFFF;
	}
	return def;
}

void pinMode(uint8_t pin, uint8_t mode){
	PinPrt gpiodef = PinXlate(pin);
	if ((gpiodef.Pin == 0xFFFF)) return;//abort

	GPIO_InitTypeDef GPIO_InitStruct = {0};
	//	/*Configure GPIO pin : Mode1_Pin */
	GPIO_InitStruct.Pin = gpiodef.Pin;
	if(mode == INPUT_PULLUP){
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
		GPIO_InitStruct.Pull = GPIO_PULLUP;
	}else if (mode == OUTPUT){
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	}
	HAL_GPIO_Init(gpiodef.Port , &GPIO_InitStruct);
}
void digitalWrite(uint8_t pin, uint8_t state){
	PinPrt gpiodef = PinXlate(pin);
	if ((gpiodef.Pin == 0xFFFF)) return;//abort
	if(state==HIGH) PIN_HIGH(gpiodef.Port, gpiodef.Pin);
	else PIN_LOW(gpiodef.Port, gpiodef.Pin);
}

//int analogRead(uint8_t pin, ADC_HandleTypeDef hadc1){
int analogRead(uint8_t pin){
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	int intPin = (int)pin;
	uint8_t ADCchnl;
	int reading =0;
	if (OldPin != pin){
		OldPin = pin;

/* configure selected pin for ADC input */
	PinPrt gpiodef = PinXlate(pin);
    GPIO_InitStruct.Pin = gpiodef.Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(gpiodef.Port, &GPIO_InitStruct);
/* Find the ADC Channel the selected pin is linked to */
    switch(intPin) {
	case 0 :
		ADCchnl = ADC_CHANNEL_0;
		break;
	case 1 :
		ADCchnl = ADC_CHANNEL_1;
		break;
	case 2 :
		ADCchnl = ADC_CHANNEL_2;
		break;
	case 3 :
		ADCchnl = ADC_CHANNEL_3;
		break;
	case 4 :
		ADCchnl = ADC_CHANNEL_4;
		break;
	case 5 :
		ADCchnl = ADC_CHANNEL_5;
		break;
	case 6 :
		ADCchnl = ADC_CHANNEL_6;
		break;
	case 7 :
		ADCchnl = ADC_CHANNEL_7;
		break;
	case 16 :
		ADCchnl = ADC_CHANNEL_8;
		break;
	case 17 :
		ADCchnl = ADC_CHANNEL_9;
		break;
	case 18 :
		ADCchnl = ADC_CHANNEL_10;
		break;
	case 19 :
		ADCchnl = ADC_CHANNEL_11;
		break;
	case 20 :
		ADCchnl = ADC_CHANNEL_12;
		break;
	case 21 :
		ADCchnl = ADC_CHANNEL_13;
		break;
	case 22 :
		ADCchnl = ADC_CHANNEL_14;
		break;
	case 23 :
		ADCchnl = ADC_CHANNEL_15;
		break;
	default :
		return 0;
	}
    /* this is the 1st time through, Configure ADC1 to capture/Digitize
     * Analog input
     */
   if(hadc1.Instance == 0) MX_ADC1_Init(&hadc1);
	/* Configure for the selected ADC channel
	 * its corresponding rank in the sequencer and its sample time.
	 */

	sConfig.Channel = ADCchnl;
	if (sConfig.Rank != 1){
		sConfig.Rank = 1;
		sConfig.SamplingTime = ADC_SAMPLETIME_28CYCLES;
	}
	sConfig.SamplingTime = ADC_SAMPLETIME_28CYCLES;
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
			Error_Handler();
	}
	}
	//reading = 2000;
	HAL_ADC_Start(&hadc1);
	if (HAL_ADC_PollForConversion(&hadc1, 5) == HAL_OK) {
		reading = (int) HAL_ADC_GetValue(&hadc1);
	} else Error_Handler();
	return reading;
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
void MX_ADC1_Init(ADC_HandleTypeDef* hadc1)
{
	/** Configure the global features of the ADC
	 * (Clock, Resolution, Data Alignment and number of conversion)
	 * Note: AD here is set for 10 bit (not 12) resolution
	 */
	hadc1->Instance = ADC1;
	hadc1->Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	hadc1->Init.Resolution = ADC_RESOLUTION_12B;
	hadc1->Init.ScanConvMode = DISABLE;
	hadc1->Init.ContinuousConvMode = DISABLE;
	hadc1->Init.DiscontinuousConvMode = DISABLE;
	hadc1->Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	hadc1->Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc1->Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc1->Init.NbrOfConversion = 1;
	hadc1->Init.DMAContinuousRequests = DISABLE;
	hadc1->Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	if (HAL_ADC_Init(hadc1) != HAL_OK)
	{
		Error_Handler();
	}
	int curPin;
	for(int i = 0; i<=7; i++){ //The HAL_ADC_Init call destroys LCD parallel input pin setup, So restore them.
		if(i==PA3) curPin= PB0;
		else curPin = i;
		pinMode(curPin, OUTPUT);
		digitalWrite(curPin, HIGH);
	}
}


///////////////////////////////////////////////////////////////////////////////////////////
//reset systick
void coretick_init(void) {
	//configure dwt as the time base for millis()/micros()
#if defined(CoreDebug_DEMCR_TRCENA_Msk)
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;		//enable debug tracer
#endif
	//ITM->LAR = 0xC5ACCE55;					//unlock access to dwt, if so equip'd
//	DWT->CTRL |= ITM_TCR_ITMENA_Msk;			//enable dwt cycle count
	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM5_Init 1 */

	/* USER CODE END TIM5_Init 1 */
	htim5.Instance = TIM5;
	htim5.Init.Prescaler = 9600-1;
	htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim5.Init.Period = 4294967295;
	htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
	if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	HAL_TIM_Base_Start_IT(&htim5);
/*setup timer 3 for microsec and millisec delay funtions */
	  TIM_ClockConfigTypeDef sClockSourceConfig3 = {0};
	  TIM_MasterConfigTypeDef sMasterConfig3 = {0};

	  /* USER CODE BEGIN TIM3_Init 1 */

	  /* USER CODE END TIM3_Init 1 */
	  htim3.Instance = TIM3;
	  htim3.Init.Prescaler = 96-1;
	  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	  htim3.Init.Period = 65535-1;
	  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  sClockSourceConfig3.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig3) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig3) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  HAL_TIM_Base_Start_IT(&htim3);
}

//return timer clicks
//execution time = 30 ticks, no optimization

//delay cycles using SysTick ticks()
//watch out for overflow - max = 2^32/(F_CPU / 1000)
void coretick_delay(uint32_t dly) {
	uint32_t start_time = ticks();

	//ms *= cyclesPerMillisecond();				//convert ms to ticks
	while (ticks() - start_time < dly) continue;	//wait for timer to expire
}

//delay ms using SysTick ticks()
//watch out for overflow - max = 2^32/(F_CPU / 1000)
void coretick_delayms(uint32_t ms) {
	uint32_t start_time = ticks();

	ms *= cyclesPerMillisecond();				//convert ms to ticks
	while (ticks() - start_time < ms) continue;	//wait for timer to expire
}

//delay using SysTick ticks()
//watch out for overflow - max = 2^32/(F_CPU / 1000000)
void coretick_delayus(uint32_t us) {
	uint32_t start_time = ticks();

	us *= cyclesPerMicrosecond();				//convert ms to ticks
	while (ticks() - start_time < us) continue;	//wait for timer to expire
}

//JMH - taken from WMath.cpp
extern long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

uint32_t GetTimr5Cnt(void){
	return __HAL_TIM_GET_COUNTER(&htim5);
//	return ticks();
}
////20221024 JMH Added "delay_us" function to provide a us delay via STM32CubeIDE platform
void delay_us (uint16_t us)
{
	__HAL_TIM_SET_COUNTER(&htim3,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim3) < us);  // wait for the counter to reach the us input in the parameter
}

////////////////////////////////////////////////////////////////////
void delay(int Millis){
	while(Millis>0){
		delay_us(1000);
		--Millis;
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////


