/*
 * TFTMsgBox.cpp
 *
 *  Created on: Oct 7, 2021
 *      Author: jim
 */
/* 20220301- added delay to InitDsplay() method */
/* 20220302- added "void TuneFreq(int RxFreq)" method */
/* 20220304- Added 2nd paramter'SideToneFreq' to "TuneFreq(int RxFreq, int SideToneFreq)" method */
#include "TFTMsgBox.h"
#include "Arduino.h"
TFTMsgBox::TFTMsgBox( MCUFRIEND_kbv *tft_ptr, char *StrdTxt){
	ptft = tft_ptr;
	pStrdTxt = StrdTxt;
	txtpos = 0;
	RingbufPntr1 =0;
	RingbufPntr2 =0;

	CPL = 40; //number of characters each line that a 3.5" screen can contain
	row = 10; //number of usable rows on a 3.5" screen
	fontH = 16; //based on font 2
	fontW = 12;// based on font 2
	CursorPntr = 0;
	cursorY = 0;
	cursorX = 0;
	cnt = 0; //used in scrollpage routine
	curRow = 0;
	offset = 0;
	BlkState = false;
	SOTFlg = true;
	StrTxtFlg = false;
	StatMsgStrt = 0;
	TitlMsgStrt = 0;
};

void TFTMsgBox::InitDsplay(void){
	ptft->reset();
	uint16_t ID = ptft->readID();
	if (ID == 0x9090) ID = 0x9486; //do this to fix color issues
	if (ID == 0xD3D3) ID = 0x9341;
	ptft->begin(ID);//  The value here is screen specific & depends on the chipset used to drive the screen,
	ptft->setRotation(1); // valid values 1 or 3
	delay(50);//20220301- found A delay was needed here; apparently to assure display is properly initialized
	ptft->fillScreen(TFT_BLACK);
	ptft->setCursor(cursorX, cursorY);
	ptft->setTextColor(TFT_WHITE);//tft.setTextColor(WHITE, BLACK);
	ptft->setTextSize(2);
	ptft->setTextWrap(false);
	displayW = ptft->width();
	displayH = ptft->height();
	CPL = int((displayW/fontW)+1);
	row =int(displayH/fontH);
	StatusY = displayH-fontH;
	StatusX = 0;
	SmtrX = int(displayW/2);//+(1*fontW);
	SmtrY = 2*(fontH-5);
};
void TFTMsgBox::setFont(int Fw, int Fh){
	fontH = Fh;
	fontW = Fw;
	CPL = int((displayW/fontW)+1);
	row =int(displayH/fontH);
	StatusY = displayH-fontH;
	SmtrY = 2*(fontH-5);
}

/* normally called by the Keyboard parser process
 * the main feature of this entry point is to set
 * the cursor position pointer
 */
void TFTMsgBox::KBentry(char Ascii) {
	char buf[2];
	uint16_t color = TFT_WHITE;
	buf[0] = Ascii;
	buf[1] = 0;

	if(StrTxtFlg){
		pStrdTxt[txtpos] = Ascii;
		pStrdTxt[txtpos+1] = 0;
		txtpos++;
		if(txtpos>=19) txtpos =18;
		else color = TFT_YELLOW;
	}
	if(CursorPntr == 0) CursorPntr = cnt;
	dispMsg(buf, TFT_WHITE);
};
void TFTMsgBox::dispMsg(char Msgbuf[50], uint16_t Color) {
	int msgpntr = 0;
	/* Add the contents of the Msgbuf to ringbuffer */
	while ( Msgbuf[msgpntr] != 0) {
		if(RingbufPntr1 < RingBufSz-1) RingbufChar[RingbufPntr1+1] = 0;
		else RingbufChar[0] = 0;
		RingbufChar[RingbufPntr1] = Msgbuf[msgpntr];
		RingbufClr[RingbufPntr1] = Color;
		RingbufPntr1++;
		if(RingbufPntr1 == RingBufSz) RingbufPntr1 = 0;
		msgpntr++;
	}
};
/* timer interrupt driven method. drives the Ringbuffer pointer to ensure that
 * character(s) sent to TFT Display actually get printed (when time permits)
 */
void TFTMsgBox::dispMsg2(void) {
	while ( RingbufPntr2!= RingbufPntr1) {
		ptft->setCursor(cursorX, cursorY);

		char curChar = RingbufChar[RingbufPntr2];
		uint16_t Color = RingbufClr[RingbufPntr2];
		if(curChar != 10){ //test for "line feed" character
			ptft->setTextColor( RingbufClr[RingbufPntr2] );
			ptft->print(curChar);
			/* If needed add this character to the Pgbuf */
			if (curRow > 0) {
				Pgbuf[cnt-CPL] = curChar;
				Pgbuf[cnt-(CPL-1)] = 0;
				PgbufColor[cnt-CPL] = Color;
			}
			cnt++;
			if ((cnt - offset)*fontW >= displayW) {
				curRow++;
				cursorX = 0;
				cursorY = curRow * (fontH + 10);
				offset = cnt;
				ptft->setCursor(cursorX, cursorY);
				if (curRow + 1 > row) {
					scrollpg();
				}
			}
			else{
				cursorX = (cnt - offset) * fontW;
			}
		}else{
			DisplCrLf();
		}
		RingbufPntr2++;
		if(RingbufPntr2 == RingBufSz) RingbufPntr2 = 0;
	}// End while loop
};
//////////////////////////////////////////////////////////////////////
void TFTMsgBox::Delete(int ChrCnt){
	while(ChrCnt !=0){// delete display of ever how many characters were printed in the last decodeval (may be more than one letter generated)
		//first,buzz thru the pgbuf array until we find the the last character (delete the last character in the pgbuf)
		int TmpPntr = 0;
		while(Pgbuf[TmpPntr]!=0) TmpPntr++;
		if(TmpPntr>0) Pgbuf[TmpPntr-1] =0;// delete last character in the array by replacing it with a "0"
		cnt--;
		int xoffset = cnt;
		//use xoffset to locate the character position (on the display's x axis)
		curRow = 0;
		while (xoffset >= CPL){
			xoffset -=CPL;
			curRow++;
		}
		cursorX  =  xoffset*(fontW);
		cursorY = curRow * (fontH + 10);
		if(xoffset==(CPL-1)) offset= offset-CPL; //we just jump back to last letter in the previous line, So we need setup to properly calculate what display row we will be on, come the next character
		ptft->fillRect(cursorX, cursorY, fontW+4, (fontH + 10), TFT_BLACK); //black out/erase last displayed character
		ptft->setCursor(cursorX, cursorY);
		--ChrCnt;
		/*Now if we are also storing characters (via "F1" command) need to remove last entry from that buffer too */
		if(StrTxtFlg && (txtpos>0)){
			txtpos--;
			pStrdTxt[txtpos] = 0;

		}
	}
};
//////////////////////////////////////////////////////////////////////
void TFTMsgBox::DisplCrLf(void){
	/* Pad the remainder of the line with space */
	if((cnt-offset)==0) return;
	int curOS = offset;
	ptft->setTextColor( TFT_BLACK);
	while((cnt - curOS)*fontW <= displayW) {
		ptft->print(" "); //ASCII "Space"
		/* If needed add this character to the Pgbuf */
		if (curRow > 0) {
			Pgbuf[cnt-CPL] = 32;
			Pgbuf[cnt-(CPL-1)] = 0;
			PgbufColor[cnt-CPL] = TFT_BLACK;
		}
		cnt++;
		if ((cnt - offset)*fontW >= displayW) {
			curRow++;
			cursorX = 0;
			cursorY = curRow * (fontH + 10);
			offset = cnt;
			ptft->setCursor(cursorX, cursorY);
			if (curRow + 1 > row) {
				scrollpg();
				return;
			}
		}
		else{
			cursorX = (cnt - offset) * fontW;
		}
		if(((curOS+CPL)-cnt)==0) break;
	}
};
//////////////////////////////////////////////////////////////////////
void TFTMsgBox::scrollpg() {
	//buttonEnabled =false;
	BlkState = true;
	BlkStateCntr =0;
	cursorX = 0;
	cnt = 0;
	cursorY = 0;
	curRow = 0;
	offset = 0;
	bool PrintFlg = true;
	int curptr = RingbufPntr1;
	if(RingbufPntr2> RingbufPntr1) curptr = RingbufPntr1+RingBufSz;
	if((curptr-RingbufPntr2)>CPL-1) PrintFlg = false;
	//  enableDisplay(); //this is for touch screen support
	if(PrintFlg){
		ptft->fillRect(cursorX, cursorY, displayW, row * (fontH + 10), TFT_BLACK); //erase current page of text
		ptft->setCursor(cursorX, cursorY);
	}
	while (Pgbuf[cnt] != 0 && curRow + 1 < row) { //print current page buffer and move current text up one line
		if(PrintFlg){
			ptft->setTextColor(PgbufColor[cnt]);
			ptft->print(Pgbuf[cnt]);
		}
		Pgbuf[cnt] = Pgbuf[cnt + CPL]; //shift existing text character forward by one line
		PgbufColor[cnt] = PgbufColor[cnt+CPL];
		cnt++;
		if (((cnt) - offset)*fontW >= displayW) {
			curRow++;
			offset = cnt;
			cursorX = 0;
			cursorY = curRow * (fontH + 10);
			if(PrintFlg) ptft->setCursor(cursorX, cursorY);
		}
		else cursorX = (cnt - offset) * fontW;

	}//end While Loop
	if(!PrintFlg){ //clear last line of text
		ptft->fillRect(cursorX, cursorY, displayW, (fontH + 10), TFT_BLACK); //erase current page of text
		ptft->setCursor(cursorX, cursorY);
	}
	/* And if needed, move the CursorPntr up on line*/
	if(CursorPntr - CPL> 0) CursorPntr = CursorPntr - CPL;
	BlkState = false;
	/* now, if a usable state change happened while scrolling the text,
	 * apply that state value now */
	int blks = BlkStateCntr;
	while(BlkStateCntr > 0){
		IntrCrsr(BlkStateVal[blks-BlkStateCntr]);
		BlkStateCntr--;
	}
};

void TFTMsgBox::IntrCrsr(int state){
	/* state codes
		0 No activity
		1 Processing
		2 Letter Complete
		3 Start Space
		4 Start Character
		5 End Space & Start Next Character
	 */
	if(BlkState){
		BlkStateVal[BlkStateCntr] = state;//save this state, so it can be processed after the scroll page routine completes
		BlkStateCntr++;
		return;
	}
	switch (state){
	case 0:// No activity
		if(SOTFlg)CursorPntr = cnt;
		break; //do nothing
	case 1:// Processing
		break; //do nothing
	case 2:// Letter Complete
		RestoreBG();//restore normal Background
		break;
	case 3:// Start Space
		HiLiteBG();//Highlight Background
		break;
	case 4:// Start Letter
		HiLiteBG();//Highlight Background
		break;
	case 5:// restore Backgound & Highlight Next Character or Space
		if(CursorPntr+1 >=cnt) CursorPntr = cnt-1;//test, just in case something got screwed up
		RestoreBG();//restore normal Background
		HiLiteBG();//Highlight Background
		break;
	case 6:// Abort restore Backgound & Highlight Next Character or Space
		RestoreBG();//restore normal Background
		CursorPntr = cnt;
//		if(CursorPntr+1 >=cnt) CursorPntr = cnt-1;//test, just in case something got screwed up
		break;
	}
	return;

};
void TFTMsgBox::HiLiteBG(void){
	PosHiLiteCusr();
	ptft->setTextColor(PgbufColor[CursorPntr-CPL], TFT_RED);
	ptft->print(Pgbuf[CursorPntr-CPL]);
	ptft->setTextColor(TFT_WHITE, TFT_BLACK);// restore normal color scheme
    // dont need to put Cursor back, other calls to print will do that
};
void TFTMsgBox::RestoreBG(void){
	PosHiLiteCusr();
	ptft->setTextColor(PgbufColor[CursorPntr-CPL], TFT_BLACK);
	ptft->print(Pgbuf[CursorPntr-CPL]);
	CursorPntr++;
	//if(CursorPntr == cnt) CursorPntr = 0;
};
void TFTMsgBox::PosHiLiteCusr(void){
	/* figure out where the HighLight Y cursor needs to be set */
	int HLY = 0;
	int HLX = 0;
	int tmppntr = 0;
	int tmprow = 1;
	while(tmppntr +CPL<=CursorPntr){
		tmprow++;
		tmppntr +=CPL;
	}
	HLY = (tmprow-1) * (fontH + 10);
	HLX = (CursorPntr -((tmprow-1) * CPL))*fontW;
	ptft->setCursor(HLX, HLY);
};

void TFTMsgBox::dispStat(char Msgbuf[50], uint16_t Color){
	int i;
	//	ptft->fillRect(StatusX, StatusY, (displayW-StatusX), (fontH + 10), TFT_BLACK);
	ptft->setCursor(StatusX+(StatMsgStrt*fontW), StatusY);
	ptft->setTextColor(Color, TFT_BLACK);
	/* 1st figure out how many leading spaces to print to "center"
	 * the Status message
	 */
	if(StatMsgStrt == 0){
		int availspace = int((displayW-StatusX)/fontW);
		i = 0;
		while(Msgbuf[i] != 0) i++;
		int LdSpaceCnt = int((availspace- i)/2);
		if(LdSpaceCnt>0){
			for(i = 0; i<LdSpaceCnt; i++){
				ptft->print(" ");
				StatMsgStrt++;
			}
		}
		for(i = 0; i< 50; i++){
			if(Msgbuf[i] == 0) break;
			if(i*fontW >= (displayW-StatusX)) break;//410 is where the WPM text starts
			ptft->print(Msgbuf[i]);
			OlDStat[i] = Msgbuf[i];
		}
		/*finish out remainder of line with blank space */
		//	ptft->setTextColor(TFT_BLACK);
		while((i+LdSpaceCnt)*fontW <= (displayW-StatusX)) {
			ptft->print(" ");
			i++;
		}
	}else{ //we're overwriting an old status'
		for(i = 0; i< 50; i++){
			if(Msgbuf[i] == 0) break;
			if(OlDStat[i] != Msgbuf[i]){
				OlDStat[i] = Msgbuf[i];
				ptft->print(Msgbuf[i]);
			}else{
				ptft->setCursor(StatusX+((i+StatMsgStrt+1)*fontW), StatusY);

			}
		}

	}
};
////////////////////////////////////////////
void TFTMsgBox::dispTitl(char TitlTxt[], uint16_t Color){
	int i;
	//	ptft->fillRect(StatusX, StatusY, (displayW-StatusX), (fontH + 10), TFT_BLACK);
	ptft->setCursor(0, 0);
	ptft->setTextColor(Color, TFT_BLACK);
	TitlMsgStrt = 0;
	/* 1st figure out how many leading spaces to print to "center"
	 * the Status message
	 */
	if(TitlMsgStrt == 0){
		int availspace = int((displayW-StatusX)/fontW);
		i = 0;
		while(TitlTxt[i] != 0) i++;
		int LdSpaceCnt = int((availspace- i)/2);
		if(LdSpaceCnt>0){
			for(i = 0; i<LdSpaceCnt; i++){
				ptft->print(" ");
				TitlMsgStrt++;
			}
		}
		for(i = 0; i< 50; i++){
			if(TitlTxt[i] == 0) break;
			if(i*fontW >= (displayW-StatusX)) break;//410 is where the WPM text starts
			ptft->print(TitlTxt[i]);
			OlDStat[i] = TitlTxt[i];
		}
		/*finish out remainder of line with blank space */
		//	ptft->setTextColor(TFT_BLACK);
		while((i+LdSpaceCnt)*fontW <= (displayW-StatusX)) {
			ptft->print(" ");
			i++;
		}
	}else{ //we're overwriting an old status'
		for(i = 0; i< 50; i++){
			if(TitlTxt[i] == 0) break;
			if(OlDStat[i] != TitlTxt[i]){
				OlDStat[i] = TitlTxt[i];
				ptft->print(TitlTxt[i]);
			}else{
				ptft->setCursor(StatusX+((i+TitlMsgStrt+1)*fontW), StatusY);

			}
		}

	}
};
////////////////////////////////////////////
void TFTMsgBox::SigSmtr(char Msgbuf[50], uint16_t Color){
	int i;
	//	SmtrX = int(displayW/2);
	//   SmtrY
	ptft->setCursor(SmtrX, SmtrY);//StatusX+(StatMsgStrt*fontW), StatusY)
	ptft->setTextColor(Color, TFT_BLACK);
	for(i = 0; i< 50; i++){
		if(Msgbuf[i] == 0) break;
		if(OlDSmtr[i] != Msgbuf[i]){
			OlDSmtr[i] = Msgbuf[i];
			ptft->print(Msgbuf[i]);
		}else{
			ptft->setCursor(SmtrX+((i+1)*fontW), SmtrY);

		}
	}
	while (OlDSmtr[i] != 0){
		ptft->print(" ");
		OlDSmtr[i] = 0 ;
		i++;
	}

};
////////////////////////////////////////////
void TFTMsgBox::LOFreq(int LoFreq){
	int i;
	sprintf( Msgbuf, "LO: %dKHz \n", int(LoFreq/1000) );
	ptft->setCursor(0, SmtrY);
	ptft->setTextColor(TFT_BLUE, TFT_BLACK);
	for(i = 0; i< 50; i++){
		if(Msgbuf[i] == 0) break;
		ptft->print(Msgbuf[i]);

	}
};

void TFTMsgBox::SmplRate(int SamplRateInt){
	int i;
	sprintf( Msgbuf, "SR:%dHz\n", SamplRateInt);
	ptft->setCursor(0, 200);
	ptft->setTextColor(TFT_BLUE, TFT_BLACK);
	for(i = 0; i< 50; i++){
		if(Msgbuf[i] == 0) break;
		ptft->print(Msgbuf[i]);

	}

};

void TFTMsgBox::SdTFreq(int SdToneFreq){
	int i;
	sprintf( Msgbuf, "ST: %dHz\n", SdToneFreq);
	ptft->setCursor(130, 200);
	ptft->setTextColor(TFT_GREEN, TFT_BLACK);
	for(i = 0; i< 50; i++){
		if(Msgbuf[i] == 0) break;
		ptft->print(Msgbuf[i]);

	}
};

void TFTMsgBox::TuneFreq(int RxFreq, int SideToneFreq){
	char TxtBuf[16];
	RxFreq = RxFreq+SideToneFreq;
	int RxKHz  = int(RxFreq/1000);
	int RxHz  = RxFreq- (RxKHz*1000);
	sprintf(TxtBuf, "Tune:%d %03dHz \n", RxKHz, RxHz);
	dispStat(TxtBuf, TFT_WHITE);
};
////////////////////////////////////////////
void TFTMsgBox::setSOTFlg(bool flg)
{
	SOTFlg = flg;
	/*Now Use the max3421 interrupt box to show "Send On Text State"(SOT) mode */
	uint16_t color;
	int Xpos = 10;
	int Ypos = 290;
	int Wdth = 30;
	int Hght = 30;
	if(SOTFlg && !StrTxtFlg) color =TFT_GREEN;
	else if(SOTFlg && StrTxtFlg) color = TFT_WHITE;
	else color =TFT_YELLOW;
	ptft->fillRect(Xpos, Ypos, Wdth, Hght, color);
};
void TFTMsgBox::setStrTxtFlg(bool flg)
{
	StrTxtFlg = flg;
	/*Now Use the max3421 interrupt box to show "Store Text" mode */
	uint16_t color;
	int Xpos = 10;
	int Ypos = 290;
	int Wdth = 30;
	int Hght = 30;
	if(!StrTxtFlg && SOTFlg) color =TFT_GREEN;
	else if(!StrTxtFlg && !SOTFlg) color =TFT_YELLOW;
	else{
		color = TFT_WHITE;
		pStrdTxt[0] = 0;
		txtpos = 0;
	}
	ptft->fillRect(Xpos, Ypos, Wdth, Hght, color);
};

void TFTMsgBox::setTxtSize(int Sz)
{
	ptft->setTextSize(Sz);
};
