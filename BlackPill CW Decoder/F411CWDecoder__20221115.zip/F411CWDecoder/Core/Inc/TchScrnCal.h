/*
 * TchScrnCal.h
 *
 *  Created on: Jul 1, 2022
 *      Author: jim
 */

#ifndef INC_TCHSCRNCAL_H_
#define INC_TCHSCRNCAL_H_

#include "TouchScreen_kbv.h"
#include "MCUFRIEND_kbv.h"
//#include "TFTMsgBox.h"
extern char Title[];
extern int XP,XM,YP,YM;
extern int TS_LEFT, TS_RT, TS_TOP, TS_BOT;
extern MCUFRIEND_kbv tft;
extern TouchScreen_kbv ts;
extern TSPoint_kbv tp;
void TchScrnCal_MainLoop(void);



#endif /* INC_TCHSCRNCAL_H_ */
