/*
 * ScopeDemo.h
 *
 *  Created on: Aug 30, 2021
 *      Author: jim
 */

#ifndef INC_SCOPEDEMO_H_
#define INC_SCOPEDEMO_H_

void ScopeLoop(void);



#endif /* INC_SCOPEDEMO_H_ */
