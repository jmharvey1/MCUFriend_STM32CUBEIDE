/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  * 20221001 added touch screen calibrate routine to program
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include <eeprom.h>
#include <SetUpCwDecoder.h>
#include "main.h"
#include "usb_device.h"
#include "BtnSuprt.h"
#include "DcodeCW.h"
#include "FFTdemo.h"
#include "TchScrnCal.h"
#include "TFTMsgBox.h"
#include "usbd_cdc_if.h"
#include "WS2812B.h"
#include "Arduino.h"
#include "TouchScreen_kbv.h"
#include "UTFTGLUE.h"              //use GLUE class and constructor

//#include "../../Libraries/eeprom/Inc/stm32f4xx_flash.h"
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB8|PB9|

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF
#define LED_NO    1
//#define TITLE "Goertzel ADC/DMA Demo"
//#define REVDT "03/25/2021"

//#define SAMPL_RATE 3.965    // in microseconds; should give an interrupt rate of 252,206Hz (95)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
//ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

SPI_HandleTypeDef hspi2;
DMA_HandleTypeDef hdma_spi2_tx;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim5;
//USBD_CDC_HandleTypeDef   *hcdc = (USBD_CDC_HandleTypeDef*) pdev->pClassData;

/* USER CODE BEGIN PV */
uint8_t toggle =0x0;
uint8_t toggle1 =0x0;
uint8_t next = 0;
uint8_t next1 = 0;
uint8_t delayLine;
uint8_t delayLine2;
uint8_t LEDRED = 0;
uint8_t LEDGREEN = 0;
uint8_t LEDBLUE = 0;
uint8_t LightLvl = 0;
uint8_t NoStrdVals = 0;

uint16_t adc_buf[ADC_BUF_LEN];
//uint16_t Geo_buf[2048];
uint16_t ID = 0x9090;
//uint16_t EEaddress = 0x0000;

uint16_t VirtAddVarTab[NB_OF_VAR] = {0x0000, 0x0002, 0x0004};
uint16_t VarDataTab[NB_OF_VAR];

int DMACycle = 1;
int N = 0; //Block size sample 6 cycles of a 750Hz tone; ~8ms interval
//int CYCLE_CNT =0;// 6.0
int NL = ADC_BUF_LEN/2;
int NC = 0;
int NH = 0;
int BIAS = 2040;
int TonSig = 0;
int pntr =0;
int SkipCnt =0;
int SkipCnt1 =0;
int PrgmNdx =0;// used to control which program the decoder is running

long ManSqlch = 2000;
unsigned long HlfCBtime = 0;
unsigned long HlfCBcnt = 0;
unsigned long FulCBtime = 0;
unsigned long FulCBcnt = 0;

int scrnHeight = 0;
int scrnWidth =0;
//int Fstop = 4096;// sizeof(adc_buf);
int Hstop = ADC_BUF_LEN/2;// sizeof(adc_buf)/2;
int KeyState = 0; // used for plotting to show Key "UP" or "DOWN" state
int captrBuf[480];
const int fontH = 16;// needed global variable for read/detect button support
const int fontW = 12;// needed global variable for read/detect button support
//const int XP=PB7, XM=PA6, YP=PA7, YM=PB6;
//x = map(p.y, LEFT=492, RT=522, 0, 320)
//y = map(p.x, TOP=399, BOT=634, 0, 480)
//const int TS_LEFT=634,TS_RT=399,TS_TOP=492,TS_BOT=522;

float feqlratio = 0.97;//0.958639092;//0.979319546;
float feqhratio = 1.02;//1.044029352;//1.022014676;
float TARGET_FREQUENCYC = 750; //Hz
float TARGET_FREQUENCYL = feqlratio*TARGET_FREQUENCYC;//734.0; //Hz
float TARGET_FREQUENCYH = feqhratio*TARGET_FREQUENCYC;//766.0; //Hz

//float SAMPLING_RATE = 248694.3546;//based clock divide by 4, and a SAMPLETIME_84CYCLES
//float SAMPLING_RATE =250375.56; //based on scope measurements
//float SAMPLING_RATE =257575.0; //based on reported Center Freq
float SAMPLING_RATE =250000.0; //based on TIM5 microsecond measurements between HlfCBtime & FulCBtime
float Q1;
float Q2;
float Q1H;
float Q2H;
float Q1C;
float Q2C;
//float cosine;
//float sine;
float PhazAng;
float coeff;
float coeffL;
float coeffC;
float coeffH;
float magA = 0;
float magB = 0;
float magC = 0;
float magC2 = 0;
float magL = 0;
float magH = 0;
float SqlchLvl = 0;
float AdjSqlch= 0;
float AvgLo = 0;
float AvgHi = 0;
float AvgVal = 0;
float DimFctr = 0.60;//1.0;
float CurNoise =10000;
float TSF = 1.2; //TSF = Tone Scale Factor; used as part of calc to set/determine Tone Signal to Noise ratio; Tone Component
float NSF = 1.24; //1.84; //1.55; //2.30;//2.85;//0.64; //NSF = Noise Scale Factor; used as part of calc to set determine Tone Signal to Noise ratio; Noise Component
float ClipLvl = 1500000;
const int MagBSz = 6;
float MagBuf[MagBSz];
float NoiseFlr =0;
float SigPk =0;
int MBpntr=0;

char biasbuf[52];
bool Skip = false;
bool Ready = true;
uint8_t NuMagData = 0x0;
bool RSetNoise = false;
bool toneDetect = false;
bool NoiseSqlch = true;
bool TonPltFlg = false;
bool RunFFT_DEMO = false;
bool SetScrnActv = false;
uint8_t LongSmplFlg; // controls high speed sampling VS High Sensitivity ;can not set the value here
/* Start Auto Tune variables */
bool AutoTune = false; //true;
bool Scaning = false;
/*end Auto Tune variables*/
uint8_t GudSig = 0;
struct DF_t DFault;
/* end Auto Tune variables */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* Black Pill STM32F411 Init Routines */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
//static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM5_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI2_Init(void);
/* USER CODE BEGIN PFP */
/* Tone DSP Routines */
float GetMagnitudeSquared(float q1, float q2, float Coeff);
void ResetGoertzel(void);
void InitGoertzel(void);
void ProcessSample(int sample, int Scnt);
void ComputeMags(void);
void Chk4KeyDwn(void);
void ScanFreq(void);
void CalcFrqParams(float NewToneFreq);
/*standard support routines */
//uint32_t flash_read(uint32_t address);
//void flash_write(uint32_t address, uint32_t data);
void delay_us (uint16_t us);
void delay(int Millis);
void USBprintln(const char *msg);
void USBprintStr(String *msg);
void USBprint(const char *msg);
void USBprintInt(int val);
void USBprintIntln( int val);
void EXTI15_10_IRQHandler(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
char StrdTxt[140] ={'\0'};
MCUFRIEND_kbv tft;
TFTMsgBox tftmsgbx(&tft, StrdTxt);
UTFTGLUE myGLCD(0,0,0,0,0,0); //all dummy args
WS2812B strip((uint16_t)LED_NO, &hspi2, &hdma_spi2_tx );//
int XP=PB6,XM=PA7,YP=PA6,YM=PB7; //480x320 ID=0x9486
int TS_LEFT=951,TS_RT=85,TS_TOP=124,TS_BOT=909;

//TouchScreen_kbv ts(XP, YP, XM, YM, 300);
//TSPoint_kbv tp; //global point

template <class T>
int EEPROM_read(uint16_t ee, T& value)
{
   uint16_t* p = (uint16_t*)(void*)&value;
   uint16_t tmp;
   int i=0;
   while (i < sizeof(value)){
       //*p++ = EEPROM.read(ee++);
	   EE_ReadVariable(ee, &tmp);
	   ee +=2;
	   i +=2;
	   *p = tmp;
	   p++;//p +=2;
   }
   return i;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_TIM2_Init();
	MX_TIM3_Init();
	MX_TIM5_Init();
	MX_USB_DEVICE_Init();
	MX_ADC1_Init();
	MX_SPI2_Init();
	/* USER CODE BEGIN 2 */


	HAL_TIM_Base_Start_IT(&htim2); //JMH these are important; if not here the interrupt clock functions wont work
	HAL_TIM_Base_Start(&htim3); //JMH these are important; if not here the interrupt clock functions wont work
	HAL_TIM_Base_Start(&htim5);
	coretick_init(); //JMH Added to support time measurements i.e millis() & micros() see Arduino.h & Arduino.cpp
	/* Unlock the Flash Program Erase controller */
	//	FLASH_Unlock();

	/* EEPROM Init */
	//	EE_Init();
	/* USER CODE BEGIN 2 */
	/*set the tone detect pin, "Key Out" pin "High" */
	//HAL_GPIO_WritePin(DMA_Evnt_GPIO_Port, DMA_Evnt_Pin, GPIO_PIN_SET);
	/* USER CODE END 2 */

	InitGoertzel();
	/*      For testing:          */
	//	float omega = (2.0 * M_PI * 6) / 2000.0;
	//	for(int i =0; i <= 2048; i++){
	//		Geo_buf[i] = (int)20*cos(omega*i);
	//	}
	/* Don't need to start the ADC DMA now Because it will automatically get started in the
	 * Decode loop as part of the the read resistive touch routine.
	 */
	DFault.DimFctr = DimFctr;
	DFault.TSF = TSF;
	DFault.NSF = NSF;
	DFault.BIAS = BIAS;
	DFault.ManSqlch = ManSqlch;
	DFault.NoiseSqlch = NoiseSqlch;
	DFault.DeBug = DeBug;
	DFault.AutoTune = AutoTune;
	DFault.TARGET_FREQUENCYC = TARGET_FREQUENCYC;
	DFault.SAMPLING_RATE = SAMPLING_RATE;
	DFault.TS_BOT = TS_BOT;
	DFault.TS_LEFT = TS_LEFT;
	DFault.TS_RT = TS_RT;
	DFault.TS_TOP = TS_TOP;
	DFault.XM = XM;
	DFault.XP = XP;
	DFault.YM = YM;
	DFault.YP = YP;
	/* Unlock the Flash Program Erase controller */
	FLASH_Unlock();

	/* EEPROM Init */
	uint16_t reslt = EE_Init();
	if (reslt != fLASH_COMPLETE){
		char buf[150];
		sprintf(buf, "EE_Init() ERROR: %d", reslt);
		USBprintln(buf);
		while(1);
	}
	int offset = 0;
	int	n= EEPROM_read(EEaddress+offset, DimFctr);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, TSF);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, NSF);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, BIAS);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, ManSqlch);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, NoiseSqlch);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, DeBug);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, AutoTune);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, TARGET_FREQUENCYC);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, SAMPLING_RATE);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset),TS_BOT);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, TS_LEFT);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), TS_TOP);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), TS_RT);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, XM);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), XP);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, YM);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, YP);
	offset += 2*n;
	n= EEPROM_read(EEaddress+offset, scrnHeight);
	offset += 2*n;
	n = EEPROM_read(EEaddress+(offset), scrnWidth);
	offset += 2*n;
	FLASH_Lock();
	if(SAMPLING_RATE==0 && BIAS==0){
		LdFactryVals();
		NoStrdVals = 1;
	}

	switch(DeBug){
	case 0:
		TonPltFlg = false;
		Test = false;
//		sprintf(textMsg, " DEBUG Off");
		break;
	case 1:
		Test = false;
//		sprintf(textMsg, " DEBUG Plot");
		TonPltFlg = true;
		break;
	case 2:
		TonPltFlg = false;
		Test = true;
//		sprintf(textMsg, "DEBUG Decode");
		break;
	default:
//		sprintf(textMsg, "DB Val: %d", DeBug);
		break;

	}
	LongSmplFlg = 1;//set to "1" for High Sensitivity, longer sample interval [8ms Vs 4ms]; Need to set the value here, otherwise it will always test "false"
	/* Added the following to solve timing issues */
//	unsigned long now = HAL_GetTick();
//	while (HAL_GetTick()-now < 100){
//		delay(1);
//	}
	//CalcFrqParams(TARGET_FREQUENCYC);
	StartDecoder(); //this routine lives in the DcodeCW.cpp file
	/* Nothing past this point ever gets executed */
	//	BldButtons(); //Defined in BtnSuprt.h
	//	InitGoertzel();
	int DsplyCntr = 0;
	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */

	while (1)
		/* USER CODE END WHILE */
	{
		DsplyCntr++;
		if(DsplyCntr>1000){
			DsplyCntr = 0;
		}
		//		while(FulCBcnt<10000);
		//		unsigned long Stop = HAL_GetTick()- Start;//Tick count seems to be off by a factor of 1.5; i.e mltiply stop value by 1.5 to get true millisecond count.
		//		HAL_ADC_Stop_DMA(&hadc1);
		//		HAL_ADC_Stop(&hadc1);
		//		while(1){
		//			delay(2);
		//		}
		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}
////////////////////////////////////////////////////////////////////////////
void ResetGoertzel(void)
{
  Q2 = 0;
  Q1 = 0;
  Q2C = 0;
  Q1C = 0;
  Q2H = 0;
  Q1H = 0;
  AvgVal = 0;
}

/* Call this once, to precompute the constants. */
void InitGoertzel(void)
{
//	int  k;//float  k;
	int CYCLE_CNT;// 6.0
	float  floatN;
	float  omega;
	float cosine;
	float sine;
	float CyRadians;
	/* For the lowest frequency of interest, Find the Maximum Number of whole Cycles we can look at  */
	if(!LongSmplFlg){// ~4ms sample interval
		CYCLE_CNT = (int)((((float)(ADC_BUF_LEN/2))*TARGET_FREQUENCYL)/SAMPLING_RATE);
	}else {// ~8ms sample interval
		CYCLE_CNT = (int)((((float)(ADC_BUF_LEN))*TARGET_FREQUENCYL)/SAMPLING_RATE);
	}
	CyRadians = (2.0 * M_PI * CYCLE_CNT);
	NL = (int)((SAMPLING_RATE / TARGET_FREQUENCYL) * (float)(CYCLE_CNT));
	floatN = (float) NL;

//	k = (int) (0.5 + ((floatN * TARGET_FREQUENCYL) / SAMPLING_RATE));
//	omega = (2.0 * M_PI * CYCLE_CNT) / floatN;
	omega = CyRadians / floatN;
	//  sine = sin(omega);
	cosine = cos(omega);
	coeffL = 2.0 * cosine;

	//	CYCLE_CNT = (int)((((float)(ADC_BUF_LEN/2))*TARGET_FREQUENCYC)/SAMPLING_RATE);
	NC = (int)((SAMPLING_RATE / TARGET_FREQUENCYC) * (float)(CYCLE_CNT));
	floatN = (float) NC;

//	k = (int) (0.5 + ((floatN * TARGET_FREQUENCYC) / SAMPLING_RATE));
//	omega = (2.0 * M_PI * k) / floatN;
//	omega = (2.0 * M_PI * CYCLE_CNT) / floatN;
	omega = CyRadians / floatN;
//	sine = sin(omega);
	cosine = cos(omega);
	coeffC = 2.0 * cosine;


	NH = (int)((SAMPLING_RATE / TARGET_FREQUENCYH) * (float)(CYCLE_CNT));
	floatN = (float) NH;

//	k = (float) (0.5 + ((floatN * TARGET_FREQUENCYH) / SAMPLING_RATE));
//	omega = (2.0 * M_PI * k) / floatN;
//	omega = (2.0 * M_PI * CYCLE_CNT) / floatN;
	omega = CyRadians / floatN;
	//  sine = sin(omega);
	cosine = cos(omega);
	coeffH = 2.0 * cosine;
	ResetGoertzel();
//	if(!LongSmplFlg){
//	    NL = Hstop;
//	}else{
//		NL = 2*Hstop;
//	}
//	NC= NL;
//	NH= NL;
}

/* Call this routine for every sample. */
void ProcessSample(int sample, int Scnt)
{
  float Q0;
  float FltSampl = (float)sample;
  //samplerate = 21630;  max centerfreq out single freq
//  if (Scnt < NC) {
	Q0 = (coeffC * Q1C) - Q2C + FltSampl;
    Q2C = Q1C;
    Q1C = Q0;
//  }


//  if (Scnt < NH) { //The Highest Freq has the fewest number of samples
	Q0 = (coeffH * Q1H) - Q2H + FltSampl;
    Q2H = Q1H;
    Q1H = Q0;
//  }

  Q0 = (coeffL * Q1) - Q2 + FltSampl;
  Q2 = Q1;
  Q1 = Q0;
}


/* Optimized Goertzel */
/* Call this after every block to get the RELATIVE magnitude squared. */
float GetMagnitudeSquared(float q1, float q2, float Coeff)
{
  float result;

  result = (q1 * q1) + (q2 * q2) - (q1 * q2 * Coeff);
//  float real = (q1 - q2 * cosine);
//  float imag = (q2 * sine);
//  result = (real*real) + (imag*imag);
//  PhazAng = 360*((atan(real/imag))/(2*M_PI));
  return result;
}
void ComputeMags(void){
	magC = sqrt(GetMagnitudeSquared(Q1C, Q2C, coeffC));
	magH = sqrt(GetMagnitudeSquared(Q1H, Q2H, coeffH));
	magL = sqrt(GetMagnitudeSquared(Q1, Q2, coeffL));
	//magB = ((99*magB)+magC)/100;
	float CurLvl = (magC + magL + magH)/3;
	/* Find Noisefloor for this recent period */
	MagBuf[MBpntr++] = CurLvl;
	if(MBpntr>(MagBSz-1)) MBpntr = 0;
	NoiseFlr = MagBuf[0];
	SigPk = MagBuf[0];
	for( int i =1 ; i <MagBSz; i++){
		if(MagBuf[i]<NoiseFlr) NoiseFlr = MagBuf[i];
		if(MagBuf[i]>SigPk) SigPk = MagBuf[i];

	}
	float NSR = NoiseFlr/SigPk;
	magB = ((magB)+CurLvl)/2; //((2*magB)+CurLvl)/3; //(magC + magL + magH)/3; //
	/* try to establish what the long term noise floor is */
	//if(CurNoise < 16000 )CurNoise = ((59*CurNoise)+(1.4*NSF*magB))/60;
	if(CurNoise < 30000 )CurNoise = ((59*CurNoise)+(1.4*NSF*SigPk))/60;
	else if(LongSmplFlg && (CurNoise < 45000)) CurNoise = ((59*CurNoise)+(1.4*NSF*SigPk))/60;
	else{
//		if((magB< (1.5*NSF*CurNoise)&&(magB<(1.25*SqlchLvl)))||(NoiseFlr<SqlchLvl)){//if((magB< CurNoise) &&(magB<30000)){
//			float magB1 = magB;
//			if(magB1>(1.0*CurNoise)) magB1 = 1.0*CurNoise;
//			if((CurNoise<SqlchLvl)&&(CurLvl<CurNoise)) CurNoise = ((49*CurNoise)+(1.6*NSF*(magB1-0.4*NoiseFlr)))/50;
//			else CurNoise = ((249*CurNoise)+(1.6*NSF*(magB1-0.4*NoiseFlr)))/250;
//		}
		//if(magB < CurNoise) CurNoise = ((249*CurNoise)+(1.6*NSF*(SigPk-NoiseFlr)))/250;
		if(magB < CurNoise){
			if(!Skip){
				//CurNoise = ((49*CurNoise)+(1.6*NSF*(SigPk-NoiseFlr)))/50;
				CurNoise = ((99*CurNoise)+(1.6*NSF*(SigPk-NoiseFlr)))/100;
			}
			else{
				SkipCnt++;
				if(SkipCnt >4) Skip = false;
			}
		}
	}
	/* If we're in a key-down state, and the Noise floor just Jumped up, as a reflection of this state give up the gain in "curnoise" that happened due to the time lag in noisefloor */
	//if((CurNoise > (0.0014*NoiseFlr)) && (NSR>0.8)) CurNoise = CurNoise - (0.0007*NoiseFlr);
	/* the following should never happen, but if "true" reset noise level to something realistic */
	if(CurNoise<0) CurNoise = (SqlchLvl);
	/* Now try to establish "key down" & "key up" average levels */
	if((NSF*NoiseFlr)>SqlchLvl){//if(magB>SqlchLvl){//if(magC>SqlchLvl){
		/* Key Down bucket */
		AvgHi= ((5*AvgHi)+magB)/6;//((3*AvgHi)+magC)/4;
		//AvgLo += 0.10*AvgLo;
	}
	else{
		/* Key Up bucket, & bleed off some of the key down level*/
		AvgLo= ((49*AvgLo)+magB)/50;
		AvgHi -= 0.0015*AvgHi;//AvgHi -= 0DFault.DimFctr = DimFctr;
	}
	/* use the two Hi & Lo buckets to establish the current mid point */
	float Avg = ((AvgHi-AvgLo)/2)+(1.2*AvgLo);
	/* add this current mid point to the running average mid point */
	SqlchLvl = ((29*SqlchLvl)+Avg)/30;
	/* Now based on the current key down level see if a differential correction needs to be added into the average */
	if(SqlchLvl>0.55*AvgHi)  SqlchLvl = 0.55*AvgHi;
	if(SqlchLvl<0.50*AvgHi) SqlchLvl = 0.50*AvgHi;
	/* Finally, make sure the running average is never less than the current noise floor */
	if(CurNoise > 3.0*SigPk) CurNoise = 3.0*SigPk; //CurNoise -(0.6*NoiseFlr);
	if(SqlchLvl <=CurNoise){
		if((NoiseFlr>(CurNoise))&&(CurNoise>magB) && GudSig) CurNoise = CurNoise -(0.6*NoiseFlr);
		AdjSqlch = CurNoise;
		if((NoiseFlr>CurNoise)&& ((NoiseFlr/SigPk)>0.65)){
			GudSig = 1;
			SkipCnt1 =0;
		}
		if((NoiseFlr<CurNoise)&& ((SigPk/NoiseFlr)>5.0)){
			SkipCnt1++;
			if(SkipCnt1 >4){
				SkipCnt1 = 4;
				GudSig = 0;
			}
		}
	}else{
		AdjSqlch = SqlchLvl;
		if(AdjSqlch > 1.1*CurNoise){
			GudSig = 1;
			SkipCnt1 =0;
		}
		//if(AdjSqlch > 1.1*CurNoise && ((AdjSqlch < NoiseFlr)||(AdjSqlch > SigPk))) GudSig = 1;
		//if(AdjSqlch> 1.2*CurNoise  && (SqlchLvl > SigPk)) GudSig = 1;
		//else GudSig = 0;
	}
	Ready = true;
	NuMagData = 0x1;
	/* The Following (Commented out) code will generate the CW code for "5" with a Calibrated 31ms "keydown" period */
	//	next1++;
	//	if(next1==2){
	//		next1 =0;
	//		next++;
	//		if(next<20){
	//			if(next % 2 == 0){
	//				toggle1 ^= 1; //exclusive OR
	//				if(toggle1) HAL_GPIO_WritePin(DMA_Evnt_GPIO_Port, DMA_Evnt_Pin, GPIO_PIN_RESET);//PIN_HIGH(LED_GPIO_Port, LED_Pin);
	//				else HAL_GPIO_WritePin(DMA_Evnt_GPIO_Port, DMA_Evnt_Pin, GPIO_PIN_SET);//PIN_LOW(LED_GPIO_Port, LED_Pin);
	//			}
	//		}else if(next>40) next = 0;
	//		else{
	//			HAL_GPIO_WritePin(DMA_Evnt_GPIO_Port, DMA_Evnt_Pin, GPIO_PIN_SET);
	//			toggle1 = 0;
	//		}
	//	}
	/* END Calibrated TEST Code generation; Note when using the above code the Ckk4KeyDwn routine should be commented out */

	Chk4KeyDwn();

}
////////////////////////////////////////////////////////////////////////////
void Chk4KeyDwn(void)
{
	//int loopcnt =0;
	float  ToneLvl = magB;//magC;
	//float SqlchLvl = SqlchLvl;
	bool GudTone = true;

	//	if(magL > ToneLvl) ToneLvl = magL;
	//	if(magH > ToneLvl) ToneLvl = magH;
	if((NoiseFlr)<(0.4*AdjSqlch)){
		GudTone = false;
		toneDetect = false;
		RSetNoise = false;
	}
	if (( ToneLvl > AdjSqlch)& !Scaning) {
		TonSig = (int)(((2999*((float)ToneLvl))+((float)ToneLvl))/3000.0);//only used on the settings screen to give a slow changing tone lvl reading
		toneDetect = true;
		Skip = true;
		SkipCnt =0;
		/*ReArm "RSetNoise" if we now have a KeyDown Condition, But the Noise Floor is still lagging the tone Detect Signal*/
		if(!RSetNoise && !GudTone) RSetNoise = true;
	} else {
		if((AdjSqlch > 45000) && ((2.5*NoiseFlr) > AdjSqlch) && ((SigPk) > AdjSqlch)) toneDetect = true;
		else toneDetect = false;
		if((AdjSqlch > NoiseFlr) && (SigPk > AdjSqlch)){
			if(((SigPk - AdjSqlch) > (AdjSqlch - NoiseFlr)&&(SigPk/NoiseFlr <3.0)) || (NoiseFlr/SigPk > 0.8))  toneDetect = true;
			else toneDetect = false;
		}
	}

	delayLine = delayLine << 1;
	delayLine &= 0b00001110;
	delayLine2 = delayLine2 << 1; //2nd delay line used pass led info to RGB LED
	delayLine2 &= 0b00001110;
	if (GudTone) delayLine2 |= 0b00000001;
	if (toneDetect) delayLine |= 0b00000001;
	//Use For Slow code [<27WPM] fill in the glitches  pin is left open
	if (avgDit>40) { //incoming code is slower than 30WPM //if(digitalRead(SlowData)){
		if (((delayLine ^ 0b00001110) == 4 ) || ((delayLine ^ 0b00001111) == 4)) delayLine |= 0b00000100;
		if (((delayLine ^ 0b00000001) == 0b00000100) || ((delayLine ^ 0b00000000) == 0b00000100)) delayLine &= 0b11111011;
	}
	KeyState = -8000;

	if (delayLine & 0b00001000) { // key Closed
		HAL_GPIO_WritePin(DMA_Evnt_GPIO_Port, DMA_Evnt_Pin, GPIO_PIN_RESET);
		KeyState = -250;
	}
	else { //No Tone Detected
		HAL_GPIO_WritePin(DMA_Evnt_GPIO_Port, DMA_Evnt_Pin, GPIO_PIN_SET);
	}

	//	if (TonPltFlg) {
	//		// Add the final entry to the plot data
	//		Serial.print(KeyState);//Light Blue
	//		Serial.print("\t");
	//		Serial.print(ltrCmplt);//Black
	//		Serial.print("\t");
	//		float badltrbrkT = -4000;
	//		if(badLtrBrk) badltrbrkT = -1900;
	//		Serial.println(badltrbrkT);//BLue
	//		//TonPltFlg = false;
	//	}

	//The following code is just to support the RGB LED.
	if (delayLine & 0b00001000) { //key Closed
		LEDGREEN = 0;
		LEDRED = 0;
		LEDBLUE = 0;
		if (ToneLvl > ClipLvl) { //Excessive Tone Amplitude
			LEDGREEN = 120;
			LEDRED = 120;
			LEDBLUE = 120;
		}//End Excessive Tone Amplitude
		else { // modulated light tests
			LightLvl = (uint8_t)(256 * (ToneLvl / ClipLvl));
			//Serial.println(LightLvl);
			if (ToneLvl < 1500) { // Just detectable Tone
				LEDGREEN = LightLvl;
				LEDRED = LightLvl;
				LEDBLUE = LightLvl;
			}//End Just detectable Tone
			else { //Freq Dependant Lighting
				magC2 = magC;//1.02*magC;
				if ((magC2 >= magH) && (magC2 >= magL)) { //Freq Just Right
					LEDGREEN = LightLvl;
				}//End Freq Just Right
				else if ((magH > magC) && (magH >= magL)) { //Freq High
					LEDBLUE = LightLvl;
				}//End Freq High
				else if ((magL > magC) && (magL >= magH)) { //Freq Low
					LEDRED = LightLvl;
				}//End Freq Low
				if (LEDGREEN == 0 & LEDRED == 0 & LEDBLUE == 0) {
					LEDGREEN = 10;
					LEDRED = 10;
					LEDBLUE = 10;
				}
			}//End Freq Dependant Lighting

		}//End modulated light tests
	}//end Key Closed Tests
	else { //key open
		LEDGREEN = 0;
		LEDRED = 0;
		LEDBLUE = 0;

	}
	LEDGREEN = (uint8_t)(DimFctr*((float)LEDGREEN));
	LEDRED = (uint8_t)(DimFctr*((float)LEDRED));
	LEDBLUE = (uint8_t)(DimFctr*((float)LEDBLUE));
	strip.setPixelColor(0, strip.Color(LEDRED, LEDGREEN, LEDBLUE));
	strip.show(); //activate the RGB LED
	// this round of sound processing is complete, so setup to start to collect the next set of samples
	if(AutoTune) ScanFreq(); // go check to see if the center frequency needs to be adjusted
	//	ResetGoertzel();
	//	AvgVal = 0.0;
	//	OvrLd = false;
	//	CurCnt = 0;

}
////////////////////////////////////////////////////////////////////////////
void ScanFreq(void){
  /*  this routine will start a Sweep the audio tone range by decrementing the Geortzel center frequency when a valid tome has not been heard
   *  within 4 wordbreak intervals since the last usable tone was detected
   *  if nothing is found at the bottom frquency (500Hz), it jumps back to the top (900 Hz) and starts over
  */
  float DltaFreq = 0.0;


  if( magC > AdjSqlch){ //We have a valid tone.
    Scaning = false;  //enable the tonedetect process to allow key closer events.
    if(magC> magL & magC> magH) return;
    if(magH> magL) DltaFreq = +2.5;
    else DltaFreq = -2.5;
  } else {
    if((HAL_GetTick()-noSigStrt) > 5*wordBrk){
       DltaFreq = -20.0;
      Scaning = true;  //lockout the tonedetect process while we move to a new frequency; to prevent false key closer events while in the frequency hunt mode
    }
  }
  if(DltaFreq == 0.0) return;//Go back; Nothing needs fixing
  TARGET_FREQUENCYC += DltaFreq;
  if(TARGET_FREQUENCYC < 500) TARGET_FREQUENCYC =900.0;// start over( back to the top frequency); reached bottom of the frequency range
  CalcFrqParams(TARGET_FREQUENCYC);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
void CalcFrqParams(float NewToneFreq){
  //float NewToneFreq = TARGET_FREQUENCYC + 10.0;
  TARGET_FREQUENCYC = NewToneFreq; //Hz
  TARGET_FREQUENCYL = feqlratio*NewToneFreq; //Hz
  TARGET_FREQUENCYH = feqhratio*NewToneFreq; //Hz
  InitGoertzel();
  //coeff = coeffC;
  //N = NC;
  /* TODO Display current freq, only if we are running BtnSuprt.cpp setup loop */
  //if(setupflg && !Scaning)ShwUsrParams();
}
//////////////////////////////////////////////////////////////////////////
/* internal flash/eeprom support functions */
//uint32_t flash_read(uint32_t address){
//    return *(uint32_t*)address;
//}
//
//void flash_write(uint32_t address, uint32_t data){
//    HAL_FLASH_Unlock();
//    FLASH_Erase_Sector(FLASH_SECTOR_0,VOLTAGE_RANGE_1);
//    HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD,address,data);
//    HAL_FLASH_Lock();
//}
//////////////////////////////////////////////////////////////////////////

void USBprintInt( int val){
	char buf[15];
	sprintf(buf, "%d", val);
	USBprint(buf);
}
/////////////////////////////////////////////////////////////////////
void USBprintIntln( int val){
	char buf[15];
	sprintf(buf, "%d\n", val);
	USBprintln(buf);
}
/////////////////////////////////////////////////////////////////////
void USBprintStr(String *msg){
	char buf[150];
	sprintf(buf, "%s", msg);
	USBprint(buf);
}
/////////////////////////////////////////////////////////////////////
void USBprintln(const char *msg)
{
	char buf[150];
	sprintf(buf, "%s\n", msg);
	USBprint(buf);
	return;
}
void USBprint(const char *msg)
{
	char buf[150];
	uint8_t Buffer[150];
	sprintf(buf, "%s", msg);
	uint32_t BfLen = 150;
	//while(USBD_Interface_fops_FS.TransmitCplt(BfLen,(uint8_t)1) != USBD_OK);
	//while(USBD_Interface_fops_FS.TransmitCplt(hUsbDeviceFS->pbuf, &BfLen,(uint8_t)1) != USBD_OK);

	int i = 0;
	for(i = 0; i<=sizeof(buf); i++ ){
		Buffer[i] = (uint8_t)buf[i];
		if(buf[i] ==0) break;
	}
	int BsyCntr = 0;
	/*setup guard rail to prevent USB err when trying to display title*/
	bool tstState = false;
	if(Test){
		tstState = true;
		Test = false;
	}

	uint8_t USBstat = USBD_BUSY;
	while(USBstat != USBD_OK){
		USBstat = CDC_Transmit_FS(Buffer, i);
		BsyCntr++;
		if(BsyCntr >10) break;
	}
	if(0){ /*Set to "1" when debugging USB serial print*/
		switch (USBstat){
		case USBD_BUSY:
			sprintf(buf, "#USB BUSY# - %s", msg);
			dispMsg(buf);
			break;
		case USBD_FAIL:
			sprintf(buf, "#USB FAIL# - %s", msg);
			dispMsg(buf);
			break;
		}
	}
	if(tstState) Test = true;
	return;
}

///////////////////////////////////////////////////////////////////////////////////////////////
//20210206 JMH Added "delay_us" function to provide a us delay via STM32CubeIDE platform
void delay_us (uint16_t us)
{
	__HAL_TIM_SET_COUNTER(&htim3,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim3) < us);  // wait for the counter to reach the us input in the parameter
}

//////////////////////////////////////////////////////////////////////
void delay(int Millis){
	while(Millis>0){
		delay_us(1000);
		--Millis;
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;
  //sConfig.SamplingTime = ADC_SAMPLETIME_112CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  if(PrgmNdx == 0){
	  htim2.Init.Prescaler = 9600-1;
	  htim2.Init.Period = 10000;
  }
  else if(PrgmNdx == 1){
	  htim2.Init.Prescaler = 96-1;
	  htim2.Init.Period = 21;
  }
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 96-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 96-1;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 4294967295;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|DMA_Evnt_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_D0_Pin LCD_D1_Pin LCD_D2_Pin LCD_D4_Pin
                           LCD_D5_Pin LCD_D6_Pin LCD_D7_Pin */
  GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_D3_Pin DMA_Evnt_Pin LCD_RD_Pin LCD_WR_Pin
                           LCD_RS_Pin LCD_CS_Pin LCD_RST_Pin */
  GPIO_InitStruct.Pin = LCD_D3_Pin|DMA_Evnt_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : KeyIn_EXT13_Pin */
  GPIO_InitStruct.Pin = KeyIn_EXT13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(KeyIn_EXT13_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */
// Called when first half of buffer is filled
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc) {
	int k;
	//if(DMACycle == 0) return;
	//HAL_GPIO_WritePin(DMA_Evnt_GPIO_Port, DMA_Evnt_Pin, GPIO_PIN_SET);
//	HlfCBtime = __HAL_TIM_GET_COUNTER(&htim5);
//	if(HlfCBtime>FulCBtime){
//			SAMPLING_RATE = 1024000000/(HlfCBtime-FulCBtime);
//		}
	if(Ready){
		//HlfCBcnt++;
		//		pntr++;
		//		if(pntr>341)pntr=0;
		Ready = !Ready;
		//DMACycle = 0;
		ResetGoertzel();
		if(!LongSmplFlg){// ~4ms sample interval
			//for(int i = 0; i < NL; i++){
			for(int i = 0 ; i < Hstop; i++){
				//Geo_buf[i] = adc_buf[i];    // read the DMA/ADC value from pin PB1; (k = 0 to 4096)
				k = (adc_buf[i] - BIAS);
				//			int pntr2 = i+pntr;
				//			if(pntr2>=Hstop) pntr2 -=Hstop;
				//			k =Geo_buf[pntr2];
				ProcessSample(k, i);
			}
			ComputeMags();
		}else{// ~8ms sample interval
			for(int i = 0 ; i < Hstop; i++){
				k = (adc_buf[i] - BIAS);
				ProcessSample(k, i);
			}
			Ready = true;
		}
	}
}

// Called when buffer is completely filled
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
	int k;
	//if(DMACycle == 1) return;
	//HAL_GPIO_WritePin(DMA_Evnt_GPIO_Port, DMA_Evnt_Pin, GPIO_PIN_SET);
//	FulCBtime = __HAL_TIM_GET_COUNTER(&htim5);
//	if(FulCBtime > HlfCBtime){
//		SAMPLING_RATE = 1024000000/(FulCBtime - HlfCBtime);
//	}
	if(Ready){
		//FulCBcnt++;
		//		pntr++;
		//		if(pntr>341)pntr=0;
		Ready = !Ready;
		//DMACycle = 1;
		int LastSmpl = 2*Hstop;//
		if(!LongSmplFlg){ //~4ms sample interval
			ResetGoertzel();
			for(int i = Hstop; i < LastSmpl; i++){
				//Geo_buf[i-Hstop] = adc_buf[i];    // read the DMA/ADC value from pin PB1; (k = 0 to 4096)
				k = (adc_buf[i] - BIAS);
				//			int pntr2 = i-(Hstop+1)+pntr;
				//			if(pntr2>=2048) pntr2 -= 2048;
				//			k =Geo_buf[pntr2];
				ProcessSample(k, i-Hstop);
			}

		}else{// ~8ms sample interval
			for(int i = Hstop; i <= LastSmpl; i++){
				//Geo_buf[i-Hstop] = adc_buf[i];    // read the DMA/ADC value from pin PB1; (k = 0 to 4096)
				k = (adc_buf[i] - BIAS);
				//			int pntr2 = i-(Hstop+1)+pntr;
				//			if(pntr2>=2048) pntr2 -= 2048;
				//			k =Geo_buf[pntr2];
				ProcessSample(k, i);
			}

		}
		ComputeMags();
		//Ready = true; this is now being reset in the ComputeMags() routine
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	  if(RunFFT_DEMO) FFT_PeriodElapsedCallback();
	  toggle ^= 1; //exclusive OR
	  if(toggle) PIN_HIGH(LED_GPIO_Port, LED_Pin);
	  else PIN_LOW(LED_GPIO_Port, LED_Pin);
}

/**
  * @brief This function handles EXTI line[15:10] interrupts.
  */
//void EXTI15_10_IRQHandler(void)
//{
//  /* USER CODE BEGIN EXTI15_10_IRQn 0 */
//
//  /* USER CODE END EXTI15_10_IRQn 0 */
//  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
//  /* USER CODE BEGIN EXTI15_10_IRQn 1 */
//  //KeyEvntSR();
//  /* USER CODE END EXTI15_10_IRQn 1 */
//}


///////////////////////////////////////////////////////////////////////////////////////////////


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  ShwUsrParams();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
