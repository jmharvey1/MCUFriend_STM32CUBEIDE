/*
  Arduino.h - Main include file for the Arduino SDK
  Copyright (c) 2005-2013 Arduino Team.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef Arduino_h
#define Arduino_h

#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include <stdint.h>
//#include "pgmspace.h" //20210206 JMH commented out
//#include <avr/io.h> //20210206 JMH commented out
//#include <avr/interrupt.h> //20210206 JMH commented out

#include "binary.h"
#include "stm32f4xx_hal.h"
#ifdef __cplusplus
extern "C"{
#endif

void yield(void);

#define HIGH 0x1
#define LOW  0x0

#define INPUT 0x0
#define OUTPUT 0x1
#define INPUT_PULLUP 0x2

#define LED_Pin GPIO_PIN_13
#define LED_GPIO_Port GPIOC
#define PA0 0
#define PA1 1
#define PA2 2
#define PA3 3
#define PA4 4
#define PA5 5
#define PA6 6
#define PA7 7


#define PB0 16
#define PB1 17
#define PB2 18
#define PB3 19
#define PB4 20
#define PB5 21
#define PB6 22
#define PB7 23
#define PB8 24
//#define LCD_D1_Pin GPIO_PIN_1
//#define LCD_D1_GPIO_Port GPIOA
//#define LCD_D2_Pin GPIO_PIN_2
//#define LCD_D2_GPIO_Port GPIOA
//#define LCD_D4_Pin GPIO_PIN_4
//#define LCD_D4_GPIO_Port GPIOA
//#define LCD_D5_Pin GPIO_PIN_5
//#define LCD_D5_GPIO_Port GPIOA
//#define LCD_D6_Pin GPIO_PIN_6
//#define LCD_D6_GPIO_Port GPIOA
//#define LCD_D7_Pin GPIO_PIN_7
//#define LCD_D7_GPIO_Port GPIOA
//#define LCD_D3_Pin GPIO_PIN_0
//#define LCD_D3_GPIO_Port GPIOB
//#define LCD_RD_Pin GPIO_PIN_5
//#define LCD_RD_GPIO_Port GPIOB
//#define LCD_WR_Pin GPIO_PIN_6
//#define LCD_WR_GPIO_Port GPIOB
//#define LCD_RS_Pin GPIO_PIN_7
//#define LCD_RS_GPIO_Port GPIOB
//#define LCD_CS_Pin GPIO_PIN_8
//#define LCD_CS_GPIO_Port GPIOB
//#define LCD_RST_Pin GPIO_PIN_9
//#define LCD_RST_GPIO_Port GPIOB

#define PI 3.1415926535897932384626433832795
#define HALF_PI 1.5707963267948966192313216916398
#define TWO_PI 6.283185307179586476925286766559
#define DEG_TO_RAD 0.017453292519943295769236907684886
#define RAD_TO_DEG 57.295779513082320876798154814105
#define EULER 2.718281828459045235360287471352


#define SERIAL  0x0
#define DISPLAY 0x1

//#define LSBFIRST 0
//#define MSBFIRST 1

enum BitOrder {
  LSBFIRST = 0,
  MSBFIRST = 1
};


//#define CHANGE 1
//#define FALLING 2
//#define RISING 3

#if defined(__AVR_ATtiny24__) || defined(__AVR_ATtiny44__) || defined(__AVR_ATtiny84__)
  #define DEFAULT 0
  #define EXTERNAL 1
  #define INTERNAL1V1 2
  #define INTERNAL INTERNAL1V1
#elif defined(__AVR_ATtiny25__) || defined(__AVR_ATtiny45__) || defined(__AVR_ATtiny85__)
  #define DEFAULT 0
  #define EXTERNAL 4
  #define INTERNAL1V1 8
  #define INTERNAL INTERNAL1V1
  #define INTERNAL2V56 9
  #define INTERNAL2V56_EXTCAP 13
#else  
#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__) || defined(__AVR_ATmega1284__) || defined(__AVR_ATmega1284P__) || defined(__AVR_ATmega644__) || defined(__AVR_ATmega644A__) || defined(__AVR_ATmega644P__) || defined(__AVR_ATmega644PA__)
#define INTERNAL1V1 2
#define INTERNAL2V56 3
#else
#define INTERNAL 3
#endif
#define DEFAULT 1
#define EXTERNAL 0
#endif

// undefine stdlib's abs if encountered
#ifdef abs
#undef abs
#endif

#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))
#define abs(x) ((x)>0?(x):-(x))
#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
#define round(x)     ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))
#define radians(deg) ((deg)*DEG_TO_RAD)
#define degrees(rad) ((rad)*RAD_TO_DEG)
#define sq(x) ((x)*(x))

//#define interrupts() sei()
//#define noInterrupts() cli()

#define clockCyclesPerMicrosecond() ( F_CPU / 1000000L )
#define clockCyclesToMicroseconds(a) ( (a) / clockCyclesPerMicrosecond() )
#define microsecondsToClockCycles(a) ( (a) * clockCyclesPerMicrosecond() )

/////////////////////////////////////////////////////////////////////////////
//global variables
//initialize the timer
void coretick_init(void);

//return dwt cycle count
#define coreticks()		(DWT->CYCCNT)
#ifndef ticks
  #define ticks()			coreticks()
#endif

//ticks per us - arduino styled function
#define F_CPU 2500 //JMH added this define based on BlackPill F411 configuration
#define cyclesPerMillisecond()		(F_CPU / 10ul)
#define cyclesPerMicrosecond()		(F_CPU / 10000ul)
#define millis()					(ticks() / cyclesPerMillisecond())
#define micros()					(ticks() / cyclesPerMicrosecond())

//precision delays using ticks()
void coretick_delay(uint32_t dly);
void coretick_delayms(uint32_t ms);
void coretick_delayus(uint32_t us);




/////////////////////////////////////////////////////////////////////////////



#define lowByte(w) ((uint8_t) ((w) & 0xff))
#define highByte(w) ((uint8_t) ((w) >> 8))

#define bitRead(value, bit) (((value) >> (bit)) & 0x01)
#define bitSet(value, bit) ((value) |= (1UL << (bit)))
#define bitClear(value, bit) ((value) &= ~(1UL << (bit)))
#define bitToggle(value, bit) ((value) ^= (1UL << (bit)))
#define bitWrite(value, bit, bitvalue) ((bitvalue) ? bitSet(value, bit) : bitClear(value, bit))

// avr-libc defines _NOP() since 1.6.2
#ifndef _NOP
#define _NOP() do { __asm__ volatile ("nop"); } while (0)
#endif

typedef unsigned int word;

#define bit(b) (1UL << (b))

typedef bool boolean;
typedef uint8_t byte;

void init(void);
void initVariant(void);

int atexit(void (*func)()) __attribute__((weak));
typedef struct {
	uint16_t Pin;
	GPIO_TypeDef* Port;
}PinPrt;

PinPrt PinXlate(uint8_t pin);//JMH 20210219 Black Pill STM32F411 Specific
void pinMode(uint8_t pin, uint8_t mode);//JMH 20210219 Black Pill STM32F411 Specific
void digitalWrite(uint8_t pin, uint8_t val);//JMH 20210219 Black Pill STM32F411 Specific
//int digitalRead(uint8_t pin);

extern ADC_HandleTypeDef hadc1;//JMH 20210219 Black Pill STM32F411 Specific
extern ADC_ChannelConfTypeDef sConfig;//JMH 20210219 Black Pill STM32F411 Specific
extern int OldPin;
void MX_ADC1_Init(ADC_HandleTypeDef* hadc1);//JMH 20210219 Black Pill STM32F411 Specific
int analogRead(uint8_t pin);//JMH 20210219 Black Pill STM32F411 Specific
//int analogRead(uint8_t pin, ADC_HandleTypeDef hadc1);
//void analogReference(uint8_t mode);
//void analogWrite(uint8_t pin, int val);

//unsigned long millis(void);
//unsigned long micros(void);
//void delay(unsigned long ms);//JMH 20210219 Black Pill STM32F411 Specific
void delayMicroseconds(unsigned int us);
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout);
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout);

void shiftOut(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder, uint8_t val);
uint8_t shiftIn(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder);

//void attachInterrupt(uint8_t interruptNum, void (*userFunc)(void), int mode);
//void detachInterrupt(uint8_t interruptNum);

void setup(void);
void loop(void);

// Get the bit location within the hardware port of the given virtual pin.
// This comes from the pins_*.c file for the active board configuration.

#define analogInPinToBit(P) (P)

// On the ATmega1280, the addresses of some of the port registers are
// greater than 255, so we can't store them in uint8_t's.
//extern const uint16_t PROGMEM port_to_mode_PGM[];
//extern const uint16_t PROGMEM port_to_input_PGM[];
//extern const uint16_t PROGMEM port_to_output_PGM[];
//
//extern const uint8_t PROGMEM digital_pin_to_port_PGM[];
//// extern const uint8_t PROGMEM digital_pin_to_bit_PGM[];
//extern const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[];
//extern const uint8_t PROGMEM digital_pin_to_timer_PGM[];

// Get the bit location within the hardware port of the given virtual pin.
// This comes from the pins_*.c file for the active board configuration.
// 
// These perform slightly better as macros compared to inline functions
//
#define digitalPinToPort(P) ( pgm_read_byte( digital_pin_to_port_PGM + (P) ) )
#define digitalPinToBitMask(P) ( pgm_read_byte( digital_pin_to_bit_mask_PGM + (P) ) )
#define digitalPinToTimer(P) ( pgm_read_byte( digital_pin_to_timer_PGM + (P) ) )
#define analogInPinToBit(P) (P)
#define portOutputRegister(P) ( (volatile uint8_t *)( pgm_read_word( port_to_output_PGM + (P))) )
#define portInputRegister(P) ( (volatile uint8_t *)( pgm_read_word( port_to_input_PGM + (P))) )
#define portModeRegister(P) ( (volatile uint8_t *)( pgm_read_word( port_to_mode_PGM + (P))) )

#define NOT_A_PIN 0
#define NOT_A_PORT 0

#define NOT_AN_INTERRUPT -1

#ifdef ARDUINO_MAIN
#define PA 1
#define PB 2
#define PC 3
#define PD 4
#define PE 5
#define PF 6
#define PG 7
#define PH 8
#define PJ 10
#define PK 11
#define PL 12
#endif

#define NOT_ON_TIMER 0
#define TIMER0A 1
#define TIMER0B 2
#define TIMER1A 3
#define TIMER1B 4
#define TIMER1C 5
//#define TIMER2  6
#define TIMER2A 7
#define TIMER2B 8

#define TIMER3A 9
#define TIMER3B 10
#define TIMER3C 11
#define TIMER4A 12
#define TIMER4B 13
#define TIMER4C 14
#define TIMER4D 15
#define TIMER5A 16
#define TIMER5B 17
#define TIMER5C 18

#ifdef __cplusplus
} // extern "C"
#endif

#ifdef __cplusplus
#include "WCharacter.h"
#include "WString.h"
//#include "HardwareSerial.h"
//#include "USBAPI.h"
#if defined(HAVE_HWSERIAL0) && defined(HAVE_CDCSERIAL)
#error "Targets with both UART0 and CDC serial not supported"
#endif

uint16_t makeWord(uint16_t w);
//uint16_t makeWord(byte h, byte l);

#define word(...) makeWord(__VA_ARGS__)

unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout = 1000000L);
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout = 1000000L);

void tone(uint8_t _pin, unsigned int frequency, unsigned long duration = 0);
void noTone(uint8_t _pin);

// WMath prototypes
//long random(long);
//long random(long, long);
void randomSeed(unsigned long);
long map(long, long, long, long, long);

#endif

//#include "pins_arduino.h" //20210206 JMH using modified file

#endif
