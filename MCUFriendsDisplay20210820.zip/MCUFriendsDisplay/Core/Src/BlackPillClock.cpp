/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.cpp
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "main.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include "MCUFRIEND_kbv.h"
#include "Adafruit_GFX.h"
#include "STM32F411def.h"
#include "Arduino.h"
//#include "utility/BlackPill_STM32F411def.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB8|PB9|

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MASKA  ~0x3F0000
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
//I2S_HandleTypeDef hi2s2;
//DMA_HandleTypeDef hdma_i2s2_ext_rx;
//DMA_HandleTypeDef hdma_spi2_tx;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

PCD_HandleTypeDef hpcd_USB_OTG_FS;
unsigned long AvgBias =0;
uint16_t ID;
int toggle = 0;

float sx = 0, sy = 1, mx = 1, my = 0, hx = -1, hy = 0;    // Saved H, M, S x & y multipliers
float sdeg=0, mdeg=0, hdeg=0;
uint16_t osx=120, osy=120, omx=120, omy=120, ohx=120, ohy=120;  // Saved H, M, S x & y coords
uint16_t x00=0, x11=0, y00=0, y11=0;
//uint32_t targetTime = 0;                    // for next 1 second timeout
boolean initial = 1;
char Bufr[30];

static uint8_t conv2d(const char* p) {
  uint8_t v = 0;
  if ('0' <= *p && *p <= '9')
    v = *p - '0';
  return 10 * v + *++p - '0';
}

uint8_t hh=conv2d(__TIME__), mm=conv2d(__TIME__+3), ss=conv2d(__TIME__+6);  // Get H, M, S from compile time

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
//static void MX_DMA_Init(void);
//static void MX_I2S2_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
void delay_us (uint16_t us);
void delay(int Millis);
//void Timer_ISR(void);
void dispMsg(char Msgbuf[32], int cursorX, int cursorY, int FontSz);
MCUFRIEND_kbv tft;

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
//	MX_DMA_Init();
//	MX_I2S2_Init();
	MX_USB_OTG_FS_PCD_Init();
	MX_TIM2_Init();
	MX_TIM3_Init();
	/* USER CODE BEGIN 2 */
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_Base_Start(&htim3);
	/*###########################################################################*/
	//                       Begin Arduino SetUp Code

	tft.reset();

	ID = tft.readID();

	//  ID = 0x4747;//MCUfriends.com 2.8" Display id
	//  ID = 0x9486;// MCUfriends.com 2.8" Display id;
	//  ID = 0x9341;// MCUfriends.com 2.8" Display id; (White Letters on Black Screen)
	//  ID = 0x6814;// MCUfriends.com 3.5" Display id
	//ID = 0x9090;//MCUfriends.com 3.5" Display id (Black Letters on White Screen)
	tft.begin(ID);//  The value here is screen specific & depends on the chipset used to drive the screen,
	tft.setRotation(2);

	//tft.fillScreen(ILI9341_BLACK);
	//tft.fillScreen(ILI9341_RED);
	//tft.fillScreen(ILI9341_GREEN);
	//tft.fillScreen(ILI9341_BLUE);
	//tft.fillScreen(ILI9341_BLACK);
	//tft.fillScreen(ILI9341_GREY);
	tft.fillScreen(TFT_LIGHTGREY);


	//tft.setTextColor(ILI9341_WHITE, ILI9341_GREY);  // Adding a background colour erases previous text automatically
	//tft.setTextColor(TFT_WHITE, ILI9341_GREY);  // Adding a background colour erases previous text automatically
	tft.setTextColor(TFT_WHITE, TFT_LIGHTGREY);  // Adding a background colour erases previous text automatically

	// Draw clock face
	//tft.fillCircle(120, 120, 118, ILI9341_GREEN);
	//tft.fillCircle(120, 120, 110, ILI9341_BLACK);
	tft.fillCircle(120, 120, 118, TFT_GREEN);
	//delay_us (50);
	tft.fillCircle(120, 120, 110, TFT_BLACK);

	// Draw 12 lines
	for(int i = 0; i<360; i+= 30) {
		sx = cos((i-90)*0.0174532925);
		sy = sin((i-90)*0.0174532925);
		x00 = sx*114+120;
		y00 = sy*114+120;
		x11 = sx*100+120;
		y11 = sy*100+120;

		//tft.drawLine(x00, y00, x11, y11, ILI9341_GREEN);
		tft.drawLine(x00, y00, x11, y11, TFT_GREEN);
	}

	// Draw 60 dots
	for(int i = 0; i<360; i+= 6) {
		sx = cos((i-90)*0.0174532925);
		sy = sin((i-90)*0.0174532925);
		x00 = sx*102+120;
		y00 = sy*102+120;
		// Draw minute markers
		//tft.drawPixel(x00, y00, ILI9341_WHITE);
		tft.drawPixel(x00, y00, TFT_WHITE);

		// Draw main quadrant dots
		//if(i==0 || i==180) tft.fillCircle(x00, y00, 2, ILI9341_WHITE);
		//if(i==90 || i==270) tft.fillCircle(x00, y00, 2, ILI9341_WHITE);
		if(i==0 || i==180) tft.fillCircle(x00, y00, 2, TFT_WHITE);
		if(i==90 || i==270) tft.fillCircle(x00, y00, 2, TFT_WHITE);
	}

	//tft.fillCircle(120, 121, 3, ILI9341_WHITE);
	tft.fillCircle(120, 121, 3, TFT_WHITE);

	// Draw text at position 120,260 using fonts 4
	// Only font numbers 2,4,6,7 are valid. Font 6 only contains characters [space] 0 1 2 3 4 5 6 7 8 9 : . a p m
	// Font 7 is a 7 segment font and only contains characters [space] 0 1 2 3 4 5 6 7 8 9 : .
	dispMsg(" Time Flies", 20, 260, 3);
	sprintf(Bufr," ID = 0x%x", ID );
	dispMsg(Bufr, 20, 290, 3);
	int k = 0;

	/*                         End Arduino SetUp Code                               */
	/*###########################################################################*/


	/* USER CODE END 2 */

	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	while (1)
	{
		/* USER CODE END WHILE */
		delay(20);
		int curPin = PB1; //Mic Board Analog output connection point
		k = analogRead(curPin); // read the ADC value from pin PB1; (k = 0 to 4096)
		AvgBias = ((99* AvgBias) +k)/100;

		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}
/* ####################         END MAIN LOOP        ##########################*/


//////////////////////////////////////////////////////////////////////
//20210206 JMH Added "delay_us" function to provide a us delay via STM32CubeIDE platform
void delay_us (uint16_t us)
{
	__HAL_TIM_SET_COUNTER(&htim3,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim3) < us);  // wait for the counter to reach the us input in the parameter
}

//////////////////////////////////////////////////////////////////////
void delay(int Millis){
	while(Millis>0){
		delay_us(1000);
		--Millis;
	}
}
//////////////////////////////////////////////////////////////////////

void dispMsg(char Msgbuf[32], int cursorX, int cursorY, int FontSz) {
  int msgpntr = 0;
  int curRow = 0;
  int offset =0;
  int fontH = 16;
  int fontW = 18;//12;
  int displayW = 320;
  int cnt = 0;
  while (Msgbuf[msgpntr] != 0) ++msgpntr;

  //clear previous entry
  tft.fillRect(cursorX , (cursorY), msgpntr * fontW, fontH + 10, TFT_LIGHTGREY);
  tft.setCursor(cursorX, cursorY);
  tft.setTextColor(TFT_BLACK);//tft.setTextColor(WHITE, BLACK);
  tft.setTextSize(FontSz);
  msgpntr = 0;
  while ( Msgbuf[msgpntr] != 0) {
    char curChar = Msgbuf[msgpntr];
    tft.print(curChar);
    msgpntr++;
    cnt++;
    if (((cnt) - offset)*fontW >= displayW) {
      curRow++;
      cursorX = 0;
      cursorY = curRow * (fontH + 10);
      offset = cnt;
      tft.setCursor(cursorX, cursorY);
//      if (curRow + 1 > row) {
//        scrollpg();
//      }
    }
    else cursorX = (cnt - offset) * fontW;
  }
}
//////////////////////////////////////////////////////////////////////
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 96;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 12;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
//static void MX_I2S2_Init(void)
//{
//
//  /* USER CODE BEGIN I2S2_Init 0 */
//
//  /* USER CODE END I2S2_Init 0 */
//
//  /* USER CODE BEGIN I2S2_Init 1 */
//
//  /* USER CODE END I2S2_Init 1 */
//  hi2s2.Instance = SPI2;
//  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
//  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
//  hi2s2.Init.DataFormat = I2S_DATAFORMAT_24B;
//  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
//  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_96K;
//  hi2s2.Init.CPOL = I2S_CPOL_LOW;
//  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
//  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_ENABLE;
//  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN I2S2_Init 2 */
//
//  /* USER CODE END I2S2_Init 2 */
//
//}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 9600-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 10000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 96-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USB_OTG_FS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_FS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_FS_Init 0 */

  /* USER CODE END USB_OTG_FS_Init 0 */

  /* USER CODE BEGIN USB_OTG_FS_Init 1 */

  /* USER CODE END USB_OTG_FS_Init 1 */
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_OTG_FS_Init 2 */

  /* USER CODE END USB_OTG_FS_Init 2 */

}

/**
  * Enable DMA controller clock
  */
//static void MX_DMA_Init(void)
//{
//
//  /* DMA controller clock enable */
//  __HAL_RCC_DMA1_CLK_ENABLE();
//
//  /* DMA interrupt init */
//  /* DMA1_Stream3_IRQn interrupt configuration */
//  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
//  /* DMA1_Stream4_IRQn interrupt configuration */
//  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
//
//}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
			|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin
			|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin : LED_Pin */
	GPIO_InitStruct.Pin = LED_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

//	uint32_t mode = 0x1u;
//	uint32_t position;
//	uint32_t ioposition = 0x00U;
//	uint32_t iocurrent = 0x00U;
//	uint32_t temp = 0x00U;
//	uint8_t dataVal = 0xFFU;
//	uint32_t ABSRR = 0x00U;
//	uint32_t ABSRR0 = 0x00U;
//	uint32_t ABSRR1 = 0x00U;
//	uint32_t ABSRR2 = 0x00U;
//	temp = MASKA;
//	temp = 0x00U;
//	temp =  0x0080 << 16;
//	ABSRR = (((dataVal) & (1<<1)) << 6); //Binary:11100000000
//	temp =  0x0080 << 16;                         //       100000000  (((dataVal) & (1<<7)) << 1) bit7/PA8
//	PIN_OUTPUT(LCD_D0_GPIO_Port, LCD_D0_Pin);     //     10000000000  (((dataVal) & (1<<2)) << 8) bit2/PA10
//	PIN_OUTPUT(LCD_D1_GPIO_Port, LCD_D1_Pin);     //      1000000000  (((dataVal) & (1<<0)) << 9) bit0/PA9
//	PIN_OUTPUT(LCD_D2_GPIO_Port, LCD_D2_Pin);
//	PIN_OUTPUT(LCD_D3_GPIO_Port, LCD_D3_Pin);
//	PIN_OUTPUT(LCD_D4_GPIO_Port, LCD_D4_Pin);
//	PIN_OUTPUT(LCD_D5_GPIO_Port, LCD_D4_Pin);
//	PIN_OUTPUT(LCD_D6_GPIO_Port, LCD_D6_Pin);
//	PIN_OUTPUT(LCD_D7_GPIO_Port, LCD_D7_Pin);
//	temp = LCD_D7_GPIO_Port->MODER;
	//10101000000000000000000000000000
	//10101000000000000101000100010100
	//11111111111111111010111011101011
	//00000000000000000101000100010100
	//                      1010000100
	//11111111111111111111111111111011
	//00000000000000000000000000000100
//	temp = LCD_D3_GPIO_Port->MODER;
//	/* Configure the port pins */
//	for(position = 0U; position < 16U; position++)
//	{
//		/* Get the IO position */
//		ioposition = 0x01U << position;
//		/* Get the current IO position */
//		iocurrent = (uint32_t)(LED_Pin) & ioposition;
//		if(iocurrent == ioposition) break;
//	}
//	uint32_t position2 = 0U;
//	position2 = CALL_FUNCS(LED_Pin);
//	temp = PINMASK(LED_Pin);
//	temp = LED_GPIO_Port->MODER;
//	PIN_INPUT(LED_GPIO_Port, LED_Pin);
//	temp = LED_GPIO_Port->MODER;
//	PIN_OUTPUT(LED_GPIO_Port, LED_Pin);
//	temp = LED_GPIO_Port->MODER;


	/*Configure GPIO pins : LCD_D0_Pin LCD_D1_Pin LCD_D2_Pin LCD_D4_Pin
                           LCD_D5_Pin LCD_D6_Pin LCD_D7_Pin */
	GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
			|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : LCD_D3_Pin LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin
                           LCD_CS_Pin LCD_RST_Pin */
	GPIO_InitStruct.Pin = LCD_D3_Pin|LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin
			|LCD_CS_Pin|LCD_RST_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	//HAL_GPIO_TogglePin(,);
	toggle ^= 1;
	//digitalWrite(LED_BUILTIN, toggle);//Arduino call syntax
	if(toggle) PIN_HIGH(LED_GPIO_Port, LED_Pin);
	else PIN_LOW(LED_GPIO_Port, LED_Pin);
	//HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, (GPIO_PinState)toggle);
	ss++;              // Advance second
	    if (ss==60) {
	      ss=0;
	      mm++;            // Advance minute
	      if(mm>59) {
	        mm=0;
	        hh++;          // Advance hour
	        if (hh>23) {
	          hh=0;
	        }
	      }
	    }

	    // Pre-compute hand degrees, x & y coords for a fast screen update
	    sdeg = ss*6;                  // 0-59 -> 0-354
	    mdeg = mm*6+sdeg*0.01666667;  // 0-59 -> 0-360 - includes seconds
	    hdeg = hh*30+mdeg*0.0833333;  // 0-11 -> 0-360 - includes minutes and seconds
	    hx = cos((hdeg-90)*0.0174532925);
	    hy = sin((hdeg-90)*0.0174532925);
	    mx = cos((mdeg-90)*0.0174532925);
	    my = sin((mdeg-90)*0.0174532925);
	    sx = cos((sdeg-90)*0.0174532925);
	    sy = sin((sdeg-90)*0.0174532925);

	    if (ss==0 || initial) {
	      initial = 0;
	      // Erase hour and minute hand positions every minute
	      //tft.drawLine(ohx, ohy, 120, 121, ILI9341_BLACK);
	      tft.drawLine(ohx, ohy, 120, 121, TFT_BLACK);
	      ohx = hx*62+121;
	      ohy = hy*62+121;
	      //tft.drawLine(omx, omy, 120, 121, ILI9341_BLACK);
	      tft.drawLine(omx, omy, 120, 121, TFT_BLACK);
	      omx = mx*84+120;
	      omy = my*84+121;
	    }

	      // Redraw new hand positions, hour and minute hands not erased here to avoid flicker
	      //tft.drawLine(osx, osy, 120, 121, ILI9341_BLACK);
	      tft.drawLine(osx, osy, 120, 121, TFT_BLACK);
	      osx = sx*90+121;
	      osy = sy*90+121;
	      tft.drawLine(osx, osy, 120, 121, TFT_RED);
	      tft.drawLine(ohx, ohy, 120, 121, TFT_WHITE);
	      tft.drawLine(omx, omy, 120, 121, TFT_WHITE);
	      tft.drawLine(osx, osy, 120, 121, TFT_RED);

	    //tft.fillCircle(120, 121, 3, ILI9341_RED);
	    tft.fillCircle(120, 121, 3, TFT_RED);
	    sprintf(Bufr," Bias: %d", AvgBias );
	    dispMsg(Bufr, 20, 320, 3);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
