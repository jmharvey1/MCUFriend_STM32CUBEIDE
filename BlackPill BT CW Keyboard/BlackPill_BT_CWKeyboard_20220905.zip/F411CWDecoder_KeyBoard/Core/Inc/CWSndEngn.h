/*
 * CWSndEngn.h
 *
 *  Created on: Oct 5, 2021
 *      Author: jim
 */
	/*
	 * Given:
	 * 	Global Variables:
	 * 		TmInrvlCnt, KeyState, SymblCnt, RingBufrPntr1, RingBufrPntr2,
	 * 		Symbl
	 *
	 * 1. Is Time interval (TmInrvlCnt) > 0
	 * 2. If "Yes" (we're actively sending), Dec TmInrvlCnt
	 * Is Is TmInrvlCnt now = 0?
	 * 		If "NO" return (wait for next Interrupt).
	 * 		If "YES", Were we sending a Keyup (Space) or a KeyDwn?.
	 * 			If KeyDwn then need to change to Keyup, and setup inter-character break (1 time interval)
	 * 			If Keyup, and are we actively processing a letter?
	 * 5. 			If "YES" (SymblCnt >0) continue to unpack (Goto SymblCnt >0)
	 * 6. 			If "NO" (SymblCnt =0) continue space interval to from a letter break
	 * 				(+2 time intervals for a total of 3 continuous Keyup periods)
	 * 				 Exit to wait for next interrupt.
	 *
	 * Then if here(KeyUp & TmIntrvlCnt = 0):
	 * Is there a symbol waiting to be processed?
	 * 7. 	If "NO" (RingBufrPntrs are =) Exit to wait for next interrupt.
	 * 8. 	If "YES" (RingBufrPntr1 != RingBufrPntr2), there's symbol to be processed,
	 *    	get it( inc RingBufrPntr2), set SymbCnt = 15.
	 *    	(DO While loop) shift "Symbl" left an dec SymbCnt to the 1st active bit
	 *    	(SymblCnt equals the number of symbols to be sent) (Goto SymblCnt >0)
	 *
	 *  SymblCnt >0:
	 *  	shift "Symbl" left
	 *      Is this symbol a "dit" (0) or a "dah" (1)?
	 *      	its a "dit" set TmInrvlCnt = 1
	 *      	its a "dah" set TmInrvlCnt = 3
	 *    Set KeyDwn Exit to wait for next interrupt.
	 */

///////////////////////////////////////////////////////////////////////////

#ifndef INC_CWSNDENGN_H_
#define INC_CWSNDENGN_H_
#include "stdint.h"
#include "main.h"
#include "MCUFRIEND_kbv.h"
class CWSNDENGN
{
private:
	TIM_HandleTypeDef *pDotClk;
	MCUFRIEND_kbv *ptft;
	int TmInrvlCnt;
	bool KeyDwn;
	bool LtrBkFlg;
	bool ActvFlg;
	bool SpcFlg;
	bool SOTFlg;
	bool StrTxtFlg;
	bool TuneFlg;
	bool LstNtrySpcFlg;
	bool RfrshSpd;
	int curWPM;
	int SymblCnt;
	int RingBufrPntr1;
	int RingBufrPntr2;
	int intcntr;//used for debugging
	unsigned int ARReg;
	unsigned int SndWPM;
	uint16_t Symbl;
	char SndBuf[160];
	void ConfigKey(bool KeyState);
	int CalcARRval(int wpm);
	int AdvncPntr(int pntr);
	void ShwWPM(int wpm);
	uint16_t ChrToSymb(char* CurChr);

public:
	CWSNDENGN(TIM_HandleTypeDef *TIM_ptr, MCUFRIEND_kbv *tft_ptr);
	bool IsActv(void);
	bool LstNtrySpc(void);
	int Intr(void);
	void AddNewChar(char* Nuchr);
	void LdMsg(char *Msg, size_t len);
	void IncWPM(void);
	void DecWPM(void);
	void Tune(void);
	int Delete(void);
	void SOTmode(void);
	void StrTxtmode(void);
	void AbortSnd(void);
	void RefreshWPM(void);
	int GetWPM(void);
	void SetWPM(int newWPM);

};
#endif /* INC_CWSNDENGN_H_ */
