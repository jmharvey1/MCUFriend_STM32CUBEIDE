/*
 * KeyBoardR01.h
 *
 *  Created on: Oct 6, 2021
 *      Author: jim
 */

#ifndef INC_KEYBOARDR01_H_
#define INC_KEYBOARDR01_H_

#include "CWSndEngn.h"
#include "TFTMsgBox.h"
#include "MCUFRIEND_kbv.h"
#include "usbhub.h"

//#define TFTOUTPUT //enable to direct Serial.print calls to the TFT Display

extern CWSNDENGN CWsndengn;
extern TFTMsgBox tftmsgbx;
extern USB Usb;
extern struct DF_t DFault;
extern char MyCall[10];
extern char StrdTxt[20];
extern char MemF2[80];
extern MCUFRIEND_kbv tft;
extern TIM_HandleTypeDef htim5;
//extern float DimFctr;//TODO Needs to go away
//extern float TSF;//TODO Needs to go away
//extern int BIAS;//TODO Needs to go away
//extern long ManSqlch;//TODO Needs to go away
//extern bool NoiseSqlch;//TODO Needs to go away
extern int DeBug;//TODO Needs to go away
//extern float NSF;//TODO Needs to go away
//extern bool AutoTune;//TODO Needs to go away
//extern float TARGET_FREQUENCYC;//TODO Needs to go away
//extern float SAMPLING_RATE;//TODO Needs to go away
extern bool setupFlg;
extern uint16_t KBntry; //used by SetUpScrn.cpp to handle Keyboard entries while user is operating in settings mode
void dispMsg(char Msgbuf[50], uint16_t Color);
template <class T>
void HexStr(T val, char* bufptr) {
        int num_nibbles = sizeof (T) * 2;
        int i = 0;
        do {
                char v = 48 + (((val >> (num_nibbles - 1) * 4)) & 0x0f);
                if(v > 57) v += 7;
                bufptr[i] = v;
                i++;
        } while(--num_nibbles);
        bufptr[i] = 0;
}
#endif /* INC_KEYBOARDR01_H_ */
