/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : TestUSB.cpp
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
//#include <eeprom.h>
#include <SetUpCwDecoder.h>

#include "main.h"
#include "pgmstrings.h"
#include "usb_device.h"
#include "BtnSuprt.h"
#include "DcodeCW.h"
#include "FFTdemo.h"
#include "usbd_cdc_if.h"
//#include "WS2812B.h"
#include "Arduino.h"
#include "TouchScreen_kbv.h"
#include "UTFTGLUE.h"              //use GLUE class and constructor

#include "usbhub.h"
#include "BTD.h"

//#include "../../Libraries/eeprom/Inc/stm32f4xx_flash.h"
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB8|PB9|
/*
*	MAX3421E Mini USB2.0 Shield to STM32 SPI2 pin connections
*	Shield-lbl|SS |CLK |MISO|MOSI|VBUS|INT|RST|VCC|   |
*	STM32 pin |PA8|PB15|PB14|PB10| 5V |PA9| R |3V3| G |
*
*	Mini Shield Notes:
*	1. Ground pin not labeled. Use 2nd pin from bottom.
*	2. VBUS trace must be cut to isolate USB "A" connector from MAX3421 3.3 volt runs.
*	3. Shield pin labeled "CLK" is actually connected to the MAX3421 pin 16 "MOSI".
*	4. Shield pin labeled "MOSI" is actually connected to the MAX3421 pin 13 "SCLK".
*	5. Shield pin labeled "RST" must be "tied high", otherwise MAX3421 is in perpetual "reset" state.
 */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define RingBufSz 400

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
DMA_HandleTypeDef hdma_adc1;

SPI_HandleTypeDef hspi2;
extern SPI_HandleTypeDef SPI_Handle = hspi2;//Do this to keep the USBHost library happy
DMA_HandleTypeDef hdma_spi2_tx;

TIM_HandleTypeDef htim2; //hanldes the Black pill's blue LED BLINK process
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim5;
/* USER CODE BEGIN PV */
uint8_t LstIntrState = 0;
/* touch screen variables */
char RevDate[9] = "20210921";
char RingbufChar[RingBufSz];
uint16_t RingbufClr[RingBufSz];
char Pgbuf[448];
uint16_t PgbufColor[448];

int RingbufPntr1 =0;
int RingbufPntr2 =0;
char Msgbuf[50];
char Title[50];
int displayW = 320;
int CPL = 40; //number of characters each line that a 3.5" screen can contain
int row = 10; //number of uable rows on a 3.5" screen
int scrnHeight = 0;
int scrnWidth = 0;
int cursorY = 0;
int cursorX = 0;
int cnt = 0; //used in scrollpage routine
int curRow = 0;
int offset = 0;
int textSrtX = 0;
int textSrtY = 0;
/* End Touch Screen Variables */
bool USBinit = false;
bool running = false;
int tim2IntrCnt = 0;
uint8_t toggle =0x0;

uint16_t ID = 0x9090;

const int fontH = 16;// needed global variable for read/detect button support
const int fontW = 12;// needed global variable for read/detect button support
//const int XP=PB7, XM=PA6, YP=PA7, YM=PB6;
//x = map(p.y, LEFT=492, RT=522, 0, 320)
//y = map(p.x, TOP=399, BOT=634, 0, 480)
//const int TS_LEFT=634,TS_RT=399,TS_TOP=492,TS_BOT=522;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* Black Pill #define STM32F411 Init Routines */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
//static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM5_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI2_Init(void);
/* USER CODE BEGIN PFP */
/* Tone DSP Routines */

/*standard support routines */
//uint32_t flash_read(uint32_t address);
//void flash_write(uint32_t address, uint32_t data);
/* TFT Display Print Support functions*/
void ShwINTRPinState(void);
void MAX3421INT(void);
void delay_us (uint16_t us);//this is called in the MCUFRIEND_kbv.cpp file
void scrollpg();
void DisplCrLf(void);
void dispMsg2(void);
void dispMsg(char Msgbuf[50], uint16_t Color);

/* USB_Desc.ino routines */
void PrintAllAddresses(UsbDevice *pdev);
void PrintAddress(uint8_t addr);
uint8_t getdevdescr( uint8_t addr, uint8_t &num_conf );
void PrintDescriptors(uint8_t addr);
void PrintAllDescriptors(UsbDevice *pdev);
void printunkdescr( uint8_t* descr_ptr );
void printProgStr(const char* str);
void printepdescr( uint8_t* descr_ptr );
void printintfdescr( uint8_t* descr_ptr );
void printconfdescr( uint8_t* descr_ptr );
void print_hex(int v, int num_places);
uint8_t getconfdescr( uint8_t addr, uint8_t conf );
void printhubdescr(uint8_t *descrptr, uint8_t addr);
/* END USB_Desc.ino routines */
void EXTI15_10_IRQHandler(void);
/* USER CODE E#define ND PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
MCUFRIEND_kbv tft;
UTFTGLUE myGLCD(0,0,0,0,0,0); //all duvoid PrintAllDescriptors(UsbDevice *pdev)mmy args
SerialClass Serial; // Arduino styuint8_t void PrintAllDescriptors(UsbDevice *pdev)getdevdescr( uint8_t addr, uint8_t &num_conf );le Serial class
MAX3421E Max;//used to support ShwINTRPinState() function
USB Usb;
//USBHub Hub1(&Usb); // Some dongles have a hub inside
BTD Btd(&Usb); // You have to create the Bluetooth Dongle instance like so
//WS2812B strip((uint16_t)LED_NO, &hspi2, &hdma_spi2_tx );//


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_TIM2_Init();
	MX_TIM3_Init();
	MX_TIM5_Init();
	MX_USB_DEVICE_Init();
	MX_ADC1_Init();
	MX_SPI2_Init();
	SPI_Handle = hspi2;
	/* USER CODE BEGIN 2 */

	HAL_TIM_Base_Start_IT(&htim2); // Handles the Blackpill's blue LED BLINK process
	HAL_TIM_Base_Start(&htim3); //JMH these are important; if not here the interrupt clock functions wont work
	HAL_TIM_Base_Start(&htim5);
	//HAL_TIM_Base_Start_IT(&htim2);
	coretick_init(); //JMH Added to support time measurements i.e millis() & micros() see Arduino.h & Arduino.cpp
	LstIntrState = 0;
	/* Infinite loop */
	/* USER CODE BEGIN WHILE */
	tft.reset();
	ID = tft.readID();
	if (ID == 0x9090) ID = 0x9486; //do this to fix color issues
	tft.begin(ID);//  The value here is screen specific & depends on the chipset used to drive the screen,
	tft.setRotation(1); // valid values 1 or 3
	tft.fillScreen(BLACK);
	tft.fillScreen(BLACK);//Had to do this twice to get the Screen Fully "Blacked" out
	scrnHeight = tft.height();
	scrnWidth = tft.width();
	displayW = scrnWidth;

	tft.setCursor(textSrtX, textSrtY);
	tft.setTextColor(WHITE);//tft.setTextColor(WHITE, BLACK);
	tft.setTextSize(2);
	tft.setTextWrap(false);
	if (scrnHeight == 320) { //true for the 3.5 inch tft display
		sprintf( Title, "             KW4KD (%s)\n", RevDate );
	}
	dispMsg(Title, TFT_WHITE);

	/* END touch-screen setup*/


	Serial.println(F("Start"));
	if (Usb.Init() == -1) { //JMH -this should be called "MAX3421.Init"; See usbhost.h
		Serial.println(F("OSC did not start"));
		while (1); // Halt
	}
	else{
		Serial.println(F("Passed OSC start check"));
	}
	delay( 200 );
	while (1)
		/* USER CODE END WHILE */
	{
		delay(250);
		Usb.Task();
		int CurUSBstate = Usb.getUsbTaskState();
		if ( CurUSBstate == USB_STATE_RUNNING )
		{
			running = true;
			Serial.println(F("Begin Host Descriptor Report"));

			Usb.ForEachUsbDevice(&PrintAllDescriptors);
			Usb.ForEachUsbDevice(&PrintAllAddresses);
			dispMsg("DONE", TFT_GREEN);

			while ( running ) { // stop
				if(!running){
					if (Usb.Init() == -1) { //JMH -this should be called "MAX3421.Init"; See usbhost.h
						Serial.println(F("OSC did not start"));
						while (1); // Halt
					}
					else{
						Serial.println(F("Passed OSC start check"));
					}
				}
			}
		}
		else{
			switch(CurUSBstate) {
			case 0x10:
				Serial.println(F("USB_STATE_DETACHED"));
				break;
			case 0x11:
				Serial.println(F("USB_DETACHED_SUBSTATE_INITIALIZE"));
				break;
			case 0x12:
				Serial.println(F("USB_DETACHED_SUBSTATE_WAIT_FOR_DEVICE"));
				Usb.Init();
				break;
			case 0x13:
				Serial.println(F("USB_DETACHED_SUBSTATE_ILLEGAL"));
				break;
			case 0x20:
				Serial.println(F("USB_ATTACHED_SUBSTATE_SETTLE"));
				break;
			case 0x30:
				Serial.println(F("USB_ATTACHED_SUBSTATE_RESET_DEVICE"));
				break;
			case 0x40:
				Serial.println(F("USB_ATTACHED_SUBSTATE_WAIT_RESET_COMPLETE"));
				break;
			case 0x50:
				Serial.println(F("USB_ATTACHED_SUBSTATE_WAIT_SOF"));
				break;
			case 0x51:
				Serial.println(F("USB_ATTACHED_SUBSTATE_WAIT_RESET"));
				break;
			case 0x60:
				Serial.println(F("USB_ATTACHED_SUBSTATE_GET_DEVICE_DESCRIPTOR_SIZE"));
				break;
			case 0x70:
				Serial.println(F("USB_STATE_ADDRESSING"));
				break;
			case 0x80:
				Serial.println(F("USB_STATE_CONFIGURING - 0x80"));
				break;
			case 0x90:
				Serial.println(F("USB_STATE_RUNNING - 0x90"));
				break;
			case 0xa0:
				Serial.println(F("USB_STATE_ERROR - 0xa0"));
				break;
			}
		}

		/* USER CODE BEGIN 3 */
	}
	/* USER CODE END 3 */
}//end main loop
//////////////////////////////////////////////////////////////////////////////////////////////////
void PrintAllAddresses(UsbDevice *pdev)
{
	UsbDeviceAddress adr;
	adr.devAddress = pdev->address.devAddress;
	Serial.print("\r\nAddr:");
	Serial.print(adr.devAddress, HEX);
	Serial.print("(");
	Serial.print(adr.bmHub, HEX);
	Serial.print(".");
	Serial.print(adr.bmParent, HEX);
	Serial.print(".");
	Serial.print(adr.bmAddress, HEX);
	Serial.println(")");
}

void PrintAddress(uint8_t addr)
{
  UsbDeviceAddress adr;
  adr.devAddress = addr;
  Serial.print("\r\nADDR:\t");
  Serial.println(adr.devAddress, HEX);
  Serial.print("DEV:\t");
  Serial.println(adr.bmAddress, HEX);
  Serial.print("PRNT:\t");
  Serial.println(adr.bmParent, HEX);
  Serial.print("HUB:\t");
  Serial.println(adr.bmHub, HEX);
}

void PrintDescriptors(uint8_t addr)
{
  uint8_t rcode = 0;
  uint8_t num_conf = 0;
  delay(2000);
  rcode = getdevdescr( (uint8_t)addr, num_conf );
  delay(5000);
  if ( rcode )
  {
    printProgStr(Gen_Error_str);
    print_hex( rcode, 8 );
  }
  Serial.print("\r\n");

  for (int i = 0; i < num_conf; i++)
  {
	delay(2000);
    rcode = getconfdescr( addr, i );                 // get configuration descriptor
    if ( rcode )
    {
      printProgStr(Gen_Error_str);
      print_hex(rcode, 8);
    }
    Serial.println("\r\n");
  }
}

void PrintAllDescriptors(UsbDevice *pdev)
{
  Serial.println("\r\n");
  print_hex(pdev->address.devAddress, 8);
  Serial.println("\r\n--");
  PrintDescriptors( pdev->address.devAddress );
}
uint8_t getdevdescr( uint8_t addr, uint8_t &num_conf )
{
  USB_DEVICE_DESCRIPTOR buf;
  uint8_t rcode;
  rcode = Usb.getDevDescr( addr, 0, 0x12, ( uint8_t *)&buf );
  if ( rcode ) {
    return ( rcode );
  }
  printProgStr(Dev_Header_str);
  printProgStr(Dev_Length_str);
  print_hex( buf.bLength, 8 );
  printProgStr(Dev_Type_str);
  print_hex( buf.bDescriptorType, 8 );
  printProgStr(Dev_Version_str);
  print_hex( buf.bcdUSB, 16 );
  printProgStr(Dev_Class_str);
  print_hex( buf.bDeviceClass, 8 );
  printProgStr(Dev_Subclass_str);
  print_hex( buf.bDeviceSubClass, 8 );
  printProgStr(Dev_Protocol_str);
  print_hex( buf.bDeviceProtocol, 8 );
  printProgStr(Dev_Pktsize_str);
  print_hex( buf.bMaxPacketSize0, 8 );
  printProgStr(Dev_Vendor_str);
  print_hex( buf.idVendor, 16 );
  printProgStr(Dev_Product_str);
  print_hex( buf.idProduct, 16 );
  printProgStr(Dev_Revision_str);
  print_hex( buf.bcdDevice, 16 );
  printProgStr(Dev_Mfg_str);
  print_hex( buf.iManufacturer, 8 );
  printProgStr(Dev_Prod_str);
  print_hex( buf.iProduct, 8 );
  printProgStr(Dev_Serial_str);
  print_hex( buf.iSerialNumber, 8 );
  printProgStr(Dev_Nconf_str);
  print_hex( buf.bNumConfigurations, 8 );
  num_conf = buf.bNumConfigurations;
  return ( 0 );
}

void printhubdescr(uint8_t *descrptr, uint8_t addr)
{
  HubDescriptor  *pHub = (HubDescriptor*) descrptr;
  uint8_t        len = *((uint8_t*)descrptr);

  printProgStr(PSTR("\r\n\r\nHub Descriptor:\r\n"));
  printProgStr(PSTR("bDescLength:\t\t"));
  Serial.println(pHub->bDescLength, HEX);

  printProgStr(PSTR("bDescriptorType:\t"));
  Serial.println(pHub->bDescriptorType, HEX);

  printProgStr(PSTR("bNbrPorts:\t\t"));
  Serial.println(pHub->bNbrPorts, HEX);

  printProgStr(PSTR("LogPwrSwitchMode:\t"));
  Serial.println(pHub->LogPwrSwitchMode, BIN);

  printProgStr(PSTR("CompoundDevice:\t\t"));
  Serial.println(pHub->CompoundDevice, BIN);

  printProgStr(PSTR("OverCurrentProtectMode:\t"));
  Serial.println(pHub->OverCurrentProtectMode, BIN);

  printProgStr(PSTR("TTThinkTime:\t\t"));
  Serial.println(pHub->TTThinkTime, BIN);

  printProgStr(PSTR("PortIndicatorsSupported:"));
  Serial.println(pHub->PortIndicatorsSupported, BIN);

  printProgStr(PSTR("Reserved:\t\t"));
  Serial.println(pHub->Reserved, HEX);

  printProgStr(PSTR("bPwrOn2PwrGood:\t\t"));
  Serial.println(pHub->bPwrOn2PwrGood, HEX);

  printProgStr(PSTR("bHubContrCurrent:\t"));
  Serial.println(pHub->bHubContrCurrent, HEX);

  for (uint8_t i = 7; i < len; i++)
    print_hex(descrptr[i], 8);

  //for (uint8_t i=1; i<=pHub->bNbrPorts; i++)
  //    PrintHubPortStatus(&Usb, addr, i, 1);
}

uint8_t getconfdescr( uint8_t addr, uint8_t conf )
{
	uint8_t buf[ BUFSIZE ];
	uint8_t* buf_ptr = buf;
	uint8_t rcode;
	uint8_t descr_length;
	uint8_t descr_type;
	uint16_t total_length;
	rcode = Usb.getConfDescr( addr, 0, 4, conf, buf );  //get total length
	//  LOBYTE( total_length ) = buf[ 2 ];
	//  HIBYTE( total_length ) = buf[ 3 ];
	if ( total_length > 256 ) {   //check if total length is larger than buffer
		printProgStr(Conf_Trunc_str);
		total_length = 256;
	}
	rcode = Usb.getConfDescr( addr, 0, total_length, conf, buf ); //get the whole descriptor
	while ( buf_ptr < buf + total_length ) { //parsing descriptors
		descr_length = *( buf_ptr );
		if(descr_length>0){
			descr_type = *( buf_ptr + 1 );
			switch ( descr_type ) {
			case ( USB_DESCRIPTOR_CONFIGURATION ):
        		printconfdescr( buf_ptr );
			break;
			case ( USB_DESCRIPTOR_INTERFACE ):
        		printintfdescr( buf_ptr );
			break;
			case ( USB_DESCRIPTOR_ENDPOINT ):
        		printepdescr( buf_ptr );
			break;
			case 0x29:
				printhubdescr( buf_ptr, addr );
				break;
			default:
				printunkdescr( buf_ptr );
				break;
			}//switch( descr_type
		}
		if(descr_length == 0) buf_ptr++;
		else {
			buf_ptr = ( buf_ptr + descr_length );    //advance buffer pointer
			delay(2000);
		}

	}//while( buf_ptr <=...
	return ( rcode );
}
/* prints hex numbers with leading zeroes */
// copyright, Peter H Anderson, Baltimore, MD, Nov, '07
// source: http://www.phanderson.com/arduino/arduino_display.html
void print_hex(int v, int num_places)
{
	int mask = 0, n, num_nibbles, digit;

	for (n = 1; n <= num_places; n++) {
		mask = (mask << 1) | 0x0001;
	}
	v = v & mask; // truncate v to specified number of places

	num_nibbles = num_places / 4;
	if ((num_places % 4) != 0) {
		++num_nibbles;
	}
	do {
		digit = ((v >> (num_nibbles - 1) * 4)) & 0x0f;
		Serial.print(digit, HEX);
	}
	while (--num_nibbles);
}
/* function to print configuration descriptor */
void printconfdescr( uint8_t* descr_ptr )
{
  USB_CONFIGURATION_DESCRIPTOR* conf_ptr = ( USB_CONFIGURATION_DESCRIPTOR* )descr_ptr;
  printProgStr(Conf_Header_str);
  printProgStr(Conf_Totlen_str);
  print_hex( conf_ptr->wTotalLength, 16 );
  printProgStr(Conf_Nint_str);
  print_hex( conf_ptr->bNumInterfaces, 8 );
  printProgStr(Conf_Value_str);
  print_hex( conf_ptr->bConfigurationValue, 8 );
  printProgStr(Conf_String_str);
  print_hex( conf_ptr->iConfiguration, 8 );
  printProgStr(Conf_Attr_str);
  print_hex( conf_ptr->bmAttributes, 8 );
  printProgStr(Conf_Pwr_str);
  print_hex( conf_ptr->bMaxPower, 8 );
  return;
}
/* function to print interface descriptor */
void printintfdescr( uint8_t* descr_ptr )
{
  USB_INTERFACE_DESCRIPTOR* intf_ptr = ( USB_INTERFACE_DESCRIPTOR* )descr_ptr;
  printProgStr(Int_Header_str);
  printProgStr(Int_Number_str);
  print_hex( intf_ptr->bInterfaceNumber, 8 );
  printProgStr(Int_Alt_str);
  print_hex( intf_ptr->bAlternateSetting, 8 );
  printProgStr(Int_Endpoints_str);
  print_hex( intf_ptr->bNumEndpoints, 8 );
  printProgStr(Int_Class_str);
  print_hex( intf_ptr->bInterfaceClass, 8 );
  printProgStr(Int_Subclass_str);
  print_hex( intf_ptr->bInterfaceSubClass, 8 );
  printProgStr(Int_Protocol_str);
  print_hex( intf_ptr->bInterfaceProtocol, 8 );
  printProgStr(Int_String_str);
  print_hex( intf_ptr->iInterface, 8 );
  return;
}
/* function to print endpoint descriptor */
void printepdescr( uint8_t* descr_ptr )
{
  USB_ENDPOINT_DESCRIPTOR* ep_ptr = ( USB_ENDPOINT_DESCRIPTOR* )descr_ptr;
  printProgStr(End_Header_str);
  printProgStr(End_Address_str);
  print_hex( ep_ptr->bEndpointAddress, 8 );
  printProgStr(End_Attr_str);
  print_hex( ep_ptr->bmAttributes, 8 );
  printProgStr(End_Pktsize_str);
  print_hex( ep_ptr->wMaxPacketSize, 16 );
  printProgStr(End_Interval_str);
  print_hex( ep_ptr->bInterval, 8 );

  return;
}
/*function to print unknown descriptor */
void printunkdescr( uint8_t* descr_ptr )
{
  uint8_t length = *descr_ptr;
  uint8_t i;
  printProgStr(Unk_Header_str);
  printProgStr(Unk_Length_str);
  print_hex( *descr_ptr, 8 );
  printProgStr(Unk_Type_str);
  print_hex( *(descr_ptr + 1 ), 8 );
  printProgStr(Unk_Contents_str);
  descr_ptr += 2;
  for ( i = 0; i < length; i++ ) {
    print_hex( *descr_ptr, 8 );
    descr_ptr++;
  }
}


/* Print a string from Program Memory directly to save RAM */
void printProgStr(const char* str)
{
  char c;
  if (!str) return;
  while ((c = pgm_read_byte(str++)))
    Serial.print(c);
}
/* end USB_Desc.ino routines */
////////////////////////////////////////////////////////////////////////////

//20210206 JMH Added "delay_us" function to provide a us delay via STM32CubeIDE platform
void delay_us (uint16_t us)
{
	__HAL_TIM_SET_COUNTER(&htim3,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim3) < us);  // wait for the counter to reach the us input in the parameter
}
///////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
void dispMsg(char Msgbuf[50], uint16_t Color) {
	int msgpntr = 0;
//	PrgmNdx =0;
	//int xoffset = 0;// used in the delete character routine.
	/* Add the contents of the Msgbuf to ringbuffer */
	/* But 1st, Kill interrupts from MAX3421 */
	uint8_t CPUCTLval = Usb.regRd(rCPUCTL);
	CPUCTLval = CPUCTLval & 0xFE;
	Usb.regWr(rCPUCTL, CPUCTLval); //Disable interrupt pin
	while ( Msgbuf[msgpntr] != 0) {
		if(RingbufPntr1 < RingBufSz-1) RingbufChar[RingbufPntr1+1] = 0;
		else RingbufChar[0] = 0;
		RingbufChar[RingbufPntr1] = Msgbuf[msgpntr];
		RingbufClr[RingbufPntr1] = Color;
		RingbufPntr1++;
		if(RingbufPntr1 == RingBufSz) RingbufPntr1 = 0;
		msgpntr++;
	}
	/* Restore interrupts from MAX3421 */
	CPUCTLval = Usb.regRd(rCPUCTL);
	CPUCTLval = CPUCTLval | 0x01;
	Usb.regWr(rCPUCTL, CPUCTLval); //enable interrupt pin
//	PrgmNdx =1;
//	dispMsg2();
}
void dispMsg2(void) {
	while ( RingbufPntr2!= RingbufPntr1) {
	//while ( RingbufChar[RingbufPntr2] != 0) {

		//    if(dletechar){ // we need to erase the last displayed character
		//      dletechar = false;
		//      while(MsgChrCnt[1] !=0){// delete display of ever how many characters were printed in the last decodeval (may be more than one letter generated)
		//        //first,buzz thru the pgbuf array until we find the the last charater (delete the last character in the pgbuf)
		//        int TmpPntr = 0;
		//        while(Pgbuf[TmpPntr]!=0) TmpPntr++;
		//        if(TmpPntr>0) Pgbuf[TmpPntr-1] =0;// delete last character in the array by replacing it with a "0"
		//        //TmpPntr =0;
		//        cnt--;
		//        xoffset = cnt;
		//        //use the xoffset to locate the character position (on the display's x axis)
		//        //int DelRow = 0;
		//        curRow = 0;Usb.Init()
		//        while (xoffset >= CPL){
		//          xoffset -=CPL;
		//          //DelRow++;
		//          curRow++;
		//        }
		//        //int Xpos =  xoffset*(fontW);
		//        cursorX  =  xoffset*(fontW);
		//        //cursorY = DelRow * (fontH + 10);
		//        cursorY = curRow * (fontH + 10);
		//        if(xoffset==(CPL-1)) offset= offset-CPL; //we just jump back to last letter in the previous line, So we need setup to properly calculate what display row we will be on, come the next character
		//        tft.fillRect(cursorX, cursorY, fontW+4, (fontH + 10), BLACK); //black out/erase last displayed character
		//        tft.setCursor(cursorX, cursorY);
		//        --MsgChrCnt[1];
		//      }
		//
		//    }//end delete character
		//    else{
		tft.setCursor(cursorX, cursorY);
		//    }

		char curChar = RingbufChar[RingbufPntr2];
		uint16_t Color = RingbufClr[RingbufPntr2];
		if(curChar != 10){ //test for "line feed" character
			tft.setTextColor( RingbufClr[RingbufPntr2] );
			tft.print(curChar);
			//RingbufPntr2++;
			//if(RingbufPntr2 == 120) RingbufPntr2 = 0;
			/* If needed add this character to the Pgbuf */
			if (curRow > 0) {
				//sprintf ( Pgbuf, "%s%c", Pgbuf, curChar);  // add the character just "printed" to the "PgBuf"
				Pgbuf[cnt-CPL] = curChar;
				Pgbuf[cnt-(CPL-1)] = 0;
				PgbufColor[cnt-CPL] = Color;
			}

			//msgpntr++;
			cnt++;
			if ((cnt - offset)*fontW >= displayW) {
				curRow++;
				//newRow = true;
				cursorX = 0;
				cursorY = curRow * (fontH + 10);
				offset = cnt;
				tft.setCursor(cursorX, cursorY);
				if (curRow + 1 > row) {
					scrollpg();
				}
			}
			else{
				cursorX = (cnt - offset) * fontW;
				//newRow = false;
			}

		}else{
			DisplCrLf();
			//RingbufPntr2++;
			//if(RingbufPntr2 == 120) RingbufPntr2 = 0;
		}
		RingbufPntr2++;
		if(RingbufPntr2 == RingBufSz) RingbufPntr2 = 0;
	}
}
//////////////////////////////////////////////////////////////////////
void DisplCrLf(void){
	/* Pad the remainder of the line with space */
	if((cnt-offset)==0) return;
	//	sprintf(Title, " ");
	int curOS = offset;
	tft.setTextColor( TFT_BLACK);
	while((cnt - curOS)*fontW <= displayW) {
		//dispMsg(Title, TFT_BLACK);
		tft.print(32); //ASCII "Space"
		/* If needed add this character to the Pgbuf */
		if (curRow > 0) {
			Pgbuf[cnt-CPL] = 32;
			Pgbuf[cnt-(CPL-1)] = 0;
			PgbufColor[cnt-CPL] = TFT_BLACK;
		}
		cnt++;
		if ((cnt - offset)*fontW >= displayW) {
			curRow++;
			//newRow = true;
			cursorX = 0;
			cursorY = curRow * (fontH + 10);
			offset = cnt;
			tft.setCursor(cursorX, cursorY);
			if (curRow + 1 > row) {
				scrollpg();
				return;
			}
		}
		else{
			cursorX = (cnt - offset) * fontW;
		}
		if(((curOS+CPL)-cnt)==0) break;
	}
}
//////////////////////////////////////////////////////////////////////
void scrollpg() {
	//buttonEnabled =false;
	cursorX = 0;
	cnt = 0;
	cursorY = 0;
	curRow = 0;
	offset = 0;
	bool PrintFlg = true;
	int curptr = RingbufPntr1;
	if(RingbufPntr2> RingbufPntr1) curptr = RingbufPntr1+RingBufSz;
	if((curptr-RingbufPntr2)>CPL-1) PrintFlg = false;
	//  enableDisplay(); //this is for touch screen support
	if(PrintFlg){
		tft.fillRect(cursorX, cursorY, displayW, row * (fontH + 10), BLACK); //erase current page of text
		tft.setCursor(cursorX, cursorY);
	}
	while (Pgbuf[cnt] != 0 && curRow + 1 < row) { //print current page buffer and move current text up one line
		if(PrintFlg){
			tft.setTextColor(PgbufColor[cnt]);
			tft.print(Pgbuf[cnt]);
		}
		Pgbuf[cnt] = Pgbuf[cnt + CPL]; //shift existing text character forward by one line
		PgbufColor[cnt] = PgbufColor[cnt+CPL];
		cnt++;
		if (((cnt) - offset)*fontW >= displayW) {
			curRow++;
			offset = cnt;
			cursorX = 0;
			cursorY = curRow * (fontH + 10);
			if(PrintFlg) tft.setCursor(cursorX, cursorY);
		}
		else cursorX = (cnt - offset) * fontW;

	}//end While Loop
	if(!PrintFlg){ //clear last line of text
		tft.fillRect(cursorX, cursorY, displayW, (fontH + 10), BLACK); //erase current page of text
		tft.setCursor(cursorX, cursorY);
	}
}
/////////////////////////////////////////////////////////////////////
/*
 * MAX3421E interrupt service routine
 * pin PA9 on Black Pill
 * */
void MAX3421INT(void){
	uint16_t INTcolor = TFT_BLUE;
	ShwINTRPinState();
//	delay(500);
	uint8_t Regval = Usb.regRd(0xc8); //read HIRQ register
	uint8_t HIRQ = Usb.IntHandler();
	uint8_t USBIRQRegval = Usb.regRd(rUSBIRQ);
	uint8_t HIENQRegval = Usb.regRd(rHIEN);
	/* HIRQ|    7    |    6   |   5   |   4    |    3    |    2    |    1    |     0     |
	 *      HXFRDNIRQ FRAMEIRQ CONNIRQ SUSDNIRQ SNDBAVIRQ RCVDAVIRQ RSMREQIRQ BUSEVENTIRQ
	 */
	dispMsg("HIRQ: ", INTcolor);
	D_PrintBin(Regval, 0x80);//2nd parameter is print debug level; to print, debug level must be 0x80 or less; See file printhex.h
	dispMsg("\n", INTcolor);
	if(USBIRQRegval&0b1){// if true OSC running IRQ is set
		/* Clear OSC IRQ */
		USBIRQRegval = USBIRQRegval & 0b11111110;
		Usb.regWr(rUSBIRQ, USBIRQRegval);
		USBIRQRegval = Usb.regRd(rUSBIRQ);
		sprintf( Title, "INT-Cleared OSC IRQ\n");
		dispMsg(Title, INTcolor);
	}
	if(HIENQRegval&0b1000000){// if true FrameIRQ enable is set
			/* Clear OSC IRQ */
			HIENQRegval = HIENQRegval & 0b10111111;
			Usb.regWr(rHIEN, HIENQRegval);
			HIENQRegval = Usb.regRd(rHIEN);
			sprintf( Title, "INT-Cleared FRAME IRQ\n");
			dispMsg(Title, INTcolor);
			Regval = Usb.regRd(0xc8);
			if(Regval & 0b1000000){
				Regval = Regval & 0b10111111;
				Usb.regWr(0xc8, Regval);
				Regval = Usb.regRd(0xc8);
			}

		}
	bool loop = true;
	while(loop){
		loop = false;
		bool ConDetect = true;
		int CurUSBstate = Usb.getUsbTaskState();
		if(Regval& bmCONDETIRQ){
			if(Regval== 0x69) Usb.regWr(0xc8, 0x69); //Write HIRQ register
			else Usb.regWr(0xc8, bmCONDETIRQ); //Write HIRQ register
			sprintf( Title,   "CONDETIRQ-");
		}else{
			ConDetect = false;
			sprintf( Title, "INT??-");
		}
		switch(CurUSBstate) {
		case 0x10:
			sprintf( Title, "%s USB_STATE_DETACHED\n", Title);
			running = false;
			break;
		case 0x11:
			sprintf( Title, "%s USB_DETACHED_SS_INITIALIZE\n", Title);
			Usb.Init();
			Usb.Task();
			loop = true;
			break;
		case 0x12:
			sprintf( Title, "%s USB_DETACHED_SS_WAIT_FOR_DEVICE\n", Title);
			USBinit = false;
			running = true;
			break;
		case 0x13:
			sprintf( Title, "%s USB_DETACHED_ILLEGAL\n", Title);
//			if(bthid.connected) bthid.disconnect();
			USBinit = false;
			running = false;
			break;
		case 0x20:
			sprintf( Title, "%s USB_ATTACHED_SS_SETTLE\n", Title);
			running = true;
			break;
		case 0x30:
			sprintf( Title, "%s USB_ATTACHED_SS_RESET_DEVICE\n", Title);
			loop = true;
			break;
		case 0x40:
			sprintf( Title, "%s USB_ATTACHED_SS_WAIT_RESET_COMPLETE\n", Title);
			running = true;
			break;
		case 0x50:
			sprintf( Title, "%s USB_ATTACHED_SS_WAIT_SOF\n", Title);
			running = true;
			break;
		case 0x51:
			sprintf( Title, "%s USB_ATTACHED_SS_WAIT_RESET\n", Title);
			Usb.Task();
			loop = true;
			break;
		case 0x60:
			sprintf( Title, "%s USB_ATTACHED_SS_GET_DEVICE_DESCRIPTOR_SIZE\n", Title);
			running = true;
			break;
		case 0x70:
			sprintf( Title, "%s USB_STATE_ADDRESSING\n", Title);
			running = true;
			break;
		case 0x80:
			sprintf( Title, "%s USB_STATE_CONFIGURING - 0x80\n", Title);
			running = true;
			break;
		case 0x90:
			if(!ConDetect && running){
				running = false;
				USBinit = false;
//				if(bthid.connected) bthid.disconnect();
				sprintf( Title, "%s USB_STATE_RUNNING - ReStart\n", Title);
			}
			else{
				sprintf( Title, "%s USB_STATE_RUNNING - Good\n", Title);
				running = true;
			}
			break;
		case 0xa0:
			sprintf( Title, "%s USB_STATE_ERROR - 0xa0\n", Title);
			USBinit = false;
			break;
		}
//		dispMsg(Title, INTcolor);
	} /* End while Loop */
	ShwINTRPinState();
	return;
}
///////////////////////////////////////////////////////////////////////////
void ShwINTRPinState(void)
{
	uint16_t color;
	int Xpos = 10;
	int Ypos = 290;
	int Wdth = 30;
	int Hght = 30;
	uint8_t pinstate = Max.IntrState(); //If "0" interrupt pin is Low; i.e. Interrupt detected
	if(pinstate == LstIntrState) return;
	LstIntrState = pinstate;
	if(pinstate==1) color =TFT_GREEN;
	else color =TFT_RED;
	tft.fillRect(Xpos, Ypos, Wdth, Hght, color);
	if(color == TFT_RED) delay(25);
}

///////////////////////////////////////////////////////////////////////////////////////////////

/* Begin Standard STM32F411 / STMCUBEIDE startup/initialize routines */

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;
  //sConfig.SamplingTime = ADC_SAMPLETIME_112CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
//  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;//use this with WS2812B library
//  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;//use this with USBhost library
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
//  if(PrgmNdx == 0){
//	  htim2.Init.Prescaler = 9600-1;
//	  htim2.Init.Period = 10000;
//  }
//  else if(PrgmNdx == 1){ //setup for period = 20 milliseconds
	  //htim2.Init.Prescaler = 96-1;
	  //htim2.Init.Period = 21;
	  htim2.Init.Prescaler = 960-1;
	  htim2.Init.Period = 2000;
//  }
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 96-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 96-1;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 4294967295;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin|MAX3421SS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|DMA_Evnt_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_D0_Pin LCD_D1_Pin LCD_D2_Pin LCD_D4_Pin
                           LCD_D5_Pin LCD_D6_Pin LCD_D7_Pin */
  GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin|MAX3421SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_D3_Pin DMA_Evnt_Pin LCD_RD_Pin LCD_WR_Pin
                           LCD_RS_Pin LCD_CS_Pin LCD_RST_Pin */
  GPIO_InitStruct.Pin = LCD_D3_Pin|DMA_Evnt_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : KeyIn_EXT13_Pin */
  GPIO_InitStruct.Pin = KeyIn_EXT13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(KeyIn_EXT13_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : MAX3421INT_Pin */
  GPIO_InitStruct.Pin = MAX3421INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(MAX3421INT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : MAX3421INT_Pin */
  GPIO_InitStruct.Pin = MAX3421INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(MAX3421INT_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init This sets up MAX3421 interrupt*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */
// Called when first half of buffer is filled
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc) {
//	int k;
//	if(Ready){
//		Ready = !Ready;
////		ResetGoertzel();
//		if(!LongSmplFlg){// ~4ms sample interval
//			for(int i = 0 ; i < Hstop; i++){
//				k = (adc_buf[i] - BIAS);
////				ProcessSample(k, i);
//			}
////			ComputeMags();
//		}else{// ~8ms sample interval
//			for(int i = 0 ; i < Hstop; i++){
//				k = (adc_buf[i] - BIAS);
////				ProcessSample(k, i);
//			}
//			Ready = true;
//		}
//	}
}

// Called when buffer is completely filled
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
//	int k;
//	if(Ready){
//		Ready = !Ready;
//		int LastSmpl = 2*Hstop;//
//		if(!LongSmplFlg){ //~4ms sample interval
////			ResetGoertzel();
//			for(int i = Hstop; i < LastSmpl; i++){
//				k = (adc_buf[i] - BIAS);
////				ProcessSample(k, i-Hstop);
//			}
//
//		}else{// ~8ms sample interval
//			for(int i = Hstop; i <= LastSmpl; i++){
//				k = (adc_buf[i] - BIAS);
////				ProcessSample(k, i);
//			}
//
//		}
////		ComputeMags();
//	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	ShwINTRPinState();
	dispMsg2();
	tim2IntrCnt++;
	if(tim2IntrCnt<25) return;
//	unsigned long CurTickVal = HAL_GetTick();
//	unsigned long period = CurTickVal -Start;
	tim2IntrCnt = 0;
	toggle ^= 1; //exclusive OR
	if(toggle) PIN_HIGH(LED_GPIO_Port, LED_Pin);
	else PIN_LOW(LED_GPIO_Port, LED_Pin);
//	Start = CurTickVal;
}

/**
  * @brief This function handles EXTI line[15:10] interrupts.
  */
//void EXTI15_10_IRQHandler(void)
//{
//  /* USER CODE BEGIN EXTI15_10_IRQn 0 */
//
//  /* USER CODE END EXTI15_10_IRQn 0 */
//  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
//  /* USER CODE BEGIN EXTI15_10_IRQn 1 */
//  //KeyEvntSR();
//  /* USER CODE END EXTI15_10_IRQn 1 */
//}


///////////////////////////////////////////////////////////////////////////////////////////////


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/


