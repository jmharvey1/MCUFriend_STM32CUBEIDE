/*
 * BTcodes.h
 *
 *  Created on: Oct 15, 2021
 *      Author: jim
 */

#ifndef USBHOST_BTCODES_H_
#define USBHOST_BTCODES_H_



typedef struct {
        uint8_t Ecode;
        const char * const EventName;
} CodeTble;

CodeTble HCIevents[] = {
{0x01,	"Inquiry Complete"},
{0x02, "Inquiry Result"},
{0x03, "Connection Complete"},
{0x04, "Connection Request"},
{0x05, "Disconnection Complete"},
{0x06, "Authentication Complete"},
{0x07, "Remote Name Request Complete"},
{0x08, "Encryption Change"},
{0x09, "Change Connection Link Key Complete"},
{0x0A, "Master Link Key Complete"},
{0x0B, "Read Remote Supported Features Complete"},
{0x0C, "Read Remote Version Information Complete"},
{0x0D, "QoS Setup Complete"},
{0x0E, "Command Complete"},
{0x0F, "Command Status"},
{0x10, "Hardware Error"},
{0x11, "Flush Occurred"},
{0x12, "Role Change"},
{0x13, "Number Of Completed Packets"},
{0x14, "Mode Change"},
{0x15, "Return Link Keys"},
{0x16, "PIN Code Request"},
{0x17, "Link Key Request"},
{0x18, "Link Key Notification"},
{0x19, "Loopback Command"},
{0x1A, "Data Buffer Overflow"},
{0x1B, "Max Slots Change"},
{0x1C, "Read Clock Offset Complete"},
{0x1D, "Connection Packet Type Changed"},
{0x1E, "QoS Violation"},
{0x1F, "Page Scan Mode Change"},
{0x20, "Page Scan Repetition Mode Change"},
{0x21, "HCI Flow Specification Complete"},
{0x22, "Inquiry Result with RSSI"},
{0x23, "Read Remote Extended Features Complete"},
{0x2C, "Synchronous Connection Complete"},
{0x2D, "Synchronous Connection Changed"},
{0x2E, "Sniff Subrating"},
{0x2F, "Extended Inquiry Result"}
};

CodeTble HCIerrs[] = {
{0x00, "Success"},
{0x01, "Unknown HCI command"},
{0x02, "Unknown connection identifier"},
{0x03, "Hardware failure"},
{0x04, "Page timeout"},
{0x05, "Authentication failure"},
{0x06, "PIN missing"},
{0x07, "Memory capacity exceeded"},
{0x08, "Connection timeout"},
{0x09, "Connection limit exceeded"},
{0x0A, "Synchronous connection limit to a device exceeded"},
{0x0B, "ACL connection already exists"},
{0x0C, "Command disallowed"},
{0x0D, "Connection rejected due to limited resources"},
{0x0E, "Connection rejected due to security reasons"},
{0x0F, "Connection rejected due to unacceptable BD_ADDR"},
{0x10, "Connection accept timeout exceeded"},
{0x11, "Unsupported feature or parameter value"},
{0x12, "Invalid HCI command parameters"},
{0x13, "Remote user terminated connection"},
{0x14, "Remote device terminated connection due to low resources"},
{0x15, "Remote device terminated connection due to power off"},
{0x16, "Connection terminated by local host"},
{0x17, "Repeated attempts"},
{0x18, "Pairing not allowed"},
{0x19, "Unknown LMP PDU"},
{0x1A, "Unsupported remote feature"},
{0x1B, "SCO offset rejected"},
{0x1C, "SCO interval rejected"},
{0x1D, "SCO air mode rejected"},
{0x1E, "Invalid LMP parameters"},
{0x1F, "Unspecified error"},
{0x20, "Unsupported LMP parameter value"},
{0x21, "Role change not allowed"},
{0x22, "LMP response timeout"},
{0x23, "LMP error transaction collision"},
{0x24, "LMP PDU not allowed"},
{0x25, "Encryption mode not acceptable"},
{0x26, "Link key cannot be changed"},
{0x27, "Requested QoS not supported"},
{0x28, "Instant passed"},
{0x29, "Pairing with unit key not supported"},
{0x2A, "Different transaction collision"},
{0x2B, "Reserved"},
{0x2C, "QoS unacceptable parameter"},
{0x2D, "QoS rejected"},
{0x2E, "Channel classification not supported"},
{0x2F, "Insufficient security"},
{0x30, "Parameter out of mandatory range"},
{0x31, "Reserved"},
{0x32, "Role switch pending"},
{0x33, "Reserved"},
{0x34, "Reserved slot violation"},
{0x35, "Role switch failed"}
};
CodeTble DnglVer[] = {
{0x04, "Bluetooth Core Specification 2.1 + EDR"},
{0x05, "Bluetooth Core Specification 3.0 + HS"},
{0x06, "Bluetooth Core Specification 4.0"},
{0x07, "Bluetooth Core Specification 4.1"},
{0x08, "Bluetooth Core Specification 4.2"},
{0x09, "Bluetooth Core Specification 5.0"},
{0x0A, "Bluetooth Core Specification 5.1"},
{0x0B, "Bluetooth Core Specification 5.2"},
{0x0C, "Bluetooth Core Specification 5.3"}
};

CodeTble HCIstatus[] = {
{0x00, "INIT_STATE"},
{0x01, "BTD ConfigureDevice"},
{0x02, "Address in use"},
{0x03, "Address not found"},
{0x04, "epinfo is null"},
{0x05, "Out of address space"},
{0x06, "Code needs a hub instance"},
{0x07, "BTD Init"},
{0x08, "BT Dongle Initialized"},
{0x09, "Connection Established"},
{0x0A, "Connection Already Exists"},
{0x0B, "Disconnected"},
{0x0C, "Rmt Name Cmplt"},
{0x0D, "Keybrd cncting"},
{0x0E, "Enter PIN"},
{0x0F, "No pin was set"},
{0x10, "HID Paired"},
{0x11, "Paired"},
{0x12, "Pairing Failed"},
{0x13, "Keyboard found"},
{0x14, "NO Keyboard found"},
{0x15, "HCI event error"},
{0x16, "XXX"},
{0x17, "EnDevDscvr"}, //Enable Device discovery
{0x18, "HID Dev Lnkd"},  //Connected to HID Device
{0x19, "Dev Lnkd"}, //Connected to Device
{0x1A, "Lnk Lost"}, // Device Disconnected
{0x1B, "RESET"},
{0x1C, "Restart- No Device Found"},
{0x1D, "Authentication failure"},
{0x1E, "Released BTD"},
{0x1F, "Reset complete"},
{0x20, "Reset No Response"}
};
#endif /* USBHOST_BTCODES_H_ */
