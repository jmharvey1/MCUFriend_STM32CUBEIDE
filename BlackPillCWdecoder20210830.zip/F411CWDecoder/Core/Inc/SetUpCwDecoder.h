/*
 * SetUpCwDecoder.h
 *
 *  Created on: Mar 28, 2021
 *      Author: jim
 */

#ifndef INC_SETUPCWDECODER_H_
#define INC_SETUPCWDECODER_H_

#include "Arduino.h"
#include "UTFTGLUE.h"
#include "TouchScreen_kbv.h"
#include "WS2812B.h"
extern int scrnHeight;
extern int scrnWidth;
extern int captrBuf[];
//extern unsigned long HlfCBcnt;
//extern unsigned long FulCBcnt;
extern uint16_t ID;
extern int PrgmNdx;
extern float TARGET_FREQUENCYC; //Hz
extern float TARGET_FREQUENCYL; //Hz
extern float TARGET_FREQUENCYH;

extern MCUFRIEND_kbv tft;
extern UTFTGLUE myGLCD;
extern WS2812B strip;
//extern SPI_HandleTypeDef hspi2;

void MX_TIM2_Init(void);

//void delay_us (uint16_t us);
//void delay(int Millis);
//void USBprintStr(String *msg);
//void USBprintln(const char *msg);
//void USBprint(const char *msg);
//void USBprintInt(int val);
//void USBprintIntln( int val);


#endif /* INC_SETUPCWDECODER_H_ */
