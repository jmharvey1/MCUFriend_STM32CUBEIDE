/*
 * STM32_TouchScreen_Calibr_native.cpp
 *
 *  Created/Modified/Ported on: Feb 15, 2021
 *      Author: JMH
 *  20210821 JMH: updated "diagnose_pins" routine added averaging readings,
 *  & more robust testing for touch pin pairs
 *
 *  TouchScreen_Calibr_native for MCUFRIEND UNO Display Shields
 *  adapted by David Prentice
 *  for Adafruit's <TouchScreen.h> Resistive Touch Screen Library
 *  from Henning Karlsen's original UTouch_Calibration program.
 *  Many Thanks.
 */

/*
    Touchscreen needs XM, YP to be on Analog capable pins.  Measure resistance with DMM to determine X, Y
    300R pair is XP, XM.  500R pair is YP, YM.  choose XM, YP from PA7, PA6.  XP, YM from PB6, PB7
    Run the Calibration sketch to get accurate TS_LEFT, TS_RT, TS_TOP, TS_BOT values.
    Adafruit_Touchscreen might need: typedef volatile uint32_t RwReg;
    JMH 20200126 modified Adafruit TouchScreen.h, found in the libraries folder,
    by adding the suggested code/declaration

*/
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"
#include "usbd_cdc_if.h"
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include "MCUFRIEND_kbv.h"
#include "Adafruit_GFX.h"
#include "STM32F411def.h"
#include "TouchScreen_kbv.h"
#include "Arduino.h"
#define PORTRAIT  1
#define LANDSCAPE 0
#define TOUCH_ORIENTATION  PORTRAIT
#define ARSIZE 4
#define WHITE 0xFFFF
#define RED   0xF800
#define GRAY  0x8410
#define BLACK 0x0000
#define TITLE "BLACK PILL TouchScreen Calibration - 20210820"
#define MAPLEMINI 0

/* Private includes ----------------------------------------------------------*/

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
//LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
//STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB8|PB9|

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
//extern ADC_HandleTypeDef hadc1;
//I2S_HandleTypeDef hi2s2;
//DMA_HandleTypeDef hdma_i2s2_ext_rx;
//DMA_HandleTypeDef hdma_spi2_tx;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
PCD_HandleTypeDef hpcd_USB_OTG_FS;

unsigned long AvgBias =0;
uint16_t ID;
int toggle = 0;

float sx = 0, sy = 1, mx = 1, my = 0, hx = -1, hy = 0;    // Saved H, M, S x & y multipliers
float sdeg=0, mdeg=0, hdeg=0;
boolean initial = 1;
char Bufr[14];

//static uint8_t conv2d(const char* p) {
//  uint8_t v = 0;
//  if ('0' <= *p && *p <= '9')
//    v = *p - '0';
//  return 10 * v + *++p - '0';
//}
//uint8_t hh=conv2d(__TIME__), mm=conv2d(__TIME__+3), ss=conv2d(__TIME__+6);  // Get H, M, S from compile time

unsigned long millisval = 0;
unsigned long Secruntime =0;
unsigned long LastRanNum =0;

int XP = PB6, YP = PA6, XM = PA7, YM = PB7; //most common configuration
uint32_t cx, cy, cz;
uint32_t rx[8], ry[8];
int32_t clx, crx, cty, cby;
float px, py;
int dispx, dispy, text_y_center, swapxy;
uint32_t calx, caly, cals;
static unsigned int PB[ARSIZE] = {
  21,
  22,
  23,
  24
};
char PrtTbl[33][4] = {
  "PA0",
  "PA1",
  "PA2",
  "PA3",
  "PA4",
  "PA5",
  "PA6",
  "PA7",
  "8",
  "9",
  "10",
  "11",
  "12",
  "13",
  "14",
  "15",
  "PB0",
  "PB1",
  "PB2",
  "PB3",
  "PB4",
  "PB5",
  "PB6",
  "PB7",
  "PB8",
  "25",
  "26",
  "27",
  "28",
  "29",
  "30",
  "31",
  "32"
};
/* Private variables END---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
//static void MX_DMA_Init(void);
//static void MX_I2S2_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
//void MX_ADC1_Init(hadc1);
//void Timer_ISR(void);
bool ISPRESSED(void);
char *Aval(int pin);
void showpins(int A, int D, int value, const char *msg);
void showpins2(int A, int D, int value, const char *msg);
bool diagnose_pins(void); //STM32 Version JMH 20200618 added to support STM32 type boards
void readResistiveTouch(void);
void centerprint(const char *s, int y);
bool to_hex(char* dest, size_t dest_len, uint16_t values, size_t val_len);
void delay(int Millis);
int random(int max);
void USBprintln(const char *msg);
void USBprint(const char *msg);
void USBprintStr(String *msg);
void USBprintInt(int val);
//unsigned long millis(void);
void dispMsg(char Msgbuf[32], int cursorX, int cursorY, int FontSz);
bool to_hex(char* dest, size_t dest_len, uint16_t values, size_t val_len);
void centertitle(const char *s);
void startup();
void centerprint(const char *s, int y);
void report();
void calibrate(int x, int y, int i, String msg);
void drawCrossHair(int x, int y, uint16_t color);
void readCoordinates();
void fail();


MCUFRIEND_kbv tft;
TouchScreen_kbv ts(XP, YP, XM, YM, 300);   //re-initialised after diagnose
TSPoint_kbv tp;                            //global point
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  //MX_DMA_Init();
  //MX_I2S2_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_USB_DEVICE_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  //MX_ADC1_Init(&hadc1);
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim2);
  HAL_TIM_Base_Start(&htim3);
  //HAL_ADC_Start(&hadc1);
  /*###########################################################################*/
  /*                       Begin Arduino SetUp Code                             */
//  Serial.begin(115200);
  delay(5000);
  USBprintln(TITLE);
  bool ret = true;
  tft.reset();
  ret = diagnose_pins();
  tft.reset();
  uint16_t ID = tft.readID();
  char Buff[50];
  char Buff2[10];
  if (to_hex(Buff2, sizeof(Buff2), ID, sizeof(ID))) sprintf(Buff, "ID = 0x%s Found" , Buff2);
  else sprintf(Buff, "FAILED to Convert");
  USBprintln(Buff);
  if (ID == 0x9090) ID = 0x9486; //do this to fix color issues
  if (to_hex(Buff2, sizeof(Buff2), ID, sizeof(ID))) sprintf(Buff, "Using ID = 0x%s" , Buff2);
  else sprintf(Buff, "FAILED to Convert");
  USBprintln(Buff);
  tft.begin(ID);
  tft.setRotation(TOUCH_ORIENTATION);
  dispx = tft.width();
  dispy = tft.height();
  text_y_center = (dispy / 2) - 6;
  if (ret == false) {
	  tft.fillScreen(BLACK);
	  tft.fillScreen(BLACK);
	  centerprint("BROKEN TOUCHSCREEN", text_y_center);
	  while (true);    //just tread water
  }



  /*                       End Arduino SetUp Code                               */
   /*###########################################################################*/


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE BEGIN 3 */
	  tft.fillScreen(BLACK);
	  startup();

	    tft.fillScreen(BLACK);
	    drawCrossHair(dispx - 11, 10, GRAY);
	    drawCrossHair(dispx / 2, 10, GRAY);
	    drawCrossHair(10, 10, GRAY);
	    drawCrossHair(dispx - 11, dispy / 2, GRAY);
	    drawCrossHair(10, dispy / 2, GRAY);
	    drawCrossHair(dispx - 11, dispy - 11, GRAY);
	    drawCrossHair(dispx / 2, dispy - 11, GRAY);
	    drawCrossHair(10, dispy - 11, GRAY);
	    centerprint("***********", text_y_center - 12);
	    centerprint("***********", text_y_center + 12);

	    calibrate(10, 10, 0, F(" LEFT, TOP, Pressure"));
	    calibrate(10, dispy / 2, 1, F(" LEFT, MIDH, Pressure"));
	    calibrate(10, dispy - 11, 2, F(" LEFT, BOT, Pressure"));
	    calibrate(dispx / 2, 10, 3, F(" MIDW, TOP, Pressure"));
	    calibrate(dispx / 2, dispy - 11, 4, F(" MIDW, BOT, Pressure"));
	    calibrate(dispx - 11, 10, 5, F(" RT, TOP, Pressure"));
	    calibrate(dispx - 11, dispy / 2, 6, F(" RT, MIDH, Pressure"));
	    calibrate(dispx - 11, dispy - 11, 7, F(" RT, BOT, Pressure"));

	    cals = (long(dispx - 1) << 12) + (dispy - 1);
	    if (TOUCH_ORIENTATION == PORTRAIT) swapxy = rx[2] - rx[0];
	    else swapxy = ry[2] - ry[0];
	    swapxy = (swapxy < -500 || swapxy > 500);
	    if ((TOUCH_ORIENTATION == PORTRAIT) ^ (swapxy != 0)) {
	      clx = (rx[0] + rx[1] + rx[2]) / 3;
	      crx = (rx[5] + rx[6] + rx[7]) / 3;
	      cty = (ry[0] + ry[3] + ry[5]) / 3;
	      cby = (ry[2] + ry[4] + ry[7]) / 3;
	    } else {
	      clx = (ry[0] + ry[1] + ry[2]) / 3;
	      crx = (ry[5] + ry[6] + ry[7]) / 3;
	      cty = (rx[0] + rx[3] + rx[5]) / 3;
	      cby = (rx[2] + rx[4] + rx[7]) / 3;
	    }
	    px = float(crx - clx) / (dispx - 20);
	    py = float(cby - cty) / (dispy - 20);
	    //  px = 0;
	    clx -= px * 10;
	    crx += px * 10;
	    cty -= py * 10;
	    cby += py * 10;

	    calx = (long(clx) << 14) + long(crx);
	    caly = (long(cty) << 14) + long(cby);
	    if (swapxy)
	      cals |= (1L << 31);

	    report();          // report results
	    while (true) {}    // tread water

  }
  /* USER CODE END WHILE */
  /* USER CODE END 3 */
}
/* ####################         END MAIN LOOP        ##########################*/
///////////////////////////////////////////////////////////////////////
/*         Begin STM32_TouchScreen_Calibr_Native Private Functions           */

void startup()
{
  centertitle(TITLE);

  tft.println("#define NUMSAMPLES 3 in Library\n");
  tft.println("Use a stylus or something");
  tft.println("similar to touch as close");
  tft.println("to the center of the");
  tft.println("highlighted crosshair as");
  tft.println("possible. Keep as still as");
  tft.println("possible and keep holding");
  tft.println("until the highlight is");
  tft.println("removed. Repeat for all");
  tft.println("crosshairs in sequence.\n");
  tft.println("Report can be pasted from USB Serial\n");
  tft.println("Touch screen to continue");

  while (ISPRESSED() == false) {}
  while (ISPRESSED() == true) {}
  //    waitForTouch();
}

void drawCrossHair(int x, int y, uint16_t color)
{
  tft.drawRect(x - 10, y - 10, 20, 20, color);
  tft.drawLine(x - 5, y, x + 5, y, color);
  tft.drawLine(x, y - 5, x, y + 5, color);
}

void calibrate(int x, int y, int i, String msg)
{
  drawCrossHair(x, y, WHITE);
  readCoordinates();
  centerprint("* RELEASE *", text_y_center);
  drawCrossHair(x, y, GRAY);
  rx[i] = cx;
  ry[i] = cy;
  USBprint("\r\ncx="); USBprintInt(cx);
  USBprint(" cy=");  USBprintInt(cy);
  USBprint(" cz=");  USBprintInt(cz);
  if (msg)  USBprintStr(&msg);
  while (ISPRESSED() == true) {}
}

void readCoordinates()
{
  int iter = 5000;
  int failcount = 0;
  int cnt = 0;
  uint32_t tx = 0;
  uint32_t ty = 0;
  boolean OK = false;

  while (OK == false)
  {
    centerprint("*  PRESS  *", text_y_center);
    while (ISPRESSED() == false) {}
    centerprint("*  HOLD!  *", text_y_center);
    cnt = 0;
    iter = 400;
    do
    {
      readResistiveTouch();
      if (tp.z > 20)
      {
        tx += tp.x;
        ty += tp.y;
        cnt++;
      }
      else
        failcount++;
    } while ((cnt < iter) && (failcount < 10000));
    if (cnt >= iter)
    {
      OK = true;
    }
    else
    {
      tx = 0;
      ty = 0;
      cnt = 0;
    }
    if (failcount >= 10000)
      fail();
  }

  cx = tx / iter;
  cy = ty / iter;
  cz = tp.z;
}

void report()
{
  uint16_t TS_LEFT, TS_RT, TS_TOP, TS_BOT, TS_WID, TS_HT, TS_SWAP;
  int16_t tmp;
  char buf[60];
  centertitle(TITLE);

  tft.println(F("To use the new calibration"));
  tft.println(F("settings you must map the values"));
  tft.println(F("from Point p = ts.getPoint() e.g. "));
  tft.println(F("x = map(p.x, LEFT, RT, 0, tft.width());"));
  tft.println(F("y = map(p.y, TOP, BOT, 0, tft.height());"));
  tft.println(F("swap p.x and p.y if diff ORIENTATION"));

  //.kbv show human values
  TS_LEFT = (calx >> 14) & 0x3FFF;
  TS_RT   = (calx >>  0) & 0x3FFF;
  TS_BOT  = (caly >> 14) & 0x3FFF;
  TS_TOP  = (caly >>  0) & 0x3FFF;
  TS_WID  = ((cals >> 12) & 0x0FFF) + 1;
  TS_HT   = ((cals >>  0) & 0x0FFF) + 1;
  TS_SWAP = (cals >> 31);
  if (TOUCH_ORIENTATION == LANDSCAPE) { //always show PORTRAIT first
    tmp = TS_LEFT, TS_LEFT = TS_BOT, TS_BOT = TS_RT, TS_RT = TS_TOP, TS_TOP = tmp;
    tmp = TS_WID, TS_WID = TS_HT, TS_HT = tmp;
  }
  tft.setCursor(0, 120);
  USBprintln("");
  sprintf(buf, "MCUFRIEND_kbv ID=0x%04X  %d x %d",
          tft.readID(), TS_WID, TS_HT);
  tft.println(buf);
  USBprintln(buf);
  //    USBprintln("Raw XP/YP/XM/YM values:");
  //    Serial.println(XP); Serial.println(YP); Serial.println(XM); Serial.println(YM);
  sprintf(buf, "\nconst int XP=%s,XM=%s,YP=%s,YM=%s; //%dx%d ID=0x%04X",
          PrtTbl[XP],  PrtTbl[XM],  PrtTbl[YP],  PrtTbl[YM], TS_WID, TS_HT, tft.readID());
  USBprintln(buf);
  sprintf(buf, "const int TS_LEFT=%d,TS_RT=%d,TS_TOP=%d,TS_BOT=%d;",
          TS_LEFT, TS_RT, TS_TOP, TS_BOT);
  USBprintln(buf);
  sprintf(buf, "PORTRAIT CALIBRATION     %d x %d", TS_WID, TS_HT);
  tft.println("");
  tft.println(buf);
  USBprintln(buf);
  sprintf(buf, "x = map(p.x, LEFT=%d, RT=%d, 0, %d)", TS_LEFT, TS_RT, TS_WID);
  tft.println(buf);
  USBprintln(buf);
  sprintf(buf, "y = map(p.y, TOP=%d, BOT=%d, 0, %d)", TS_TOP, TS_BOT, TS_HT);
  tft.println(buf);
  USBprintln(buf);
  sprintf(buf, "Touch Pin Wiring XP=%s XM=%s YP=%s YM=%s",
          PrtTbl[XP], PrtTbl[XM], PrtTbl[YP], PrtTbl[YM]);
  tft.println("");
  tft.println(buf);
  USBprintln(buf);

  tmp = TS_LEFT, TS_LEFT = TS_TOP, TS_TOP = TS_RT, TS_RT = TS_BOT, TS_BOT = tmp;
  tmp = TS_WID, TS_WID = TS_HT, TS_HT = tmp;

  sprintf(buf, "LANDSCAPE CALIBRATION    %d x %d", TS_WID, TS_HT);
  tft.println("");
  tft.println(buf);
  USBprintln(buf);
  sprintf(buf, "y = map(p.x, TOP=%d, BOT=%d, 0, %d)", TS_LEFT, TS_RT, TS_WID);
  tft.println(buf);
  USBprintln(buf);
  sprintf(buf, "x = map(p.y, LEFT=%d, RT=%d, 0, %d)", TS_TOP, TS_BOT, TS_HT);
  tft.println(buf);
  USBprintln(buf);
}

void fail()
{
  centertitle("Touch Calibration FAILED");

  tft.println("Unable to read the position");
  tft.println("of the press. This is a");
  tft.println("hardware issue and can");
  tft.println("not be corrected in");
  tft.println("software.");
  tft.println("check XP, XM pins with a multimeter");
  tft.println("check YP, YM pins with a multimeter");
  tft.println("should be about 300 ohms");

  while (true) {};
}

void centertitle(const char *s)
{
  tft.fillScreen(BLACK);
  tft.fillRect(0, 0, dispx, 14, RED);
  tft.fillRect(0, 14, dispx, 1, WHITE);
  centerprint(s, 1);
  tft.setCursor(0, 30);
  tft.setTextColor(WHITE, BLACK);
}

void centerprint(const char *s, int y)
{
  int len = strlen(s) * 6;
  tft.setTextColor(WHITE, RED);
  tft.setCursor((dispx - len) / 2, y);
  tft.print(s);
}

bool ISPRESSED(void)
{
  // .kbv this was too sensitive !!
  // now touch has to be stable for 50ms
  int count = 0;
  bool state, oldstate;
  while (count < 10) {
    readResistiveTouch();
    state = tp.z > 200;     //ADJUST THIS VALUE TO SUIT YOUR SCREEN e.g. 20 ... 250
    if (state == oldstate) count++;
    else count = 0;
    oldstate = state;
    delay(5);
  }
  return oldstate;
}


char *Aval(int pin)
{
  static char buf[2][10], cnt;
  cnt = !cnt;
  sprintf(buf[cnt], "%s", PrtTbl[pin]);
  return buf[cnt];

}

void showpins(int A, int D, int value, const char *msg)
{
	  char buf[50];
	  sprintf(buf, "%s (%s, %s) = %d", msg, Aval(A), Aval(D), value);
     USBprintln(buf);
}
void showpins2(int A, int D, int value, const char *msg)
{
  char buf[50];
  sprintf(buf, "%s (%s, %s) = %d", msg, Aval(A), Aval(D), value);
   USBprintln(buf);
}


bool diagnose_pins(void) //STM32 Version JMH 20200618 added to support STM32 type boards
{

	unsigned int i, j, s, Apins[2], Dpins[2], Values[2];
	int found = 0;
	unsigned long value;
	Values[0] = 1000;
	Values[1] = 1000;
	Apins[0] = 50;
	Apins[1] = 50;
	Dpins[0] = 50;
	Dpins[1] = 50;
	USBprintln("Making all control and bus pins INPUT_PULLUP");
	USBprintln("Typical 30k Analog pullup with corresponding pin");
	USBprintln("would read low when digital is written LOW");
	USBprintln("e.g. reads ~25 for 300R X direction");
	USBprintln("e.g. reads ~30 for 500R Y direction");
	USBprintln("");

	//BlackPill

	for (int p = PA0; p <= PA7; p++) {
		if(p == PA3){
			i = PB0;
		}else i= p;
		pinMode(i, INPUT_PULLUP);
		delay(10);
		/* Added this step to get the ADC going before actually running the Pin Scan */
		value = analogRead(i);
	}
	for (int j = 0; j<=3; j++){
		pinMode(PB[j], INPUT_PULLUP);
	}
	delay(50);
	for (int p = PA0; p <=  PA7; p++) {
		if(p == PA3) i = PB0;
		else i= p;
		pinMode(i, INPUT_PULLUP);
		for ( j = 0; j <= 3; j++) {
			pinMode(PB[j], OUTPUT);
			digitalWrite(PB[j], LOW);
			delay(10);
			value = analogRead(i); // ignore first reading
			value = 0;
			/* take 10 readings & average the result */
			for(s=0 ; s<10; s++){
				delay(2);
				value += analogRead(i);// analogRead() defined in Arduino.cpp
			}
			value = value/10;
			showpins(i,PB[j], value, "Testing :");
			if (value < 20) { //its a potential candidate
				/* Now test this entry for conflicts */
				bool gud = true;
				/* has the digital or analog pin been identified before */
				if (i == Apins[0] || i == Apins[1] ){ // if we have a match we need to throw both entries out
					gud = false;
					found--;
					if(i == Apins[0]){
						Values[0] = 1000;
						Apins[0] = 50;
						Dpins[0] = 50;
					}else{
						Values[1] = 1000;
						Apins[1] = 50;
						Dpins[1] = 50;
					}
				}
				if (PB[j] == Dpins[0] || PB[j] == Dpins[1] ){ // if we have a match we need to throw both entries out
					gud = false;
					found--;
					if(PB[j] == Dpins[0]){
						Values[0] = 1000;
						Apins[0] = 50;
						Dpins[0] = 50;
					}else{
						Values[1] = 1000;
						Apins[1] = 50;
						Dpins[1] = 50;
					}

				}
				if(gud){
					if(Values[0] == 1000){
						found++;
						Dpins[0] = PB[j];
						Apins[0] = i;
						Values[0] = value;
					}else if (Values[1] == 1000){
						found++;
						Dpins[1] = PB[j];
						Apins[1] = i;
						Values[1] = value;
					}else{  /* all the spots have been taken, so we need to kick out the highest value */
						if((value> Values[0]) && (value> Values[1])){
							// ignore this latest reading
						}else if(Values[0]<= Values[1]){
							Dpins[1] = PB[j];
							Apins[1] = i;
							Values[1] = value;

						} else {
							Dpins[0] = PB[j];
							Apins[0] = i;
							Values[0] = value;
						}
					}
				}
			}
//			if (value < 50) {  //if (value < 200)
//				if (found < 2) {
//					Apins[found] = i;
//					Dpins[found] = PB[j];
//					Values[found] = value;
//				}
//				found++;
//			}
			pinMode(PB[j], INPUT_PULLUP);
			delay(50);
		}
		pinMode(i, INPUT_PULLUP);
	}
	//  }
	if (found == 2) {
		//    USBprintln("Diagnosing as:-");
		int idx = Values[1] < Values[0];
		for (i = 0; i < 2; i++) {
			showpins2(Apins[i], Dpins[i], Values[i],
					(Values[i] > Values[!i]) ? "XM,XP: " : "YP,YM: ");
		}
		XM = Apins[!idx]; XP = Dpins[!idx]; YP = Apins[idx]; YM = Dpins[idx];
		ts = TouchScreen_kbv(XP, YP, XM, YM, 300); //re-initialise with pins
		//USBprintln(XP); USBprintln(YP); USBprintln(XM); USBprintln(YM);
		return true; //success
	}
	USBprintln("BROKEN TOUCHSCREEN");
	return false;
}

bool to_hex(char* dest, size_t dest_len, uint16_t values, size_t val_len) {
  if (dest_len < (val_len * 2 + 1)) /* check that dest is large enough */
    return false;
  *dest = '\0'; /* in case val_len==0 */
  val_len--;
  while (val_len--) {
    /* sprintf directly to where dest points */
    sprintf(dest, "%02X", values);
    dest += 2;
    ++values;
  }
  return true;
}

void readResistiveTouch(void)
{
	tp = ts.getPoint();
	pinMode(YP, OUTPUT);      //restore shared pins
	pinMode(XM, OUTPUT);
	digitalWrite(YP, HIGH);  //because TFT control pins
	digitalWrite(XM, HIGH);
	//    USBprintln("tp.x=" + String(tp.x) + ", tp.y=" + String(tp.y) + ", tp.z =" + String(tp.z));
}

//void centerprint(const char *s, int y)
//{
//  int len = strlen(s) * 6;
//  tft.setTextColor(WHITE, RED);
//  tft.setCursor((dispx - len) / 2, y);
//  tft.print(s);
//}
//END STM32_TouchScreen_Calibr_Native Private Functions
//////////////////////////////////////////////////////////////////////
//20210206 JMH Added "delay_us" function to provide a us delay via STM32CubeIDE platform
void delay_us (uint16_t us)
{
	__HAL_TIM_SET_COUNTER(&htim3,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim3) < us);  // wait for the counter to reach the us input in the parameter
}

//////////////////////////////////////////////////////////////////////
void delay(int Millis){
	while(Millis>0){
		delay_us(1000);
		--Millis;
	}
}
//////////////////////////////////////////////////////////////////////
int random(int max){
	int Frctn =0;
	unsigned long curCnt = (3*LastRanNum)+ millis();
	unsigned long Multpl = curCnt/max;
	Frctn = (curCnt-(max*Multpl));
	LastRanNum = Frctn;
	return Frctn;
}

//////////////////////////////////////////////////////////////////////
//unsigned long millis(void){
//	millisval = (__HAL_TIM_GET_COUNTER(&htim2))/10;
//	millisval += 1000*Secruntime;
//	return millisval;
//}
/////////////////////////////////////////////////////////////////////
void USBprintInt( int val){
	char buf[15];
	sprintf(buf, "%d", val);
	USBprint(buf);
}
/////////////////////////////////////////////////////////////////////
void USBprintStr(String *msg){
	char buf[150];
	sprintf(buf, "%s", msg);
	USBprint(buf);
}
/////////////////////////////////////////////////////////////////////
void USBprintln(const char *msg)
{
	  char buf[150];
	  sprintf(buf, "%s\n\r", msg);
	  USBprint(buf);
}
void USBprint(const char *msg)
{
	char buf[150];
	uint8_t Buffer[150];
	sprintf(buf, "%s", msg);
	uint32_t BfLen = 150;
	int i = 0;
	for(i = 0; i<=sizeof(buf); i++ ){
		Buffer[i] = (uint8_t)buf[i];
		if(buf[i] ==0) break;
	}
	int BsyCntr = 0;
	/*setup guard rail to prevent USB err when trying to display title*/
	bool tstState = false;
//	if(Test){
//		tstState = true;
//		Test = false;
//	}

	uint8_t USBstat = USBD_BUSY;
	while(USBstat != USBD_OK){
		USBstat = CDC_Transmit_FS(Buffer, i);
		BsyCntr++;
		if(BsyCntr >10) break;
	}
	if(0){ /*Set to "1" when debugging USB serial print*/
		switch (USBstat){
		case USBD_BUSY:
			sprintf(buf, "#USB BUSY# - %s", msg);
//			dispMsg(buf);
			break;
		case USBD_FAIL:
			sprintf(buf, "#USB FAIL# - %s", msg);
//			dispMsg(buf);
			break;
		}
	}
//	if(tstState) Test = true;
	delay_us(2000);// wait 2ms after sending USB serial data to allow the USB buffer to "clear" before trying to send another data string.
	return;
}

//void USBprint(const char *msg)
//{
//	  char buf[150];
//	  uint8_t Buffer[150];
//	  sprintf(buf, "%s", msg);
//	  int i = 0;
//	  for(i = 0; i<=sizeof(buf); i++ ){
//		  Buffer[i] = (uint8_t)buf[i];
//		  if(buf[i] ==0) break;
//	  }
//	  CDC_Transmit_FS(Buffer, i);
//	  delay_us(2000);
//}

/////////////////////////////////////////////////////////////////////
void dispMsg(char Msgbuf[32], int cursorX, int cursorY, int FontSz) {
  int msgpntr = 0;
  int curRow = 0;
  int offset =0;
  int fontH = 16;
  int fontW = 18;//12;
  int displayW = 320;
  int cnt = 0;
  while (Msgbuf[msgpntr] != 0) ++msgpntr;

  //clear previous entry
  tft.fillRect(cursorX , (cursorY), msgpntr * fontW, fontH + 10, TFT_LIGHTGREY);
  tft.setCursor(cursorX, cursorY);
  tft.setTextColor(TFT_BLACK);//tft.setTextColor(WHITE, BLACK);
  tft.setTextSize(FontSz);
  msgpntr = 0;
  while ( Msgbuf[msgpntr] != 0) {
    char curChar = Msgbuf[msgpntr];
    tft.print(curChar);
    msgpntr++;
    cnt++;
    if (((cnt) - offset)*fontW >= displayW) {
      curRow++;
      cursorX = 0;
      cursorY = curRow * (fontH + 10);
      offset = cnt;
      tft.setCursor(cursorX, cursorY);
//      if (curRow + 1 > row) {
//        scrollpg();
//      }
    }
    else cursorX = (cnt - offset) * fontW;
  }
}
//////////////////////////////////////////////////////////////////////
///**
//  * @brief ADC1 Initialization Function
//  * @param None
//  * @retval None
//  */
//static void MX_ADC1_Init(void)
//{
//
//  /* USER CODE BEGIN ADC1_Init 0 */
//
//  /* USER CODE END ADC1_Init 0 */
//
//  ADC_ChannelConfTypeDef sConfig = {0};
//
//  /* USER CODE BEGIN ADC1_Init 1 */
//
//  /* USER CODE END ADC1_Init 1 */
//  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
//  */
////  hadc1.Instance = ADC1;
//  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
//  hadc1.Init.Resolution = ADC_RESOLUTION_10B;
//  hadc1.Init.ScanConvMode = DISABLE;
//  hadc1.Init.ContinuousConvMode = DISABLE;
//  hadc1.Init.DiscontinuousConvMode = DISABLE;
//  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
//  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
//  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
//  hadc1.Init.NbrOfConversion = 1;
//  hadc1.Init.DMAContinuousRequests = DISABLE;
//  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
//  if (HAL_ADC_Init(&hadc1) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
//  */
////  sConfig.Channel = ADC_CHANNEL_0;
////  sConfig.Rank = 1;
////  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
////  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
////  {
////    Error_Handler();
////  }
//  /* USER CODE BEGIN ADC1_Init 2 */
//
//  /* USER CODE END ADC1_Init 2 */
//
//}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 96;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 12;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
//static void MX_I2S2_Init(void)
//{
//
//  /* USER CODE BEGIN I2S2_Init 0 */
//
//  /* USER CODE END I2S2_Init 0 */
//
//  /* USER CODE BEGIN I2S2_Init 1 */
//
//  /* USER CODE END I2S2_Init 1 */
//  hi2s2.Instance = SPI2;
//  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
//  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
//  hi2s2.Init.DataFormat = I2S_DATAFORMAT_24B;
//  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
//  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_96K;
//  hi2s2.Init.CPOL = I2S_CPOL_LOW;
//  hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
//  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_ENABLE;
//  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN I2S2_Init 2 */
//
//  /* USER CODE END I2S2_Init 2 */
//
//}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 9600-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 10000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 96-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USB_OTG_FS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_FS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_FS_Init 0 */

  /* USER CODE END USB_OTG_FS_Init 0 */

  /* USER CODE BEGIN USB_OTG_FS_Init 1 */

  /* USER CODE END USB_OTG_FS_Init 1 */
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_OTG_FS_Init 2 */

  /* USER CODE END USB_OTG_FS_Init 2 */

}

/**
  * Enable DMA controller clock
  */
//static void MX_DMA_Init(void)
//{
//
//  /* DMA controller clock enable */
//  __HAL_RCC_DMA1_CLK_ENABLE();
//
//  /* DMA interrupt init */
//  /* DMA1_Stream3_IRQn interrupt configuration */
//  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
//  /* DMA1_Stream4_IRQn interrupt configuration */
//  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
//  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
//
//}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOH_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
			|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin
			|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin : LED_Pin */
	GPIO_InitStruct.Pin = LED_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : LCD_D0_Pin LCD_D1_Pin LCD_D2_Pin LCD_D4_Pin
                           LCD_D5_Pin LCD_D6_Pin LCD_D7_Pin */
//	GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
//			|LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin;
//	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//	GPIO_InitStruct.Pull = GPIO_NOPULL;
//	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : LCD_D3_Pin LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin
                           LCD_CS_Pin LCD_RST_Pin */
	GPIO_InitStruct.Pin = LCD_D3_Pin|LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin
			|LCD_CS_Pin|LCD_RST_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
//	/*Configure GPIO pin : PA0 */
//	GPIO_InitStruct.Pin = GPIO_PIN_0;
//	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
//	GPIO_InitStruct.Pull = GPIO_PULLUP;
//	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
//	GPIO_InitStruct.Pin = GPIO_PIN_1;
//	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
//	GPIO_InitStruct.Pull = GPIO_PULLUP;
//	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	//HAL_GPIO_TogglePin(,);
	toggle ^= 1;
	Secruntime++;
	//digitalWrite(LED_BUILTIN, toggle);//Arduino call syntax
	if(1) PIN_HIGH(LED_GPIO_Port, LED_Pin);
	else PIN_LOW(LED_GPIO_Port, LED_Pin);
	//HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, (GPIO_PinState)toggle);
//	    sprintf(Bufr," Bias: %d", AvgBias );
//	    dispMsg(Bufr, 20, 320, 3);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/




