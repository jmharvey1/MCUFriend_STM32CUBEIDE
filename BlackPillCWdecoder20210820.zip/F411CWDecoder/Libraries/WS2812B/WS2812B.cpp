/*
 * WS2812B.cpp
 *
 *  Created on: Mar 19, 2021
 *      Author: jim
 */

#include "WS2812B.h"
#include "STM32F411def.h" //JMH added to conform with ST32CUBEIDE
#include <stdbool.h>
#include <string.h> // memcpy
#include <stdlib.h> //realloc

void encode_byte( uint8_t data, uint8_t ws_buffer[], int16_t buffer_index )
{
   int index = data * 4;
   ws_buffer[buffer_index++] = leddata[index++];
   ws_buffer[buffer_index++] = leddata[index++];
   ws_buffer[buffer_index++] = leddata[index++];
   ws_buffer[buffer_index++] = leddata[index++];

}
//WS2812B::WS2812B(uint16_t number_of_leds):
WS2812B::WS2812B(uint16_t number_of_leds, SPI_HandleTypeDef* spipntr, DMA_HandleTypeDef* dmapntr) :
		  brightness(0), pixels(NULL)
{

	_hspi2 = spipntr;
	_hdma_spi2_tx = dmapntr;
	updateLength(number_of_leds);

}

WS2812B::~WS2812B()
{
//  if(pixels)
//  {
//	  free(pixels);
//  }
  //_mySPI->end();//JMH- Removed to conform with STM32CUBIDE
}
void WS2812B::begin(void) {

	if (!begun)
	{

		MX_SPI2_Init();
		begun = true;
	}
}

void WS2812B::updateLength(uint16_t n)
{
//  if(ws_buffer)
//  {
//	  free(ws_buffer);
//  }

  numBytes = (n*12)+n+2; //(n<<3) + n + 2; // 9 encoded bytes per pixel. 1 byte empty peamble to fix issue with SPI MOSI and on byte at the end to clear down MOSI
							// Note. (n<<3) +n is a fast way of doing n*9

  ws_buffer[numBytes];
  if(1)//if((ws_buffer = (uint8_t *)malloc(numBytes)))
  {
	numLEDs = n;
	pixels = (uint8_t *)ws_buffer;
	// Only need to init the part of the double buffer which will be interacted with by the API e.g. setPixelColor
	*pixels=0;//clear the preamble byte
	*(pixels+numBytes-1)=0;// clear the post send cleardown byte.
	clear();// Set the encoded data to all encoded zeros
  }
  else
  {
    numLEDs = numBytes = 0;
  }
}

// Sends the current buffer to the leds
void WS2812B::show(void)
{
	HAL_SPI_Transmit_DMA(_hspi2, ws_buffer, numBytes); //JMH added for STM32CUBEIDE support
	// Need to copy the last / current buffer to the other half of the double buffer as most API code does not rebuild the entire contents
	// from scratch. Often just a few pixels are changed e.g in a chaser effect

//	if (pixels==ws_buffer)
//	{
//		// pixels was using the first buffer
//		pixels	= ws_buffer + numBytes;  // set pixels to second buffer
//		memcpy(pixels,ws_buffer,numBytes);// copy first buffer to second buffer
//	}
//	else
//	{
//		// pixels was using the second buffer
//		pixels	= ws_buffer;  // set pixels to first buffer
//		memcpy(pixels,ws_buffer+numBytes,numBytes);	 // copy second buffer to first buffer
//	}
}

/*Sets a specific pixel to a specific r,g,b colour
* Because the pixels buffer contains the encoded bitstream, which is in triplets
* the lookup table need to be used to find the correct pattern for each byte in the 3 byte sequence.
*/
void WS2812B::setPixelColor(uint16_t n, uint8_t r, uint8_t g, uint8_t b)
 {
   uint8_t *bptr = pixels + (n<<3) + n +1;
   uint8_t *tPtr = (uint8_t *)leddata + g*2 + g;// need to index 3 x g into the lookup

   *bptr++ = *tPtr++;
   *bptr++ = *tPtr++;
   *bptr++ = *tPtr++;

   tPtr = (uint8_t *)leddata + r*2 + r;
   *bptr++ = *tPtr++;
   *bptr++ = *tPtr++;
   *bptr++ = *tPtr++;

   tPtr = (uint8_t *)leddata + b*2 + b;
   *bptr++ = *tPtr++;
   *bptr++ = *tPtr++;
   *bptr++ = *tPtr++;
 }

void WS2812B::setPixelColor(uint16_t n, uint32_t c)
  {
     uint8_t r,g,b;

    if(brightness)
	{
      r = ((int)((uint8_t)(c >> 16)) * (int)brightness) >> 8;
      g = ((int)((uint8_t)(c >>  8)) * (int)brightness) >> 8;
      b = ((int)((uint8_t)c) * (int)brightness) >> 8;
	}
	else
	{
      r = (uint8_t)(c >> 16),
      g = (uint8_t)(c >>  8),
	  b = (uint8_t)c;
	}

   int offset = ((numLEDs-1) * 12)+1;

   encode_byte( r, ws_buffer, offset );
   encode_byte( g, ws_buffer, offset+4 );
   encode_byte( b, ws_buffer, offset+8 );
}

// Convert separate R,G,B into packed 32-bit RGB color.
// Packed format is always RGB, regardless of LED strand color order.
uint32_t WS2812B::Color(uint8_t r, uint8_t g, uint8_t b) {
  return ((uint32_t)r << 16) | ((uint32_t)g <<  8) | b;
}

// Convert separate R,G,B,W into packed 32-bit WRGB color.
// Packed format is always WRGB, regardless of LED strand color order.
uint32_t WS2812B::Color(uint8_t r, uint8_t g, uint8_t b, uint8_t w) {
  return ((uint32_t)w << 24) | ((uint32_t)r << 16) | ((uint32_t)g <<  8) | b;
}


uint16_t WS2812B::numPixels(void) const {
  return numLEDs;
}

// Adjust output brightness; 0=darkest (off), 255=brightest.  This does
// NOT immediately affect what's currently displayed on the LEDs.  The
// next call to show() will refresh the LEDs at this level.  However,
// this process is potentially "lossy," especially when increasing
// brightness.  The tight timing in the WS2811/WS2812 code means there
// aren't enough free cycles to perform this scaling on the fly as data
// is issued.  So we make a pass through the existing color data in RAM
// and scale it (subsequent graphics commands also work at this
// brightness level).  If there's a significant step up in brightness,
// the limited number of steps (quantization) in the old data will be
// quite visible in the re-scaled version.  For a non-destructive
// change, you'll need to re-render the full strip data.  C'est la vie.
void WS2812B::setBrightness(uint8_t b) {
  // Stored brightness value is different than what's passed.
  // This simplifies the actual scaling math later, allowing a fast
  // 8x8-bit multiply and taking the MSB.  'brightness' is a uint8_t,
  // adding 1 here may (intentionally) roll over...so 0 = max brightness
  // (color values are interpreted literally; no scaling), 1 = min
  // brightness (off), 255 = just below max brightness.
  uint8_t newBrightness = b + 1;
  if(newBrightness != brightness) { // Compare against prior value
    // Brightness has changed -- re-scale existing data in RAM
    uint8_t  c,
            *ptr           = pixels,
             oldBrightness = brightness - 1; // De-wrap old brightness value
    uint16_t scale;
    if(oldBrightness == 0) scale = 0; // Avoid /0
    else if(b == 255) scale = 65535 / oldBrightness;
    else scale = (((uint16_t)newBrightness << 8) - 1) / oldBrightness;
    for(uint16_t i=0; i<numBytes; i++)
	{
      c      = *ptr;
      *ptr++ = (c * scale) >> 8;
    }
    brightness = newBrightness;
  }
}

//Return the brightness value
uint8_t WS2812B::getBrightness(void) const {
  return brightness - 1;
}

/*
*	Sets the encoded pixel data to turn all the LEDs off.
*/
void WS2812B::clear()
{
	uint8_t * bptr= pixels+1;// Note first byte in the buffer is a preable and is always zero. hence the +1
	uint8_t *tPtr;

	for(int i=0;i< (numLEDs *4);i++)
	{
	   tPtr = (uint8_t *)leddata;
   	   *bptr++ = *tPtr++;
	   *bptr++ = *tPtr++;
	   *bptr++ = *tPtr++;
	   *bptr++ = *tPtr++;
	}
}
/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
void WS2812B::MX_SPI2_Init(void)
{
	  /* DMA controller clock enable */
	  __HAL_RCC_DMA1_CLK_ENABLE();

	  /* DMA interrupt init */
	  /* DMA1_Stream4_IRQn interrupt configuration */
	  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
	  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);

	_hspi2->Instance = SPI2;
	_hspi2->Init.Mode = SPI_MODE_MASTER;
	_hspi2->Init.Direction = SPI_DIRECTION_2LINES;
	_hspi2->Init.DataSize = SPI_DATASIZE_8BIT;
	_hspi2->Init.CLKPolarity = SPI_POLARITY_LOW;
	_hspi2->Init.CLKPhase = SPI_PHASE_1EDGE;
	_hspi2->Init.NSS = SPI_NSS_SOFT;
	_hspi2->Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
	_hspi2->Init.FirstBit = SPI_FIRSTBIT_MSB;
	_hspi2->Init.TIMode = SPI_TIMODE_DISABLE;
	_hspi2->Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	_hspi2->Init.CRCPolynomial = 10;
	if (HAL_SPI_Init(_hspi2) != HAL_OK)
	{
		Error_Handler();
	}


}
