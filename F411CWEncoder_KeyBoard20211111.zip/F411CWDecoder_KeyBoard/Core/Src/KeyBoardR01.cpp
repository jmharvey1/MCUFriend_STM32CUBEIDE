/*
 **** JMH 20211004 1st cut at a Keyboard based CW code generator ****
 Example sketch for the HID Bluetooth library - developed by Kristian Lauszus
 For more information visit my blog: http://blog.tkjelectronics.dk/ or
 send me an e-mail:  kristianl@tkjelectronics.com

*   MCU Friend TFT Display to STM32F411 (Black Pill) pin connections
*   LCD pins  |D7 |D6 |D5 |D4 |D3 |D2 |D1 |D0 | |RD |WR |RS |CS |RST|
*   STM32 pin |PA7|PA6|PA5|PA4|PB0|PA2|PA1|PA0| |PB5|PB6|PB7|PB8|PB9|
*
*	MAX3421E Mini USB2.0 Shield to STM32 SPI2 pin connections
*	Shield-lbl|SS |CLK |MISO|MOSI|VBUS|INT|RST|VCC|   |
*	STM32 pin |PA8|PB15|PB14|PB10| 5V |PA9| R |3V3| G |
*
*	Mini Shield Notes:
*	1. Ground pin not labeled. Use 2nd pin from bottom.
*	2. VBUS trace must be cut to isolate USB "A" connector from MAX3421 3.3 volt runs.
*	3. Shield pin labeled "CLK" is actually connected to the MAX3421 pin 16 "MOSI".
*	4. Shield pin labeled "MOSI" is actually connected to the MAX3421 pin 13 "SCLK".
*	5. Shield pin labeled "RST" must be "tied high", otherwise MAX3421 is in perpetual "reset" state.
*/
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
//#include <eeprom.h>
#include <SetUpCwDecoder.h>

#include "main.h"
#include "KeyBoardR01.h"
#include "pgmstrings.h"
#include "usb_device.h"
//#include "BtnSuprt.h"
//#include "DcodeCW.h"
#include "usbd_cdc_if.h"
#include "Arduino.h"
#include "TouchScreen_kbv.h"
#include "UTFTGLUE.h"              //use GLUE class and constructor

#include "usbhub.h"
#include "BTD.h"
#include "KeyboardParser.h"
#include "MouseParser.h"
//#include "CWSndEngn.h"
//#include "TFTMsgBox.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//#define RingBufSz 400
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
//ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

SPI_HandleTypeDef hspi2;
extern SPI_HandleTypeDef SPI_Handle = hspi2;//Do this to keep the USBHost library happy
DMA_HandleTypeDef hdma_spi2_tx;
TIM_HandleTypeDef htim2; //this clock sets the pace of the Blackpill's blue LED BLINK process
TIM_HandleTypeDef htim3; //Handles MicroSecond delay function
TIM_HandleTypeDef htim5; // This acts as the CW dot clock

/* USER CODE BEGIN PV */
//uint16_t ID = 0x9090;
char MyCall[10] = {'K', 'W', '4', 'K', 'D'};
char StrdTxt[20] ={'\0'};
uint8_t toggle =0x0;
uint8_t toggle1 =0x0;
uint8_t StatusOLD = 0xFF;
uint8_t Status = 0;
int tim2IntrCnt = 0;
uint8_t LstIntrState = 0;
int LstTaskState = 0;
/* touch screen variables */
char RevDate[9] = "20211111";
//char ErMsg[23] = {0x42, 0x6C, 0x75, 0x65, 0x74, 0x6F, 0x6F, 0x74, 0x68, 0x20, 0x33, 0x2E, 0x30, 0x20, 0x4B, 0x65, 0x79, 0x62, 0x6F, 0x61, 0x72, 0x64, 0x0D};
//char RingbufChar[RingBufSz];
//uint16_t RingbufClr[RingBufSz];
//char Pgbuf[448];
//uint16_t PgbufColor[448];

//int RingbufPntr1 =0;
//int RingbufPntr2 =0;
//char Msgbuf[50];
char Title[50];
//int displayW = 320;
//int CPL = 40; //number of characters each line that a 3.5" screen can contain
//int row = 10; //number of uable rows on a 3.5" screen
//int fontH = 16;
//int fontW = 12;
//int scrnHeight = 0;
//int scrnWidth = 0;
//int cursorY = 0;
//int cursorX = 0;
//int cnt = 0; //used in scrollpage routine
//int curRow = 0;
//int offset = 0;
int textSrtX = 0;
int textSrtY = 0;
unsigned long Start = 0;
/* End Touch Screen Variables */
bool running = false;
bool USBinit = false;
bool waitFlg = true;
//bool IntRdy = false;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* Black Pill #define STM32F411 Init Routines */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
//static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM5_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI2_Init(void);
/* USER CODE BEGIN PFP */
/* Tone DSP Routines */

/*standard support routines */
//uint32_t flash_read(uint32_t address);
//void flash_write(uint32_t address, uint32_t data);
/* USB_Desc.ino routines */
/* END USB_Desc.ino routines */
void delay_us (uint16_t us);
//void USBprintln(const char *msg);
//void USBprintStr(String *msg);
//void USBprint(const char *msg);
//void USBprintInt(int val);
//void USBprintIntln( int val);
void EXTI15_10_IRQHandler(void);
void RptUsbState(uint8_t StateCd);
void dispMsg(char Msgbuf[50], uint16_t Color);
//void dispMsg2(void);
//void DisplCrLf(void);
//void scrollpg();
void MAX3421INT(void);
void ShwINTRPinState(void);
void ShwBlink(uint8_t tgl);
/* USER CODE E#define ND PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

MCUFRIEND_kbv tft;
UTFTGLUE myGLCD(0,0,0,0,0,0); //all duvoid PrintAllDescriptors(UsbDevice *pdev)mmy args
CWSNDENGN CWsndengn(&htim5, &tft);
TFTMsgBox tftmsgbx(&tft, StrdTxt);
SerialClass Serial; // Arduino styuint8_t void PrintAllDescriptors(UsbDevice *pdev)getdevdescr( uint8_t addr, uint8_t &num_conf );le Serial class
MAX3421E Max;
USB Usb;
//USBHub Hub1(&Usb); // Some dongles have a hub inside
BTD Btd(&Usb); // You have to create the Bluetooth Dongle instance like so

/* You can create the instance of the class in two ways */
// This will start an inquiry and then pair with your device -
// you only have to do this once.
// If you are using a Bluetooth keyboard, then you should type in
// the password on the keypad and then press "enter".
BTHID bthid(&Btd, PAIR, "0000");

// After that you can simply create the instance like so and then press any button on the device
//BTHID bthid(&Btd);
/* create a hub instance */
USBHub Hub1(&Usb);

KbdRptParser keyboardPrs;
MouseRptParser mousePrs;
/*Start main */
int main(void)
{
	/* Start Setup */
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_TIM2_Init();
	MX_TIM3_Init();
	MX_TIM5_Init();
	MX_USB_DEVICE_Init();
	MX_ADC1_Init();
	MX_SPI2_Init();
	SPI_Handle = hspi2; //SPI_Handle is used/called in usbhost.h
	/* USER CODE BEGIN 2 */


	HAL_TIM_Base_Start(&htim3); //JMH these are important; if not here the interrupt clock functions wont work
	HAL_TIM_Base_Start_IT(&htim5);
	HAL_TIM_Base_Start_IT(&htim2); // Handles the Blackpill's blue LED BLINK process
	coretick_init(); //JMH Added to support time measurements i.e millis() & micros() see Arduino.h & Arduino.cpp

	bthid.SetReportParser(KEYBOARD_PARSER_ID, &keyboardPrs);
	bthid.SetReportParser(MOUSE_PARSER_ID, &mousePrs);


	bthid.setProtocolMode(USB_HID_BOOT_PROTOCOL); // Boot Protocol Mode
	// If "Boot Protocol Mode" does not work,
	// then try "Report Protocol Mode"
	//bthid.setProtocolMode(HID_RPT_PROTOCOL); // Report Protocol Mode

	// If that does not work either,
	// then un-comment PRINTREPORT in BTHID.cpp to see the raw report

	PIN_HIGH(LED_GPIO_Port, LED_Pin);// LED Off
	PIN_LOW(LED_GPIO_Port, LED_Pin);// TONE Off
	/* begin touchscreen setup*/
	tftmsgbx.InitDsplay();
	sprintf( Title, "             KW4KD (%s)\n", RevDate );
	tftmsgbx.dispMsg(Title, TFT_WHITE);

//	tftmsgbx.dispMsg(ErMsg, TFT_ORANGE);
//	tftmsgbx.dispMsg("\n", TFT_ORANGE);
//	delay(5000);
	/* END touch-screen setup*/
    while(waitFlg);//Added this delay to allow MAX3421 USB board to get up and running at initial power on.
	USBinit = false;
	int CurUSBstate = LstTaskState;
	bool PRunFlg = false;
	LstIntrState = 1;
	int NoRunCnt = 80;
	/* End Setup */
	/* Infinite loop starts here */

	while (1){
		if(!USBinit){
			USBinit = true;
			running = false;
			/* Usb.int() actually runs  MAX3421e< SPI_SS, INTR >::Init()
			 * found in the usbhost.h file
			 * which inturn does a software MAX3421 chip reset & returns with
			 * oscillator running status [-1 = "no"]
			 */
			if (Usb.Init() == -1) {
				sprintf( Title, "OSC did not start\n");
				tftmsgbx.dispMsg(Title, TFT_RED);
				while (1); // Halt
			}else{
				sprintf( Title, "OSC OK\n");
				tftmsgbx.dispMsg(Title, TFT_GREEN);
			}
		}
		if(!running){
			sprintf( Title, "WAIT FOR INTTERRUPT\n");
			tftmsgbx.dispMsg(Title, TFT_ORANGE);
		}else if(!PRunFlg){
			PRunFlg = true;
			sprintf( Title, "RUNNING\n");
			tftmsgbx.dispMsg(Title, TFT_GREEN);
		}
//		uint8_t HIRQRegval = Usb.regRd(rHIRQ); //read register rHIRQ =0xc8; b1000 =SNDBAVIRQ set
//		uint8_t CPUCTLRegval = Usb.regRd(rCPUCTL); //read register b1 = IE
		uint8_t PINCTLRegval = Usb.regRd(rPINCTL); //read register b11000 = FDUPSPI, INTLEVEL
		//		uint8_t GPINIRQRegval = Usb.regRd(rGPINIRQ);
		//		uint8_t USBIRQRegval = Usb.regRd(rUSBIRQ);
		if(PINCTLRegval&0b1000){// if true interrupt IRQ mode currently is level control
			/* Change IRQ mode to EDGE/pulse mode */
			PINCTLRegval = PINCTLRegval & 0b11110111;
			Usb.regWr(rPINCTL, PINCTLRegval);
//			PINCTLRegval = Usb.regRd(rPINCTL);
//			sprintf( Title, "INT set to Pulse Mode\n");
//			tftmsgbx.dispMsg(Title, TFT_ORANGE);
		}
//		int NoRunCnt = 80;
		while(!running){ //wait for interrupt event/status to set the running flag to true
/*     Sit in this loop for no more than 10 seconds before attempting a restart */
			//			HIRQRegval = Usb.regRd(0xc8); //read HIRQ register
			ShwINTRPinState();
			delay(100);
			NoRunCnt++;
			if(NoRunCnt>=100){//Wait 10 seconds & try another restart
				if(bthid.connected){
					bthid.disconnect();
					Btd.Release();
				}
				USBinit = false;

				LstTaskState = 0;
				break;
			}
		}// end while not running loop
		NoRunCnt = 80;//reset back to a 5 second wait
		do{ //Sits in this loop until the HID Library is started
			Usb.Task();// set the state of the USB host & runs setup/tear-down routines as needed
			CurUSBstate = Usb.getUsbTaskState();
			RptUsbState(CurUSBstate);
//			HIRQRegval = Usb.regRd(rHIRQ); //read register rHIRQ =0xc8; b1000 =SNDBAVIRQ set
//			CPUCTLRegval = Usb.regRd(rCPUCTL); //read register b1 = IE
			PINCTLRegval = Usb.regRd(rPINCTL);
			ShwINTRPinState();
			delay(1);
			NoRunCnt++;
			if(NoRunCnt>10000){//Wait 10 seconds & try another restart
				if(bthid.connected) bthid.disconnect();
				USBinit = false;
				Btd.Release();
				LstTaskState = 0;
				break;
			}
		} while((CurUSBstate != USB_STATE_RUNNING ) && USBinit);//while((CurUSBstate == LstTaskState) && USBinit);

		if ( CurUSBstate == USB_STATE_RUNNING )
		{
			sprintf( Title, "HID Bluetooth Library Started\n");
			tftmsgbx.dispMsg(Title, TFT_GREEN);
			char VenIDStr[5];
			char ProdIDStr[5];
			char VerStr[5];
			running = true;
			bool PostVid = true;
			bool PostRmtName = true;
			uint16_t curID = 0;
			/* sit in this loop while all is "good" */
			int NoDnglCnt = 0;
			while (running) {
				Usb.Task(); // Checks Interrupt pin state and sets the "usb_task_state" usb class property
                if(PostVid){
                	curID = Btd.GetVid();
                }
				if(PostVid && (curID !=0x0000)){
                	PostVid = false;
        			HexStr(curID, VenIDStr);
        			HexStr(Btd.GetPid(), ProdIDStr);
        			HexStr(Btd.GetVer(), VerStr);
        			sprintf(Title, "VenId:%s; ProdID:%s; Ver:%s\n", VenIDStr, ProdIDStr, VerStr);
        			tftmsgbx.dispMsg(Title, TFT_WHITE);
                }
                if(PostRmtName && (Btd.GetStatus() == 0x0C)){
					PostRmtName = false;
        			sprintf(Title, "%s\n", Btd.remote_name);
        			tftmsgbx.dispMsg(Title, TFT_WHITE);

                }
				CurUSBstate = Usb.getUsbTaskState();
				RptUsbState(CurUSBstate);
				if ( CurUSBstate != USB_STATE_RUNNING ){
					running = false;
				}
/* If the dongle doesnt initialize in a reasonable period, restart the init process*/
				if((Status == 0x1E)||(Status == 0x15) || (Status == 0x1C) || (Status == 0x20)) // "Released BTD" 0x15, "HCI event error
				{
					delay(100);
					NoDnglCnt++;
					if(NoDnglCnt>50){
						running = false;
						USBinit = false;
						if(bthid.connected){
							bthid.disconnect();
							//Btd.Release();
						}
						Btd.Release();
						Usb.Init();
						//Usb.setUsbTaskState(USB_ATTACHED_SUBSTATE_RESET_DEVICE);//Usb.setUsbTaskState(USB_STATE_CONFIGURING);

					}
				}else if (Status == 0x15){ //"HCI event error"
					running = false;
					USBinit = false;
					Btd.Release();
				}else NoDnglCnt = 0;
			}//end running loop
			CurUSBstate = -1;
			USBinit = false;
			if(bthid.connected){
				bthid.disconnect();
				delay(5000);
			}
		}
		RptUsbState(CurUSBstate);

	} 	/*END WHILE */
}/*end main */
////////////////////////////////////////////////////////////////////////////
void RptUsbState(uint8_t StateCd){
	/* Only post State if there's a change in state*/
	if(LstTaskState == StateCd) return ;
	LstTaskState = StateCd;
	switch(LstTaskState) {
	case 0x10:
		sprintf( Title, "USB_STATE_DETACHED\n");
		break;
	case 0x11:	//should never see this state.
				//As it automatically rolls over to "USB_DETACHED_SS_WAIT_FOR_DEVICE"
		sprintf( Title, "USB_DETACHED_SS_INITIALIZE\n");
		break;
	case 0x12:
		/*When this state is found Usb::Task() runs Usb::init()
		 * And if say a Bletooth Dongle had been plugged in,
		 * its BDT::release() method was also run which also calls BDT::initialize().
		 * Which sets all variables, endpoint structs etc. to default values.
		 */
		sprintf( Title, "USB_DETACHED_SS_WAIT_FOR_DEVICE\n");
		break;
	case 0x13:
		sprintf( Title, "USB_DETACHED_SS_ILLEGAL\n");
		break;
	case 0x20:
		sprintf( Title, "USB_ATTACHED_SS_SETTLE\n");
		break;
	case 0x30:
		sprintf( Title, "USB_ATTACHED_SS_RESET_DEVICE\n");
		break;
	case 0x40:
		sprintf( Title, "USB_ATTACHED_SS_WAIT_RESET_COMPLETE\n");
		break;
	case 0x50:
		/*     SOF = Start Of Frame    */
		sprintf( Title, "USB_ATTACHED_SS_WAIT_SOF\n");
		break;
	case 0x51:
		sprintf( Title, "USB_ATTACHED_SS_WAIT_RESET\n");
		break;
	case 0x60:
		sprintf( Title, "USB_ATTACHED_SS_GET_DEVICE_DESCRIPTOR_SIZE\n");
		break;
	case 0x70:
		sprintf( Title, "USB_STATE_ADDRESSING\n");
		break;
	case 0x80:
		sprintf( Title, "USB_STATE_CONFIGURING - 0x80\n");
		/*
		 * When the "CONFIGURING" state was reached USB::configuring() method was run, & setup the devConfig property/structure
		 */
		break;
	case 0x90:
		sprintf( Title, "USB_STATE_RUNNING - 0x90\n");
		running = true;
		break;
	case 0xa0:
		sprintf( Title, "USB_STATE_ERROR - 0xa0\n");
		USBinit = false;
		break;
	}
	tftmsgbx.dispMsg(Title, TFT_YELLOW);
}
////////////////////////////////////////////////////////////////////////////
void dispMsg(char Msgbuf[50], uint16_t Color) {
	tftmsgbx.dispMsg(Msgbuf, Color);
}

/////////////////////////////////////////////////////////////////////
/*
 * MAX3421E interrupt service routine
 * pin PA9 on Black Pill
 * */
void MAX3421INT(void){
	uint16_t INTcolor = TFT_BLUE;
	ShwINTRPinState();
	uint8_t HIRQRegval = Usb.regRd(0xc8); //read HIRQ register
//	uint8_t HIRQ = Usb.IntHandler();
	uint8_t USBIRQRegval = Usb.regRd(rUSBIRQ);
	uint8_t HIENQRegval = Usb.regRd(rHIEN);
	/* HIRQ|    7    |    6   |   5   |   4    |    3    |    2    |    1    |     0     |
	 *      HXFRDNIRQ FRAMEIRQ CONNIRQ SUSDNIRQ SNDBAVIRQ RCVDAVIRQ RSMREQIRQ BUSEVENTIRQ
	 */
//	tftmsgbx.dispMsg("HIRQ: ", INTcolor);
//	D_PrintBin(HIRQRegval, 0x80);//2nd parameter is print debug level; to print, debug level must be 0x80 or less; See file printhex.h
//	tftmsgbx.dispMsg("\n", INTcolor);
	if(USBIRQRegval&0b1){// if true OSC running IRQ is set
		/* Clear OSC IRQ */
		USBIRQRegval = USBIRQRegval & 0b11111110;
		Usb.regWr(rUSBIRQ, USBIRQRegval);
		USBIRQRegval = Usb.regRd(rUSBIRQ);
		sprintf( Title, "INT-Cleared OSC IRQ\n");
		tftmsgbx.dispMsg(Title, INTcolor);
	}
	if(HIENQRegval&0b1000000){// if true FrameIRQ enable is set
			/* Clear OSC IRQ */
			HIENQRegval = HIENQRegval & 0b10111111;
			Usb.regWr(rHIEN, HIENQRegval);
			HIENQRegval = Usb.regRd(rHIEN);
			sprintf( Title, "INT-Cleared FRAME IRQ\n");
			tftmsgbx.dispMsg(Title, INTcolor);
			HIRQRegval = Usb.regRd(0xc8);
			if(HIRQRegval & 0b1000000){
				HIRQRegval = HIRQRegval & 0b10111111;
				Usb.regWr(0xc8, HIRQRegval);
				HIRQRegval = Usb.regRd(0xc8);
			}

		}
	bool loop = true;
	while(loop){
		loop = false;
		bool ConDetect = true;
		int CurUSBstate = Usb.getUsbTaskState();
		if(HIRQRegval & bmCONDETIRQ){
			if(HIRQRegval== 0x69) Usb.regWr(0xc8, 0x69); //Write HIRQ register
			else Usb.regWr(0xc8, bmCONDETIRQ); //Write HIRQ register
			sprintf( Title,   "CONDETIRQ-");
		}else{
			ConDetect = false;
			sprintf( Title, "INT??-");
		}
		switch(CurUSBstate) {
		case 0x10:
			sprintf( Title, "%s USB_STATE_DETACHED\n", Title);
			break;
		case 0x11:
			sprintf( Title, "%s USB_DETACHED_SS_INITIALIZE\n", Title);
			break;
		case 0x12:
			sprintf( Title, "%s USB_DETACHED_SS_WAIT_FOR_DEVICE\n", Title);
			break;
		case 0x13:
			sprintf( Title, "%s USB_DETACHED_ILLEGAL\n", Title);
			if(bthid.connected) bthid.disconnect();
			USBinit = false;
			running = false;
			break;
		case 0x20:
			sprintf( Title, "%s USB_ATTACHED_SS_SETTLE\n", Title);
			running = true;
			break;
		case 0x30:
			sprintf( Title, "%s USB_ATTACHED_SS_RESET_DEVICE\n", Title);
			loop = true;
			break;
		case 0x40:
			sprintf( Title, "%s USB_ATTACHED_SS_WAIT_RESET_COMPLETE\n", Title);
			running = true;
			break;
		case 0x50:
			sprintf( Title, "%s USB_ATTACHED_SS_WAIT_SOF\n", Title);
			running = true;
			break;
		case 0x51:
			sprintf( Title, "%s USB_ATTACHED_SS_WAIT_RESET\n", Title);
			Usb.Task();
			loop = true;
			break;
		case 0x60:
			sprintf( Title, "%s USB_ATTACHED_SS_GET_DEVICE_DESCRIPTOR_SIZE\n", Title);
			running = true;
			break;
		case 0x70:
			sprintf( Title, "%s USB_STATE_ADDRESSING\n", Title);
			running = true;
			break;
		case 0x80:
			sprintf( Title, "%s USB_STATE_CONFIGURING - 0x80\n", Title);
			running = true;
			break;
		case 0x90:
			if(running){
				running = false;
				USBinit = false;
				if(bthid.connected) bthid.disconnect();
				Btd.Release();
				sprintf( Title, "%s USB_STATE_RUNNING - ReStart\n", Title);
			}
			else{
				sprintf( Title, "%s USB_STATE_RUNNING - Good\n", Title);
				running = true;
			}
			break;
		case 0xa0:
			sprintf( Title, "%s USB_STATE_ERROR - 0xa0\n", Title);
			USBinit = false;
			break;
		}
//		tftmsgbx.dispMsg(Title, INTcolor);
	} /* End while Loop */
//	ShwINTRPinState();
	return;
}
///////////////////////////////////////////////////////////////////////////
void ShwINTRPinState(void)
{
	uint16_t color;
	int Xpos = 10;
	int Ypos = 290;
	int Wdth = 30;
	int Hght = 30;
	uint8_t pinstate = Max.IntrState(); //If "0" interrupt pin is Low; i.e. Interrupt detected
	if(pinstate == LstIntrState) return;
	LstIntrState = pinstate;
	if(pinstate==1) color =TFT_GREEN;
	else color =TFT_RED;
	tft.fillRect(Xpos, Ypos, Wdth, Hght, color);
	if(color == TFT_RED) delay(25);
}

///////////////////////////////////////////////////////////////////////////
void ShwBlink(uint8_t tgl)
{
	uint16_t color;
	int Xpos = 50;
	int Ypos = 290;
	int Wdth = 30;
	int Hght = 30;
	if(tgl) color =TFT_BLACK;
	else color =TFT_BLUE;
	tft.fillRect(Xpos, Ypos, Wdth, Hght, color);
}
///////////////////////////////////////////////////////////////////////////

///* the following print via STM32F411 USB routines have largely been
// * replaced by Arduino like "Serial.print" functions*/
//
//void USBprintInt( int val){
//	char buf[15];
//	sprintf(buf, "%d", val);
//	USBprint(buf);
//}
///////////////////////////////////////////////////////////////////////
//void USBprintIntln( int val){
//	char buf[15];
//	sprintf(buf, "%d\n", val);
//	USBprintln(buf);
//}
///////////////////////////////////////////////////////////////////////
//void USBprintStr(String *msg){
//	char buf[150];
//	sprintf(buf, "%s", msg);
//	USBprint(buf);
//}
//
///////////////////////////////////////////////////////////////////////
//void USBprintln(const char *msg)
//{
//	char buf[150];
//	sprintf(buf, "%s\n", msg);
//	USBprint(buf);
//	return;
//}
//void USBprint(const char *msg)
//{
//	char buf[150];
//	uint8_t Buffer[150];
//	sprintf(buf, "%s", msg);
//	uint32_t BfLen = 150;
//	//while(USBD_Interface_fops_FS.TransmitCplt(BfLen,(uint8_t)1) != USBD_OK);
//	//while(USBD_Interface_fops_FS.TransmitCplt(hUsbDeviceFS->pbuf, &BfLen,(uint8_t)1) != USBD_OK);
//
//	int i = 0;
//	for(i = 0; i<=sizeof(buf); i++ ){
//		Buffer[i] = (uint8_t)buf[i];
//		if(buf[i] ==0) break;
//	}
//	int BsyCntr = 0;
//	/*setup guard rail to prevent USB err when trying to display title*/
//	bool tstState = false;
////	if(Test){
////		tstState = true;
////		Test = false;
////	}
//
//	uint8_t USBstat = USBD_BUSY;
//	while(USBstat != USBD_OK){
//		USBstat = CDC_Transmit_FS(Buffer, i);
//		BsyCntr++;
//		if(BsyCntr >10) break;
//	}
//	if(0){ /*Set to "1" when debugging USB serial print*/
//		switch (USBstat){
//		case USBD_BUSY:
//			sprintf(buf, "#USB BUSY# - %s", msg);
//			tftmsgbx.dispMsg(buf, TFT_WHITE);
//			break;
//		case USBD_FAIL:
//			sprintf(buf, "#USB FAIL# - %s", msg);
//			tftmsgbx.dispMsg(buf, TFT_WHITE);
//			break;
//		}
//	}
////	if(tstState) Test = true;
//	return;
//}

///////////////////////////////////////////////////////////////////////////////////////////////
//20210206 JMH Added "delay_us" function to provide a us delay via STM32CubeIDE platform
void delay_us (uint16_t us)
{
	__HAL_TIM_SET_COUNTER(&htim3,0);  // set the counter value a 0
	while (__HAL_TIM_GET_COUNTER(&htim3) < us);  // wait for the counter to reach the us input in the parameter
}
///////////////////////////////////////////////////////////////////////////////////////////////

/* Begin Standard STM32F411 / STMCUBEIDE startup/initialize routines */

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */
  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_84CYCLES;
  //sConfig.SamplingTime = ADC_SAMPLETIME_112CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
//  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;//use this with WS2812B library
//  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;//use this with USBhost library
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
void MX_TIM2_Init(void)
{

	/* USER CODE BEGIN TIM2_Init 0 */

	/* USER CODE END TIM2_Init 0 */

	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_MasterConfigTypeDef sMasterConfig = {0};

	/* USER CODE BEGIN TIM2_Init 1 */

	/* USER CODE END TIM2_Init 1 */
	htim2.Instance = TIM2;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	/* setup for a clock interrupt period = ~20 milliseconds */
	htim2.Init.Prescaler = 960-1;// =>100Khz clock
	htim2.Init.Period = 2000;//=> interrupt interval = 20ms
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
	{
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}
	/* USER CODE BEGIN TIM2_Init 2 */

	/* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 96-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}
/* Timer 5 is the "DOT clock" (this interrupt executes at the rate of the
*  Dot interval for the current WPM setting  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  /* Setup for 1ms interrupt */
  htim5.Init.Prescaler = 96-1; // 1 microsecond period or 1Mhz clock
  htim5.Init.Period = 1000000;// peroid = 1,000,000 => 1 second interrupt interval
  htim5.Init.Period = 80000; // period = 80ms (15WPM)
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin | TONE_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin|MAX3421SS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_D3_Pin|DMA_Evnt_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin | TONE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_D0_Pin LCD_D1_Pin LCD_D2_Pin LCD_D4_Pin
                           LCD_D5_Pin LCD_D6_Pin LCD_D7_Pin */
  GPIO_InitStruct.Pin = LCD_D0_Pin|LCD_D1_Pin|LCD_D2_Pin|LCD_D4_Pin
                          |LCD_D5_Pin|LCD_D6_Pin|LCD_D7_Pin|MAX3421SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_D3_Pin DMA_Evnt_Pin LCD_RD_Pin LCD_WR_Pin
                           LCD_RS_Pin LCD_CS_Pin LCD_RST_Pin */
  GPIO_InitStruct.Pin = LCD_D3_Pin|DMA_Evnt_Pin|LCD_RD_Pin|LCD_WR_Pin
                          |LCD_RS_Pin|LCD_CS_Pin|LCD_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : KeyIn_EXT13_Pin */
  GPIO_InitStruct.Pin = KeyIn_EXT13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(KeyIn_EXT13_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : MAX3421INT_Pin */
  GPIO_InitStruct.Pin = MAX3421INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(MAX3421INT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : MAX3421INT_Pin */
  GPIO_InitStruct.Pin = MAX3421INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(MAX3421INT_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init This sets up MAX3421 interrupt*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 8, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */
// Called when first half of buffer is filled
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc) {
//	int k;
//	if(Ready){
//		Ready = !Ready;
////		ResetGoertzel();
//		if(!LongSmplFlg){// ~4ms sample interval
//			for(int i = 0 ; i < Hstop; i++){
//				k = (adc_buf[i] - BIAS);
////				ProcessSample(k, i);
//			}
////			ComputeMags();
//		}else{// ~8ms sample interval
//			for(int i = 0 ; i < Hstop; i++){
//				k = (adc_buf[i] - BIAS);
////				ProcessSample(k, i);
//			}
//			Ready = true;
//		}
//	}
}

// Called when buffer is completely filled
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc) {
//	int k;
//	if(Ready){
//		Ready = !Ready;
//		int LastSmpl = 2*Hstop;//
//		if(!LongSmplFlg){ //~4ms sample interval
////			ResetGoertzel();
//			for(int i = Hstop; i < LastSmpl; i++){
//				k = (adc_buf[i] - BIAS);
////				ProcessSample(k, i-Hstop);
//			}
//
//		}else{// ~8ms sample interval
//			for(int i = Hstop; i <= LastSmpl; i++){
//				k = (adc_buf[i] - BIAS);
////				ProcessSample(k, i);
//			}
//
//		}
////		ComputeMags();
//	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	char StatMsg[30];
	int IntState =0;
	if(htim->Instance == TIM2) IntState = 2;
	else if(htim->Instance == TIM5) IntState = 5;
	switch (IntState){
	case 2:
		ShwINTRPinState();
		tftmsgbx.dispMsg2();
		Status = Btd.GetStatus();
		//tftmsgbx.dispStat(StatMsg, TFT_WHITE);
		tim2IntrCnt++;
		if(tim2IntrCnt<25) break;
		if(StatusOLD != Status){// only print/update status line if there's a change
			StatusOLD = Status;
			Btd.Rtn_StateStr((uint8_t)Status, StatMsg);//  .Rtn_StateStr((uint8_t)State, &StatMsg);
			uint16_t color;
			switch (StatusOLD){
			case 0x15: //"HCI event error"
				color = TFT_RED;
				//running = false;
				break;
			case 0x1A: //"Device Disconnected"
				color = TFT_YELLOW;
				break;
			case 0x11: //"Paired"
				color = TFT_GREEN;
				break;
			case 0x10: //"HID Paired"
				color = TFT_GREEN;
				break;
			case 0x0B: //"Disconnected"
				color = TFT_YELLOW;
				break;
			case 0x1C: //"Restart- No Device Found"
				//				running = false;
				//				if(bthid.connected) bthid.disconnect();
				//				Btd.Release();
				color = TFT_RED;
				break;
			case 0x1D:  //"Authentication failure"
				running = false;
				color = TFT_RED;
				break;
			case 0x20:  //"Reset No Response"
				//				running = false;
				color = TFT_RED;
				break;
			case 0x0E: //"Enter PIN"
				color = TFT_WHITE;
				sprintf(StatMsg, "%s: %s", StatMsg, Btd.btdPin);
				break;
			default:
				color = TFT_WHITE;
			}
			sprintf(StatMsg, "%s S:%d; E:%d", StatMsg, Btd.GetState(), Btd.GetEvent());
			tftmsgbx.dispStat(StatMsg, color);
		}
		if(waitFlg)waitFlg = false;
		tim2IntrCnt = 0;
		toggle ^= 1; //exclusive OR
		ShwBlink(toggle);
		break;
		/*Timer 5 is the "DOT clock" (this interrupt executes at the rate of the
		 * dot interval for the current WPM setting  */
	case 5:
		//if(htim->Instance == TIM5){
		int state = CWsndengn.Intr();//check CW send Engine & process as code as needed
		tftmsgbx.IntrCrsr(state);//Set Display Box CW Send Cursor as needed
		break;
		//}
	}
}

/**
  * @brief This function handles EXTI line[15:10] interrupts.
  */
//void EXTI15_10_IRQHandler(void)
//{
//  /* USER CODE BEGIN EXTI15_10_IRQn 0 */
//
//  /* USER CODE END EXTI15_10_IRQn 0 */
//  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
//  /* USER CODE BEGIN EXTI15_10_IRQn 1 */
//  //KeyEvntSR();
//  /* USER CODE END EXTI15_10_IRQn 1 */
//}


///////////////////////////////////////////////////////////////////////////////////////////////


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  int i = 9;
  int j = 0;
  while (1)
  {
	  j = i;
	  i = j;
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
